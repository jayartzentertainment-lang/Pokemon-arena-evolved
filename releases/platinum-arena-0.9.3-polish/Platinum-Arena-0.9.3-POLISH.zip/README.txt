PLATINUM ARENA 0.9.3 - POLISH DEMO

HOW TO PLAY
1. Unzip this download.
2. Open Platinum-Arena-0.9.3-POLISH.nds in your Nintendo DS emulator
   (for example, melonDS or DeSmuME). Open the .nds file, not the ZIP.
3. Start New Game. Choose your character and follow Platinum's story.
4. Use the game's Save menu before closing the emulator. Keep the emulator's
   save file beside the game or in its configured save folder.

This is a new Platinum game, separate from Emerald Arena. Emerald/Arena Plus
DS saves cannot be transferred. Keep a backup before testing future builds.
To continue a Platinum Arena preview save, use your emulator's Import Save
option or copy its .sav/.dsv under the new ROM's matching filename. Preserve
the original save first; save states are not a substitute for an in-game save.
The file is 256 MiB; the extra directional animation sets need more ROM
storage. Only active fighters' animations are loaded into DS memory.

PRACTICE MODE
Hold L+R+Select on the title screen to open the battle test menu.
Choose Pokemon, arena, level and 1v1 or 2v2. Practice uses separate teams
and does not change your story save. B returns to the native main menu.

LIVE BATTLE CONTROLS (NINTENDO DS BUTTONS)
D-pad: move and aim
Y: normal strike
A: selected move
X: next move, without changing your selection
L: cycle selected move
R: reserved; no standalone action
B + direction: dash
Hold B without a direction: shield until release or stamina exhaustion
Select: toggle aim lock
Start: pause; switch Pokemon, use medicine or try to run

Your emulator lets you map these DS buttons to keyboard/controller buttons.
The field/story menus keep their original Platinum controls.
The live battle pause menu also offers control remapping. These mappings
remain active until the ROM restarts; they are not stored in the story save.

CATCHING
Hold L+R to aim; use the D-pad, then release either shoulder to throw.
B cancels before throwing. Carry ordinary Poke Balls in your bag.
In a wild double battle, reduce the opposing team to one Pokemon first.
Caught Pokemon go to your real party or PC.

COMBAT AND APPEARANCE
Normal strikes use no stamina. Special moves spend PP. Dash and sustained
guard use stamina, which refills after a delay. Strong moves can chip through
guard. Opposing beams can clash. Double battles include an AI teammate.
EXP, level-ups, rewards and evolution connect to your native Platinum party.
The new-game creator offers Lucas, Dawn, Brendan, May, Red or Leaf, with skin, hair-color
and outfit-color choices. Arbitrary haircuts/clothing shapes are not included.

PLEASE EXPECT AN EARLY BUILD
The original Platinum story/maps remain, but the full campaign and real DS
hardware have not been validated. Some moves use simplified action behavior;
full abilities, weather and complex held-item rules are incomplete.
493 canonical species use directional animations. Extra
alternate forms may use native front/back battle images. Artist credits and
pinned source manifests are included in the credits folder.
Link, Frontier, Safari, Pal Park, tutorial and recorded battles keep the
original Platinum battle engine. Action catching currently uses ordinary
Poke Balls and skips the native nickname/Pokedex-detail screens.

TESTED IN THIS EXACT ROM
- Full modified256MiB ROM build and overlay/DMA layout audit.
- All493 directional asset identities,138528frames and unchanged worst-four pose-memory bound.
- Core combat, held shields/chip/clashes/criticals, native party/capture/rewards and navigation sanitizer regressions.
- Six-base creator host/legacy-save checks; Lucas/Brendan/Red and Leaf previews verified in this ROM.
- Battle Lab1v1 and new effects/shield rendering in this ROM.

OTHER UNTESTED OR LIMITED AREAS RECORDED FOR THIS ROM
- Full campaign, real DS hardware and long sessions.
- All female creator states, complex move scripts, full abilities/weather/held-item rules.
- Complete tag/NPC partner battle coverage.
- The finalD native story battle/return/save replay remains pending; previewA passed these checks.

If you find a bug, record the area, Pokemon/moves, buttons pressed and what
happened. A screenshot or short video plus your emulator name is helpful.
The included RELEASE.json records the exact tested ROM SHA256.
Source-art attributions and license notices are retained in the credits folder.

NEW EFFECTS
Includes selected fire/water/electric/ice, hit, guard and clash frames from
your three new effect packs. Menu cursors/control labels are corrected.

This is a demo for your playtesting. Pending checks remain marked pending in
RELEASE.json; the unchanged native story path was previously tested in preview A.
