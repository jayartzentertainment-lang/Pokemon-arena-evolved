# Supplied action effects

The 0.9.3 native effect atlas cuts and converts selected artwork from the three sprite archives supplied by the user. All 56 frames are shown in contact.png. Source files are retained under source/ and SHA256 hashes are recorded in manifest.json and archives.json.

- Pokémon Mystery Dungeon: Explorers of Sky (Nintendo DS): fire burst, water puff, electrical burst, ice shards.
- Pokémon Ranger: Guardian Signs (Nintendo DS): expanding ring sequence used as shield feedback. Its variable-height cells are cut separately; magenta sheet registration dots are removed.
- The King of Fighters XI (PlayStation 2): strike impact and blue burst sequences used for hit/clash feedback.

These labels describe the visually selected animations; the numbered ripped source directories do not establish move IDs. The ZIP files contain no author/readme/license notices. This folder records provenance and does not grant rights to the underlying game artwork. Original game artwork belongs to its respective creators and rights holders (Nintendo/The Pokémon Company/Chunsoft for Pokémon; SNK for The King of Fighters).

Regenerate from the retained subset with `python3 tools/arena/import_extra_effects.py`. It reserves alpha at palette index0, applies one shared15color palette, preserves sequence alignment and uses nearest-neighbor resizing into 32×32 sprites. The atlas occupies28672 bytes of OBJ VRAM and requires no per-frame filesystem access or extra heap pose cache.
