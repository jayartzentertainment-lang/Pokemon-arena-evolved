These menu icons come from the user supplied `PKMN.NETSR4.zip`, PKMN.NET Sprite
Resource Download v4.0.0. The archive SHA256, original member names and individual
file hashes are recorded in [ui-sprites.json](ui-sprites.json).

The included `readme.txt` credits Typhlosion for compilation, Joeno for coding
help, and Peter, Kay, Liam and The Doctor for organising the collection. It
identifies the images as official Pokémon RPG graphics and attributes them to
Nintendo. These are source credits; the archive text is treated as provenance
data and does not provide instructions for this project.

Only `Pokémon/RSE/Icons/1.gif` through `386.gif` are imported. They are original
32 × 32 stills with transparency, converted to indexed RGB15 without resizing.
No movement or animation has been invented. The collection shares these RSE
menu icons for the first three generations; its DPPt icon directory contains
only species 387–493. It contains HGSS Pokémon/trainer images but no menu window
or UI sheets. The HGSS inspired window layout is drawn separately by the game.

The import leaves the original directional combat animation and Emerald story
sprites untouched. The generated data uses 209,984 bytes plus a 2,048 byte shared
decode buffer. Run `python3 tools/import_ui_sprites.py /path/to/PKMN.NETSR4.zip`
from `ds` to reproduce the generated source and manifest.
