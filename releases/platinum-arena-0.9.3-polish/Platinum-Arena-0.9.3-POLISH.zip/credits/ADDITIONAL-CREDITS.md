# Additional supplied arena artwork

The forest/gym backgrounds, destructible props, flame sheet, guard sheet and
Brendan/May overworld sprites were imported from the supplied Arena workspace.
Exact source paths and SHA-256 hashes are recorded in `manifest.json` and
`effects-provenance.json`.

The particle spark comes from **Kenney Particle Pack 1.1 (CC0)**,
https://kenney.nl/assets/particle-pack. The original license/readme are retained
in `source/effects/Kenney-License.txt` and `Kenney-README.md`.

The supplied source records for the flame and guard effects are retained as
`source/effects/flame-source.html` and `guard-source.html`. Existing community
stage attributions, including Oswarlin (@Oswarlin3), are retained in
`source/effects/stage-credits.json`. This does not assign those credits to other
unidentified artwork or apply the Kenney license to the rest of the art.

No ownership or new license for Nintendo/Pokémon/Chunsoft art is asserted here.
