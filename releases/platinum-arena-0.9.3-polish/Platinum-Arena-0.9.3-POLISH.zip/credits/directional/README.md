This extension supplies the 199 canonical Pokémon that were static fallbacks in the 0.9.2 demo. Together with the 187 unchanged supplied Arena sets and the 107 unchanged Gen IV sets, all 493 canonical species now have genuine eight-direction idle, walk and attack animation data. The 64 alternate forms still use their correctly identified native Platinum front/back portraits.

Artwork comes from PMDCollab/SpriteCollab pinned at commit `d25607ff4746957df10bdb78db090887cd94f1f8`. Source files, original per-species artist credits and hashes are retained under `source/`. `manifest.json` records every output animation, timing, palette, per-species memory use and transformation. `LICENSE.md` contains the source license.

Each source direction is preserved. Species whose full source animation does not fit a 64-pixel sprite cell or the 150 KiB pose-cache limit receive one consistent integer nearest-neighbour reduction across every pose and direction. Runtime display scaling compensates for that reduction. Recorded edge translations retain lunging frames within the native cell. No missing artwork or frames are fabricated.

Rebuild only this extension and the combined species pack:

```sh
python3 tools/arena/compile_gen4.py --source res/arena/directional/source --cache-limit 153600 --pack-name directional.pack
python3 tools/arena/generate_assets.py --species-only --arena /path/to/accepted/ds
python3 tools/arena/validate_assets.py --arena /path/to/accepted/ds
```

Optional pinned-source refresh reuses the saved species selection:

```sh
python3 tools/arena/fetch_gen4.py --output res/arena/directional/source --dex-manifest res/arena/directional/source/download-manifest.json
```

Regular ROM builds read the staged combined pack without network access. `--species-only` preserves independently edited effects and backgrounds. The validator enforces the original 640,824-byte ceiling for the four largest distinct pose caches and checks that the 187 supplied directional records and pack bytes remain identical.
