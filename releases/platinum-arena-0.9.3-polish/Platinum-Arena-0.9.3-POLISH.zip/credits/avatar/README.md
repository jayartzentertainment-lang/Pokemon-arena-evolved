# Regional trainer artwork

The creator contains Lucas/Dawn from the native Platinum resources,
Brendan/May from the supplied Emerald source, and Red/Leaf from the retained
FireRed source files. The underlying Pokémon game artwork is credited to
Nintendo, Game Freak and The Pokémon Company. Source-code repository licenses
do not constitute a blanket license for the game artwork.

The FireRed files are pinned to `pret/pokefirered` revision
`037335f4c725d7c9aecdac87066f2002b4bd7e14`. The retained
`kanto-source/manifest.json` lists original paths, file sizes and SHA256 hashes.
`provenance.json` identifies every imported image and palette and the final
66-entry avatar pack. Leaf is called `green` in FireRed's overworld files.

The importer adapts GBA frames to Platinum's existing texture dimensions,
native direction order, frame timing and shared-frame aliases. Special DS
device gestures use the matching regional idle or field-move poses, and
contest states retain the regional clothing. These adaptations and palette
quantization are listed explicitly in the pack provenance.

For more complete source sheets, visit:

- https://github.com/pret/pokeplatinum/tree/main/res/graphics/field_sprites/player
- https://github.com/pret/pokefirered/tree/master/graphics/object_events/pics/people
- https://github.com/pret/pokeheartgold

Download all poses and the palette for a character together. A portrait alone
does not supply directional walking, running, riding and field-action frames.
