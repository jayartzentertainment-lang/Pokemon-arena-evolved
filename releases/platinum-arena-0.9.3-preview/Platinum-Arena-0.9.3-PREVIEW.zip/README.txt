PLATINUM ARENA 0.9.3 PREVIEW

Unzip this download, then open Platinum-Arena-0.9.3-PREVIEW.nds in your DS emulator.
The ROM is 256 MiB. The ZIP is smaller because the ROM contains padding.

This is the exact new build requested during testing. Emulator playtesting is
still in progress. Preserve a backup of your existing save before trying it.

Included changes: directional animations for all493 canonical Pokemon,
stationary small character previews, corrected regional sprite directions,
Red/Leaf creator bases, Battle Lab, larger arena, decorated battle UI,
sustained shields, heavy-move guard chip, beam clashes and move sound cues.
The newly uploaded extra effect packs are not integrated in this preview.
Some alternate forms still use native still images. Full campaign and real
DS hardware have not been verified. The native sendout-to-action handoff is
new in this build and still needs runtime validation.

At the title screen, hold L+R+Select to open Battle Lab for1v1/2v2 tests.
D-pad move; Y strike; A selected move; X next move; L cycle; R reserved;
hold B stationary to shield, B+direction to dodge; Select aim; Start pause.
Controls can be changed in the Lab or battle pause menu until ROM restart.
Practice teams are separate from the story save.

ROM SHA256: 1413f0c56a23338ff6d2af198fcad7987db2bafa38f11ae9372301ece148df23
