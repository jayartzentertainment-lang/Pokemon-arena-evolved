#!/usr/bin/env python3
"""Exercise production recoloring against every complete native player rig palette."""
import ctypes
from pathlib import Path
import subprocess
import tempfile
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]

class Profile(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint8) for name in ("body", "skin", "hair", "outfit", "regional")]

with tempfile.TemporaryDirectory(prefix="platinum-avatar-assets-") as temporary:
    library = Path(temporary) / "avatar.so"
    subprocess.run(["cc", "-std=c99", "-Wall", "-Wextra", "-Werror", "-shared", "-fPIC",
                    "-DARENA_AVATAR_HOST", "-I" + str(ROOT / "include"),
                    str(ROOT / "src/arena/avatar.c"), "-o", str(library)], check=True)
    native = ctypes.CDLL(str(library))
    native.ArenaAvatar_ApplyPalette.argtypes = [ctypes.POINTER(Profile), ctypes.POINTER(ctypes.c_uint16), ctypes.c_int]
    checked = 0
    for image_path in sorted((ROOT / "res/graphics/field_sprites/player").glob("*.png")):
        body = int("player_f" in image_path.name)
        image = Image.open(image_path)
        palette = image.getpalette()
        used = [index for _, index in image.getcolors()]
        values = [sum((palette[index * 3 + channel] >> 3) << (channel * 5) for channel in range(3)) for index in used]
        for feature in ("skin", "hair", "outfit"):
            profile = Profile(body, 0, 0, 0)
            setattr(profile, feature, 1)
            output = (ctypes.c_uint16 * len(values))(*values)
            native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), output, len(values))
            assert list(output) != values, (image_path.name, feature, "no visible customization")
            checked += 1
        # Original palettes and each chosen palette survive repeated cache uploads.
        for skin in range(4):
            for hair in range(6):
                for outfit in range(8):
                    profile = Profile(body, skin, hair, outfit)
                    output = (ctypes.c_uint16 * len(values))(*values)
                    native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), output, len(values))
                    first = list(output)
                    if skin == hair == outfit == 0:
                        assert first == values
                    native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), output, len(values))
                    assert list(output) == first, (image_path.name, skin, hair, outfit, "cache recolor drift")
                    checked += 1
    print(f"Native avatar asset palettes: {checked} original, feature and cache-stability checks passed")
