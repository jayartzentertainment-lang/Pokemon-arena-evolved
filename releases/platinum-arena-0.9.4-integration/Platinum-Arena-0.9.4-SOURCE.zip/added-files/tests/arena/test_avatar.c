#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "arena/avatar.h"

#define RGB5(r,g,b) ((u16)((r)|((g)<<5)|((b)<<10)))

static int equal(const ArenaAvatarProfile *a, const ArenaAvatarProfile *b)
{
    return !memcmp(a, b, sizeof(*a));
}

/* The shipped 0.9.2 record uses ten payload bits and a CRC6. Build its
 * bytes independently so backward compatibility is not tested by writing
 * another new-format record and then reading it again. */
static void legacy_record(u8 *save, const ArenaAvatarProfile *profile)
{
    unsigned bit, crc = 0x35;
    u16 value = profile->body | (profile->skin << 1) | (profile->hair << 3)
        | (profile->outfit << 6) | (profile->regional << 9);
    for (bit = 0; bit < 10; bit++) {
        unsigned feedback = ((crc >> 5) ^ (value >> bit)) & 1;
        crc = ((crc << 1) & 63) ^ (feedback ? 0x27 : 0);
    }
    value |= crc << 10;
    save[2] = 2; save[3] = 0xa9;
    save[42] = value & 255; save[43] = value >> 8;
}

int main(void)
{
    unsigned body, skin, hair, outfit, regional, byte, bit, count = 0, legacyCount = 0;
    for (regional = 0; regional < ARENA_AVATAR_REGION_COUNT; regional++) {
    for (body = 0; body < 2; body++) {
        for (skin = 0; skin < ARENA_AVATAR_SKIN_COUNT; skin++) {
            for (hair = 0; hair < ARENA_AVATAR_HAIR_COUNT; hair++) {
                for (outfit = 0; outfit < ARENA_AVATAR_OUTFIT_COUNT; outfit++) {
                    u8 save[ARENA_AVATAR_PLAYER_SAVE_BYTES];
                    u8 before[ARENA_AVATAR_PLAYER_SAVE_BYTES];
                    ArenaAvatarProfile expected = {body, skin, hair, outfit, regional};
                    ArenaAvatarProfile actual;
                    ArenaAvatarProfile defaults;
                    u16 colors[] = {RGB5(31,26,23), RGB5(27,20,15), RGB5(7,8,10), RGB5(7,12,17), RGB5(23,7,9), RGB5(27,13,15), 0x8000, 0x7fff};
                    u16 once[sizeof(colors)/sizeof(*colors)];
                    for (byte = 0; byte < sizeof(save); byte++) save[byte] = (u8)(byte * 13u + 17);
                    memcpy(before, save, sizeof(save));
                    ArenaAvatar_WriteRecord(save, &expected);
                    for (byte = 0; byte < sizeof(save); byte++) {
                        if (byte != 2 && byte != 3 && byte != 42 && byte != 43) assert(save[byte] == before[byte]);
                    }
                    ArenaAvatar_ReadRecord(save, body, &actual);
                    assert(equal(&expected, &actual));
                    if (regional < 2) {
                        u8 legacy[ARENA_AVATAR_PLAYER_SAVE_BYTES] = {0};
                        legacy_record(legacy, &expected);
                        ArenaAvatar_ReadRecord(legacy, body, &actual);
                        assert(equal(&expected, &actual));
                        legacyCount++;
                    }
                    ArenaAvatar_Default(&defaults, body);
                    /* A one-bit record corruption must always choose the safe native default. */
                    for (byte = 0; byte < 4; byte++) {
                        unsigned idx = byte < 2 ? byte + 2 : byte + 40;
                        for (bit = 0; bit < 8; bit++) {
                            save[idx] ^= 1u << bit;
                            ArenaAvatar_ReadRecord(save, body, &actual);
                            assert(equal(&defaults, &actual));
                            save[idx] ^= 1u << bit;
                        }
                    }
                    ArenaAvatar_ApplyPalette(&expected, colors, sizeof(colors)/sizeof(*colors));
                    if (!regional) assert(colors[6] == 0x8000 && colors[7] == 0x7fff);
                    memcpy(once, colors, sizeof(colors));
                    ArenaAvatar_ApplyPalette(&expected, colors, sizeof(colors)/sizeof(*colors));
                    assert(!memcmp(once, colors, sizeof(colors)));
                    count++;
                }
            }
        }
    }
    }
    {
        u8 legacy[ARENA_AVATAR_PLAYER_SAVE_BYTES] = {0};
        ArenaAvatarProfile actual;
        ArenaAvatarProfile expected;
        ArenaAvatar_Default(&expected, 1);
        ArenaAvatar_ReadRecord(legacy, 1, &actual);
        assert(equal(&expected, &actual));
        legacy[2] = 1; legacy[3] = 0xa8; /* unsupported older/newer version */
        ArenaAvatar_ReadRecord(legacy, 1, &actual);
        assert(equal(&expected, &actual));
        ArenaAvatar_Default(&actual, 0); actual.hair = ARENA_AVATAR_HAIR_COUNT;
        memcpy(legacy, "01234567890123456789012345678901234567890123", sizeof(legacy));
        {u8 before[sizeof(legacy)]; memcpy(before,legacy,sizeof(legacy)); ArenaAvatar_WriteRecord(legacy,&actual); assert(!memcmp(before,legacy,sizeof(legacy)));}
    }
    printf("Avatar: %u profiles, %u legacy records, byte isolation, all single-bit corruption checks and palette stability pass\n", count, legacyCount);
    return 0;
}
