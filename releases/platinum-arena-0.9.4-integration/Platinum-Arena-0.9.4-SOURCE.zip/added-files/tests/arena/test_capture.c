/* Real live-capture controller, party transfer and action combat. The native
 * rewards/bag/storage boundary is mocked; native RNG odds are not re-tested. */
#include "arena/capture.h"
#include "arena/rewards.h"
#include "arena/vendor/arena_navigation.h"
#include "constants/items.h"
#include "pokemon.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#define Q 256
#define SHOULDERS (PAD_BUTTON_L|PAD_BUTTON_R)
static ArenaCapture capture;
static ArenaPartyBridge bridge;
static Combat combat;
static Party parties[4];
static FieldBattleDTO dto;
static unsigned balls,pcCount,capacity,consumeCalls,shakeCalls,catchCalls,awards,defeats;
static unsigned storeCalls,event,lastStore,consumeEvent,shakeEvent;
static unsigned shakePaidSerial,catchPaidSerial;
static unsigned expectedOwner,expectedSlot,returnedShakes,result;
static BOOL allowThrow,allowConsume,allowAward,paidBall;
static Pokemon caughtMon;
static CombatInput lastInput;

int Party_GetCurrentCount(const Party *p){return p->count;}
Pokemon *Party_GetPokemonBySlotIndex(const Party *p,int slot)
{assert(slot>=0&&slot<p->count);return (Pokemon *)&p->mon[slot];}
u32 Pokemon_GetValue(Pokemon *p,enum PokemonDataParam param,void *dest)
{(void)dest;assert((unsigned)param<180);return p->data[param];}
void Pokemon_SetValue(Pokemon *p,enum PokemonDataParam param,const void *value)
{
    if(param==MON_DATA_HP)p->data[param]=*(const u16 *)value;
    else {assert(param>=MON_DATA_MOVE1_PP&&param<=MON_DATA_MOVE4_PP);p->data[param]=*(const u8 *)value;}
}
void __real_ArenaParty_Store(ArenaPartyBridge *);
void __wrap_ArenaParty_Store(ArenaPartyBridge *p)
{assert(p==&bridge);storeCalls++;lastStore=++event;__real_ArenaParty_Store(p);}
static void Defeat(void *context,unsigned actor,unsigned owner,unsigned slot,Pokemon *mon,u32 mask)
{(void)context;(void)actor;(void)owner;(void)slot;(void)mon;(void)mask;defeats++;}

BOOL ArenaRewards_CanThrow(FieldBattleDTO *p)
{
    assert(p==&dto);
    return allowThrow&&balls&&(!(p->battleType&BATTLE_TYPE_TRAINER))
        &&((unsigned)parties[0].count<MAX_PARTY_SIZE||pcCount<capacity);
}
BOOL ArenaRewards_ConsumeBall(FieldBattleDTO *p,int ball)
{
    assert(p==&dto&&ball==ITEM_POKE_BALL);consumeCalls++;
    if(!allowConsume||!ArenaRewards_CanThrow(p))return FALSE;
    paidBall=TRUE;balls--;consumeEvent=++event;return TRUE;
}
int ArenaRewards_CatchShakes(FieldBattleDTO *p,int owner,int slot,int ball,u32 *rng)
{
    assert(p==&dto&&ball==ITEM_POKE_BALL&&paidBall&&rng==&capture.random);
    assert((unsigned)owner==expectedOwner&&(unsigned)slot==expectedSlot);
    assert(storeCalls&&lastStore>consumeEvent);shakeEvent=++event;
    Pokemon *mon=&parties[owner].mon[slot];
    unsigned actor=capture.target;
    assert(mon->data[MON_DATA_HP]==(combat.fighters[actor].hp+7u)/8u);
    assert(mon->data[MON_DATA_MOVE1_PP]==combat.fighters[actor].pp[0]);
    assert(shakePaidSerial!=consumeCalls);shakePaidSerial=consumeCalls;shakeCalls++;
    *rng=*rng*0x41C64E6Du+0x6073u;
    return returnedShakes;
}
BOOL ArenaRewards_Catch(FieldBattleDTO *p,int owner,int slot,int ball)
{
    assert(p==&dto&&ball==ITEM_POKE_BALL&&paidBall);
    assert((unsigned)owner==expectedOwner&&(unsigned)slot==expectedSlot);
    assert(shakePaidSerial==consumeCalls&&returnedShakes==4&&lastStore>shakeEvent);
    assert(catchPaidSerial!=consumeCalls);catchPaidSerial=consumeCalls;catchCalls++;
    if(!allowAward)return FALSE;
    /* Throw-time capacity was checked before payment; the last ball may be 0. */
    if((unsigned)parties[0].count==MAX_PARTY_SIZE&&pcCount==capacity)return FALSE;
    caughtMon=parties[owner].mon[slot];
    if((unsigned)parties[0].count<MAX_PARTY_SIZE)parties[0].mon[parties[0].count++]=caughtMon;
    else pcCount++;
    paidBall=FALSE;awards++;result=4;return TRUE;
}

/* Match the native session's physical key adapter. Capture consumes raw Nitro
 * bits, while the simulation's older command names are intentionally stable. */
static CombatInput Map(u32 held,u32 pressed)
{
    CombatInput input={0,0};
    static const u16 native[]={PAD_KEY_UP,PAD_KEY_DOWN,PAD_KEY_LEFT,PAD_KEY_RIGHT,
        PAD_BUTTON_A,PAD_BUTTON_B,PAD_BUTTON_Y,PAD_BUTTON_SELECT,PAD_BUTTON_L,PAD_BUTTON_X};
    static const u16 command[]={COMBAT_UP,COMBAT_DOWN,COMBAT_LEFT,COMBAT_RIGHT,
        COMBAT_A,COMBAT_B,COMBAT_X,COMBAT_Y,COMBAT_R,COMBAT_ALT};
    for(unsigned i=0;i<sizeof(native)/sizeof(native[0]);i++) {
        if(held&native[i])input.held|=command[i];
        if(pressed&native[i])input.pressed|=command[i];
    }
    return input;
}
static BOOL Step(u32 held,u32 pressed)
{
    CombatInput input=Map(held,pressed);
    BOOL tick=ArenaCapture_Process(&capture,held,pressed,&input);
    lastInput=input;if(tick)Combat_Tick(&combat,input);
    return tick;
}
static void Advance(unsigned frames){while(frames--)Step(0,0);}
static void Until(unsigned phase,unsigned limit)
{while(capture.phase!=phase&&limit--)Step(0,0);assert(capture.phase==phase);}
static void Mon(unsigned owner,unsigned slot)
{
    Pokemon *p=&parties[owner].mon[slot];parties[owner].count=slot+1;
    p->data[MON_DATA_SPECIES]=390+owner*5+slot;p->data[MON_DATA_HP]=20;
    p->data[MON_DATA_MAX_HP]=25;p->data[MON_DATA_LEVEL]=5;
    p->data[MON_DATA_ATK]=p->data[MON_DATA_DEF]=20;
    p->data[MON_DATA_SP_ATK]=p->data[MON_DATA_SP_DEF]=20;
    p->data[MON_DATA_SPEED]=40;p->data[MON_DATA_TYPE_1]=10;p->data[MON_DATA_TYPE_2]=10;
    p->data[MON_DATA_MOVE1]=52;p->data[MON_DATA_MOVE2]=10;
    p->data[MON_DATA_MOVE1_PP]=17;p->data[MON_DATA_MOVE2_PP]=20;
    p->data[MON_DATA_EXPERIENCE]=135;
}
static void Place(unsigned actor,int x,int y)
{combat.fighters[actor].x=combat.fighters[actor].previousX=x*Q;combat.fighters[actor].y=combat.fighters[actor].previousY=y*Q;}
static void Reset(unsigned type,unsigned players,unsigned enemies)
{
    memset(parties,0,sizeof(parties));memset(&dto,0,sizeof(dto));dto.battleType=type;
    for(unsigned i=0;i<4;i++)dto.parties[i]=&parties[i];
    for(unsigned i=0;i<players;i++)Mon(0,i);
    for(unsigned i=0;i<enemies;i++)Mon(1,i);
    if(type&BATTLE_TYPE_2vs2){Mon(2,0);Mon(3,0);}
    assert(ArenaParty_Begin(&bridge,&dto,&combat));combat.aiEnabled=0;
    ArenaParty_SetDefeatCallback(&bridge,Defeat,0);
    for(unsigned i=0;i<ARENA_OBSTACLES;i++)ArenaNav_SetObstacle(i,0);
    Place(0,70,100);Place(1,150,100);
    if(bridge.actorCount==4){Place(2,70,215);Place(3,220,215);}
    balls=5;capacity=60;pcCount=consumeCalls=shakeCalls=catchCalls=awards=defeats=0;
    storeCalls=event=lastStore=consumeEvent=shakeEvent=0;
    shakePaidSerial=catchPaidSerial=0;
    expectedOwner=1;expectedSlot=0;returnedShakes=4;result=0;
    allowThrow=allowConsume=allowAward=TRUE;paidBall=FALSE;
    memset(&caughtMon,0,sizeof(caughtMon));ArenaCapture_Init(&capture,&bridge,12345,0);
}
static void Aim(void)
{Step(SHOULDERS,SHOULDERS);assert(capture.phase==ARENA_CAPTURE_AIM);}
static void Throw(void)
{
    unsigned before=balls,calls=consumeCalls;Step(PAD_BUTTON_R,0);
    assert(capture.phase==ARENA_CAPTURE_THROW&&balls==before-1&&consumeCalls==calls+1);
}

static void RawButtonsAndPriority(void)
{
    assert(PAD_BUTTON_L==0x0200&&PAD_BUTTON_R==0x0100);
    assert(PAD_BUTTON_Y==0x0800&&PAD_BUTTON_X==0x0400&&PAD_BUTTON_A==1);
    Reset(0,1,1);unsigned pp=combat.fighters[0].pp[0];
    u32 all=SHOULDERS|PAD_BUTTON_A|PAD_BUTTON_X|PAD_BUTTON_Y;
    Step(all,all);assert(capture.phase==ARENA_CAPTURE_AIM);
    assert(!lastInput.held&&!lastInput.pressed&&combat.fighters[0].pp[0]==pp);
    assert(combat.fighters[0].phase==COMBAT_READY&&balls==5&&!consumeCalls);
    Step(PAD_BUTTON_L,0);assert(capture.phase==ARENA_CAPTURE_THROW&&consumeCalls==1);
    Advance(10);assert(consumeCalls==1&&balls==4);
    Reset(0,1,1);ArenaCapture_Init(&capture,&bridge,1,SHOULDERS);
    Step(SHOULDERS,0);assert(capture.phase==ARENA_CAPTURE_IDLE);
    Step(PAD_BUTTON_L,0);Aim();assert(!consumeCalls);
}
static void CancelAndFreshChord(void)
{
    const u32 cancel[]={PAD_BUTTON_B,PAD_BUTTON_START,PAD_BUTTON_SELECT};
    for(unsigned i=0;i<3;i++) {
        Reset(0,1,1);Aim();Step(SHOULDERS,cancel[i]);
        assert(capture.phase==ARENA_CAPTURE_IDLE&&!consumeCalls&&balls==5);
        for(unsigned n=0;n<8;n++)Step(SHOULDERS,0);
        assert(capture.phase==ARENA_CAPTURE_IDLE);
        Step(0,0);Aim();Throw();
    }
    Reset(0,1,1);Aim();allowThrow=FALSE;Step(0,0);
    assert(capture.phase==ARENA_CAPTURE_IDLE&&!consumeCalls&&balls==5);
    Reset(0,1,1);Aim();allowConsume=FALSE;Step(0,0);
    assert(capture.phase==ARENA_CAPTURE_IDLE&&consumeCalls==1&&balls==5&&!paidBall);
}
static void HitNativeOrderAndSingleAward(void)
{
    Reset(0,1,1);Aim();Throw();
    combat.fighters[1].hp=89;combat.fighters[1].pp[0]=3;
    Until(ARENA_CAPTURE_ABSORB,30);
    assert(shakeCalls==1&&storeCalls==1&&catchCalls==0&&balls==4);
    unsigned frame=combat.frame;
    Until(ARENA_CAPTURE_CAUGHT,200);
    assert(combat.frame==frame&&shakeCalls==1&&storeCalls==2&&awards==1&&result==4);
    assert(caughtMon.data[MON_DATA_HP]==12&&caughtMon.data[MON_DATA_MOVE1_PP]==3);
    assert(caughtMon.data[MON_DATA_EXPERIENCE]==135&&!defeats);
    Advance(150);assert(capture.finished&&awards==1&&catchCalls==1&&consumeCalls==1);
    assert(parties[0].count==2&&parties[0].mon[0].data[MON_DATA_EXPERIENCE]==135);
}
static void MissCoverAndDefeatedTarget(void)
{
    Reset(0,1,1);Aim();
    for(unsigned i=0;i<30;i++)Step(SHOULDERS|PAD_KEY_DOWN,0);
    Throw();Until(ARENA_CAPTURE_MISS,30);
    assert(!shakeCalls&&!catchCalls&&balls==4);Until(ARENA_CAPTURE_IDLE,30);
    Reset(0,1,1);ArenaNav_SetObstacle(0,1);
    Place(1,(gArenaObstacles[0].left+gArenaObstacles[0].right)/2,
        (gArenaObstacles[0].top+gArenaObstacles[0].bottom)/2);
    Aim();Throw();Until(ARENA_CAPTURE_MISS,30);assert(!shakeCalls&&!catchCalls);
    Reset(0,1,1);Aim();Throw();combat.fighters[1].hp=0;
    /* Keep this unit case focused on throw contact, before core winner handling. */
    for(unsigned i=0;i<24&&capture.phase==ARENA_CAPTURE_THROW;i++) {
        CombatInput input={0,0};ArenaCapture_Process(&capture,0,0,&input);
    }
    assert(capture.phase==ARENA_CAPTURE_MISS&&!shakeCalls&&!catchCalls);
}
static void FailureTimingAndQueuedAltRecovery(void)
{
    const unsigned timing[]={20,54,88,122};
    for(unsigned shakes=0;shakes<4;shakes++) {
        Reset(0,1,1);returnedShakes=shakes;Aim();Throw();Until(ARENA_CAPTURE_SHAKE,80);
        Advance(timing[shakes]-1);assert(capture.phase==ARENA_CAPTURE_SHAKE);
        Step(0,0);assert(capture.phase==ARENA_CAPTURE_BREAK&&!catchCalls&&shakeCalls==1);
        Until(ARENA_CAPTURE_IDLE,30);assert(capture.recovery==12);
        unsigned pp=combat.fighters[0].pp[1];
        for(unsigned i=0;i<12;i++) {
            combat.fighters[0].buffered=1;combat.fighters[0].bufferedSlot=1;combat.fighters[0].bufferTimer=10;
            Step(PAD_BUTTON_A|PAD_BUTTON_X|PAD_BUTTON_Y,PAD_BUTTON_X);
            assert(!(lastInput.held&(COMBAT_A|COMBAT_X|COMBAT_ALT)));
            assert(!(lastInput.pressed&(COMBAT_A|COMBAT_X|COMBAT_ALT)));
            assert(!combat.fighters[0].bufferTimer&&combat.fighters[0].pp[1]==pp);
        }
        Step(PAD_BUTTON_X,PAD_BUTTON_X);assert(combat.fighters[0].pp[1]==pp-1);
    }
}
static void WildAndTrainerRules(void)
{
    Reset(BATTLE_TYPE_TRAINER,1,1);Step(SHOULDERS,SHOULDERS);
    assert(capture.phase==ARENA_CAPTURE_IDLE&&!consumeCalls);
    Reset(BATTLE_TYPE_DOUBLES,2,2);Step(SHOULDERS,SHOULDERS);
    assert(capture.phase==ARENA_CAPTURE_IDLE&&!consumeCalls);
    Step(0,0);combat.fighters[1].hp=0;expectedSlot=1;Aim();
    assert(capture.target==3);Throw();Until(ARENA_CAPTURE_CAUGHT,250);
    assert(awards==1&&caughtMon.data[MON_DATA_SPECIES]==396);
    Reset(BATTLE_TYPE_DOUBLES|BATTLE_TYPE_2vs2,1,1);
    combat.fighters[1].hp=0;expectedOwner=3;Aim();Throw();
    Until(ARENA_CAPTURE_CAUGHT,250);assert(awards==1&&capture.target==3);
}
static void ControlActorAndStorage(void)
{
    Reset(BATTLE_TYPE_DOUBLES,2,2);combat.fighters[3].hp=0;
    assert(ArenaParty_SwitchPlayer(&bridge,1)&&bridge.controlActor==2);
    storeCalls=event=lastStore=consumeEvent=shakeEvent=0;
    combat.fighters[2].buffered=1;combat.fighters[2].bufferTimer=10;
    Aim();assert(!combat.fighters[2].bufferTimer);
    Throw();assert(capture.startX==combat.fighters[2].x-24*Q);
    Until(ARENA_CAPTURE_CAUGHT,250);assert(awards==1&&bridge.controlActor==2);
    Reset(0,6,1);pcCount=59;Aim();Throw();Until(ARENA_CAPTURE_CAUGHT,250);
    assert(awards==1&&pcCount==60&&parties[0].count==6);
    Reset(0,6,1);pcCount=60;Step(SHOULDERS,SHOULDERS);
    assert(capture.phase==ARENA_CAPTURE_IDLE&&!consumeCalls&&balls==5);
    Reset(0,1,1);balls=0;Step(SHOULDERS,SHOULDERS);
    assert(capture.phase==ARENA_CAPTURE_IDLE&&!consumeCalls);
    Reset(0,1,1);Aim();Throw();allowAward=FALSE;Until(ARENA_CAPTURE_BREAK,250);
    assert(catchCalls==1&&!awards&&balls==4);
    Reset(0,1,1);balls=1;Aim();Throw();Until(ARENA_CAPTURE_CAUGHT,250);
    assert(balls==0&&consumeCalls==1&&awards==1);
    Reset(0,1,1);returnedShakes=0;Aim();Throw();Until(ARENA_CAPTURE_IDLE,250);
    u32 previousRandom=capture.random;Advance(12);returnedShakes=4;Aim();Throw();
    Until(ARENA_CAPTURE_CAUGHT,250);
    assert(balls==3&&consumeCalls==2&&shakeCalls==2&&awards==1&&capture.random!=previousRandom);
}
int main(void)
{
    RawButtonsAndPriority();CancelAndFreshChord();HitNativeOrderAndSingleAward();
    MissCoverAndDefeatedTarget();FailureTimingAndQueuedAltRecovery();
    WildAndTrainerRules();ControlActorAndStorage();
    puts("PASS: raw Nitro capture controls, cancel/latch, payment, hit/miss/cover, native ordering, shake timing, single award, no XP, wild doubles, actor2 and ALT recovery");
    return 0;
}
