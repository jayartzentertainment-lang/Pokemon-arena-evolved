#include <assert.h>
#include <string.h>
#include "arena/controls.h"
int main(void)
{
    CombatInput input;
    ArenaControls_Reset();
    input=ArenaControls_Map(2048|64,2048);
    assert(input.held==(COMBAT_X|COMBAT_UP));assert(input.pressed==COMBAT_X);
    input=ArenaControls_Map(2,2);assert(input.held==COMBAT_B);
    input=ArenaControls_Map(256,256);assert(input.held==0); /* R initially reserved */
    ArenaControls_Cycle(ARENA_CONTROL_STRIKE,1); /* Y -> L, swaps cycle to Y */
    assert(!strcmp(ArenaControls_Label(ARENA_CONTROL_STRIKE),"L"));
    input=ArenaControls_Map(512,512);assert(input.held==COMBAT_X);
    input=ArenaControls_Map(2048,2048);assert(input.held==COMBAT_R);
    input=ArenaControls_Map(512|256|16,512|256); /* capture wins over remap */
    assert(input.held==COMBAT_RIGHT);assert(input.pressed==0);
    ArenaControls_Cycle(ARENA_CONTROL_STRIKE,1); /* L -> spare R */
    input=ArenaControls_Map(256,256);assert(input.held==COMBAT_X);
    input=ArenaControls_Map(512,512);assert(input.held==0);
    ArenaControls_Reset();
    input=ArenaControls_Map(1|1024|4,1|1024|4);
    assert(input.held==(COMBAT_A|COMBAT_ALT|COMBAT_Y));
    assert(!strcmp(ArenaControls_Label(ARENA_CONTROL_STRIKE),"Y"));
    return 0;
}
