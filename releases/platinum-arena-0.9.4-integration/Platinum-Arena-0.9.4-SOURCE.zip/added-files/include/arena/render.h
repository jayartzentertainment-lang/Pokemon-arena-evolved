#ifndef PLATINUM_ARENA_RENDER_H
#define PLATINUM_ARENA_RENDER_H

#include "arena/combat.h"
#include "constants/heap.h"

typedef struct ArenaRender ArenaRender;

/* Caller suspends native field graphics and owns the VBlank callback. This
 * renderer never registers a task or callback, accesses raw card/save ports,
 * or retains pointers into the native battle graphics overlay. */
ArenaRender *ArenaRender_New(enum HeapID heapID, unsigned background);
/* Preload at entry / replacement only; no filesystem I/O in Draw/VBlank.
 * Canonical dex is 1..493. Four actors share identical immutable pose data. */
BOOL ArenaRender_SetActor(ArenaRender *render, unsigned side, unsigned dex, unsigned form);
void ArenaRender_Draw(ArenaRender *render, const Combat *combat);
void ArenaRender_VBlank(ArenaRender *render);
/* Root calls after detaching its VBlank callback. */
void ArenaRender_Free(ArenaRender *render);
/* Optional modal UI: retained until replaced or NULL; string is copied. */
void ArenaRender_SetMessage(ArenaRender *render, const char *message);
void ArenaRender_SetCapture(ArenaRender *render,unsigned phase,unsigned target,s32 aimX,s32 aimY,s32 ballX,s32 ballY,unsigned age);
/* Native full party totals, including benched and fainted Pokémon. */
void ArenaRender_SetPartyStatus(ArenaRender *render,unsigned team,unsigned total,unsigned remaining);
/* Native party metadata; inactive actors use level/status zero. */
void ArenaRender_SetActorInfo(ArenaRender *render,unsigned actor,unsigned level,u32 status);
void ArenaRender_SetControlLabels(ArenaRender *render,const char *strike,const char *guard,const char *selected,const char *next,const char *cycle,const char *aim);
u32 ArenaRender_ResidentBytes(const ArenaRender *render);

#endif
