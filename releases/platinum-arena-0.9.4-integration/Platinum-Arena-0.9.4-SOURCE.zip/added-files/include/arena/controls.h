#ifndef PLATINUM_ARENA_CONTROLS_H
#define PLATINUM_ARENA_CONTROLS_H
#include "arena/combat.h"
/* Main-resident settings survive overlay reloads and battles. These do not
 * change the retail save format; restarting the ROM restores defaults. */
enum ArenaControlAction { ARENA_CONTROL_STRIKE,ARENA_CONTROL_GUARD,
    ARENA_CONTROL_MOVE,ARENA_CONTROL_NEXT,ARENA_CONTROL_CYCLE,
    ARENA_CONTROL_AIM,ARENA_CONTROL_COUNT };
const char *ArenaControls_Label(unsigned action);
void ArenaControls_Reset(void);
void ArenaControls_Cycle(unsigned action,int direction);
CombatInput ArenaControls_Map(uint32_t held,uint32_t pressed);
#endif
