#!/usr/bin/env python3
"""Run portable arena regressions and optionally compile with Platinum MWCC."""
import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BUILD = ROOT / "build/arena-core-checks"
SOURCES = ["src/arena/combat.c", "src/arena/move_data.c",
           "src/arena/vendor/arena_moves.c", "src/arena/vendor/arena_navigation.c",
           "src/arena/vendor/arena_physics.c"]
TESTS = ["test_combat", "test_team_combat", "test_platinum_core", "test_combat_polish",
         "test_navigation", "test_move_geometry", "test_physics"]


def run(label, command, cwd=ROOT):
    result = subprocess.run(command, cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (BUILD / (label + ".log")).write_text(shlex.join(command) + "\n" + result.stdout)
    print(label + ": " + str(result.returncode), flush=True)
    if result.stdout:
        print(result.stdout, end="", flush=True)
    result.check_returncode()


def main():
    args = argparse.ArgumentParser()
    args.add_argument("--native", action="store_true")
    args.add_argument("--sanitize", action="store_true")
    args = args.parse_args()
    BUILD.mkdir(parents=True, exist_ok=True)
    run("generated-moves", ["python3", "tools/arena/generate_moves.py", "--check"])
    flags = ["-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-Iinclude"]
    if args.sanitize:
        flags += ["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
    for test in TESTS:
        output = BUILD / test
        run("host-compile-" + test, [os.environ.get("CC", "gcc")] + flags
            + ["tests/arena/" + test + ".c"] + SOURCES + ["-o", str(output)])
        run("host-run-" + test, [str(output)])
    if args.native:
        entries = json.loads((ROOT / "build/compile_commands.json").read_text())
        entry = next(e for e in entries if e["file"].endswith("/battle/battle_system.c"))
        original = shlex.split(entry["command"])
        command = []
        index = 0
        while index < len(original):
            value = original[index]
            if value in ("-c", "-o", "-prefix"):
                index += 2
                continue
            if value in ("-gccdep", "-MD"):
                index += 1
                continue
            command.append(value)
            index += 1
        command += ["-prefix", "pch/global_pch.h"]
        for source in SOURCES:
            run("native-" + Path(source).stem, command + ["-c", str(ROOT/source),
                "-o", str(BUILD/(Path(source).stem + ".mw.o"))], Path(entry["directory"]))


if __name__ == "__main__":
    main()
