/* Native Platinum encounter -> live combat -> native field/evolution boundary.
 * No standalone boot, ARM7, cartridge or EEPROM code is imported. */
#include "arena/session.h"
#include "arena/combat.h"
#include "arena/party_bridge.h"
#include "arena/rewards.h"
#include "arena/render.h"
#include "arena/assets.h"
#include "arena/capture.h"
#include "arena/controls.h"
#include "arena/heap.h"
#include "constants/moves.h"
#include "constants/species.h"
#include "main.h"
#include "bag.h"
#include "heap.h"
#include "item_use_pokemon.h"
#include "math_util.h"
#include "pokemon.h"
#include "screen_fade.h"
#include "sound.h"
#include "sound_playback.h"
#include "system.h"
#include <stdio.h>
#include <string.h>

enum { SESSION_FADE_IN,SESSION_FIGHT,SESSION_PAUSE,SESSION_PARTY,SESSION_ITEMS,
    SESSION_ITEM_TARGET,SESSION_ITEM_MOVE,SESSION_RESULT,SESSION_LEARN,SESSION_FADE_OUT,
    SESSION_PRACTICE,SESSION_CONTROLS,SESSION_NOTICE };
typedef struct ArenaSession {
    FieldBattleDTO *dto;
    Combat combat;
    ArenaPartyBridge party;
    ArenaCapture capture;
    ArenaRender *render;
    u32 lastTick,started,age;
    u32 soundedHits,soundedBlocks;
    u32 soundedReleases[4];
    u16 loadedDex[4];
    u8 loadedForm[4];
    u8 loadedOwner[4],loadedSlot[4];
    u8 mode,choice,partyChoice,itemChoice,result,runAttempts,soundedCapture;
    u16 learnIndex;
    u16 practiceDex[4];
    u8 practice,practiceDoubles,practiceClash,practiceBackground,practiceLevel,settingsReturn,noticeReturn;
    char message[320];
} ArenaSession;
static BOOL sPracticeApplication;
static void PracticeText(ArenaSession *s);
static void ControlsText(ArenaSession *s);
static BOOL StartPractice(ArenaSession *s);
static void ExitPractice(ArenaSession *s);
static const u16 sMedicine[]={ITEM_POTION,ITEM_SUPER_POTION,ITEM_HYPER_POTION,
    ITEM_MAX_POTION,ITEM_FULL_RESTORE,ITEM_REVIVE,ITEM_MAX_REVIVE,ITEM_FULL_HEAL,
    ITEM_ETHER,ITEM_ELIXIR};
static const char *const sMedicineNames[]={"Potion","Super Potion","Hyper Potion",
    "Max Potion","Full Restore","Revive","Max Revive","Full Heal","Ether","Elixir"};
static const u16 sPracticeInitial[]={SPECIES_CHARIZARD,SPECIES_GYARADOS,SPECIES_BLASTOISE,SPECIES_LAPRAS};
static const char *Name(unsigned dex,unsigned form)
{
    const AssetSpecies *species=ArenaAssets_FindSpecies(dex,form);
    return species?species->name:"Pokemon";
}
static const char *MoveName(unsigned id)
{const CombatMoveInfo *move=Combat_GetMoveInfo(id);return move?move->name:"---";}
static void VBlank(void *context)
{
    ArenaSession *s=context;
    if(s&&s->render)ArenaRender_VBlank(s->render);
    OS_SetIrqCheckFlag(OS_IE_V_BLANK);
}
static void Defeated(void *context,unsigned actor,unsigned owner,unsigned slot,
    Pokemon *mon,u32 participants)
{
    ArenaSession *s=context;(void)actor;(void)mon;
    if(!s->practice)ArenaRewards_OnDefeat(s->dto,owner,slot,participants);
}
static BOOL LoadActors(ArenaSession *s)
{
    unsigned i;
    for(i=0;i<s->combat.fighterCount;i++){
        unsigned dex=s->combat.fighters[i].species,form=s->party.actor[i].form;
        if(!s->party.actor[i].active||!dex)continue;
        if(s->loadedOwner[i]!=s->party.actor[i].owner||s->loadedSlot[i]!=s->party.actor[i].slot){
            if(!s->practice)ArenaRewards_OnSendOut(s->dto,s->party.actor[i].owner,s->party.actor[i].slot);
            s->soundedReleases[i]=s->combat.fighters[i].releaseSerial;
            s->loadedOwner[i]=s->party.actor[i].owner;s->loadedSlot[i]=s->party.actor[i].slot;
        }
        if(s->loadedDex[i]!=dex||s->loadedForm[i]!=form){
            if(!ArenaRender_SetActor(s->render,i,dex,form))return FALSE;
            s->loadedDex[i]=dex;s->loadedForm[i]=form;
        }
    }
    return TRUE;
}
static void ApplyControlLabels(ArenaSession *s)
{
    ArenaRender_SetControlLabels(s->render,ArenaControls_Label(ARENA_CONTROL_STRIKE),
        ArenaControls_Label(ARENA_CONTROL_GUARD),ArenaControls_Label(ARENA_CONTROL_MOVE),
        ArenaControls_Label(ARENA_CONTROL_NEXT),ArenaControls_Label(ARENA_CONTROL_CYCLE),
        ArenaControls_Label(ARENA_CONTROL_AIM));
}
static void UpdatePartyStatus(ArenaSession *s)
{
    unsigned team,owner,slot,total,remaining,actor;
    for(actor=0;actor<COMBAT_FIGHTERS;actor++){
        Pokemon *mon=actor<s->party.actorCount?ArenaParty_ActorPokemon(&s->party,actor):NULL;
        /* Read the native Pokemon rather than cached presentation values so
         * level-ups, medicine and party swaps update the healthbox together. */
        ArenaRender_SetActorInfo(s->render,actor,
            mon?Pokemon_GetValue(mon,MON_DATA_LEVEL,NULL):0,
            mon?Pokemon_GetValue(mon,MON_DATA_STATUS,NULL):0);
    }
    for(team=0;team<2;team++){
        total=remaining=0;
        for(owner=team;owner<MAX_BATTLERS;owner+=2){
            unsigned count=Party_GetCurrentCount(s->dto->parties[owner]);
            for(slot=0;slot<count;slot++){
                Pokemon *mon=Party_GetPokemonBySlotIndex(s->dto->parties[owner],slot);
                if(Pokemon_GetValue(mon,MON_DATA_IS_EGG,NULL))continue;
                total++;if(Pokemon_GetValue(mon,MON_DATA_HP,NULL))remaining++;
            }
        }
        ArenaRender_SetPartyStatus(s->render,team,total,remaining);
    }
}
static void ControlsText(ArenaSession *s)
{
    static const char *const actions[]={"Strike","Shield / dodge","Selected move","Next move","Cycle move","Aim lock"};
    unsigned i;int used=snprintf(s->message,sizeof(s->message),"Controls - until restart\n");
    ApplyControlLabels(s);
    for(i=0;i<ARENA_CONTROL_COUNT;i++)used+=snprintf(s->message+used,sizeof(s->message)-used,
        "%c %s: %s\n",s->choice==i?'>':' ',actions[i],ArenaControls_Label(i));
    used+=snprintf(s->message+used,sizeof(s->message)-used,"%c Reset defaults\n%c Back\n",
        s->choice==6?'>':' ',s->choice==7?'>':' ');
    snprintf(s->message+used,sizeof(s->message)-used,"Left/Right: change  B: back\nA/B menus, START pause fixed");
    ArenaRender_SetMessage(s->render,s->message);
}
static void PracticeText(ArenaSession *s)
{
    static const char *const actors[]={"You","Ally","Foe1","Foe2"};
    static const char *const modes[]={"Free 1v1","Free 2v2","Clash 1v1","Clash 2v2"};
    unsigned mode=s->practiceDoubles|(s->practiceClash?2:0),i;
    int used=snprintf(s->message,sizeof(s->message),"BATTLE LAB  L/R +/-25\n%c Mode: %s\n",s->choice==0?'>':' ',modes[mode]);
    for(i=0;i<4;i++)used+=snprintf(s->message+used,sizeof(s->message)-used,"%c %s %03u %s\n",
        s->choice==i+1?'>':' ',actors[i],s->practiceDex[i],Name(s->practiceDex[i],0));
    used+=snprintf(s->message+used,sizeof(s->message)-used,"%c Arena: %s\n%c Level: %u\n%c Controls\n%c Start battle\n",
        s->choice==5?'>':' ',s->practiceBackground?"Training hall":"Meadow",
        s->choice==6?'>':' ',s->practiceLevel,s->choice==7?'>':' ',s->choice==8?'>':' ');
    snprintf(s->message+used,sizeof(s->message)-used,"START: fight  B: exit");
    ArenaRender_SetMessage(s->render,s->message);
}
/* Every practice Pokemon, item and result belongs to this temporary DTO.
 * Native capture is disabled (trainer rules), and no rewards/save callbacks
 * are registered. Destroying the app discards the entire practice encounter. */
static BOOL PracticeTeam(FieldBattleDTO *dto,const u16 species[4],unsigned doubles,unsigned level,unsigned clash)
{
    static const u16 beamByType[]={MOVE_SWIFT,MOVE_FOCUS_BLAST,MOVE_AIR_SLASH,MOVE_SLUDGE_BOMB,
        MOVE_EARTH_POWER,MOVE_POWER_GEM,MOVE_SILVER_WIND,MOVE_SHADOW_BALL,MOVE_FLASH_CANNON,
        MOVE_SWIFT,MOVE_FLAMETHROWER,MOVE_WATER_PULSE,MOVE_ENERGY_BALL,MOVE_THUNDERBOLT,
        MOVE_PSYBEAM,MOVE_ICE_BEAM,MOVE_DRAGON_BREATH,MOVE_DARK_PULSE};
    Pokemon *mon=Pokemon_New(HEAP_ID_APPLICATION);unsigned i,type;BOOL ok=TRUE;
    if(!mon)return FALSE;
    for(i=0;i<4;i++)Party_Init(dto->parties[i]);
    dto->battleType=BATTLE_TYPE_TRAINER|(doubles?BATTLE_TYPE_DOUBLES:0);
    dto->resultMask=0;dto->leveledUpMonsMask=0;dto->seed=0xA9E39093u;
    for(i=0;i<4;i++){
        if(!doubles&&(i==1||i==3))continue;
        Pokemon_InitWith(mon,species[i],level,20,TRUE,0x12345670u+i,OTID_SET,0xA9E30000u);
        type=Pokemon_GetValue(mon,MON_DATA_TYPE_1,NULL);if(type>=18)type=0;
        Pokemon_ResetMoveSlot(mon,clash?(i<2?MOVE_FLAMETHROWER:MOVE_HYDRO_PUMP):beamByType[type],0);
        Pokemon_ResetMoveSlot(mon,type==11?MOVE_HYDRO_PUMP:type==10?MOVE_FIRE_BLAST:type==13?MOVE_THUNDER:MOVE_HYPER_BEAM,1);
        Pokemon_ResetMoveSlot(mon,MOVE_TACKLE,2);
        Pokemon_ResetMoveSlot(mon,MOVE_SWIFT,3);
        if(!Party_AddPokemon(dto->parties[i<2?0:1],mon))ok=FALSE;
    }
    Heap_Free(mon);return ok;
}
static BOOL StartPractice(ArenaSession *s)
{
    SetVBlankCallback(NULL,NULL);
    if(s->render){ArenaRender_Free(s->render);s->render=NULL;}
    if(!PracticeTeam(s->dto,s->practiceDex,s->practiceDoubles,s->practiceLevel,s->practiceClash))return FALSE;
    if(!ArenaParty_Begin(&s->party,s->dto,&s->combat))return FALSE;
    /* Practice-only: the foe answers the player's first beam with its own.
     * Native encounter AI and all saved teams retain their normal behavior. */
    Combat_SetClashPractice(&s->combat,s->practiceClash);
    memset(s->loadedDex,0,sizeof(s->loadedDex));memset(s->loadedForm,0,sizeof(s->loadedForm));
    memset(s->loadedOwner,0xff,sizeof(s->loadedOwner));memset(s->loadedSlot,0xff,sizeof(s->loadedSlot));
    s->render=ArenaRender_New(HEAP_ID_BATTLE,s->practiceBackground);
    if(!s->render||!LoadActors(s))return FALSE;
    ApplyControlLabels(s);UpdatePartyStatus(s);
    ArenaCapture_Init(&s->capture,&s->party,s->dto->seed,gSystem.heldKeysRaw);
    s->soundedHits=s->soundedBlocks=0;s->soundedCapture=0;s->result=0;
    SetVBlankCallback(VBlank,s);return TRUE;
}
static void ExitPractice(ArenaSession *s)
{
    s->mode=SESSION_FADE_OUT;
    StartScreenFade(FADE_BOTH_SCREENS,FADE_TYPE_BRIGHTNESS_OUT,FADE_TYPE_BRIGHTNESS_OUT,COLOR_BLACK,6,1,HEAP_ID_BATTLE);
}
#include "move_sounds.inc"
static void SoundEvents(ArenaSession *s)
{
    unsigned actor;
    for(actor=0;actor<s->combat.fighterCount;actor++){
        CombatFighter *fighter=&s->combat.fighters[actor];
        if(fighter->releaseSerial!=s->soundedReleases[actor]){
            unsigned move=fighter->releaseMove;
            s->soundedReleases[actor]=fighter->releaseSerial;
            if(move<sizeof(sMoveSounds)/sizeof(sMoveSounds[0]))Sound_PlayEffect(sMoveSounds[move]);
        }
    }
    if(s->combat.hits!=s->soundedHits){
        s->soundedHits=s->combat.hits;Sound_PlayEffect(SEQ_SE_DP_KOUKA_M_sseq);
    }
    if(s->combat.blocked!=s->soundedBlocks){
        Sound_PlayEffect(SEQ_SE_DP_KON_sseq);
    }
    s->soundedBlocks=s->combat.blocked;
    if(s->capture.phase!=s->soundedCapture){
        s->soundedCapture=s->capture.phase;
        if(s->capture.phase==ARENA_CAPTURE_THROW)Sound_PlayEffect(SEQ_SE_DP_NAGERU_sseq);
    }
}
static void Resume(ArenaSession *s)
{s->mode=SESSION_FIGHT;s->lastTick=gSystem.vblankCounter;ArenaRender_SetMessage(s->render,NULL);}
static void PauseText(ArenaSession *s)
{
    static const char *const options[]={"Resume","Pokemon","Bag","Run","Controls"};
    unsigned i;int used;
    if(s->practice&&s->practiceClash)used=snprintf(s->message,sizeof(s->message),
        "Clash practice\n%s: beam  %s+dir: dodge\n",
        ArenaControls_Label(ARENA_CONTROL_MOVE),ArenaControls_Label(ARENA_CONTROL_GUARD));
    else used=snprintf(s->message,sizeof(s->message),"Battle menu\n");
    for(i=0;i<5;i++)used+=snprintf(s->message+used,sizeof(s->message)-used,"%c %s\n",s->choice==i?'>':' ',s->practice&&i==3?"Test menu":options[i]);
    snprintf(s->message+used,sizeof(s->message)-used,"A: choose   B: resume");
    ArenaRender_SetMessage(s->render,s->message);
}
static void PartyText(ArenaSession *s)
{
    int count=Party_GetCurrentCount(s->dto->parties[0]),used=0,i;
    used=snprintf(s->message,sizeof(s->message),"Your Pokemon\n");
    for(i=0;i<count;i++){
        Pokemon *mon=Party_GetPokemonBySlotIndex(s->dto->parties[0],i);
        unsigned dex=Pokemon_GetValue(mon,MON_DATA_SPECIES,NULL);
        used+=snprintf(s->message+used,sizeof(s->message)-used,"%c %s Lv%u %u/%u\n",
            s->partyChoice==i?'>':' ',Name(dex,Pokemon_GetForm(mon)),
            (unsigned)Pokemon_GetValue(mon,MON_DATA_LEVEL,NULL),
            (unsigned)Pokemon_GetValue(mon,MON_DATA_HP,NULL),(unsigned)Pokemon_GetValue(mon,MON_DATA_MAX_HP,NULL));
    }
    snprintf(s->message+used,sizeof(s->message)-used,s->mode==SESSION_ITEM_TARGET?"A: use item   B: back":"A: switch   B: back");
    ArenaRender_SetMessage(s->render,s->message);
}
static void ItemText(ArenaSession *s)
{
    unsigned start=s->itemChoice/5*5,i;int used=snprintf(s->message,sizeof(s->message),"Medicine\n");
    for(i=start;i<start+5&&i<sizeof(sMedicine)/sizeof(sMedicine[0]);i++){
        unsigned qty=Bag_GetItemQuantity(s->dto->bag,sMedicine[i],HEAP_ID_BATTLE);
        used+=snprintf(s->message+used,sizeof(s->message)-used,"%c %s x%u\n",s->itemChoice==i?'>':' ',sMedicineNames[i],qty);
    }
    snprintf(s->message+used,sizeof(s->message)-used,"A: choose   B: back");
    ArenaRender_SetMessage(s->render,s->message);
}
static void ItemMoveText(ArenaSession *s)
{
    Pokemon *mon=Party_GetPokemonBySlotIndex(s->dto->parties[0],s->partyChoice);
    unsigned i;int used=snprintf(s->message,sizeof(s->message),"Restore which move?\n");
    for(i=0;i<4;i++)used+=snprintf(s->message+used,sizeof(s->message)-used,"%c %s PP %u\n",
        s->choice==i?'>':' ',MoveName(Pokemon_GetValue(mon,MON_DATA_MOVE1+i,NULL)),
        (unsigned)Pokemon_GetValue(mon,MON_DATA_MOVE1_PP+i,NULL));
    snprintf(s->message+used,sizeof(s->message)-used,"A: use Ether   B: back");
    ArenaRender_SetMessage(s->render,s->message);
}
static void Notice(ArenaSession *s,const char *message,unsigned returnMode)
{
    s->noticeReturn=(u8)returnMode;s->mode=SESSION_NOTICE;
    snprintf(s->message,sizeof(s->message),"%s\nA / B: return",message);
    ArenaRender_SetMessage(s->render,s->message);
}
static void ReturnFromNotice(ArenaSession *s)
{
    s->mode=s->noticeReturn;
    if(s->mode==SESSION_ITEMS)ItemText(s);
    else if(s->mode==SESSION_PARTY||s->mode==SESSION_ITEM_TARGET)PartyText(s);
    else if(s->mode==SESSION_ITEM_MOVE)ItemMoveText(s);
    else{s->mode=SESSION_PAUSE;PauseText(s);}
}
static BOOL UseMedicine(ArenaSession *s,unsigned moveSlot)
{
    u16 item=sMedicine[s->itemChoice];
    Pokemon *mon=Party_GetPokemonBySlotIndex(s->dto->parties[0],s->partyChoice);
    if(Bag_CanRemoveItem(s->dto->bag,item,1,HEAP_ID_BATTLE)
        &&Pokemon_CheckItemEffects(mon,item,moveSlot,HEAP_ID_BATTLE)
        &&Pokemon_ApplyItemEffects(mon,item,moveSlot,s->dto->mapHeaderID,HEAP_ID_BATTLE)){
        Bag_TryRemoveItem(s->dto->bag,item,1,HEAP_ID_BATTLE);
        ArenaParty_Refresh(&s->party);Resume(s);return TRUE;
    }
    Notice(s,"That item cannot be used now.",SESSION_ITEM_TARGET);
    return FALSE;
}
static void Result(ArenaSession *s,unsigned result)
{
    s->result=result;s->mode=SESSION_RESULT;
    ArenaRender_SetMessage(s->render,result==BATTLE_RESULT_WIN?"You won!\nA / B: continue":
        result==BATTLE_RESULT_CAPTURED_MON?"Gotcha! Pokemon caught!\nA / B: continue":
        result==BATTLE_RESULT_PLAYER_FLED?"Got away safely!\nA / B: continue":
        result==BATTLE_RESULT_DRAW?"Both teams fainted. A draw!\nA / B: continue":"Your team fainted.\nA / B: continue");
}
static BOOL NextLearn(ArenaSession *s)
{
    ArenaLearnMove learn;
    while(s->learnIndex<ArenaRewards_PendingMoveCount()){
        if(ArenaRewards_PendingMove(s->learnIndex,&learn))return TRUE;
        s->learnIndex++;
    }
    return FALSE;
}
static void LearnText(ArenaSession *s)
{
    ArenaLearnMove learn;unsigned i;int used;Pokemon *mon;
    if(!ArenaRewards_PendingMove(s->learnIndex,&learn))return;
    mon=Party_GetPokemonBySlotIndex(s->dto->parties[0],learn.partySlot);
    used=snprintf(s->message,sizeof(s->message),"%s can learn %s.\nReplace a move?\n",
        Name(Pokemon_GetValue(mon,MON_DATA_SPECIES,NULL),Pokemon_GetForm(mon)),MoveName(learn.move));
    for(i=0;i<4;i++)used+=snprintf(s->message+used,sizeof(s->message)-used,"%c %s\n",s->choice==i?'>':' ',
        MoveName(Pokemon_GetValue(mon,MON_DATA_MOVE1+i,NULL)));
    snprintf(s->message+used,sizeof(s->message)-used,"%c Keep old moves",s->choice==4?'>':' ');
    ArenaRender_SetMessage(s->render,s->message);
}
static void Finish(ArenaSession *s)
{
    /* Catch arranges the source owner for the original journal. Its native
     * placement is already committed and must not be overwritten here. */
    if(s->practice){s->mode=SESSION_PRACTICE;s->choice=8;PracticeText(s);return;}
    if(s->result!=BATTLE_RESULT_CAPTURED_MON)ArenaParty_Store(&s->party);
    ArenaRewards_Finalize(s->dto,s->result);
    s->dto->totalTurnsElapsed=1+s->combat.frame/360;
    s->dto->battleRecords.totalTurns=s->dto->totalTurnsElapsed;
    s->mode=SESSION_FADE_OUT;
    StartScreenFade(FADE_BOTH_SCREENS,FADE_TYPE_BRIGHTNESS_OUT,FADE_TYPE_BRIGHTNESS_OUT,
        COLOR_BLACK,6,1,HEAP_ID_BATTLE);
}
static void TryRun(ArenaSession *s)
{
    unsigned target=Combat_TargetFighter(&s->combat,s->party.controlActor),chance;
    if((s->dto->battleType&BATTLE_TYPE_TRAINER)||(s->dto->battleStatusMask&BATTLE_STATUS_NO_RUNNING)){
        Notice(s,"You cannot run from this battle.",SESSION_PAUSE);return;
    }
    s->runAttempts++;
    if(target>=s->combat.fighterCount){Result(s,BATTLE_RESULT_PLAYER_FLED);return;}
    chance=s->combat.fighters[s->party.controlActor].speed*128/
        (s->combat.fighters[target].speed?s->combat.fighters[target].speed:1)+30*s->runAttempts;
    s->capture.random=s->capture.random*0x41c64e6du+0x6073u;
    if(s->combat.fighters[s->party.controlActor].speed>=s->combat.fighters[target].speed
        ||chance>255||(s->capture.random>>24)<chance)Result(s,BATTLE_RESULT_PLAYER_FLED);
    else{Resume(s);s->capture.message="Could not get away!";s->capture.notice=90;}
}
static void Input(ArenaSession *s,u32 held,u32 pressed,u32 repeat)
{
    unsigned count;
    if(s->mode==SESSION_FADE_IN){if(IsScreenFadeDone()){if(s->practice){s->mode=SESSION_PRACTICE;s->choice=0;PracticeText(s);}else Resume(s);}return;}
    if(s->mode==SESSION_FADE_OUT)return;
    if(s->mode!=SESSION_FIGHT&&(pressed&(PAD_BUTTON_A|PAD_BUTTON_B|PAD_KEY_UP|PAD_KEY_DOWN)))
        Sound_PlayEffect(SE_CONFIRM_sseq_3);
    if(s->mode==SESSION_NOTICE){
        if(pressed&(PAD_BUTTON_A|PAD_BUTTON_B|PAD_BUTTON_START))ReturnFromNotice(s);
        return;
    }
    if(s->mode==SESSION_CONTROLS){
        if(repeat&PAD_KEY_UP)s->choice=(s->choice+7)%8;
        if(repeat&PAD_KEY_DOWN)s->choice=(s->choice+1)%8;
        if(s->choice<ARENA_CONTROL_COUNT){
            if(repeat&PAD_KEY_LEFT)ArenaControls_Cycle(s->choice,-1);
            if(repeat&PAD_KEY_RIGHT)ArenaControls_Cycle(s->choice,1);
        }
        if((pressed&PAD_BUTTON_A)&&s->choice==6)ArenaControls_Reset();
        if((pressed&(PAD_BUTTON_B|PAD_BUTTON_START))||((pressed&PAD_BUTTON_A)&&s->choice==7)){
            s->mode=s->settingsReturn;s->choice=s->mode==SESSION_PRACTICE?7:4;
            if(s->mode==SESSION_PRACTICE)PracticeText(s);else PauseText(s);return;
        }
        ControlsText(s);return;
    }
    if(s->mode==SESSION_PRACTICE){
        int change=(repeat&PAD_KEY_LEFT)?-1:(repeat&PAD_KEY_RIGHT)?1:0;
        if(repeat&PAD_KEY_UP)s->choice=(s->choice+8)%9;
        if(repeat&PAD_KEY_DOWN)s->choice=(s->choice+1)%9;
        if(pressed&PAD_BUTTON_L)change=-25;
        if(pressed&PAD_BUTTON_R)change=25;
        if(s->choice>=1&&s->choice<=4&&change){
            int dex=(int)s->practiceDex[s->choice-1]-1+change;
            while(dex<0)dex+=493;
            s->practiceDex[s->choice-1]=1+dex%493;
        }else if(s->choice==0&&change){
            unsigned mode=s->practiceDoubles|(s->practiceClash?2:0);
            mode=(mode+(change<0?3:1))&3;
            s->practiceDoubles=mode&1;s->practiceClash=!!(mode&2);
        }
        else if(s->choice==5&&change)s->practiceBackground^=1;
        else if(s->choice==6&&change){
            int level=s->practiceLevel+(change<0?-5:5);
            s->practiceLevel=level<5?100:level>100?5:level;
        }
        if(pressed&PAD_BUTTON_B){ExitPractice(s);return;}
        if((pressed&PAD_BUTTON_A)&&s->choice==7){
            s->settingsReturn=SESSION_PRACTICE;s->mode=SESSION_CONTROLS;s->choice=0;ControlsText(s);return;
        }
        if((pressed&PAD_BUTTON_START)||((pressed&PAD_BUTTON_A)&&s->choice==8)){
            if(StartPractice(s))Resume(s);else ExitPractice(s);return;
        }
        PracticeText(s);return;
    }
    if(s->mode==SESSION_RESULT){
        if(pressed&(PAD_BUTTON_A|PAD_BUTTON_B)){
            if(s->practice){Finish(s);return;}
            if(NextLearn(s)){s->mode=SESSION_LEARN;s->choice=4;LearnText(s);}else Finish(s);
        }return;
    }
    if(s->mode==SESSION_LEARN){
        if(repeat&PAD_KEY_UP)s->choice=(s->choice+4)%5;
        if(repeat&PAD_KEY_DOWN)s->choice=(s->choice+1)%5;
        if(pressed&PAD_BUTTON_B)s->choice=4;
        if(pressed&PAD_BUTTON_A){
            ArenaRewards_ResolveMove(s->dto,s->learnIndex,s->choice==4?-1:s->choice);
            /* Keep final HP/PP synchronization from restoring the old moves. */
            ArenaParty_Refresh(&s->party);
            /* ResolveMove compacts the queue; the next choice is this index. */
            s->choice=4;
            if(!NextLearn(s)){Finish(s);return;}
        }
        LearnText(s);return;
    }
    if(s->mode==SESSION_PAUSE){
        if(repeat&PAD_KEY_UP)s->choice=(s->choice+4)%5;
        if(repeat&PAD_KEY_DOWN)s->choice=(s->choice+1)%5;
        if(pressed&(PAD_BUTTON_B|PAD_BUTTON_START)){Resume(s);return;}
        if(pressed&PAD_BUTTON_A){
            if(s->choice==0){Resume(s);return;}
            if(s->choice==1){s->mode=SESSION_PARTY;s->partyChoice=s->party.actor[s->party.controlActor].owner==0?s->party.actor[s->party.controlActor].slot:0;PartyText(s);return;}
            if(s->choice==2){s->mode=SESSION_ITEMS;s->itemChoice=0;ItemText(s);return;}
            if(s->choice==3){if(s->practice){s->mode=SESSION_PRACTICE;s->choice=8;PracticeText(s);}else TryRun(s);return;}
            if(s->choice==4){s->settingsReturn=SESSION_PAUSE;s->mode=SESSION_CONTROLS;s->choice=0;ControlsText(s);return;}
        }
        PauseText(s);return;
    }
    if(s->mode==SESSION_PARTY||s->mode==SESSION_ITEM_TARGET){
        count=Party_GetCurrentCount(s->dto->parties[0]);
        if(!count){Notice(s,"There are no Pokemon to select.",SESSION_PAUSE);return;}
        if(repeat&PAD_KEY_UP)s->partyChoice=(s->partyChoice+count-1)%count;
        if(repeat&PAD_KEY_DOWN)s->partyChoice=(s->partyChoice+1)%count;
        if(pressed&PAD_BUTTON_B){s->mode=SESSION_PAUSE;PauseText(s);return;}
        if(pressed&PAD_BUTTON_A){
            if(s->mode==SESSION_ITEM_TARGET){
                if(sMedicine[s->itemChoice]==ITEM_ETHER){
                    s->mode=SESSION_ITEM_MOVE;s->choice=0;ItemMoveText(s);return;
                }
                UseMedicine(s,0);return;
            }
            if(ArenaParty_SwitchPlayer(&s->party,s->partyChoice)){
                LoadActors(s);Resume(s);return;
            }
            Notice(s,"That Pokemon cannot battle now.",SESSION_PARTY);return;
        }
        PartyText(s);return;
    }
    if(s->mode==SESSION_ITEM_MOVE){
        if(repeat&PAD_KEY_UP)s->choice=(s->choice+3)%4;
        if(repeat&PAD_KEY_DOWN)s->choice=(s->choice+1)%4;
        if(pressed&PAD_BUTTON_B){s->mode=SESSION_ITEM_TARGET;PartyText(s);return;}
        if(pressed&PAD_BUTTON_A){UseMedicine(s,s->choice);return;}
        ItemMoveText(s);return;
    }
    if(s->mode==SESSION_ITEMS){
        count=sizeof(sMedicine)/sizeof(sMedicine[0]);
        if(repeat&PAD_KEY_UP)s->itemChoice=(s->itemChoice+count-1)%count;
        if(repeat&PAD_KEY_DOWN)s->itemChoice=(s->itemChoice+1)%count;
        if(pressed&PAD_BUTTON_B){s->mode=SESSION_PAUSE;PauseText(s);return;}
        if(pressed&PAD_BUTTON_A){
            if(!Bag_GetItemQuantity(s->dto->bag,sMedicine[s->itemChoice],HEAP_ID_BATTLE)){
                Notice(s,"You have none of that item left.",SESSION_ITEMS);return;
            }
            s->mode=SESSION_ITEM_TARGET;s->partyChoice=0;PartyText(s);return;
        }
        ItemText(s);return;
    }
    if((pressed&PAD_BUTTON_START)&&s->capture.phase==ARENA_CAPTURE_IDLE){
        ArenaParty_Store(&s->party);s->mode=SESSION_PAUSE;s->choice=0;PauseText(s);return;
    }
    {
        u32 now=gSystem.vblankCounter,due=now-s->lastTick,i;
        s->lastTick=now;if(due<1)due=1;if(due>3)due=3;
        for(i=0;i<due;i++){
            CombatInput input=ArenaControls_Map(held,i?0:pressed);
            if(ArenaCapture_Process(&s->capture,held,i?0:pressed,&input)){
                Combat_Tick(&s->combat,input);
                ArenaParty_Advance(&s->party);
            }
            if(s->capture.finished){Result(s,BATTLE_RESULT_CAPTURED_MON);break;}
            if(s->party.result){Result(s,s->party.result);break;}
        }
        if(s->mode==SESSION_FIGHT)ArenaRender_SetMessage(s->render,s->capture.notice?s->capture.message:NULL);
        if(!s->capture.finished&&!LoadActors(s)){
            /* The packaged metadata covers every canonical species/form. A
             * missing bank cannot be treated as a win or progress reward. */
            Result(s,BATTLE_RESULT_LOSE);
        }
    }
}
int ArenaSession_Run(ApplicationManager *appMan)
{
    ArenaSession *s=ApplicationManager_Data(appMan);
    if(s==NULL){
        u32 freeBytes=HeapExp_FndGetTotalFreeSize(HEAP_ID_APPLICATION);
        u32 largestBlock=ArenaHeap_MaxAllocatableSize(HEAP_ID_APPLICATION);
        /* Use the room actually available for four pose pools and the native
         * presentation instead of dropping straight to the minimum heap.
         * Leave 16 KiB to the application and round the child budget down. */
        u32 heapBytes=freeBytes>0x4000?(freeBytes-0x4000)&~0xFFFu:0;
        if(heapBytes>0xF0000)heapBytes=0xF0000;
        if(heapBytes>largestBlock)heapBytes=largestBlock&~0xFFFu;
        if(heapBytes<0xB0000)return -1;
        if(!Heap_Create(HEAP_ID_APPLICATION,HEAP_ID_BATTLE,heapBytes)){
            /* Total free memory can be fragmented. Keep the previous minimum
             * as a fallback where the allocator reports failure cleanly. */
            if(heapBytes==0xB0000||!Heap_Create(HEAP_ID_APPLICATION,HEAP_ID_BATTLE,0xB0000))return -1;
        }
        s=ApplicationManager_NewData(appMan,sizeof(*s),HEAP_ID_BATTLE);memset(s,0,sizeof(*s));
        memset(s->loadedOwner,0xff,sizeof(s->loadedOwner));
        memset(s->loadedSlot,0xff,sizeof(s->loadedSlot));
        s->dto=ApplicationManager_Args(appMan);
        s->practice=sPracticeApplication;
        if(s->practice){
            memcpy(s->practiceDex,sPracticeInitial,sizeof(s->practiceDex));
            s->practiceLevel=50;
        }
        if(!ArenaParty_Begin(&s->party,s->dto,&s->combat)){
            ApplicationManager_FreeData(appMan);Heap_Destroy(HEAP_ID_BATTLE);return -1;
        }
        if(!s->practice){ArenaRewards_Begin(s->dto);ArenaParty_SetDefeatCallback(&s->party,Defeated,s);}
        SetVBlankCallback(NULL,NULL);DisableHBlank();SetHBlankCallback(NULL,NULL);
        s->render=ArenaRender_New(HEAP_ID_BATTLE,
            s->dto->background>=BACKGROUND_INDOORS_1&&s->dto->background<=BACKGROUND_INDOORS_3?1:0);
        if(!s->render||!LoadActors(s)){
            if(s->render)ArenaRender_Free(s->render);
            ApplicationManager_FreeData(appMan);Heap_Destroy(HEAP_ID_BATTLE);return -1;
        }
        ApplyControlLabels(s);
        ArenaCapture_Init(&s->capture,&s->party,s->dto->seed^0xA7E39091u,gSystem.heldKeysRaw);
        s->started=s->lastTick=gSystem.vblankCounter;s->mode=SESSION_FADE_IN;
        SetVBlankCallback(VBlank,s);
        ArenaRender_Draw(s->render,&s->combat);
        StartScreenFade(FADE_BOTH_SCREENS,FADE_TYPE_BRIGHTNESS_IN,FADE_TYPE_BRIGHTNESS_IN,
            COLOR_BLACK,6,1,HEAP_ID_BATTLE);return 0;
    }
    if(s->mode==SESSION_FADE_OUT&&IsScreenFadeDone()){
        SetVBlankCallback(NULL,NULL);
        ArenaRender_Free(s->render);s->render=NULL;
        ApplicationManager_FreeData(appMan);Heap_Destroy(HEAP_ID_BATTLE);return 1;
    }
    s->age++;
    Input(s,gSystem.heldKeysRaw,gSystem.pressedKeysRaw,
        gSystem.pressedKeysRepeatableRaw|gSystem.pressedKeysRaw);
    SoundEvents(s);
    UpdatePartyStatus(s);
    ArenaRender_SetCapture(s->render,s->capture.phase,s->capture.target,s->capture.aimX,
        s->capture.aimY,s->capture.ballX,s->capture.ballY,s->capture.age);
    ArenaRender_Draw(s->render,&s->combat);
    return 0;
}

extern const ApplicationManagerTemplate Unk_020F8AB4;
static BOOL PracticeApp_Init(ApplicationManager *appMan,int *state)
{
    FieldBattleDTO *dto=FieldBattleDTO_New(HEAP_ID_APPLICATION,BATTLE_TYPE_TRAINER);
    (void)state;sPracticeApplication=TRUE;
    Sound_SetSceneAndPlayBGM(SOUND_SCENE_BATTLE,BATTLE_WILD_POKEMON_sseq,1);
    appMan->args=dto;
    PracticeTeam(dto,sPracticeInitial,0,50,0);
    Bag_TryAddItem(dto->bag,ITEM_POTION,99,HEAP_ID_APPLICATION);
    Bag_TryAddItem(dto->bag,ITEM_MAX_POTION,99,HEAP_ID_APPLICATION);
    Bag_TryAddItem(dto->bag,ITEM_REVIVE,99,HEAP_ID_APPLICATION);
    Bag_TryAddItem(dto->bag,ITEM_ELIXIR,99,HEAP_ID_APPLICATION);
    return TRUE;
}
static BOOL PracticeApp_Main(ApplicationManager *appMan,int *state)
{(void)state;return ArenaSession_Run(appMan)!=0;}
static BOOL PracticeApp_Exit(ApplicationManager *appMan,int *state)
{
    (void)state;FieldBattleDTO_Free(ApplicationManager_Args(appMan));appMan->args=NULL;
    Sound_SetScene(SOUND_SCENE_NONE);
    sPracticeApplication=FALSE;EnqueueApplication(FS_OVERLAY_ID_NONE,&Unk_020F8AB4);return TRUE;
}
const ApplicationManagerTemplate gArenaPracticeAppTemplate={
    PracticeApp_Init,PracticeApp_Main,PracticeApp_Exit,FS_OVERLAY_ID_NONE
};
