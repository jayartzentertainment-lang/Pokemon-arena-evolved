#include "arena/party_bridge.h"

#include <string.h>

#include "pokemon.h"

static unsigned Clamp(unsigned value, unsigned maximum)
{
    return value > maximum ? maximum : value;
}

static Pokemon *OwnerPokemon(const ArenaPartyBridge *bridge, unsigned owner, unsigned slot)
{
    Party *party;

    if (bridge == NULL || bridge->dto == NULL || owner >= MAX_BATTLERS) {
        return NULL;
    }
    party = bridge->dto->parties[owner];
    if (party == NULL || slot >= MAX_PARTY_SIZE || slot >= (unsigned)Party_GetCurrentCount(party)) {
        return NULL;
    }
    return Party_GetPokemonBySlotIndex(party, slot);
}

Pokemon *ArenaParty_ActorPokemon(const ArenaPartyBridge *bridge, unsigned actor)
{
    if (bridge == NULL || actor >= bridge->actorCount || !bridge->actor[actor].active) {
        return NULL;
    }
    return OwnerPokemon(bridge, bridge->actor[actor].owner, bridge->actor[actor].slot);
}

static BOOL Healthy(Pokemon *mon)
{
    return mon != NULL
        && Pokemon_GetValue(mon, MON_DATA_SPECIES, NULL) != 0
        && Pokemon_GetValue(mon, MON_DATA_IS_EGG, NULL) == 0
        && Pokemon_GetValue(mon, MON_DATA_HP, NULL) != 0;
}

static BOOL Deployed(const ArenaPartyBridge *bridge, unsigned owner, unsigned slot)
{
    unsigned i;

    for (i = 0; i < bridge->actorCount; i++) {
        if (bridge->actor[i].active && bridge->actor[i].owner == owner
            && bridge->actor[i].slot == slot) {
            return TRUE;
        }
    }
    return FALSE;
}

static unsigned Reserve(const ArenaPartyBridge *bridge, unsigned owner)
{
    unsigned slot;

    for (slot = 0; slot < MAX_PARTY_SIZE; slot++) {
        if (!Deployed(bridge, owner, slot) && Healthy(OwnerPokemon(bridge, owner, slot))) {
            return slot;
        }
    }
    return ARENA_PARTY_SLOT_NONE;
}

static void Configuration(Pokemon *mon, CombatFighterConfig *config)
{
    unsigned i;

    memset(config, 0, sizeof(*config));
    config->species = Pokemon_GetValue(mon, MON_DATA_SPECIES, NULL);
    config->hp = Clamp(Pokemon_GetValue(mon, MON_DATA_MAX_HP, NULL) * ARENA_PARTY_HP_SCALE, 8191);
    config->attack = Clamp(Pokemon_GetValue(mon, MON_DATA_ATK, NULL) * ARENA_PARTY_STAT_SCALE, 2047);
    config->defense = Clamp(Pokemon_GetValue(mon, MON_DATA_DEF, NULL) * ARENA_PARTY_STAT_SCALE, 2047);
    config->spAttack = Clamp(Pokemon_GetValue(mon, MON_DATA_SP_ATK, NULL) * ARENA_PARTY_STAT_SCALE, 2047);
    config->spDefense = Clamp(Pokemon_GetValue(mon, MON_DATA_SP_DEF, NULL) * ARENA_PARTY_STAT_SCALE, 2047);
    config->speed = Clamp(Pokemon_GetValue(mon, MON_DATA_SPEED, NULL), 255);
    config->types[0] = Pokemon_GetValue(mon, MON_DATA_TYPE_1, NULL);
    config->types[1] = Pokemon_GetValue(mon, MON_DATA_TYPE_2, NULL);
    for (i = 0; i < 4; i++) {
        /* Keep native IDs, even when their full scripted effect is unavailable. */
        config->moves[i] = Pokemon_GetValue(mon, MON_DATA_MOVE1 + i, NULL);
    }
}

static void ImportState(ArenaPartyBridge *bridge, unsigned actor, BOOL newlyBound)
{
    ArenaPartyActor *binding = &bridge->actor[actor];
    ArenaPartyMember *member;
    CombatFighter *fighter = &bridge->combat->fighters[actor];
    CombatFighterConfig config;
    Pokemon *mon = ArenaParty_ActorPokemon(bridge, actor);
    u16 nativeHp;
    u16 nativeMaxHp;
    u8 pp[4];
    unsigned i;

    if (mon == NULL) {
        fighter->hp = 0;
        return;
    }
    Configuration(mon, &config);
    member = &bridge->member[binding->owner][binding->slot];
    nativeHp = Pokemon_GetValue(mon, MON_DATA_HP, NULL);
    nativeMaxHp = Pokemon_GetValue(mon, MON_DATA_MAX_HP, NULL);
    if (!member->initialized || nativeHp != member->nativeHp || nativeMaxHp != member->nativeMaxHp) {
        member->hp = Clamp(nativeHp * ARENA_PARTY_HP_SCALE, config.hp);
    }
    if (!member->initialized) {
        member->stamina = COMBAT_STAMINA_MAX;
        member->regenDelay = 0;
        member->dashCooldown = 0;
    }
    member->initialized = TRUE;
    member->nativeHp = nativeHp;
    member->nativeMaxHp = nativeMaxHp;
    fighter->species = config.species;
    fighter->maxHp = config.hp;
    fighter->hp = member->hp;
    fighter->attack = config.attack;
    fighter->defense = config.defense;
    fighter->spAttack = config.spAttack;
    fighter->spDefense = config.spDefense;
    fighter->speed = config.speed;
    fighter->types[0] = config.types[0];
    fighter->types[1] = config.types[1];
    binding->level = Pokemon_GetValue(mon, MON_DATA_LEVEL, NULL);
    binding->form = Pokemon_GetValue(mon, MON_DATA_FORM, NULL);
    binding->ability = Pokemon_GetValue(mon, MON_DATA_ABILITY, NULL);
    binding->heldItem = Pokemon_GetValue(mon, MON_DATA_HELD_ITEM, NULL);
    binding->status = Pokemon_GetValue(mon, MON_DATA_STATUS, NULL);
    for (i = 0; i < 4; i++) {
        fighter->moves[i] = config.moves[i];
        pp[i] = Pokemon_GetValue(mon, MON_DATA_MOVE1_PP + i, NULL);
        binding->moves[i] = config.moves[i];
        binding->pp[i] = pp[i];
        binding->ppUps[i] = Pokemon_GetValue(mon, MON_DATA_MOVE1_PP_UPS + i, NULL);
    }
    Combat_SetMovePP(bridge->combat, actor, pp);
    if (newlyBound) {
        fighter->stamina = member->stamina;
        fighter->regenDelay = member->regenDelay;
        fighter->dashCooldown = member->dashCooldown;
    }
}

static void Participation(ArenaPartyBridge *bridge)
{
    unsigned actor;
    u32 mask = 0;

    for (actor = 0; actor < bridge->actorCount; actor += 2) {
        if (bridge->actor[actor].active && bridge->actor[actor].owner == 0
            && bridge->combat->fighters[actor].hp != 0) {
            mask |= 1u << bridge->actor[actor].slot;
        }
    }
    for (actor = 1; actor < bridge->actorCount; actor += 2) {
        ArenaPartyActor *binding = &bridge->actor[actor];
        if (binding->active && bridge->combat->fighters[actor].hp != 0) {
            bridge->playerParticipants[binding->owner][binding->slot] |= mask;
        }
    }
}

BOOL ArenaParty_Begin(ArenaPartyBridge *bridge, FieldBattleDTO *dto, Combat *combat)
{
    CombatFighterConfig config[COMBAT_FIGHTERS];
    unsigned actor;
    BOOL doubles;

    if (bridge == NULL || dto == NULL || combat == NULL) {
        return FALSE;
    }
    memset(bridge, 0, sizeof(*bridge));
    memset(config, 0, sizeof(config));
    bridge->dto = dto;
    bridge->combat = combat;
    doubles = (dto->battleType & BATTLE_TYPE_DOUBLES) != 0;
    bridge->actorCount = doubles ? COMBAT_FIGHTERS : 2;
    for (actor = 0; actor < COMBAT_FIGHTERS; actor++) {
        ArenaPartyActor *binding = &bridge->actor[actor];
        unsigned slot;
        binding->owner = actor & 1;
        binding->slot = ARENA_PARTY_SLOT_NONE;
        if (actor >= bridge->actorCount) {
            continue;
        }
        if (dto->battleType & BATTLE_TYPE_2vs2) {
            binding->owner = actor;
        } else if ((dto->battleType & BATTLE_TYPE_TAG) && actor == 3) {
            binding->owner = 3;
        }
        slot = Reserve(bridge, binding->owner);
        if (slot != ARENA_PARTY_SLOT_NONE) {
            binding->active = TRUE;
            binding->slot = slot;
            Configuration(OwnerPokemon(bridge, binding->owner, slot), &config[actor]);
        }
    }
    if (!bridge->actor[0].active || !bridge->actor[1].active) {
        return FALSE;
    }
    if (doubles) {
        Combat_InitTeams(combat, config);
    } else {
        Combat_Init(combat, config);
    }
    bridge->begun = TRUE;
    for (actor = 0; actor < bridge->actorCount; actor++) {
        ImportState(bridge, actor, TRUE);
    }
    Combat_SetControlledFighter(combat, 0);
    Participation(bridge);
    return TRUE;
}

void ArenaParty_SetDefeatCallback(ArenaPartyBridge *bridge, ArenaPartyDefeatCallback callback, void *context)
{
    bridge->onDefeat = callback;
    bridge->defeatContext = context;
}

void ArenaParty_Store(ArenaPartyBridge *bridge)
{
    unsigned actor;

    if (bridge == NULL || !bridge->begun) {
        return;
    }
    for (actor = 0; actor < bridge->actorCount; actor++) {
        Pokemon *mon = ArenaParty_ActorPokemon(bridge, actor);
        ArenaPartyActor *binding = &bridge->actor[actor];
        CombatFighter *fighter = &bridge->combat->fighters[actor];
        ArenaPartyMember *member;
        u16 hp;
        unsigned i;

        if (mon == NULL) {
            continue;
        }
        member = &bridge->member[binding->owner][binding->slot];
        member->hp = fighter->hp;
        hp = (fighter->hp + ARENA_PARTY_HP_SCALE - 1) / ARENA_PARTY_HP_SCALE;
        hp = Clamp(hp, member->nativeMaxHp);
        member->stamina = fighter->stamina;
        member->regenDelay = fighter->regenDelay;
        member->dashCooldown = fighter->dashCooldown;
        if (hp != member->nativeHp) {
            Pokemon_SetValue(mon, MON_DATA_HP, &hp);
            member->nativeHp = hp;
        }
        for (i = 0; i < 4; i++) {
            /* Never write a controller fallback ID over an original move. */
            if (fighter->moves[i] == binding->moves[i] && fighter->pp[i] != binding->pp[i]) {
                u8 pp = fighter->pp[i];
                Pokemon_SetValue(mon, MON_DATA_MOVE1_PP + i, &pp);
                binding->pp[i] = pp;
            }
        }
    }
}

void ArenaParty_Refresh(ArenaPartyBridge *bridge)
{
    unsigned actor;

    if (bridge == NULL || !bridge->begun) {
        return;
    }
    for (actor = 0; actor < bridge->actorCount; actor++) {
        ImportState(bridge, actor, FALSE);
    }
    Participation(bridge);
}

static BOOL Deploy(ArenaPartyBridge *bridge, unsigned actor, unsigned slot)
{
    ArenaPartyActor *binding = &bridge->actor[actor];
    CombatFighterConfig config;
    Pokemon *mon = OwnerPokemon(bridge, binding->owner, slot);

    if (!Healthy(mon) || Deployed(bridge, binding->owner, slot)) {
        return FALSE;
    }
    Configuration(mon, &config);
    if (!Combat_ReplaceFighter(bridge->combat, actor, &config)) {
        return FALSE;
    }
    binding->slot = slot;
    binding->active = TRUE;
    ImportState(bridge, actor, TRUE);
    return TRUE;
}

int ArenaParty_Advance(ArenaPartyBridge *bridge)
{
    unsigned actor;
    BOOL alive[2] = { FALSE, FALSE };
    BOOL rewarded = FALSE;

    if (bridge == NULL || !bridge->begun || bridge->result != BATTLE_IN_PROGRESS) {
        return bridge != NULL ? bridge->result : BATTLE_IN_PROGRESS;
    }
    ArenaParty_Store(bridge);
    for (actor = 1; actor < bridge->actorCount; actor += 2) {
        ArenaPartyActor *binding = &bridge->actor[actor];
        ArenaPartyMember *member;
        if (!binding->active || bridge->combat->fighters[actor].hp != 0) {
            continue;
        }
        member = &bridge->member[binding->owner][binding->slot];
        if (!member->defeatReported) {
            member->defeatReported = TRUE;
            if (bridge->onDefeat != NULL) {
                bridge->onDefeat(bridge->defeatContext, actor, binding->owner, binding->slot,
                    ArenaParty_ActorPokemon(bridge, actor), bridge->playerParticipants[binding->owner][binding->slot]);
                rewarded = TRUE;
            }
        }
    }
    /* Rewards can raise levels and learn moves. Import their actual values. */
    if (rewarded) {
        ArenaParty_Refresh(bridge);
    }
    for (actor = 0; actor < bridge->actorCount; actor++) {
        unsigned slot;
        if (bridge->combat->fighters[actor].hp != 0) {
            continue;
        }
        slot = Reserve(bridge, bridge->actor[actor].owner);
        if (slot != ARENA_PARTY_SLOT_NONE) {
            Deploy(bridge, actor, slot);
        }
    }
    for (actor = 0; actor < bridge->actorCount; actor++) {
        if (bridge->actor[actor].active && bridge->combat->fighters[actor].hp != 0) {
            alive[actor & 1] = TRUE;
        }
    }
    if (!alive[0] || !alive[1]) {
        bridge->result = !alive[0] && !alive[1] ? BATTLE_RESULT_DRAW
            : alive[0] ? BATTLE_RESULT_WIN : BATTLE_RESULT_LOSE;
        bridge->combat->winner = alive[0] ? 1 : 2;
    } else {
        /* Core sees only deployed actors; reserve waves keep the battle live. */
        bridge->combat->winner = 0;
    }
    if (bridge->combat->fighters[bridge->controlActor].hp == 0) {
        for (actor = 0; actor < bridge->actorCount; actor += 2) {
            if (bridge->combat->fighters[actor].hp != 0) {
                bridge->controlActor = actor;
                Combat_SetControlledFighter(bridge->combat, actor);
                break;
            }
        }
    }
    Participation(bridge);
    return bridge->result;
}

BOOL ArenaParty_PlayerSlotAvailable(const ArenaPartyBridge *bridge, unsigned slot)
{
    return Healthy(OwnerPokemon(bridge, 0, slot));
}

BOOL ArenaParty_SwitchPlayer(ArenaPartyBridge *bridge, unsigned slot)
{
    unsigned actor;
    unsigned target;

    if (bridge == NULL || !bridge->begun || bridge->result) {
        return FALSE;
    }
    ArenaParty_Store(bridge);
    if (!ArenaParty_PlayerSlotAvailable(bridge, slot)) {
        return FALSE;
    }
    for (actor = 0; actor < bridge->actorCount; actor += 2) {
        if (bridge->actor[actor].active && bridge->actor[actor].owner == 0
            && bridge->actor[actor].slot == slot) {
            bridge->controlActor = actor;
            Combat_SetControlledFighter(bridge->combat, actor);
            return TRUE;
        }
    }
    target = bridge->controlActor;
    if (bridge->actor[target].owner != 0) {
        target = 0;
    }
    if (!Deploy(bridge, target, slot)) {
        return FALSE;
    }
    bridge->controlActor = target;
    Combat_SetControlledFighter(bridge->combat, target);
    Participation(bridge);
    return TRUE;
}

u32 ArenaParty_PlayerParticipants(const ArenaPartyBridge *bridge, unsigned owner, unsigned slot)
{
    if (bridge == NULL || owner >= MAX_BATTLERS || slot >= MAX_PARTY_SIZE) {
        return 0;
    }
    return bridge->playerParticipants[owner][slot];
}
