/* Native portable DS battle simulation, authored for this port.
 * Reuses the supplied Emerald Arena move geometry, navigation, physics and
 * Arena Plus momentum helpers; copied modules retain original provenance.
 * This action ruleset implements damage, drain and Protect. Native Gen IV move categories and PP are preserved; complex scripted effects
 * use bounded action adapters rather than the turn-based script interpreter.
 */
#include "arena/combat.h"
#include "arena/move_data.h"
#include "arena/vendor/arena_moves.h"
#include "arena/vendor/arena_navigation.h"
#include "arena/vendor/arena_physics.h"
#include "arena/vendor/arena_plus.h"
#include "arena/vendor/constants/moves.h"
#include <string.h>
#define Q 256
#define RGB(r,g,b) ((r)|((g)<<5)|((b)<<10))
static const int16_t sDirections[8][2] = {
    {0,256},{181,181},{256,0},{181,-181},
    {0,-256},{-181,-181},{-256,0},{-181,181}
};
static int32_t Abs(int32_t x) { return x<0?-x:x; }
static int32_t Clamp(int32_t x,int32_t lo,int32_t hi) { return x<lo?lo:x>hi?hi:x; }
static int Sign(int32_t x) { return x>0?1:x<0?-1:0; }
static uint16_t NextRandom(Combat *c) { c->random=c->random*1664525u+1013904223u; return c->random>>16; }
static uint8_t Facing(int32_t dx,int32_t dy)
{
    if(Abs(dx)>Abs(dy)*2) return dx>0?COMBAT_E:COMBAT_W;
    if(Abs(dy)>Abs(dx)*2) return dy>0?COMBAT_S:COMBAT_N;
    if(!dx&&!dy) return COMBAT_S;
    return dx>0?(dy>0?COMBAT_SE:COMBAT_NE):(dy>0?COMBAT_SW:COMBAT_NW);
}
static int Enemies(unsigned one,unsigned two) { return (one&1)!=(two&1); }
unsigned Combat_TargetFighter(const Combat *c,unsigned side)
{
    unsigned target=COMBAT_FIGHTERS,i;
    int32_t best=0x7fffffff;
    if(!c||side>=c->fighterCount) return target;
    for(i=0;i<c->fighterCount;i++) if(Enemies(side,i)&&c->fighters[i].hp) {
        int32_t dx=(c->fighters[i].x-c->fighters[side].x)/Q;
        int32_t dy=(c->fighters[i].y-c->fighters[side].y)/Q;
        int32_t distance=dx*dx+dy*dy;
        if(distance<best) { best=distance;target=i; }
    }
    return target;
}
const CombatMoveInfo *Combat_GetMoveInfo(uint16_t move)
{ return ArenaPlatinum_GetMoveInfo(move); }
void Combat_SetMovePP(Combat *c,unsigned side,const uint8_t pp[4])
{
    unsigned i;
    if(!c||!pp||side>=c->fighterCount) return;
    for(i=0;i<4;i++) c->fighters[side].pp[i]=c->fighters[side].moves[i]?pp[i]:0;
}
uint16_t Combat_TypeColor(uint8_t type)
{
    static const uint16_t colors[18]={
        RGB(29,27,21),RGB(29,12,7),RGB(17,22,31),RGB(23,10,28),
        RGB(25,18,8),RGB(24,23,14),RGB(20,28,6),RGB(16,10,26),
        RGB(22,25,28),RGB(24,24,24),RGB(31,12,2),RGB(6,21,31),
        RGB(10,29,9),RGB(31,29,3),RGB(31,9,23),RGB(17,31,31),
        RGB(15,12,31),RGB(16,14,17)
    };
    return colors[type<18?type:0];
}
/* Gen IV retains these type IDs and Steel resistance to
 * Ghost/Dark. Immunities take precedence over dual-type resistance. */
#define T(n) (1u<<(n))
static uint16_t TypeSingle(uint8_t attack,uint8_t defense)
{
    uint32_t weak=0,resist=0,immune=0;
    switch(attack) {
    case 0: resist=T(5)|T(8); immune=T(7); break;
    case 1: weak=T(0)|T(5)|T(8)|T(15)|T(17);resist=T(2)|T(3)|T(6)|T(14);immune=T(7);break;
    case 2: weak=T(1)|T(6)|T(12);resist=T(5)|T(8)|T(13);break;
    case 3: weak=T(12);resist=T(3)|T(4)|T(5)|T(7);immune=T(8);break;
    case 4: weak=T(3)|T(5)|T(8)|T(10)|T(13);resist=T(6)|T(12);immune=T(2);break;
    case 5: weak=T(2)|T(6)|T(10)|T(15);resist=T(1)|T(4)|T(8);break;
    case 6: weak=T(12)|T(14)|T(17);resist=T(1)|T(2)|T(3)|T(7)|T(8)|T(10);break;
    case 7: weak=T(7)|T(14);resist=T(8)|T(17);immune=T(0);break;
    case 8: weak=T(5)|T(15);resist=T(8)|T(10)|T(11)|T(13);break;
    case 10:weak=T(6)|T(8)|T(12)|T(15);resist=T(5)|T(10)|T(11)|T(16);break;
    case 11:weak=T(4)|T(5)|T(10);resist=T(11)|T(12)|T(16);break;
    case 12:weak=T(4)|T(5)|T(11);resist=T(2)|T(3)|T(6)|T(8)|T(10)|T(12)|T(16);break;
    case 13:weak=T(2)|T(11);resist=T(12)|T(13)|T(16);immune=T(4);break;
    case 14:weak=T(1)|T(3);resist=T(8)|T(14);immune=T(17);break;
    case 15:weak=T(2)|T(4)|T(12)|T(16);resist=T(8)|T(10)|T(11)|T(15);break;
    case 16:weak=T(16);resist=T(8);break;
    case 17:weak=T(7)|T(14);resist=T(1)|T(8)|T(17);break;
    default:break;
    }
    if(defense>=18) return Q;
    if(immune&T(defense)) return 0;
    return weak&T(defense)?512:resist&T(defense)?128:256;
}
#undef T
uint16_t Combat_TypeMultiplier(uint8_t attack,uint8_t one,uint8_t two)
{
    uint16_t result=TypeSingle(attack,one);
    return two==one?result:result*TypeSingle(attack,two)/Q;
}
static CombatEffect *Effect(Combat *c,int32_t x,int32_t y,uint16_t color,uint8_t kind,uint8_t radius)
{
    CombatEffect *e;
    unsigned i;
    for(i=0;i<COMBAT_EFFECTS;i++) if(!c->effects[i].life) break;
    if(i==COMBAT_EFFECTS) i=c->effectCursor++%COMBAT_EFFECTS;
    e=&c->effects[i];
    e->x=x;e->y=y;e->kind=kind;e->color=color;e->radius=radius;
    e->life=e->maxLife=kind==COMBAT_SPARK?14:kind==COMBAT_CLASH?24:kind==COMBAT_DASH_TRAIL?10:18;
    e->vx=kind==COMBAT_SPARK?(int16_t)((NextRandom(c)&511)-256):0;
    e->vy=kind==COMBAT_SPARK?(int16_t)(-100-(NextRandom(c)&255)):0;
    e->direction=COMBAT_S;
    return e;
}
static void Burst(Combat *c,int32_t x,int32_t y,uint16_t color)
{
    unsigned i;
    Effect(c,x,y,color,COMBAT_RING,3);
    for(i=0;i<5;i++) Effect(c,x,y,color,COMBAT_SPARK,1);
}
static void Impact(Combat *c,uint8_t kind,unsigned actor,int32_t x,int32_t y)
{
    c->impactSerial++;c->impactKind=kind;c->impactActor=(uint8_t)actor;
    c->impactX=x;c->impactY=y;c->impactTimer=kind==COMBAT_IMPACT_CRITICAL?22:18;
}
static void Clash(Combat *c,int32_t x,int32_t y)
{
    c->clashes++;c->hitstop=3;
    Burst(c,x,y,RGB(31,31,31));
    Effect(c,x,y,RGB(24,29,31),COMBAT_CLASH,20);
    Impact(c,COMBAT_IMPACT_CLASH,255,x,y);
}
static uint8_t Windup(const CombatFighter *f,const struct ArenaMoveProfile *p)
{ return f->basicAttack?5:p->windup; }
static uint8_t Active(const CombatFighter *f,const struct ArenaMoveProfile *p)
{ return f->basicAttack?6:p->active; }
static uint8_t Recovery(const CombatFighter *f,const struct ArenaMoveProfile *p)
{ return f->basicAttack?12:(uint8_t)Clamp(p->recovery*2/3,10,100); }
unsigned Combat_AnimationTick(const CombatFighter *f,unsigned total,unsigned hit)
{
    const struct ArenaMoveProfile *p;
    unsigned time,windup,active,recovery,tail;
    if(!f||!total)return 0;
    if(f->hurtTimer||f->guardTimer)return 0;
    if(f->phase==COMBAT_READY||!(p=ArenaMoves_Get(f->actionMove)))
        return (f->dashTimer?f->animTick*2u:f->animTick)%total;
    if(hit>=total)hit=total-1;
    /* Missing marker: reserve an anticipation third, rather than starting a
     * whole attack loop on each render frame. */
    if(!hit&&total>2)hit=total/3;
    windup=Windup(f,p);active=Active(f,p);recovery=Recovery(f,p);
    time=f->actionTick?f->actionTick-1:0;
    if(f->phase==COMBAT_WINDUP) {
        unsigned before=hit?hit:1;
        return windup?(unsigned)Clamp((int)(time*before/windup),0,(int)before-1):0;
    }
    tail=total-1-hit;
    if(ArenaMoves_Beam(f->actionMove)) {
        if(f->phase==COMBAT_ACTIVE)return hit;
        time=time>windup+active?time-windup-active:0;
        return (unsigned)Clamp((int)(hit+(recovery?time*tail/recovery:tail)),0,(int)total-1);
    }
    time=time>windup?time-windup:0;
    return (unsigned)Clamp((int)(hit+time*tail/(active+recovery?active+recovery:1)),0,(int)total-1);
}
static void EndAction(CombatFighter *f)
{ f->phase=COMBAT_READY;f->actionTick=0;f->actionMove=0;f->basicAttack=0; }
static void ReleaseAction(CombatFighter *f)
{
    if(f->releasedActionSerial==f->actionSerial)return;
    f->releasedActionSerial=f->actionSerial;
    f->releaseMove=f->actionMove;f->releaseSerial++;
}
static int ClashOwnsAction(const Combat *c,const CombatBeamClash *pair,unsigned member)
{
    unsigned actor=pair->actor[member];
    const CombatFighter *f;
    if(actor>=c->fighterCount)return 0;
    f=&c->fighters[actor];
    return f->hp&&!f->hurtTimer&&!f->dashTimer&&f->phase!=COMBAT_READY&&
        f->actionMove==pair->move[member]&&f->actionSerial==pair->actionSerial[member];
}
int Combat_BeamContact(const Combat *c,unsigned side,int32_t *x,int32_t *y)
{
    unsigned i;
    if(!c||side>=c->fighterCount)return 0;
    for(i=0;i<COMBAT_BEAM_CLASHES;i++) {
        const CombatBeamClash *pair=&c->beamClashes[i];
        if(pair->phase==COMBAT_CLASH_PRESSURE&&
            (pair->actor[0]==side||pair->actor[1]==side)&&
            ClashOwnsAction(c,pair,0)&&ClashOwnsAction(c,pair,1)) {
            if(x)*x=pair->x;
            if(y)*y=pair->y;
            return 1;
        }
    }
    return 0;
}
static void EndBeamClash(Combat *c,CombatBeamClash *pair)
{
    unsigned member;
    for(member=0;member<2;member++)if(ClashOwnsAction(c,pair,member)) {
        CombatFighter *f=&c->fighters[pair->actor[member]];
        const struct ArenaMoveProfile *p=ArenaMoves_Get(f->actionMove);
        if(!p) { EndAction(f);continue; }
        f->phase=COMBAT_RECOVERY;f->actionTick=Windup(f,p)+Active(f,p);
        f->vx=f->vy=0;
    }
    pair->phase=COMBAT_CLASH_BURST;pair->age=0;
    Burst(c,pair->x,pair->y,RGB(31,29,21));
    Effect(c,pair->x,pair->y,RGB(24,29,31),COMBAT_CLASH,20);
    Impact(c,COMBAT_IMPACT_CLASH,255,pair->x,pair->y);
    c->hitstop=4;
}
static void BeamClashStep(Combat *c)
{
    unsigned i;
    for(i=0;i<COMBAT_BEAM_CLASHES;i++) {
        CombatBeamClash *pair=&c->beamClashes[i];
        if(pair->phase==COMBAT_CLASH_PRESSURE) {
            if(!ClashOwnsAction(c,pair,0)||!ClashOwnsAction(c,pair,1)||
                ++pair->age>=COMBAT_CLASH_PRESSURE_TICKS)EndBeamClash(c,pair);
            else if(!(pair->age%12))
                Effect(c,pair->x,pair->y,RGB(31,31,24),COMBAT_CLASH,10);
        } else if(pair->phase==COMBAT_CLASH_BURST&&++pair->age>=COMBAT_CLASH_BURST_TICKS)
            memset(pair,0,sizeof(*pair));
    }
}
static void Buffer(CombatFighter *f,uint8_t action)
{ f->buffered=action;f->bufferTimer=10; }
static void MoveBody(CombatFighter *f,int32_t dx,int32_t dy)
{
    int32_t x=Clamp(f->x+dx,ARENA_MIN_X*Q,ARENA_MAX_X*Q);
    int32_t y=Clamp(f->y+dy,ARENA_MIN_Y*Q,ARENA_MAX_Y*Q);
    if(ArenaNav_CanStand(x/Q,f->y/Q)) f->x=x; else f->vx=0;
    if(ArenaNav_CanStand(f->x/Q,y/Q)) f->y=y; else f->vy=0;
}
static void StartAction(Combat *c,unsigned side,uint8_t basic,uint8_t slot)
{
    CombatFighter *f=&c->fighters[side];
    unsigned target=Combat_TargetFighter(c,side);
    uint16_t move=basic?MOVE_POUND:f->moves[slot&3];
    const CombatMoveInfo *m=Combat_GetMoveInfo(move);
    if(!m||target==COMBAT_FIGHTERS||(!basic&&!f->pp[slot&3])) return;
    if(c->lockAim||side!=c->controlActor) {
        CombatFighter *other=&c->fighters[target];
        f->direction=Facing(other->x-f->x,other->y-f->y);
    }
    f->attackDirection=f->direction;
    f->actionMove=move;f->actionTick=0;f->actionDistance=0;f->phase=COMBAT_WINDUP;
    f->actionSerial++;
    f->hitMask=0;f->terrainMask=0;f->basicAttack=basic;
    f->animTick=0; /* Attacks spend PP only; stamina belongs to defense/mobility. */
    if(!basic) f->pp[slot&3]--;
}
static uint8_t CanCancel(const CombatFighter *f)
{
    const struct ArenaMoveProfile *p=ArenaMoves_Get(f->actionMove);
    return f->phase==COMBAT_READY||(p&&f->phase==COMBAT_RECOVERY&&
        f->actionTick>=Windup(f,p)+Active(f,p));
}
static void Defend(Combat *c,unsigned side,int dx,int dy)
{
    CombatFighter *f=&c->fighters[side];
    if(!CanCancel(f)||f->hurtTimer||f->dashTimer||f->guardTimer) return;
    if(dx||dy) {
        if(f->dashCooldown||f->stamina<22) return;
        EndAction(f);f->stamina-=22;f->regenDelay=18;
        f->dashTimer=12;f->dashCooldown=30;
        f->dashDirection=Facing(dx,dy);f->direction=f->dashDirection;f->animTick=0;
    } else {
        if(f->stamina<=6||f->guardExhausted) return;
        EndAction(f);f->stamina-=6;f->regenDelay=12;f->guardTimer=16;
        f->guardHeld=side==c->controlActor;f->guardAge=0;
        Effect(c,f->x,f->y,RGB(12,25,31),COMBAT_BLOCK,12)->direction=f->direction;
    }
}
static void ApplyStatus(Combat *c,unsigned owner,unsigned victim,uint16_t move)
{
    CombatFighter *f=&c->fighters[victim];
    uint8_t effect=ArenaPlatinum_GetStatusEffect(move);
    switch(effect) {
    case ARENA_STATUS_NONE:break;
    case ARENA_STATUS_HEAL:
        f->hp=Clamp(f->hp+f->maxHp/2,1,f->maxHp);break;
    case ARENA_STATUS_ATTACK_UP:f->attackBoost=300;break;
    case ARENA_STATUS_DEFENSE_UP:f->defenseBoost=300;break;
    case ARENA_STATUS_SPEED_UP:f->speedBoost=300;break;
    case ARENA_STATUS_ATTACK_DOWN:f->attackDown=240;break;
    case ARENA_STATUS_DEFENSE_DOWN:f->defenseDown=240;break;
    case ARENA_STATUS_SLOW:f->slowTimer=120;break;
    case ARENA_STATUS_GUARD:
    default:
        if(owner==victim&&f->stamina) { f->guardTimer=16;f->guardAge=0;f->regenDelay=12; }
        else f->slowTimer=90;
        break;
    }
    Effect(c,f->x,f->y,RGB(20,28,31),COMBAT_RING,12);
}
/* Returns 1 for contact, including blocks and immunity; 0 lets an evaded
 * projectile continue. No hit test uses sprite dimensions or render pixels. */
static uint8_t Hit(Combat *c,unsigned owner,unsigned victim,uint16_t move,uint8_t basic,
                   int32_t sourceX,int32_t sourceY,int16_t aimX,int16_t aimY)
{
    CombatFighter *a=&c->fighters[owner],*v=&c->fighters[victim];
    const CombatMoveInfo *m=Combat_GetMoveInfo(move);
    uint16_t mult;
    int damage,guardFacing,critical=0;
    if(!m||!v->hp||!Enemies(owner,victim)) return 0;
    if((v->dashTimer&&v->dashTimer>=5)||v->hurtTimer>10) {c->dodged++;return 0;}
    if(!basic&&m->category==2) {
        if(v->guardTimer&&v->stamina) {
            c->blocked++;v->stamina--;v->regenDelay=20;
            Impact(c,COMBAT_IMPACT_BLOCK,victim,v->x,v->y);
            if(!v->stamina) { v->guardTimer=v->guardHeld=0;v->guardExhausted=1; }
            return 1;
        }
        ApplyStatus(c,owner,victim,move);return 1;
    }
    /* Universal arena strikes are typeless, like a PP-independent fallback:
       every pairing remains playable even when all equipped moves are immune. */
    mult=basic?Q:Combat_TypeMultiplier(m->type,v->types[0],v->types[1]);
    if(!mult) { Effect(c,v->x,v->y,RGB(20,20,20),COMBAT_IMMUNE,10);return 1; }
    unsigned attack=(!basic&&m->category==1)?a->spAttack:a->attack;
    unsigned defense=(!basic&&m->category==1)?v->spDefense:v->defense;
    if(a->attackBoost) attack=attack*5/4;
    if(a->attackDown) attack=attack*4/5;
    if(v->defenseBoost) defense=defense*5/4;
    if(v->defenseDown) defense=defense*4/5;
    damage=(((basic?25:m->power)*attack)/(defense?defense:1)+15)/5;
    if(!basic&&(a->types[0]==m->type||a->types[1]==m->type)) damage=damage*3/2;
    damage=Clamp(damage*mult/Q,1,v->maxHp);
    guardFacing=(sourceX-v->x)*sDirections[v->direction][0]+(sourceY-v->y)*sDirections[v->direction][1]>=0;
    if(v->guardTimer&&v->stamina&&guardFacing) {
        int perfect=v->guardAge<5;
        int cost=perfect?4:10+damage/4;
        if(v->stamina>=cost) {
            v->stamina-=cost;v->regenDelay=20;c->blocked++;
            /* Heavy native moves still apply reduced pressure through a
             * shield. Basic strikes and low-power moves are fully blocked. */
            if(!basic&&m->power>=80) {
                int chip=Clamp(damage/5,1,v->hp);
                if(move==MOVE_FALSE_SWIPE&&chip>=v->hp) chip=v->hp>1?v->hp-1:0;
                v->hp-=chip;
            }
            Effect(c,v->x,v->y,RGB(10,31,31),COMBAT_BLOCK,14)->direction=Facing(sourceX-v->x,sourceY-v->y);
            Impact(c,COMBAT_IMPACT_BLOCK,victim,v->x,v->y);
            c->hitstop=perfect?3:2;
            if(!v->stamina||!v->hp) { v->guardTimer=v->guardHeld=0;v->guardExhausted=1; }
            return 1;
        }
        v->stamina=0;v->guardTimer=v->guardHeld=0;v->guardExhausted=1;
        Burst(c,v->x,v->y,RGB(31,20,6));
    }
    /* Native Gen IV base chance, doubled for the supported high-crit moves.
     * A critical is an actual damage event, not a cosmetic random zoom. */
    if(!basic) {
        unsigned mask=15;
        switch(move) {
        case MOVE_KARATE_CHOP:case MOVE_RAZOR_LEAF:case MOVE_CRABHAMMER:
        case MOVE_SLASH:case MOVE_AEROBLAST:case MOVE_CROSS_CHOP:
        case MOVE_BLAZE_KICK:case MOVE_AIR_CUTTER:case MOVE_POISON_TAIL:
        case MOVE_LEAF_BLADE:case MOVE_NIGHT_SLASH:case MOVE_SHADOW_CLAW:
        case MOVE_PSYCHO_CUT:case MOVE_STONE_EDGE:case MOVE_ATTACK_ORDER:
            mask=7;break;
        }
        critical=!(NextRandom(c)&mask);
        if(critical) damage=Clamp(damage*2,1,v->maxHp);
    }
    if(move==MOVE_FALSE_SWIPE&&damage>=v->hp) damage=v->hp>1?v->hp-1:0;
    if(damage>v->hp) damage=v->hp;
    v->hp-=damage;v->hurtTimer=15;v->guardTimer=v->guardHeld=0;v->dashTimer=0;
    v->vx=aimX*3;v->vy=aimY*3;v->regenDelay=16;EndAction(v);
    if(a->hp&&(move==MOVE_ABSORB||move==MOVE_MEGA_DRAIN||move==MOVE_GIGA_DRAIN||move==MOVE_LEECH_LIFE))
        a->hp=Clamp(a->hp+(damage+1)/2,0,a->maxHp);
    Burst(c,v->x,v->y,Combat_TypeColor(m->type));
    c->hits++;c->hitstop=basic?2:critical?5:3;
    if(critical&&damage) { c->criticals++;Impact(c,COMBAT_IMPACT_CRITICAL,victim,v->x,v->y); }
    return 1;
}
static void SpawnProjectile(Combat *c,unsigned side,const struct ArenaMoveProfile *p)
{
    CombatFighter *f=&c->fighters[side];
    const CombatMoveInfo *m=Combat_GetMoveInfo(p->move);
    CombatProjectile *shot;
    unsigned i;
    for(i=0;i<COMBAT_PROJECTILES;i++) if(!c->projectiles[i].life) break;
    if(i==COMBAT_PROJECTILES||!m) return;
    shot=&c->projectiles[i];
    shot->owner=side;shot->move=p->move;shot->type=m->type;
    shot->vx=sDirections[f->attackDirection][0]*p->speed/Q;
    shot->vy=sDirections[f->attackDirection][1]*p->speed/Q;
    shot->x=f->x;shot->y=f->y;
    shot->previousX=shot->x;shot->previousY=shot->y;
    shot->life=(uint8_t)Clamp(p->range*Q/(p->speed?p->speed:Q),1,200);
    shot->radius=(uint8_t)Clamp(p->radius/3,3,7);
    shot->visual=p->visual;shot->color=Combat_TypeColor(m->type);
    Effect(c,f->x,f->y,shot->color,COMBAT_RING,4);
}
static void ActionStep(Combat *c,unsigned side)
{
    CombatFighter *f=&c->fighters[side];
    const struct ArenaMoveProfile *p=ArenaMoves_Get(f->actionMove);
    const CombatMoveInfo *m=Combat_GetMoveInfo(f->actionMove);
    unsigned w,a,i;
    int16_t ax,ay,px,py,tx,ty;
    if(!f->hp||!p||!m||f->phase==COMBAT_READY||Combat_BeamContact(c,side,0,0)) return;
    w=Windup(f,p);a=Active(f,p);
    ax=sDirections[f->attackDirection][0];ay=sDirections[f->attackDirection][1];
    f->animation=p->move==MOVE_PROTECT?COMBAT_IDLE:p->animation;f->direction=f->attackDirection;
    if(f->actionTick<w) {
        f->phase=COMBAT_WINDUP;
        if(!(f->actionTick%6)) Effect(c,f->x,f->y,Combat_TypeColor(m->type),COMBAT_RING,3);
    } else if(f->actionTick<w+a) {
        f->phase=COMBAT_ACTIVE;
        if(f->actionTick==w)ReleaseAction(f);
        if(f->actionTick==w&&p->kind==ARENA_MOVE_PROJECTILE) SpawnProjectile(c,side,p);
        if(f->actionTick==w&&p->kind==ARENA_MOVE_SELF&&m->category==2&&p->move!=MOVE_PROTECT)
            ApplyStatus(c,side,side,p->move);
        if(p->move==MOVE_PROTECT) {
            if(f->stamina) { f->guardTimer=16;f->guardAge=0; }
            if(!(f->actionTick%12)) Effect(c,f->x,f->y,RGB(10,31,31),COMBAT_BLOCK,14);
        }
        if(p->kind==ARENA_MOVE_RUSH&&f->actionDistance<p->range*Q) {
            unsigned step=p->speed,remaining=(unsigned)p->range*Q-f->actionDistance;
            if(step>remaining) step=remaining;
            MoveBody(f,ax*(int)step/Q,ay*(int)step/Q);f->actionDistance+=step;
        }
        px=f->x/Q;py=f->y/Q;
        if(p->kind==ARENA_MOVE_MELEE||p->kind==ARENA_MOVE_RUSH||p->kind==ARENA_MOVE_CONE) {
            for(i=0;i<c->fighterCount;i++) if(Enemies(side,i)&&c->fighters[i].hp&&!(f->hitMask&(1u<<i))) {
                CombatFighter *v=&c->fighters[i];
                int hit;
                tx=v->x/Q;ty=v->y/Q;
                hit=ArenaMoves_InCone(tx-px,ty-py,ax,ay,p->range,p->cone);
                if(p->kind==ARENA_MOVE_RUSH) hit=ArenaMoves_SegmentHit(f->previousX/Q,f->previousY/Q,px,py,tx,ty,18);
                if(hit&&ArenaNav_LineClear(px,py,tx,ty,1)&&
                    Hit(c,side,i,f->actionMove,f->basicAttack,f->x,f->y,ax,ay)) {
                    f->hitMask|=1u<<i;
                    /* A connecting tackle stops at contact instead of
                     * carrying the attacker through and past its target. */
                    if(p->kind==ARENA_MOVE_RUSH) {
                        f->actionDistance=p->range*Q;f->vx=f->vy=0;
                    }
                }
            }
        }
        if(p->kind!=ARENA_MOVE_SELF&&p->kind!=ARENA_MOVE_PROJECTILE) {
            int16_t obstacle=ArenaNav_FirstObstacle(px,py,px+ax*p->range/Q,py+ay*p->range/Q,2);
            if(obstacle>=0&&!(f->terrainMask&(1u<<obstacle))) {
                f->terrainMask|=1u<<obstacle;
                ArenaPhysics_Hit(obstacle,ax*3,ay*3,m->power>=80?2:1);
            }
            if(!(f->actionTick%5)) Effect(c,f->x+ax*18,f->y+ay*18,Combat_TypeColor(m->type),COMBAT_RING,p->kind==ARENA_MOVE_CONE?9:5);
        }
    } else f->phase=COMBAT_RECOVERY;
    f->actionTick++;
    if(f->actionTick>=w+a+Recovery(f,p)) EndAction(f);
}
/* Resolve beams before either actor can damage a body. Two independently
 * owned slots permit both rows of a 2v2 fight to sustain contact. Neither
 * actor nor its action timer advances during the bounded pressure stage. */
static int ActiveBeam(const CombatFighter *f,const struct ArenaMoveProfile *p)
{
    return f->hp&&!f->hurtTimer&&!f->dashTimer&&p&&ArenaMoves_Beam(f->actionMove)&&
        f->phase!=COMBAT_READY&&f->actionTick>=Windup(f,p)&&
        f->actionTick<Windup(f,p)+Active(f,p);
}
static void BeamClashes(Combat *c)
{
    unsigned i,j,slot;
    for(i=0;i<c->fighterCount;i++) {
        CombatFighter *a=&c->fighters[i];
        const struct ArenaMoveProfile *pa=ArenaMoves_Get(a->actionMove);
        if(!ActiveBeam(a,pa)||Combat_BeamContact(c,i,0,0)) continue;
        for(j=i+1;j<c->fighterCount;j++) {
            CombatFighter *b=&c->fighters[j];
            const struct ArenaMoveProfile *pb=ArenaMoves_Get(b->actionMove);
            int ax,ay,bx,by,step,best=0x7fffffff,cx=0,cy=0;
            int aX=a->x/Q,aY=a->y/Q,bX=b->x/Q,bY=b->y/Q;
            CombatBeamClash *pair;
            if(!Enemies(i,j)||!ActiveBeam(b,pb)||Combat_BeamContact(c,j,0,0)) continue;
            for(slot=0;slot<COMBAT_BEAM_CLASHES;slot++)
                if(c->beamClashes[slot].phase==COMBAT_CLASH_NONE)break;
            if(slot==COMBAT_BEAM_CLASHES)return;
            ax=sDirections[a->attackDirection][0];ay=sDirections[a->attackDirection][1];
            bx=sDirections[b->attackDirection][0];by=sDirections[b->attackDirection][1];
            if(ax*bx+ay*by>0) continue; /* Parallel friendly-direction fire. */
            for(step=12;step<=pa->range;step+=4) {
                int x=aX+ax*step/Q,y=aY+ay*step/Q;
                int distance=Abs(x*2-aX-bX)+Abs(y*2-aY-bY);
                if(distance<best&&(x-bX)*bx+(y-bY)*by>=12*Q&&
                    ArenaMoves_SegmentHit(bX,bY,bX+bx*pb->range/Q,bY+by*pb->range/Q,x,y,10)&&
                    ArenaNav_LineClear(aX,aY,x,y,1)&&ArenaNav_LineClear(bX,bY,x,y,1)) {
                    best=distance;cx=x;cy=y;
                }
            }
            if(best!=0x7fffffff) {
                pair=&c->beamClashes[slot];memset(pair,0,sizeof(*pair));
                pair->x=cx*Q;pair->y=cy*Q;pair->actor[0]=(uint8_t)i;pair->actor[1]=(uint8_t)j;
                pair->move[0]=a->actionMove;pair->move[1]=b->actionMove;
                pair->actionSerial[0]=a->actionSerial;pair->actionSerial[1]=b->actionSerial;
                pair->phase=COMBAT_CLASH_PRESSURE;
                a->phase=b->phase=COMBAT_ACTIVE;
                a->actionTick=Windup(a,pa);b->actionTick=Windup(b,pb);
                a->vx=a->vy=b->vx=b->vy=0;
                a->animation=pa->animation;b->animation=pb->animation;
                a->direction=a->attackDirection;b->direction=b->attackDirection;
                ReleaseAction(a);ReleaseAction(b);
                Clash(c,cx*Q,cy*Q);
                break;
            }
        }
    }
}
static void ProjectileStep(Combat *c)
{
    unsigned i,j;
    /* Stage every shot's travel first. Clash contact cannot depend on which
     * projectile happened to obtain a lower pool slot. */
    for(i=0;i<COMBAT_PROJECTILES;i++) {
        CombatProjectile *p=&c->projectiles[i];
        int16_t obstacle;
        if(!p->life) continue;
        if(p->owner>=c->fighterCount) { p->life=0;continue; }
        p->previousX=p->x;p->previousY=p->y;
        p->x+=p->vx;p->y+=p->vy;
        obstacle=ArenaNav_FirstObstacle(p->previousX/Q,p->previousY/Q,p->x/Q,p->y/Q,p->radius);
        if(obstacle>=0) {
            const CombatMoveInfo *m=Combat_GetMoveInfo(p->move);
            ArenaPhysics_Hit(obstacle,p->vx,p->vy,m&&m->power>=80?2:1);
            Burst(c,p->x,p->y,p->color);p->life=0;continue;
        }
    }
    for(i=0;i<COMBAT_PROJECTILES;i++) {
        CombatProjectile *p=&c->projectiles[i];
        if(!p->life) continue;
        for(j=i+1;j<COMBAT_PROJECTILES&&p->life;j++) {
            CombatProjectile *q=&c->projectiles[j];
            if(q->life&&Enemies(q->owner,p->owner)&&ArenaPlus_SweptContact(
                p->previousX,p->previousY,p->x,p->y,q->previousX,q->previousY,q->x,q->y,p->radius+q->radius)) {
                p->life=q->life=0;Clash(c,(p->x+q->x)/2,(p->y+q->y)/2);
            }
        }
    }
    for(i=0;i<COMBAT_PROJECTILES;i++) {
        CombatProjectile *p=&c->projectiles[i];
        if(!p->life) continue;
        /* Resolve the first swept opposing body along the shot's travel. An
         * allied body never absorbs a shot; an evaded enemy lets it continue. */
        unsigned considered=0;
        for(unsigned pass=0;pass<c->fighterCount&&p->life;pass++) {
            unsigned victim=COMBAT_FIGHTERS;
            int32_t closest=0x7fffffff;
            for(j=0;j<c->fighterCount;j++) if(!(considered&(1u<<j))&&
                Enemies(p->owner,j)&&c->fighters[j].hp) {
                CombatFighter *target=&c->fighters[j];
                if(ArenaPlus_SweptContact(p->previousX,p->previousY,p->x,p->y,
                    target->previousX,target->previousY,target->x,target->y,p->radius+9)) {
                    int32_t along=(target->previousX-p->previousX)/Q*p->vx/Q+
                        (target->previousY-p->previousY)/Q*p->vy/Q;
                    if(along<closest) { closest=along;victim=j; }
                }
            }
            if(victim==COMBAT_FIGHTERS) break;
            considered|=1u<<victim;
            if(Hit(c,p->owner,victim,p->move,0,p->previousX,p->previousY,
                sDirections[Facing(p->vx,p->vy)][0],sDirections[Facing(p->vx,p->vy)][1])) {
                p->life=0;
            }
        }
        if(!p->life) continue;
        if(p->life) {
            if(p->x<4*Q||p->x>(ARENA_WORLD_WIDTH-4)*Q||
               p->y<24*Q||p->y>(ARENA_WORLD_HEIGHT-9)*Q) p->life=0;
            else p->life--;
            if(!(c->frame&3)) Effect(c,p->x,p->y,p->color,COMBAT_TRAIL,2);
        }
    }
}
static void EffectStep(Combat *c)
{
    unsigned i;
    for(i=0;i<COMBAT_EFFECTS;i++) {
        CombatEffect *e=&c->effects[i];
        if(!e->life) continue;
        e->life--;e->x+=e->vx;e->y+=e->vy;
        if(e->kind==COMBAT_SPARK) e->vy+=25;
    }
}
static CombatInput AIInput(Combat *c,unsigned side)
{
    CombatInput out={0,0};
    unsigned target=Combat_TargetFighter(c,side);
    CombatFighter *f=&c->fighters[side],*v;
    if(!f->hp||target==COMBAT_FIGHTERS) return out;
    v=&c->fighters[target];
    if(c->clashPractice) {
        CombatFighter *player=&c->fighters[c->controlActor];
        uint32_t serial=player->actionSerial*4u+c->controlActor+1u;
        /* Practice changes only AI intention. The ordinary release, beam
         * collision, PP and paired-clash implementation still does the work. */
        if(player->phase!=COMBAT_READY&&ArenaMoves_Beam(player->actionMove)&&
            f->phase==COMBAT_READY&&f->practiceActionSerial!=serial) {
            for(unsigned slot=0;slot<4;slot++)if(f->pp[slot]&&ArenaMoves_Beam(f->moves[slot])) {
                f->selected=(uint8_t)slot;f->practiceActionSerial=serial;
                out.pressed=COMBAT_A;break;
            }
        }
        return out;
    }
    int dx=v->x-f->x,dy=v->y-f->y,dist=ArenaNav_Distance(f->x/Q,f->y/Q,v->x/Q,v->y/Q);
    int desired=30,best=-100000,bestSlot=-1,i;
    uint8_t threat=0;
    for(i=0;i<4;i++) {
        const CombatMoveInfo *m=Combat_GetMoveInfo(f->moves[i]);
        const struct ArenaMoveProfile *p=ArenaMoves_Get(f->moves[i]);
        int score;
        if(!m||!p||!f->pp[i]||!m->power) continue;
        score=m->power*Combat_TypeMultiplier(m->type,v->types[0],v->types[1])/Q;
        if(!score) continue;
        score-=Abs(dist-(p->kind==ARENA_MOVE_PROJECTILE||p->kind==ARENA_MOVE_CONE?80:28));
        if(score>best) { best=score;bestSlot=i; }
    }
    if(bestSlot>=0) {
        const struct ArenaMoveProfile *p=ArenaMoves_Get(f->moves[bestSlot]);
        f->selected=bestSlot;
        desired=(p->kind==ARENA_MOVE_PROJECTILE||p->kind==ARENA_MOVE_CONE)?80:27;
    }
    if(!f->aiTimer) {
        struct ArenaPoint waypoint;
        f->aiTimer=12;
        if(ArenaNav_NextWaypoint(f->x/Q,f->y/Q,v->x/Q,v->y/Q,&waypoint)) {
            f->aiGoalX=waypoint.x;f->aiGoalY=waypoint.y;
        } else { f->aiGoalX=v->x/Q;f->aiGoalY=v->y/Q; }
    }
    if(dist>desired+6||!ArenaNav_LineClear(f->x/Q,f->y/Q,v->x/Q,v->y/Q,2)) {
        dx=f->aiGoalX*Q-f->x;dy=f->aiGoalY*Q-f->y;
    } else if(dist<desired-16&&desired>40) { dx=-dx;dy=-dy; }
    else { /* Short lateral steps keep ranged opponents from remaining still. */
        int lateral=(c->frame/90)&1?1:-1;
        dx=Sign(-dy)*lateral;dy=Sign(v->x-f->x)*lateral;
        if(desired<40) dx=dy=0;
    }
    if(Abs(dx)>Q/2) out.held|=dx>0?COMBAT_RIGHT:COMBAT_LEFT;
    if(Abs(dy)>Q/2) out.held|=dy>0?COMBAT_DOWN:COMBAT_UP;
    /* The lateral branch uses unit intent rather than Q8 distances. */
    if(Abs(dx)==1) out.held|=dx>0?COMBAT_RIGHT:COMBAT_LEFT;
    if(Abs(dy)==1) out.held|=dy>0?COMBAT_DOWN:COMBAT_UP;
    if(v->phase==COMBAT_WINDUP&&dist<65) threat=1;
    for(i=0;i<COMBAT_PROJECTILES;i++) {
        CombatProjectile *p=&c->projectiles[i];
        if(p->life&&Enemies(p->owner,side)&&Abs(p->x-f->x)+Abs(p->y-f->y)<48*Q&&
            (p->x-f->x)*p->vx+(p->y-f->y)*p->vy<0) threat=1;
    }
    if(threat&&f->stamina>=32&&!f->aiCooldown&&CanCancel(f)) {
        f->direction=Facing(v->x-f->x,v->y-f->y);
        if((NextRandom(c)&3)==0) out.held=0; /* Guard sometimes; dodge mostly. */
        else {
            int sx=Sign(-(v->y-f->y)),sy=Sign(v->x-f->x);
            if((c->frame/120)&1) {sx=-sx;sy=-sy;}
            out.held=(sx>0?COMBAT_RIGHT:sx<0?COMBAT_LEFT:0)|
                (sy>0?COMBAT_DOWN:sy<0?COMBAT_UP:0);
        }
        out.pressed=COMBAT_B;f->aiCooldown=40;
    } else if(!f->aiCooldown&&f->phase==COMBAT_READY&&dist<desired+35&&
        ArenaNav_LineClear(f->x/Q,f->y/Q,v->x/Q,v->y/Q,1)) {
        out.pressed=bestSlot>=0?COMBAT_A:COMBAT_X;f->aiCooldown=10;
    }
    return out;
}
static void QueueInput(CombatFighter *f,CombatInput input)
{
    int dx=!!(input.held&COMBAT_RIGHT)-!!(input.held&COMBAT_LEFT);
    int dy=!!(input.held&COMBAT_DOWN)-!!(input.held&COMBAT_UP);
    if(input.pressed&COMBAT_L) f->selected=(f->selected+3)&3;
    if(input.pressed&COMBAT_R) f->selected=(f->selected+1)&3;
    if(input.pressed&COMBAT_B) {
        f->dashDirection=Facing(dx,dy);Buffer(f,dx||dy?3:4);
    } else if((input.held&COMBAT_B)&&!dx&&!dy&&!f->guardTimer&&!f->guardExhausted) {
        Buffer(f,4);
    } else if(input.pressed&COMBAT_X) Buffer(f,2);
    else if(input.pressed&COMBAT_A) { Buffer(f,1);f->bufferedSlot=f->selected; }
    else if(input.pressed&COMBAT_ALT) { Buffer(f,1);f->bufferedSlot=(f->selected+1)&3; }
    else if(f->phase==COMBAT_READY&&(input.held&COMBAT_X))Buffer(f,2);
    else if(f->phase==COMBAT_READY&&(input.held&COMBAT_A)) { Buffer(f,1);f->bufferedSlot=f->selected; }
    else if(f->phase==COMBAT_READY&&(input.held&COMBAT_ALT)) { Buffer(f,1);f->bufferedSlot=(f->selected+1)&3; }
}
static void FighterStep(Combat *c,unsigned side,CombatInput input)
{
    CombatFighter *f=&c->fighters[side];
    unsigned target=Combat_TargetFighter(c,side);
    struct ArenaPlusMotion motion;
    int dx=!!(input.held&COMBAT_RIGHT)-!!(input.held&COMBAT_LEFT);
    int dy=!!(input.held&COMBAT_DOWN)-!!(input.held&COMBAT_UP);
    int holdingGuard=!!((input.held|input.pressed)&COMBAT_B);
    int speed;
    if(!f->hp) return;
    f->animTick++;
    if(!holdingGuard) f->guardExhausted=0;
    if(f->guardHeld&&(!holdingGuard||!f->stamina||f->hurtTimer)) {
        f->guardHeld=f->guardTimer=0;f->regenDelay=12;
        if(!f->stamina) f->guardExhausted=1;
    }
    if(f->guardTimer) {
        if(f->guardAge<255) f->guardAge++;
        if(f->guardHeld) {
            f->guardTimer=16;f->regenDelay=16;
            if(!(c->frame&3)&&f->stamina) f->stamina--;
            if(!f->stamina) {
                f->guardTimer=f->guardHeld=0;f->guardExhausted=1;f->regenDelay=24;
            }
        } else f->guardTimer--;
    }
    if(f->dashTimer) f->dashTimer--;
    if(f->hurtTimer) f->hurtTimer--;
    if(f->dashCooldown) f->dashCooldown--;
    if(f->aiTimer) f->aiTimer--;
    if(f->aiCooldown) f->aiCooldown--;
    if(f->regenDelay) f->regenDelay--;
    else if(!(c->frame%3)&&f->stamina<COMBAT_STAMINA_MAX)
        f->stamina=(uint8_t)Clamp(f->stamina+2,0,COMBAT_STAMINA_MAX);
    if(f->attackBoost) f->attackBoost--;
    if(f->defenseBoost) f->defenseBoost--;
    if(f->speedBoost) f->speedBoost--;
    if(f->attackDown) f->attackDown--;
    if(f->defenseDown) f->defenseDown--;
    if(f->slowTimer) f->slowTimer--;
    if(Combat_BeamContact(c,side,0,0)) {
        const struct ArenaMoveProfile *p=ArenaMoves_Get(f->actionMove);
        f->vx=f->vy=0;f->direction=f->attackDirection;
        f->animation=p?p->animation:COMBAT_IDLE;f->bufferTimer=0;
        return;
    }
    QueueInput(f,input);
    if(!f->hurtTimer&&!f->guardTimer&&!f->dashTimer&&f->bufferTimer) {
        if(f->buffered>=3) {
            if(CanCancel(f)) {
                uint8_t dir=f->dashDirection;
                Defend(c,side,f->buffered==3?sDirections[dir][0]:0,f->buffered==3?sDirections[dir][1]:0);
                f->bufferTimer=0;
            }
        } else if(f->phase==COMBAT_READY) {
            StartAction(c,side,f->buffered==2,f->bufferedSlot);f->bufferTimer=0;
        }
    }
    if(f->bufferTimer) f->bufferTimer--;
    if(f->hurtTimer) {
        f->vx=f->vx*205/Q;f->vy=f->vy*205/Q;
        MoveBody(f,f->vx,f->vy);f->animation=COMBAT_IDLE;return;
    }
    if(f->dashTimer) {
        static const uint16_t dashSpeedByTimer[13]={0,384,512,640,768,896,1024,1152,1280,1344,1280,1024,720};
        int dashSpeed=dashSpeedByTimer[f->dashTimer<=12?f->dashTimer:12];
        if(f->dashTimer<=4&&(dx||dy)) {
            unsigned requested=Facing(dx,dy);
            unsigned turn=(requested+8-f->dashDirection)&7;
            if(turn&&turn<=4)f->dashDirection=(f->dashDirection+1)&7;
            else if(turn)f->dashDirection=(f->dashDirection+7)&7;
        }
        f->direction=f->dashDirection;
        f->vx=sDirections[f->dashDirection][0]*dashSpeed/Q;
        f->vy=sDirections[f->dashDirection][1]*dashSpeed/Q;
        MoveBody(f,f->vx,f->vy);f->animation=COMBAT_WALK;
        if(!(c->frame&1)&&(f->x!=f->previousX||f->y!=f->previousY))
            Effect(c,f->x,f->y,RGB(14,23,31),COMBAT_DASH_TRAIL,7)->direction=f->dashDirection;
        return;
    }
    if(f->guardTimer) {
        if((c->lockAim||side!=c->controlActor)&&target!=COMBAT_FIGHTERS)
            f->direction=Facing(c->fighters[target].x-f->x,c->fighters[target].y-f->y);
        else if(dx||dy) f->direction=Facing(dx,dy);
        f->vx=f->vy=0;f->animation=COMBAT_IDLE;return;
    }
    if((c->lockAim||side!=c->controlActor)&&target!=COMBAT_FIGHTERS) {
        CombatFighter *v=&c->fighters[target];
        if(f->phase==COMBAT_READY) f->direction=Facing(v->x-f->x,v->y-f->y);
    } else if(dx||dy) {
        if(f->phase==COMBAT_READY) f->direction=Facing(dx,dy);
    }
    speed=Clamp(270+f->speed*2,340,620);
    if(f->speedBoost) speed=speed*5/4;
    if(f->slowTimer) speed=speed*4/5;
    if(f->phase==COMBAT_WINDUP) speed=speed*3/4;
    if(f->phase==COMBAT_ACTIVE) speed=speed*2/3;
    if(f->phase==COMBAT_RECOVERY) speed=speed*9/10;
    motion.x=f->vx;motion.y=f->vy;
    ArenaPlus_MoveStep(&motion,dx,dy,speed);
    f->vx=motion.x;f->vy=motion.y;MoveBody(f,f->vx,f->vy);
    f->animation=(Abs(f->vx)+Abs(f->vy)>32)?COMBAT_WALK:COMBAT_IDLE;
}
static void SeparateBodies(Combat *c)
{
    unsigned i,j;
    for(i=0;i<c->fighterCount;i++) for(j=i+1;j<c->fighterCount;j++) {
        CombatFighter *a=&c->fighters[i],*b=&c->fighters[j];
        int dx=(b->x-a->x)/Q,dy=(b->y-a->y)/Q;
        if(a->hp&&b->hp&&dx*dx+dy*dy<16*16) {
            int sx=Sign(dx),sy=Sign(dy);
            if(!sx&&!sy) sx=1;
            if(!Combat_BeamContact(c,i,0,0))MoveBody(a,-sx*Q/2,-sy*Q/2);
            if(!Combat_BeamContact(c,j,0,0))MoveBody(b,sx*Q/2,sy*Q/2);
        }
    }
}
static void InitFighter(CombatFighter *f,const CombatFighterConfig *p)
{
    unsigned j;
    memset(f,0,sizeof(*f));
    f->species=p->species;f->hp=f->maxHp=Clamp(p->hp,1,8191);
    f->attack=Clamp(p->attack,1,2047);f->defense=Clamp(p->defense,1,2047);
    f->spAttack=Clamp(p->spAttack?p->spAttack:p->attack,1,2047);
    f->spDefense=Clamp(p->spDefense?p->spDefense:p->defense,1,2047);
    f->speed=Clamp(p->speed,1,255);f->types[0]=p->types[0];f->types[1]=p->types[1];
    f->stamina=COMBAT_STAMINA_MAX;
    for(j=0;j<4;j++) {
        const CombatMoveInfo *m=Combat_GetMoveInfo(p->moves[j]);
        f->moves[j]=m?p->moves[j]:MOVE_NONE;f->pp[j]=m?m->pp:0;
    }
}
static void InitMatch(Combat *c,const CombatFighterConfig *configs,unsigned count)
{
    unsigned i;
    memset(c,0,sizeof(*c));
    ArenaNav_Init();ArenaPhysics_Init();
    c->lockAim=1;c->aiEnabled=1;c->random=0xD5A4E2u;c->fighterCount=count;
    for(i=0;i<count;i++) {
        CombatFighter *f=&c->fighters[i];
        InitFighter(f,&configs[i]);
        f->x=(ARENA_WORLD_WIDTH/2+((i&1)?62:-62))*Q;
        f->y=(ARENA_WORLD_HEIGHT/2+8+(count>2?(i<2?-30:30):0))*Q;
        f->previousX=f->x;f->previousY=f->y;
        f->direction=(i&1)?COMBAT_W:COMBAT_E;
    }
}
void Combat_Init(Combat *c,const CombatFighterConfig configs[2])
{ InitMatch(c,configs,2); }
void Combat_InitTeams(Combat *c,const CombatFighterConfig configs[COMBAT_FIGHTERS])
{ InitMatch(c,configs,COMBAT_FIGHTERS); }
void Combat_SetClashPractice(Combat *c,int enabled)
{
    unsigned i;
    if(!c)return;
    c->clashPractice=enabled!=0;
    for(i=0;i<c->fighterCount;i++)c->fighters[i].practiceActionSerial=0;
}
int Combat_SetControlledFighter(Combat *c,unsigned side)
{
    if(!c||side>=c->fighterCount||(side&1)||!c->fighters[side].hp) return 0;
    c->controlActor=(uint8_t)side;
    return 1;
}
int Combat_ReplaceFighter(Combat *c,unsigned side,const CombatFighterConfig *config)
{
    int32_t x,y;
    uint8_t direction,was_fainted;
    CombatFighter *f;
    if(!c||!config||side>=c->fighterCount)return 0;
    for(unsigned i=0;i<COMBAT_BEAM_CLASHES;i++)if(c->beamClashes[i].phase==COMBAT_CLASH_PRESSURE&&
        (c->beamClashes[i].actor[0]==side||c->beamClashes[i].actor[1]==side))EndBeamClash(c,&c->beamClashes[i]);
    f=&c->fighters[side];x=f->x;y=f->y;direction=f->direction;
    was_fainted=!f->hp;
    InitFighter(f,config);
    f->x=f->previousX=x;f->y=f->previousY=y;f->direction=direction;
    for(unsigned i=0;i<COMBAT_PROJECTILES;i++)
        if(c->projectiles[i].owner==side)memset(&c->projectiles[i],0,sizeof(c->projectiles[i]));
    c->hitstop=0;
    if(was_fainted&&f->hp)c->winner=0;
    return 1;
}
void Combat_Tick(Combat *c,CombatInput input)
{
    unsigned i;
    CombatInput controls[COMBAT_FIGHTERS]={{0,0}};
    uint8_t alive[2]={0,0};
    c->frame++;EffectStep(c);
    if(c->impactTimer) c->impactTimer--;
    if(c->winner) return;
    if(input.pressed&COMBAT_Y) c->lockAim=!c->lockAim;
    if(c->hitstop) {
        c->hitstop--;if(c->fighters[c->controlActor].hp) QueueInput(&c->fighters[c->controlActor],input);return;
    }
    for(i=0;i<c->fighterCount;i++) {
        c->fighters[i].previousX=c->fighters[i].x;
        c->fighters[i].previousY=c->fighters[i].y;
    }
    BeamClashStep(c);
    controls[c->controlActor]=input;
    if(c->aiEnabled) for(i=0;i<c->fighterCount;i++) if(i!=c->controlActor) controls[i]=AIInput(c,i);
    for(i=0;i<c->fighterCount;i++) FighterStep(c,i,controls[i]);
    BeamClashes(c);
    for(i=0;i<c->fighterCount;i++) if(!c->fighters[i].hurtTimer&&!c->fighters[i].dashTimer) ActionStep(c,i);
    SeparateBodies(c);ProjectileStep(c);ArenaPhysics_Update();
    if(c->blastSerial!=gArenaPhysicsTelemetry.blastSerial) {
        c->blastSerial=gArenaPhysicsTelemetry.blastSerial;
        Burst(c,gArenaPhysicsTelemetry.blastX*Q,gArenaPhysicsTelemetry.blastY*Q,RGB(31,22,3));
        /* Terrain explosions are visual/physical only in this prototype. */
    }
    for(i=0;i<c->fighterCount;i++) if(c->fighters[i].hp) alive[i&1]=1;
    if(!alive[1]) c->winner=1;
    else if(!alive[0]) c->winner=2;
}
