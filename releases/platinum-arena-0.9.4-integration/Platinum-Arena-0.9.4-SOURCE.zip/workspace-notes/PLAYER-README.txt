PLATINUM LIVE ACTION PORT - DEVELOPMENT BUILD

The first story battle now enters live action in a production test, with pause,
Y strike and the native first-loss story return verified. The final expanded
art build still needs its own battle and save/reload checks before packaging.
These are the implemented controls for this early Platinum action version.

Platinum's original story, maps and field menus remain. Supported offline
battles are intended to use live action combat, including 2v2 with an AI
teammate. The final candidate still needs its own runtime acceptance checks.

BATTLE CONTROLS
D-pad: move and aim
Y: normal strike
A: selected move
X: following move
L: cycle moves
R: reserved; no standalone action
B + direction: dash
B without a direction: guard/parry
Select: toggle aim lock
Start: pause, switch Pokemon, use medicine or try running

CATCHING
Hold L+R to aim. Adjust with D-pad. Release a shoulder to throw.
B cancels before throwing without spending a ball.
Uses ordinary Poke Balls from your bag. Only one wild foe may remain.
Caught Pokemon enter your actual party or PC boxes.

STAMINA AND MOVES
Normal strikes cost no stamina. Special moves spend their saved PP.
Dash and guard use stamina, which regenerates after a short delay.
EXP, level-ups, move choices, money and evolution use native party/story data.

APPEARANCE
The original new-game introduction offers Lucas, Dawn, Brendan or May and
skin, hair-color and outfit-color options. Arbitrary new haircuts and clothing
shapes are not included.

CURRENT LIMITS
Many complex moves use simplified action effects. Full original abilities,
weather, items and scripted move behavior are incomplete. There are 294
directional species: 187 retained Arena sets plus all 107 Gen IV species from
pinned SpriteCollab source. The other 199 species and 64 alternate forms use
authentic native front/back stills. The full campaign has not been played
through. Gyarados is larger and Lapras uses a smaller display canvas.
Link/Frontier/Safari/Pal Park/tutorial/recorded battles keep normal Platinum
combat. Action catching currently uses regular Poke Balls, without nickname
or detailed Pokedex-entry screens.

Arena Plus DS v0.9.1 is the separate Emerald-based game. The preserved Platinum
baseline is unchanged Platinum, not this action port.
