# Platinum character creator requirements

Status: native new-game creator and saved avatar hooks are implemented and
compile with the original Metrowerks compiler. Candidate d8320955e7de has been
tested through the original Rowan introduction, Hoenn selection and custom
colors, native field/card display, native save, emulator close/reopen and
Continue. The original Rowan body/name flow remains; a native-font
customization page is inserted before naming.

Implemented selection: native Sinnoh Lucas/Dawn, source-adapted Hoenn
Brendan/May, or source-adapted Kanto Red/Leaf, with four skin tones, six hair
colors and eight outfit colors. This is 1,152 saved combinations. Hair shape
and garment shape changes beyond the six
provided base characters are not implemented.

Persistence is a separate versioned/CRC5 avatar record using only the original
four PlayerSave padding bytes (offsets 2/3 and 42/43). PlayerSave remains 44
bytes and native save blocks remain at their existing offsets. The decoder
also accepts all 768 prior 0.9.2 CRC6 Sinnoh/Hoenn records; saving writes the
new version without changing the chosen appearance. Unrecognized or damaged
records use the original native appearance. Union Room
TrainerInfo.appearance is unchanged.

The 0.9.3 creator uses stationary small overworld previews for all six bases.
Their canvas, nearest-neighbor scale and foot baseline match. Selection changes
only the highlight; it no longer reloads or advances running sprites every frame.
The final entry transition fades the same small sprite instead of changing into
Sinnoh portrait/shrink frames. Hoenn walking/running, bike, surf, fishing and
field-action directions now follow native north/south/west/east texture order.

The native texture dictionary remains authoritative for frame timing, VRAM
size and shared-frame aliases. The avatar art pack contains 66 entries and
adapts every native walking/running, cycling, surfing, fishing, field-action,
Poketch, save, healing, VS Seeker and contest texture. Distortion World and
Hearthome variants already use those same native player textures. It also
supplies creator preview, card portrait and native back/throw cells. Its two
additional entries contain the native Lucas/Dawn standing field previews. No
Lucas/Dawn body pixels are copied into the regional bundles.

The GBA art has no exact Poketch, save, healing or VS Seeker poses;
Poketch/healing use correctly facing field poses, while save/VS Seeker use
regional field-move gestures. Regional contest states retain their regional
clothes. Four Hoenn or five Kanto GBA throw poses are held across Platinum's
eight native cells/timing. Kanto Sprayduck uses a north-facing idle pose;
special bike gestures reuse cycling poses. Portraits are quantized to the matching
16-color regional field palette. These are explicit source-art adaptations,
not newly drawn authentic DS Hoenn player animation sets.

Validation: tests/arena/test_avatar.c checks all 1,152 current records and all
768 independently encoded prior-version records, all single-bit
record corruptions, unchanged non-padding save bytes and palette stability.
tests/arena/test_avatar_assets.py checks native rig palette coverage.
tests/arena/test_hoenn_avatar_assets.py checks pack integrity, all 66 entries,
native texture names/offsets/aliases, preview, card and throw allocation bounds.
It also compares the directional frames directly with the source sheets,
including the Hoenn and Kanto north/south regression, and verifies every creator preview is
a stationary field sprite. Both changed native C units compile with Metrowerks.
The 0.9.3 changes still need the root integration build and emulator checks.
Rebuild the regional pack with tools/arena/import_hoenn_avatars.py using the
supplied Emerald source asset tree and retained pinned Kanto files;
res/arena/avatar/provenance.json records source hashes and the shipped pack
hash. The Kanto manifest pins pret/pokefirered at
037335f4c725d7c9aecdac87066f2002b4bd7e14; no network fetch is needed to rebuild
the retained art pack.

Runtime evidence: validation/avatar-v7/ records a fresh Brendan profile with
Tan skin, Brown hair and Blue outfit. The same field sprite and card portrait
appear after a genuine native save and a new emulator process. All three
card exits returned to the native field/menu. An early transition capture was
initially misread as a persistent black screen; later retained screenshots,
unchanged file hashes and read-only GPU snapshots confirm normal rendering.
Runtime checks have not yet exercised May or every riding/field-action/battle
state; their asset bounds, frame aliases and palette coverage are checked by
the asset tests above.

The small naming-keyboard body icon still uses the original Lucas/Dawn icon.

## Player-facing requirements

- At the start, offer regional trainer presets and Create Your Own Character.
- Custom character options: name, body/base appearance, skin tone, hair style
  and color, outfit and outfit colors. Available styles depend on complete art.
- Use the saved choice consistently in the overworld, story animations,
  trainer card and battle entrances/throw/back sprites. Preserve Platinum's
  original story and menu presentation around the custom player identity.
- Retain the chosen look after changing maps, saving/loading, riding, surfing,
  fishing, field actions, special outfits and Distortion World movement.
- Reuse original names/dialogue placeholders so the player's chosen name
  remains the protagonist's name. Regional appearance does not rewrite the
  campaign into that preset character's separate original story.
- Provide a live preview. Include only regional presets with usable complete
  player assets; importing a portrait is not a completed playable preset.

## Confirmed source integration points

- New-game selection/name/gender save: RowanIntro state machine and
  RowanIntro_Exit in src/applications/rowan_intro/rowan_intro_app.c.
- All player state graphics: PlayerAvatar_New, PlayerAvatar_NewLoad and
  Player_GetSpriteFromStateAndGender in src/player_avatar.c.
- Persisted player data: include/trainer_info.h and src/save_player.c.
  TrainerInfo.appearance is for Union Room NPC classes. Keep this meaning and
  create a separate versioned avatar record for customization and preset IDs.
- Player assets: res/graphics/field_sprites/player/ and field_sprites/meson.build;
  special fishing/Distortion World models need corresponding support.
- Trainer card portrait: src/applications/trainer_case/main.c.
- Battle identity: FieldBattleDTO_CopyPlayerInfoToTrainerData in
  src/field_battle_data_transfer.c; throw/back mapping in battle_display.c
  and SpriteSystem_TrainerClassBackSpriteIndex in src/pokemon.c.
- src/appearance.c and Oreburgh Pokemon Center appearance scripts are a menu
  reference for limited NPC choices, not a full player customization system.

## Asset coverage

The supplied PKMN.NETSR4.zip contains 723 trainer images across generations
1-5, including useful regional portrait candidates. It has not established
complete alternate player animation sets. See trainer-portrait-candidates.json.
Original full-player assets currently found in Platinum are Lucas and Dawn.

Each new preset/customizable base needs consistent directional walk/run,
bike, surf, field move/Poke Ball, fishing, Poketch, save/heal, Sprayduck,
VS Seeker, contest/Hearthome and Distortion World coverage, plus card portraits
and battle backs/throws. Skin, hair and outfit palette regions must match
across these views. Do not silently revert to default Lucas/Dawn artwork
when changing movement state.

## Acceptance checks for implementation

New game -> create or select -> name -> start story -> map transition ->
walk/run -> bike/surf/fishing/field actions -> card -> battle entrance ->
save -> close -> reload. Every stage must retain the same saved identity.
Check original story flags and party/save data remain valid. Regional presets
and custom palettes must be verified across every shipped asset state.

## Finding more creator sprites

- Platinum format reference: https://github.com/pret/pokeplatinum/tree/main/res/graphics/field_sprites/player . These PNGs show the exact 32-pixel frames and native direction/state ordering used by the creator.
- Red/Leaf source sheets: https://github.com/pret/pokefirered/tree/master/graphics/object_events/pics/people . Look for `red_normal`, `red_bike`, `red_fish`, `red_surf_run` and `red_item`; Leaf is named `green_*` in that source. These are GBA sheets and need the same explicit adaptation as Brendan/May. All six bases are now available in this build.
- HeartGold/SoulSilver source and format reference: https://github.com/pret/pokeheartgold . Full trainer/overworld sheets are useful; a battle portrait alone cannot supply field movement.

For an individual PNG on GitHub, open the file, choose **Raw** or **Download raw file**, then save it. Keep every sheet for the same character together with its palette and artist/source credits. For custom art, include permission to reuse it. The Spriters Resource and Eevee Expo also host sprite resources, but their pages were unavailable from this build environment and have not been checked here.

A stable base needs a fixed canvas, transparent palette index 0, matching foot
positions, north/south/west/east facing order, and named idle/walk/run and riding
states. Import validation must check actual facing as well as dimensions. Keep
the creator still while editing colors; test movement, card, battle entrance
and save/reload before exposing a new base. The current creator can retain its
native menu; it does not need a new UI framework to support those fixes.
