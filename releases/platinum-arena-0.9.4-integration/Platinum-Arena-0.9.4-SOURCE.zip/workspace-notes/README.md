# Platinum Arena workspace

The native Platinum port supports live 1v1/2v2 combat inside the original story.
Version 0.9.4 integrates continuous source-art beams, phase-based attack timing,
smoother dodges, fitted held shields, paired sustained clashes and native
level/status/team-count HUD data. The 0.9.3 roster/creator/story integration
remains the baseline. Gameplay testing of the new build belongs to the user.
Hold L+R+Select at the title screen for a save-isolated Battle Lab.

The current integration build and source downloads are recorded in
`release/integration-094/`; all gameplay checks remain pending user playtesting.
See `pokeplatinum/docs/arena/MISSING-POSES.md` for source-art downloads.

The user-requested preview A download is recorded in
`release/preview-093/upload-plan.json`; final builds and exact-hash acceptance
reports live under `validation/v093/`. A preview is separate from the completed
feature build. Full campaign and hardware coverage remain open.

- [PORT-STATUS.md](PORT-STATUS.md): implementation and practical limits.
- [CHARACTER-CREATOR.md](CHARACTER-CREATOR.md): six bases, compatibility and sprite sources.
- [setup/README.md](setup/README.md): pinned toolchain and original baseline.
- [release/README.md](release/README.md): exact-ROM release acceptance gates.
- `pokeplatinum/src/arena/`: current native implementation.
- `validation/`: build, sanitizer, art and normal-input emulator evidence.
- `prototype/`: historical isolated compiler probe, separate from current code.

Build:

```sh
source /workspace/platinum-port/setup/env.sh
make -C /workspace/platinum-port/pokeplatinum rom
```

The two uploaded archives matched all 27,668 files at pret/pokeplatinum commit
`1dc13dcea40c04ab53f1f607de46023dc409ef20`. Its preserved original baseline
passed all five checksum tests. Modified ROMs have different hashes and use
the feature checks in PORT-STATUS.md. No extra base ROM upload is needed.

Older Emerald-based Arena Plus DS releases and saves remain separate in
`/workspace/Pokemon-arena-evolved/dist`.
