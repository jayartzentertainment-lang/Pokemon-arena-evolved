#!/usr/bin/env python3
"""Save the Platinum port patch, added source/assets and setup notes, without SDKs."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile


ROOT = Path("/workspace/platinum-port")
REPO = ROOT / "pokeplatinum"
BASE = "1dc13dcea40c04ab53f1f607de46023dc409ef20"
ALLOWED = ("include/arena/", "src/arena/", "res/arena/", "tools/arena/", "tests/arena/", "docs/arena/")
EXACT = {"tests/arena_rewards_host.c", "tests/test_arena_rewards.py"}
# This generated staging pack is already embedded in arena.pack and can be
# recreated from the included Gen IV PNG/XML source using compile_gen4.py.
OMIT = {"res/arena/gen4/gen4.pack", "res/arena/directional/directional.pack"}
GUIDE = """PLATINUM ARENA 0.9.3 - SOURCE MODIFICATIONS

This archive contains the local source changes, not a complete upstream
checkout, a ROM, a compiler or an SDK. Runtime acceptance is recorded with the
separate game download. The full campaign and real hardware are unvalidated.

BASE SOURCE
https://github.com/pret/pokeplatinum
Commit: 1dc13dcea40c04ab53f1f607de46023dc409ef20 (US Rev1)

APPLY TO A CLEAN CHECKOUT OF THAT COMMIT
1. Follow the upstream checkout/dependency instructions.
2. From the checkout, run: git apply --binary /path/to/changes.patch
3. Copy the contents of added-files/ into that checkout, retaining paths.
4. Follow the upstream build instructions to obtain dependencies and run
   make rom. The modified game is expected to differ from retail checksums.

The generated arena.pack, actor metadata, backgrounds and avatar pack are
included so an ordinary build does not need the original uploaded archives.
Directional source PNG/XML, credits, pinned download manifests and conversion
tools are included. Intermediate extension packs are omitted because they are
duplicated inside arena.pack; compile_gen4.py regenerates them if needed.
Recreating the retained 187 Arena sets from raw inputs additionally requires
the original accepted Arena source/assets mentioned in their provenance.

workspace-notes/ preserves implementation/limits docs and the original cloud
setup scripts/checksums. Those scripts use the original /workspace layout and
expect its local ARM assembler toolchain. toolchain-reference/ preserves the
plain setup script used to obtain that toolchain; no tool binaries are here.
For native Platinum only, bootstrap.sh is the relevant local dependency helper.
environment-install.sh also builds the separate Emerald-based project and
runs a historical prototype, so it requires those external directories.

SOURCE-MANIFEST.json records the base commit, patch/source hashes and omitted
intermediate. SHA256SUMS records every included payload file. Keep the source
art credits and licenses when sharing modifications.
"""


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])


def build(output, version="0.9.3"):
    if git("rev-parse", "HEAD").decode().strip() != BASE:
        raise ValueError("unexpected upstream commit")
    session = (REPO / "src/arena/session.c").read_bytes()
    if b"ArenaValidation_" in session:
        raise ValueError("refusing a source snapshot containing the validation session fixture")
    patch = git("diff", "--binary", "--full-index", BASE, "--")
    guide = GUIDE.replace("PLATINUM ARENA 0.9.3", "PLATINUM ARENA " + version)
    payloads = {"changes.patch": (patch, 0o644), "SOURCE-README.txt": (guide.encode(), 0o644)}
    names = git("ls-files", "--others", "--exclude-standard", "-z").split(b"\0")
    added = []
    for raw in names:
        if not raw:
            continue
        name = raw.decode("utf-8")
        if name in OMIT:
            continue
        if not (name.startswith(ALLOWED) or name in EXACT):
            raise ValueError("unreviewed untracked path; refusing broad capture: " + name)
        path = REPO / name
        if path.is_symlink() or not path.is_file():
            raise ValueError("expected a regular source/asset file: " + name)
        if "__pycache__" in path.parts or path.suffix in (".pyc", ".o", ".nds", ".nef"):
            raise ValueError("generated build output in source paths: " + name)
        payloads["added-files/" + name] = (path.read_bytes(), 0o755 if path.stat().st_mode & 0o111 else 0o644)
        added.append(name)
    notes = ["README.md", "PORT-STATUS.md", "PLAYER-README.txt", "CHARACTER-CREATOR.md", "INTEGRATION-MAP.md"]
    notes += ["setup/" + name for name in (
        "README.md", "bootstrap.sh", "env.sh", "environment-install.sh", "prepare_local_tools.py",
        "cache_wrap_patches.py", "record_baseline.py", "dependency-provenance.json",
        "debian-package-uris.txt", "metroskrew-originals.sha256", "debs/SHA256SUMS", "start-instructions.txt")]
    notes += ["release/" + name for name in ("README.md", "package_test_release.py", "capture_source_snapshot.py")]
    if version != "0.9.3" and (ROOT / "release/package_integration_preview.py").is_file():
        notes.append("release/package_integration_preview.py")
    for name in notes:
        path = ROOT / name
        payloads["workspace-notes/" + name] = (path.read_bytes(), 0o755 if path.stat().st_mode & 0o111 else 0o644)
    setup_tool = Path("/workspace/Pokemon-arena-evolved/ds/tools/setup_toolchain.sh")
    payloads["toolchain-reference/setup_toolchain.sh"] = (setup_tool.read_bytes(), 0o755)
    tracked = git("diff", "--name-only", BASE).decode().splitlines()
    manifest = {
        "name": "Platinum Arena " + version + " source modifications",
        "base_repository": "https://github.com/pret/pokeplatinum",
        "base_commit": BASE,
        "tracked_modified_files": tracked,
        "added_files": sorted(added),
        "omitted_generated_intermediate": sorted(OMIT),
        "session_source_sha256": sha(session),
        "files_sha256": {name: sha(data) for name, (data, mode) in sorted(payloads.items())},
        "contains_sdk_or_compiler": False,
        "contains_rom_or_save": False,
    }
    manifest_data = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    snapshot_id = sha(manifest_data)
    payloads["SOURCE-MANIFEST.json"] = (manifest_data, 0o644)
    sums = "".join(sha(data) + "  " + name + "\n" for name, (data, mode) in sorted(payloads.items()))
    payloads["SHA256SUMS"] = (sums.encode(), 0o644)
    if output is None:
        output = ROOT / "validation/source-snapshots" / ("ArenaPlus-Platinum-" + version + "-source-" + snapshot_id[:12] + ".zip")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix=".source-", suffix=".zip", dir=output.parent, delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, (data, mode) in sorted(payloads.items()):
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info._compresslevel = 9
                info.create_system = 3
                info.external_attr = (0o100000 | mode) << 16
                archive.writestr(info, data)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise RuntimeError("source ZIP CRC verification failed")
        archive_sha = sha(temporary.read_bytes())
        if output.exists():
            if sha(output.read_bytes()) != archive_sha:
                raise ValueError("refusing to overwrite a different source snapshot: " + str(output))
        else:
            os.replace(temporary, output)
        print(json.dumps({"zip": str(output), "bytes": output.stat().st_size, "sha256": archive_sha,
                          "snapshot_id": snapshot_id, "base_commit": BASE,
                          "session_source_sha256": manifest["session_source_sha256"],
                          "tracked_modified_count": len(tracked), "added_file_count": len(added)}, indent=2))
    finally:
        temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="optional output ZIP; defaults to an immutable hash-named validation snapshot")
    parser.add_argument("--version", default="0.9.3", help="source snapshot version label; defaults to the original release version")
    args = parser.parse_args()
    try:
        if not args.version or any(c not in "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-" for c in args.version):
            raise ValueError("invalid version label")
        build(args.output, args.version)
    except (ValueError, OSError, RuntimeError, subprocess.CalledProcessError) as error:
        parser.exit(1, "Source snapshot failed: " + str(error) + "\n")


if __name__ == "__main__":
    main()
