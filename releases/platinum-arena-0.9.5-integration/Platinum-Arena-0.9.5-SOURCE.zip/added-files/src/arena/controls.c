#include "arena/controls.h"
/* Nitro PAD_* hardware values; use the raw DS buttons so the native story
 * button-mode preference cannot silently remap action commands twice. */
static const uint16_t sPhysical[]={1,2,1024,2048,512,256,4};
static const char *const sLabels[]={"A","B","X","Y","L","R","SELECT"};
static const uint8_t sDefaults[]={3,1,0,2,4,6};
static uint8_t sBinding[]={3,1,0,2,4,6};
/* Legacy action IDs now mean move 1, fixed defence, move 2, move 3/4,
 * toggle 3/4 and aim. The simulation bits keep their existing ABI. */
static const uint16_t sSemantic[]={COMBAT_X,COMBAT_B,COMBAT_A,COMBAT_ALT,COMBAT_R,COMBAT_Y};
const char *ArenaControls_Label(unsigned action)
{return action<ARENA_CONTROL_COUNT?sLabels[sBinding[action]]:"?";}
void ArenaControls_Reset(void)
{unsigned i;for(i=0;i<ARENA_CONTROL_COUNT;i++)sBinding[i]=sDefaults[i];}
void ArenaControls_Cycle(unsigned action,int direction)
{
    unsigned i,old,next;
    if(action>=ARENA_CONTROL_COUNT||action==ARENA_CONTROL_GUARD)return;
    old=sBinding[action];next=old;
    /* B always means guard/dodge. Other actions may swap among the remaining
     * buttons, but must never acquire B or displace the defence binding. */
    do { next=(next+(direction<0?6:1))%7; } while(next==1);
    for(i=0;i<ARENA_CONTROL_COUNT;i++)if(i!=action&&sBinding[i]==next)sBinding[i]=old;
    sBinding[action]=next;
}
CombatInput ArenaControls_Map(uint32_t held,uint32_t pressed)
{
    static const uint16_t directions[]={64,128,32,16};
    static const uint16_t commands[]={COMBAT_UP,COMBAT_DOWN,COMBAT_LEFT,COMBAT_RIGHT};
    CombatInput input={0,0};unsigned i;
    for(i=0;i<4;i++){
        if(held&directions[i])input.held|=commands[i];
        if(pressed&directions[i])input.pressed|=commands[i];
    }
    /* L+R remains the capture chord even when either button is reassigned. */
    if((held&(512|256))==(512|256)){held&=~(512|256);pressed&=~(512|256);}
    for(i=0;i<ARENA_CONTROL_COUNT;i++){
        if(held&sPhysical[sBinding[i]])input.held|=sSemantic[i];
        if(pressed&sPhysical[sBinding[i]])input.pressed|=sSemantic[i];
    }
    return input;
}
