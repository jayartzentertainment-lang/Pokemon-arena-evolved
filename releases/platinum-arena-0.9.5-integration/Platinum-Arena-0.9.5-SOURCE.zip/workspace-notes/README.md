# Platinum Arena workspace

The native Platinum port supports live 1v1/2v2 combat inside the original story.
Version 0.9.5 is a focused controls/contact upgrade: Y uses equipped move 1,
A move 2, X move 3 or 4, and L toggles X's slot. B stays fixed for guard/dodge;
a directional double-tap within 12 simulation ticks uses the normal dodge
stamina/cooldown checks. Swift gains source-art stars, damaging contacts have
their own sparks, and firing-button taps push a shared beam-clash point.
Existing continuous beams, sounds, roster, creator and story hooks remain.
Hold L+R+Select at the title screen for a save-isolated Battle Lab; Clash modes
use Y's first move by default. L+R catching and Select/Start retain their roles.

The current compiler/package records belong to `validation/v095/` and
`release/integration-095/`. No emulator, gameplay or automated regression tests
were run for this pass, per the user's request. Gameplay checks remain pending
user playtesting. See `pokeplatinum/docs/arena/CHANGES-0.9.5.md` for scope.
Expanded layered trainer customization and global followers are deferred;
only Swift receives new move-specific art here, and other VFX fallbacks remain.
See `pokeplatinum/docs/arena/MISSING-POSES.md` for source-art downloads.

The user-requested preview A download is recorded in
`release/preview-093/upload-plan.json`; final builds and exact-hash acceptance
reports live under `validation/v093/`. A preview is separate from the completed
feature build. Full campaign and hardware coverage remain open.

- [PORT-STATUS.md](PORT-STATUS.md): implementation and practical limits.
- [CHARACTER-CREATOR.md](CHARACTER-CREATOR.md): six bases, compatibility and sprite sources.
- [setup/README.md](setup/README.md): pinned toolchain and original baseline.
- [release/README.md](release/README.md): exact-ROM release acceptance gates.
- `pokeplatinum/src/arena/`: current native implementation.
- `validation/`: build, sanitizer, art and normal-input emulator evidence.
- `prototype/`: historical isolated compiler probe, separate from current code.

Build:

```sh
source /workspace/platinum-port/setup/env.sh
make -C /workspace/platinum-port/pokeplatinum rom
```

The two uploaded archives matched all 27,668 files at pret/pokeplatinum commit
`1dc13dcea40c04ab53f1f607de46023dc409ef20`. Its preserved original baseline
passed all five checksum tests. Modified ROMs have different hashes and use
the feature checks in PORT-STATUS.md. No extra base ROM upload is needed.

Older Emerald-based Arena Plus DS releases and saves remain separate in
`/workspace/Pokemon-arena-evolved/dist`.
