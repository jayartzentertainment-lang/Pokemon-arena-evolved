PLATINUM ARENA 0.9.5 - USER PLAYTEST BUILD

This focused upgrade adds the requested move-slot controls, directional
double-tap dash, contact sparks, Swift stars and interactive beam pressure.
Platinum's original story, maps, party and field menus remain the foundation.
Supported offline encounters use live action, including 2v2 with an AI teammate.
No emulator, gameplay or automated regression tests were run for this pass,
as requested. Please assess the actual game; compiler success is not a playtest.

DEFAULT BATTLE CONTROLS
D-pad: move and aim
Y: equipped move 1
A: equipped move 2
X: equipped move 3 or 4
L: toggle X between moves 3 and 4
R: reserved outside the L+R catching chord; no standalone default action
B + direction: dodge
B held without a direction: shield
Double-tap the same direction within 12 simulation ticks: dodge
Select: toggle aim lock
Start: pause, switch Pokemon, use medicine or try running

B is fixed for guard/dodge. Other combat bindings can be changed from Controls
in the pause menu or Battle Lab and reset when the ROM restarts. Menus retain
their normal A/B navigation. Double-tap and B-direction dodges share stamina,
cooldown and action-cancellation rules.

BEAM CLASHES AND BATTLE LAB
During a beam clash, tap the button assigned to the move that fired your beam.
Fresh presses push the shared contact point; holding does not repeatedly push.
An endpoint resolves one damage attempt; a timed-out clash dissipates both beams.
Tap pressure does not spend extra PP. Simultaneous 2v2 can have two clash pairs.
Hold L+R+Select at the title screen for Battle Lab. Choose Clash 1v1 or Clash
2v2, then Start. The first equipped move is the practice beam: Y by default.
Lab teams are temporary and discard practice HP/PP/rewards on exit.

CATCHING
Hold L+R to aim. Adjust with D-pad. Release a shoulder to throw.
B cancels before throwing without spending a ball.
Uses ordinary Poke Balls from your bag. Only one wild foe may remain.
Caught Pokemon enter your actual party or PC boxes.

STAMINA AND MOVES
Y/A/X use the equipped moves and their saved PP. An emergency Struggle
fallback remains available when all moves are out of PP.
Dodge and guard use stamina, which regenerates after a short delay.
Holding guard at zero stamina does not provide a shield. Strong blocked moves
can deal chip damage. Swift has new star artwork; other move-art fallbacks remain.
EXP, level-ups, move choices, money and evolution use native party/story data.

APPEARANCE
The existing introduction offers Lucas/Dawn, Brendan/May and Red/Leaf with
skin, hair-colour and outfit-colour options. The expanded layered hairstyle,
clothing and accessory editor and global Pokemon followers are deferred.
They have source assets, but are not part of this build.

CURRENT LIMITS
Many complex moves use simplified action effects. Full original abilities,
weather, items and scripted move behavior remain incomplete. All 493 canonical
species have directional sets; 64 alternate forms retain native still-image
fallbacks. Dedicated hurt/brace coverage and additional move-specific effects
remain later work. The full campaign, real hardware, all controls and battle/
save continuation need user playtesting. Gyarados and Lapras retain their
existing species-specific display sizes.
Link/Frontier/Safari/Pal Park/tutorial/recorded battles keep normal Platinum
combat. Action catching currently uses regular Poke Balls, without nickname
or detailed Pokedex-entry screens.

BUILD RECORDS
Compiler/candidate records: validation/v095/
Integration download records: release/integration-095/

HISTORICAL REFERENCES
Arena Plus DS v0.9.1 is the separate Emerald-based game. The preserved Platinum
baseline is unchanged Platinum, not this action port.
