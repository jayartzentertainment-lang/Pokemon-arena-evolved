The Platinum arena has 294 species with authentic eight-direction action sprites: 187 from the supplied Emerald Arena workspace and all 107 Gen IV species from PMDCollab/SpriteCollab at commit `d25607ff4746957df10bdb78db090887cd94f1f8`. The other 199 species and 64 alternate forms use explicitly static native Platinum front/back portraits. They remain playable; directional animation is not claimed for those fallbacks.

The separate uploaded SpriteCollab RAR exceeded the attachment tool's 32 MiB transfer limit. The Gen IV sprites here came from the pinned upstream repository, not from an uninspected archive. Per-species artist credits, source file hashes, original pose names and timing, transformations, cache sizes and output hashes are retained in `manifest.json`. The source license is in `LICENSE.md`. Nintendo/Chunsoft original rights are not reassigned by those community terms.

Every original Gen IV frame and direction is read from its actual source sheet. Minimal frame registration translations fit lunges within a 64-pixel OBJ cell while the live combat controller supplies world displacement. Ten species use a documented integer nearest-neighbour reduction to respect cell dimensions or the 160 KiB per-actor pose cache. Runtime display scaling compensates for this reduction, capped at the native 128-pixel affine cell. No new Pokemon artwork or missing animation frames were fabricated.

Gyarados uses a 128-pixel display canvas and Lapras a 72-pixel canvas. Their source body sizes differ, so this produces approximately 56–64 pixels of visible Gyarados and 44–48 pixels of Lapras. Native still portraits are normalized by their measured opaque front/back bounds so their filled canvas does not make them dwarf directional sprites. Collision uses the combat controller's foot radius and is independent of transparent canvas size.

To regenerate the staged Gen IV extension from its included source:

```sh
python3 tools/arena/compile_gen4.py
python3 tools/arena/generate_assets.py --arena /path/to/accepted/ds
python3 tools/arena/validate_assets.py --arena /path/to/accepted/ds
```

`tools/arena/fetch_gen4.py` optionally refreshes the raw source files from the same pinned revision. Ordinary ROM builds use checked-in generated cartridge data and do not contact the network. The `--arena` source must be the accepted DS Arena tree, including its original asset table and pack.

The validator checks the National Dex identity of every table row, preserves all 187 supplied directional records and their exact pack bytes, verifies imported Gen IV bytes and timings against the staged extension, checks every dictionary/map/frame range, and measures native portrait bounds from actual cartridge pixels. The largest pose cache is 161,704 bytes; the largest four distinct caches total 640,824 bytes. Poses are loaded at deployment and retained in memory during combat.
