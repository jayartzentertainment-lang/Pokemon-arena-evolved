PLATINUM ARENA 0.9.6 - SOURCE MODIFICATIONS

This archive contains the local source changes, not a complete upstream
checkout, a ROM, a compiler or an SDK. Compiler evidence accompanies the separate game download.
Gameplay testing is pending the user; no emulator or gameplay tests were run. The full campaign and real hardware are unvalidated.

BASE SOURCE
https://github.com/pret/pokeplatinum
Commit: 1dc13dcea40c04ab53f1f607de46023dc409ef20 (US Rev1)

APPLY TO A CLEAN CHECKOUT OF THAT COMMIT
1. Follow the upstream checkout/dependency instructions.
2. From the checkout, run: git apply --binary /path/to/changes.patch
3. Copy the contents of added-files/ into that checkout, retaining paths.
4. Follow the upstream build instructions to obtain dependencies and run
   make rom. The modified game is expected to differ from retail checksums.

The generated arena.pack, actor metadata, backgrounds and avatar pack are
included so an ordinary build does not need the original uploaded archives.
Directional source PNG/XML, credits, pinned download manifests and conversion
tools are included. Intermediate extension packs are omitted because they are
duplicated inside arena.pack; compile_gen4.py regenerates them if needed.
Recreating the retained 187 Arena sets from raw inputs additionally requires
the original accepted Arena source/assets mentioned in their provenance.

workspace-notes/ preserves implementation/limits docs and the original cloud
setup scripts/checksums. Those scripts use the original /workspace layout and
expect its local ARM assembler toolchain. toolchain-reference/ preserves the
plain setup script used to obtain that toolchain; no tool binaries are here.
For native Platinum only, bootstrap.sh is the relevant local dependency helper.
environment-install.sh also builds the separate Emerald-based project and
runs a historical prototype, so it requires those external directories.

SOURCE-MANIFEST.json records the base commit, patch/source hashes and omitted
intermediate. SHA256SUMS records every included payload file. Keep the source
art credits and licenses when sharing modifications.
