#!/usr/bin/env bash
# Install the pinned native DS compiler and ROM packager without system writes.
set -euo pipefail

if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
    printf '%s\n' 'This bootstrap supports Linux x86_64 (validated on Debian 13).' >&2
    exit 1
fi
for program in curl sha256sum tar dpkg-deb gcc g++; do
    command -v "$program" >/dev/null || { printf 'Missing host prerequisite: %s\n' "$program" >&2; exit 1; }
done

repo_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)
if [[ -d /workspace ]]; then
    tool_root=${ARENA_TOOLCHAIN_ROOT:-/workspace/.tools}
else
    tool_root=${ARENA_TOOLCHAIN_ROOT:-"$repo_root/.tools"}
fi
mkdir -p "$tool_root/cache" "$tool_root/arm" "$tool_root/bin" "$tool_root/src"
tool_root=$(cd -- "$tool_root" && pwd)
cache="$tool_root/cache"

fetch_verified() {
    local filename=$1 expected=$2 url=$3
    local destination="$cache/$filename" partial="$cache/$filename.part.$$"
    if [[ -f "$destination" ]]; then
        printf '%s  %s\n' "$expected" "$destination" | sha256sum --check --status || {
            printf 'Checksum mismatch in cached artifact: %s\n' "$destination" >&2
            exit 1
        }
        return
    fi
    curl --fail --show-error --location --proto '=https' --tlsv1.2 "$url" --output "$partial"
    if ! printf '%s  %s\n' "$expected" "$partial" | sha256sum --check --status; then
        rm -f -- "$partial"
        printf 'Checksum mismatch for %s\n' "$filename" >&2
        exit 1
    fi
    mv -- "$partial" "$destination"
}

# Debian digests below came from an authenticated trixie Packages index.
fetch_verified gcc-arm-none-eabi_14.2.rel1-1_amd64.deb \
    99252fdda02ad134e8c3c344d3c843f7aa5c0d006e92a5b3d53daf4bd935b5d3 \
    https://deb.debian.org/debian/pool/main/g/gcc-arm-none-eabi/gcc-arm-none-eabi_14.2.rel1-1_amd64.deb
fetch_verified binutils-arm-none-eabi_2.44-3+23+b1_amd64.deb \
    c9c4944e54de852536b4f6a238a682c38a6243cdc2843dd1c4f587e046c0615b \
    https://deb.debian.org/debian/pool/main/b/binutils-arm-none-eabi/binutils-arm-none-eabi_2.44-3+23+b1_amd64.deb
# Upstream source is fixed to an exact release tag and byte digest, over TLS.
fetch_verified ndstool-v2.3.1.tar.gz \
    5918dd3462d141bccba2412c06309bd7bca45a891067d455e97fdb8c9c1dd790 \
    https://codeload.github.com/devkitPro/ndstool/tar.gz/refs/tags/v2.3.1

compiler_stamp="$tool_root/arm/.arena-version"
if [[ ! -f "$compiler_stamp" ]] || [[ $(cat "$compiler_stamp") != 'gcc14.2.1-binutils2.44' ]]; then
    dpkg-deb --extract "$cache/gcc-arm-none-eabi_14.2.rel1-1_amd64.deb" "$tool_root/arm"
    dpkg-deb --extract "$cache/binutils-arm-none-eabi_2.44-3+23+b1_amd64.deb" "$tool_root/arm"
    printf '%s\n' 'gcc14.2.1-binutils2.44' > "$compiler_stamp"
fi

ndstool_stamp="$tool_root/bin/.arena-ndstool-version"
if [[ ! -x "$tool_root/bin/ndstool" || ! -f "$ndstool_stamp" ]] || [[ $(cat "$ndstool_stamp") != 'v2.3.1' ]]; then
    source_dir="$tool_root/src/ndstool-v2.3.1"
    mkdir -p "$source_dir/build"
    tar --extract --gzip --file "$cache/ndstool-v2.3.1.tar.gz" --strip-components=1 --directory "$source_dir"
    c_objects=()
    for source in "$source_dir"/source/*.c; do
        object="$source_dir/build/$(basename "${source%.c}").o"
        gcc -O2 -c "$source" -o "$object"
        c_objects+=("$object")
    done
    g++ -O2 -std=gnu++14 '-DPACKAGE_VERSION="2.3.1"' \
        "$source_dir"/source/*.cpp "${c_objects[@]}" -o "$tool_root/bin/ndstool"
    printf '%s\n' 'v2.3.1' > "$ndstool_stamp"
fi

# Exercise cc1, assembler and linker helpers, so missing host libraries fail now.
printf 'int main(void) { return 0; }\n' | \
    "$tool_root/arm/usr/bin/arm-none-eabi-gcc" -mcpu=arm946e-s -marm \
    -ffreestanding -nostdlib -x c -c -o "$cache/arm-smoke.o" -
"$tool_root/bin/ndstool" >/dev/null
printf 'export PATH=%q:%q:"$PATH"\n' "$tool_root/bin" "$tool_root/arm/usr/bin" > "$tool_root/env-nds.sh"
printf 'DS build tools ready in %s\n' "$tool_root"
printf 'Run: source %q\n' "$tool_root/env-nds.sh"
