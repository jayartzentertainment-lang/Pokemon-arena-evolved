/* Real bridge + real action controller against a narrow host native-DTO model.
 * Validates ownership/roundtrip/replacement behavior, not native encryption. */
#include "arena/party_bridge.h"
#include "pokemon.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static Party parties[4];
static FieldBattleDTO dto;
static ArenaPartyBridge bridge;
static Combat combat;
static unsigned writes;
static unsigned defeats;
static unsigned defeatOwner;
static unsigned defeatSlot;
static u32 defeatMask;

int Party_GetCurrentCount(const Party *party) { return party->count; }
Pokemon *Party_GetPokemonBySlotIndex(const Party *party, int slot)
{ assert(slot >= 0 && slot < party->count); return (Pokemon *)&party->mon[slot]; }
u32 Pokemon_GetValue(Pokemon *mon, enum PokemonDataParam param, void *dest)
{ (void)dest; assert((unsigned)param < 180); return mon->data[param]; }
void Pokemon_SetValue(Pokemon *mon, enum PokemonDataParam param, const void *value)
{
    /* The bridge may only modify battle HP/current PP/nonvolatile status. Identity/stat/
     * original moves/PP Ups and other trainers' ownership remain native. */
    writes++;
    if (param == MON_DATA_HP) mon->data[param] = *(const u16 *)value;
    else if (param == MON_DATA_STATUS) mon->data[param] = *(const u32 *)value;
    else {
        assert(param >= MON_DATA_MOVE1_PP && param <= MON_DATA_MOVE4_PP);
        mon->data[param] = *(const u8 *)value;
    }
}

static void Mon(unsigned owner, unsigned slot, unsigned species)
{
    Pokemon *mon = &parties[owner].mon[slot];
    if (parties[owner].count <= (int)slot) parties[owner].count = slot + 1;
    mon->data[MON_DATA_SPECIES] = species;
    mon->data[MON_DATA_HP] = 17 + slot;
    mon->data[MON_DATA_MAX_HP] = 23 + slot;
    mon->data[MON_DATA_ATK] = 11;
    mon->data[MON_DATA_DEF] = 12;
    mon->data[MON_DATA_SP_ATK] = 13;
    mon->data[MON_DATA_SP_DEF] = 14;
    mon->data[MON_DATA_SPEED] = 15;
    mon->data[MON_DATA_LEVEL] = 5 + slot;
    mon->data[MON_DATA_TYPE_1] = 10;
    mon->data[MON_DATA_TYPE_2] = 10;
    mon->data[MON_DATA_ABILITY] = 66;
    mon->data[MON_DATA_STATUS] = 0x80;
    mon->data[MON_DATA_FORM] = 1;
    mon->data[MON_DATA_HELD_ITEM] = 4;
    mon->data[MON_DATA_MOVE1] = 10;
    mon->data[MON_DATA_MOVE2] = 467;
    mon->data[MON_DATA_MOVE3] = 65535; /* Unknown native data stays intact. */
    mon->data[MON_DATA_MOVE1_PP] = 45; /* PP Ups can exceed base PP. */
    mon->data[MON_DATA_MOVE2_PP] = 7;
    mon->data[MON_DATA_MOVE3_PP] = 3;
    mon->data[MON_DATA_MOVE1_PP_UPS] = 3;
}

static void Defeat(void *ctx, unsigned actor, unsigned owner, unsigned slot, Pokemon *mon, u32 mask)
{
    assert(ctx == &dto && (actor & 1));
    assert(mon == &parties[owner].mon[slot]);
    assert(mon->data[MON_DATA_HP] == 0);
    defeats++; defeatOwner = owner; defeatSlot = slot; defeatMask = mask;
}

static void Reset(unsigned type, unsigned count0, unsigned count1, unsigned count2, unsigned count3)
{
    unsigned counts[4] = { count0, count1, count2, count3 };
    memset(parties, 0, sizeof(parties));
    memset(&dto, 0, sizeof(dto));
    dto.battleType = type;
    for (unsigned owner = 0; owner < 4; owner++) {
        dto.parties[owner] = &parties[owner];
        for (unsigned slot = 0; slot < counts[owner]; slot++) Mon(owner, slot, 390 + owner * 6 + slot);
    }
    writes = defeats = 0;
    assert(ArenaParty_Begin(&bridge, &dto, &combat));
    ArenaParty_SetDefeatCallback(&bridge, Defeat, &dto);
}

static void Roundtrip(void)
{
    Reset(0, 2, 2, 0, 0);
    Pokemon original = parties[0].mon[0];
    assert(combat.fighters[0].maxHp == 23 * 8 && combat.fighters[0].hp == 17 * 8);
    assert(combat.fighters[0].attack == 11 * 4 && combat.fighters[0].spDefense == 14 * 4);
    assert(combat.fighters[0].pp[0] == 45 && combat.fighters[0].moves[2] == 65535);
    assert(bridge.actor[0].ppUps[0] == 3 && bridge.actor[0].ability == 66);
    assert(bridge.actor[0].status == 0x80 && bridge.actor[0].form == 1);
    ArenaParty_Store(&bridge);
    assert(!memcmp(&original, &parties[0].mon[0], sizeof(original)) && writes == 0);
    combat.fighters[0].hp -= 9;
    combat.fighters[0].pp[0]--;
    combat.fighters[0].stamina = 11;
    combat.fighters[0].regenDelay = 19;
    combat.fighters[0].dashCooldown = 12;
    combat.fighters[0].cooldown[0] = 120;
    combat.fighters[0].stages[COMBAT_STAT_ATTACK] = 2;
    ArenaParty_Store(&bridge);
    assert(parties[0].mon[0].data[MON_DATA_HP] == 16);
    assert(parties[0].mon[0].data[MON_DATA_MOVE1_PP] == 44 && writes == 2);
    assert(ArenaParty_SwitchPlayer(&bridge, 1));
    combat.frame += 10; /* Benched cooldowns elapse, rather than reset. */
    assert(ArenaParty_SwitchPlayer(&bridge, 0));
    assert(combat.fighters[0].hp == 17 * 8 - 9); /* No switch-rounding heal. */
    assert(combat.fighters[0].stamina == 11 && combat.fighters[0].regenDelay == 19);
    assert(combat.fighters[0].dashCooldown == 12 && combat.fighters[0].pp[0] == 44);
    assert(combat.fighters[0].cooldown[0] == 110);
    assert(combat.fighters[0].stages[COMBAT_STAT_ATTACK] == 0); /* Switch clears stages. */
    assert(parties[0].mon[0].data[MON_DATA_MOVE3] == 65535);
    assert(parties[0].mon[0].data[MON_DATA_MOVE3_PP] == 3);
}

static void Ownership(void)
{
    Reset(BATTLE_TYPE_DOUBLES, 3, 3, 0, 0);
    assert(bridge.actor[0].owner == 0 && bridge.actor[2].owner == 0);
    assert(bridge.actor[1].owner == 1 && bridge.actor[3].owner == 1);
    assert(bridge.actor[0].slot == 0 && bridge.actor[2].slot == 1);
    assert(bridge.actor[1].slot == 0 && bridge.actor[3].slot == 1);
    combat.projectiles[0].owner = 0; combat.projectiles[0].life = 20;
    combat.fighters[2].stamina = 27;
    assert(ArenaParty_SwitchPlayer(&bridge, 1));
    assert(bridge.controlActor == 2 && combat.controlActor == 2);
    assert(combat.projectiles[0].life == 20 && combat.projectiles[0].owner == 0);
    assert(combat.fighters[2].stamina == 27);
    assert(ArenaParty_SwitchPlayer(&bridge, 2));
    assert(bridge.actor[2].slot == 2 && bridge.actor[0].slot == 0);
    assert(ArenaParty_PlayerParticipants(&bridge, 1, 0) == 7);

    Reset(BATTLE_TYPE_DOUBLES | BATTLE_TYPE_TAG, 2, 1, 0, 1);
    assert(bridge.actor[2].owner == 0 && bridge.actor[3].owner == 3);
    Reset(BATTLE_TYPE_DOUBLES | BATTLE_TYPE_2vs2, 2, 1, 2, 1);
    assert(bridge.actor[2].owner == 2 && bridge.actor[3].owner == 3);
    combat.fighters[2].hp -= 16; combat.fighters[2].pp[0]--;
    Pokemon player = parties[0].mon[0];
    ArenaParty_Store(&bridge);
    assert(!memcmp(&player, &parties[0].mon[0], sizeof(player)));
    assert(parties[2].mon[0].data[MON_DATA_HP] == 15);
    assert(parties[2].mon[0].data[MON_DATA_MOVE1_PP] == 44);
    assert(ArenaParty_PlayerParticipants(&bridge, 1, 0) == 1);
}

static void Waves(void)
{
    Reset(0, 2, 3, 0, 0);
    for (unsigned slot = 0; slot < 3; slot++) {
        assert(bridge.actor[1].slot == slot);
        combat.fighters[1].hp = 0; combat.winner = 1;
        int result = ArenaParty_Advance(&bridge);
        assert(defeats == slot + 1 && defeatOwner == 1 && defeatSlot == slot && defeatMask == 1);
        assert(result == (slot == 2 ? BATTLE_RESULT_WIN : BATTLE_IN_PROGRESS));
        if (slot != 2) assert(combat.fighters[1].hp && !combat.winner);
        ArenaParty_Advance(&bridge); assert(defeats == slot + 1);
    }
    Reset(BATTLE_TYPE_DOUBLES | BATTLE_TYPE_2vs2, 1, 2, 1, 2);
    combat.fighters[1].hp = combat.fighters[3].hp = 0; combat.winner = 1;
    assert(ArenaParty_Advance(&bridge) == BATTLE_IN_PROGRESS && defeats == 2);
    assert(bridge.actor[1].slot == 1 && bridge.actor[3].slot == 1);
    combat.fighters[1].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_IN_PROGRESS && defeats == 3);
    combat.fighters[3].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_RESULT_WIN && defeats == 4);

    Reset(BATTLE_TYPE_DOUBLES, 2, 2, 0, 0);
    combat.fighters[0].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_IN_PROGRESS);
    assert(bridge.controlActor == 2 && combat.controlActor == 2);
    combat.fighters[2].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_RESULT_LOSE);
}

static void RefreshAndEggs(void)
{
    Reset(0, 3, 2, 0, 0);
    parties[0].mon[1].data[MON_DATA_IS_EGG] = 1;
    combat.fighters[0].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_IN_PROGRESS && bridge.actor[0].slot == 2);
    assert(!ArenaParty_SwitchPlayer(&bridge, 1));
    Pokemon *mon = ArenaParty_ActorPokemon(&bridge, 0);
    mon->data[MON_DATA_MAX_HP] += 2; mon->data[MON_DATA_HP] += 2;
    mon->data[MON_DATA_ATK] += 1;
    mon->data[MON_DATA_MOVE2] = 46; mon->data[MON_DATA_MOVE2_PP] = 20;
    ArenaParty_Refresh(&bridge);
    assert(combat.fighters[0].maxHp == 27 * 8 && combat.fighters[0].hp == 21 * 8);
    assert(combat.fighters[0].attack == 12 * 4);
    assert(combat.fighters[0].moves[1] == 46 && combat.fighters[0].pp[1] == 20);
}

static void StatusAndReplacement(void)
{
    Reset(0, 2, 1, 0, 0);
    Combat_SetNativeStatus(&combat, 0, 0x10); /* Real native burn mask. */
    ArenaParty_Store(&bridge);
    assert(parties[0].mon[0].data[MON_DATA_STATUS] == 0x10);
    assert(ArenaParty_SwitchPlayer(&bridge, 1));
    assert(ArenaParty_SwitchPlayer(&bridge, 0));
    assert(Combat_GetNativeStatus(&combat, 0) == 0x10);
    parties[0].mon[0].data[MON_DATA_STATUS] = 0; /* Native medicine cure. */
    ArenaParty_Refresh(&bridge);
    assert(Combat_GetNativeStatus(&combat, 0) == 0);
    ArenaParty_SetManualPlayerReplacement(&bridge, TRUE);
    combat.fighters[0].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_IN_PROGRESS);
    assert(ArenaParty_NeedsPlayerReplacement(&bridge));
    assert(bridge.actor[0].slot == 0 && combat.fighters[0].hp == 0);
    assert(!ArenaParty_SwitchPlayer(&bridge, 0));
    assert(ArenaParty_SwitchPlayer(&bridge, 1));
    assert(!ArenaParty_NeedsPlayerReplacement(&bridge) && combat.fighters[0].hp);

    Reset(BATTLE_TYPE_DOUBLES, 3, 2, 0, 0);
    ArenaParty_SetManualPlayerReplacement(&bridge, TRUE);
    combat.fighters[0].hp = 0;
    assert(ArenaParty_Advance(&bridge) == BATTLE_IN_PROGRESS);
    assert(ArenaParty_NeedsPlayerReplacement(&bridge));
    assert(!ArenaParty_SwitchPlayer(&bridge, 1)); /* Already deployed ally. */
    assert(ArenaParty_SwitchPlayer(&bridge, 2));
    assert(bridge.actor[0].slot == 2 && bridge.actor[2].slot == 1);
    assert(!ArenaParty_NeedsPlayerReplacement(&bridge));
}

int main(void)
{
    Roundtrip(); Ownership(); Waves(); RefreshAndEggs(); StatusAndReplacement();
    puts("party bridge: HP/PP, owners, waves, participants, controls and native refresh pass");
    return 0;
}
