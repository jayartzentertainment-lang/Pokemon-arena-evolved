#!/usr/bin/env python3
"""Exercise production recoloring against every complete native player rig palette."""
import ctypes
from pathlib import Path
import subprocess
import tempfile
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]

class Profile(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint8) for name in ("body", "skin", "hair", "outfit", "regional",
                                                "hairstyle", "top", "legwear", "hat", "legColor", "shoes")]

with tempfile.TemporaryDirectory(prefix="platinum-avatar-assets-") as temporary:
    library = Path(temporary) / "avatar.so"
    subprocess.run(["cc", "-std=c99", "-Wall", "-Wextra", "-Werror", "-shared", "-fPIC",
                    "-DARENA_AVATAR_HOST", "-I" + str(ROOT / "include"),
                    str(ROOT / "src/arena/avatar.c"), "-o", str(library)], check=True)
    native = ctypes.CDLL(str(library))
    native.ArenaAvatar_ApplyPalette.argtypes = [ctypes.POINTER(Profile), ctypes.POINTER(ctypes.c_uint16), ctypes.c_int]
    native.ArenaAvatar_CustomDefault.argtypes = [ctypes.POINTER(Profile), ctypes.c_int]
    checked = 0
    for image_path in sorted((ROOT / "res/graphics/field_sprites/player").glob("*.png")):
        body = int("player_f" in image_path.name)
        image = Image.open(image_path)
        palette = image.getpalette()
        used = [index for _, index in image.getcolors()]
        values = [sum((palette[index * 3 + channel] >> 3) << (channel * 5) for channel in range(3)) for index in used]
        for feature in ("skin", "hair", "outfit"):
            profile = Profile(body, 0, 0, 0)
            setattr(profile, feature, 1)
            output = (ctypes.c_uint16 * len(values))(*values)
            native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), output, len(values))
            assert list(output) != values, (image_path.name, feature, "no visible customization")
            checked += 1
        # Original palettes and each chosen palette survive repeated cache uploads.
        for skin in range(4):
            for hair in range(6):
                for outfit in range(8):
                    profile = Profile(body, skin, hair, outfit)
                    output = (ctypes.c_uint16 * len(values))(*values)
                    native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), output, len(values))
                    first = list(output)
                    if skin == hair == outfit == 0:
                        assert first == values
                    native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), output, len(values))
                    assert list(output) == first, (image_path.name, skin, hair, outfit, "cache recolor drift")
                    checked += 1
    # Custom layers have semantic dye slots. A dye must visibly change its
    # own category while leaving all other categories and fixed trim intact.
    custom_checked = 0
    for body in range(2):
        profile = Profile()
        native.ArenaAvatar_CustomDefault(ctypes.byref(profile), body)
        original = (ctypes.c_uint16 * 16)(*[0x1234] * 16)
        native.ArenaAvatar_ApplyPalette(ctypes.byref(profile), original, 16)
        base = list(original)
        assert base[0] == 0
        for feature, count, slots in [("skin", 4, {2, 3, 4}), ("hair", 6, {5, 6, 7}),
                                      ("outfit", 8, {8, 9, 10}), ("legColor", 4, {11, 12}),
                                      ("shoes", 4, {13, 14})]:
            for choice in range(1, count):
                changed = Profile.from_buffer_copy(profile)
                setattr(changed, feature, choice)
                output = (ctypes.c_uint16 * 16)(*base)
                native.ArenaAvatar_ApplyPalette(ctypes.byref(changed), output, 16)
                actual_slots = {i for i, (before, after) in enumerate(zip(base, output)) if before != after}
                assert actual_slots == slots, (body, feature, choice, actual_slots, "semantic dye affected another category")
                once = list(output)
                native.ArenaAvatar_ApplyPalette(ctypes.byref(changed), output, 16)
                assert list(output) == once, (body, feature, choice, "custom cache recolor drift")
                custom_checked += 1
        for feature, count in [("hairstyle", 4), ("top", 3), ("legwear", 3), ("hat", 3)]:
            for choice in range(count):
                changed = Profile.from_buffer_copy(profile)
                setattr(changed, feature, choice)
                output = (ctypes.c_uint16 * 16)(*base)
                native.ArenaAvatar_ApplyPalette(ctypes.byref(changed), output, 16)
                assert list(output) == base, (body, feature, choice, "shape selection unexpectedly changes dye")
                custom_checked += 1
    print(f"Native avatar asset palettes: {checked} original checks and {custom_checked} custom dye-isolation/shape/cache checks passed")
