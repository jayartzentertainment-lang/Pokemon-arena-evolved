#!/usr/bin/env python3
"""Validate shipped art bounds, native texture aliases, card and throw coverage."""
from pathlib import Path
from struct import unpack_from
import hashlib,json
from PIL import Image, ImageOps

ROOT=Path(__file__).resolve().parents[2]
folder=ROOT/'res/arena/avatar'
b=(folder/'avatar.bin').read_bytes()
manifest=json.loads((folder/'provenance.json').read_text())
for item in json.loads((folder/'kanto-source/manifest.json').read_text())['files']:
    if 'error' in item: continue # The source manifest also records unsuccessful metadata lookups.
    source_file=folder/'kanto-source'/item['path']
    assert source_file.stat().st_size==item['bytes']
    assert hashlib.sha256(source_file.read_bytes()).hexdigest()==item['sha256']
assert len(b)==manifest['bytes'] and hashlib.sha256(b).hexdigest()==manifest['sha256']
assert unpack_from('<4sIII',b)==(b'AVA1',3,66,0)
entries=[unpack_from('<IIII',b,16+i*16)for i in range(66)]
assert len(entries)==66

def preview_tiles(field_pose):
    """The stationary pose keeps its source anchor inside native64x128 BG art."""
    canvas=Image.new('P',(64,128),0)
    canvas.paste(field_pose.resize((64,64),Image.Resampling.NEAREST),(0,32))
    expected=bytearray()
    for y in range(0,128,8):
        for x in range(0,64,8):
            pixels=list(canvas.crop((x,y,x+8,y+8)).getdata())
            expected.extend(pixels[i]|(pixels[i+1]<<4)for i in range(0,64,2))
    # Source art may move inside its32x32 pose; the surrounding preview stays
    # blank above and below it, without automatic bounding-box recentering.
    assert not any(expected[:1024]) and not any(expected[3072:])
    return bytes(expected)

states=['player_{s}','player_{s}_bike','player_{s}_holding_pokeball','player_{s}_sprayduck','player_{s}_surf','player_{s}_contest','player_{s}_fishing','player_{s}_poketch','player_{s}_save','player_{s}_pokecenter_heal','player_{s}_vs_seeker','dp_player_{s}']
frames=0
for regional in range(2):
 for body in range(2):
    for state in range(16):
        offset,size,stride,palette_size=entries[regional*32+body*16+state]
        assert palette_size==32 and offset+32+size<=len(b) and size%stride==0
        assert any(b[offset:offset+32])
        data=b[offset+32:offset+32+size]
        assert any(data)
        if state<12:
            path=ROOT/'build/res/graphics/field_sprites/field_sprites.narc.p'/f"{states[state].format(s='m'if body==0 else'f')}.nsbtx"
            original=path.read_bytes();t=original[original.index(b'TEX0'):];d=t[60:]
            oe=unpack_from('<H',d,6)[0];unit,on=unpack_from('<HH',d,oe)
            assert stride==512 and d[1]*512==size
            shared={}
            for index in range(d[1]):
                name=d[oe+on+index*16:oe+on+(index+1)*16].split(b'\0')[0].decode()
                assert '.'in name
                frame=int(name.rsplit('.',1)[1])-1
                native_offset=(unpack_from('<I',d,oe+4+index*unit)[0]&65535)*8
                assert native_offset+512<=unpack_from('<H',t,12)[0]*8
                pixels=data[frame*512:(frame+1)*512]
                assert len(pixels)==512 and any(pixels)
                if native_offset in shared: assert pixels==shared[native_offset],(body,state,frame,'native alias differs')
                shared[native_offset]=pixels
                frames+=1
        if state==12:
            assert size==4*4096 and stride==4096
            assert len({data[i*4096:(i+1)*4096]for i in range(4)})==4, 'Facing inspector needs four distinct stationary poses'
        if state==13:
            assert size==8192
            chars=data[:6144];tilemap=data[6144:]
            assert all(v==0 or 64+body*16<=v<80+body*16 for v in chars)
            indices=[unpack_from('<H',tilemap,i*2)[0]for i in range(1024)]
            assert max(indices)==60 and all(i<96 for i in indices)
        if state==14: assert size==25600 # Same eight 80x80 source cells as native throw
        if state==15: assert size==3200

# Compare the packed facing poses directly to the supplied source sheets.
# Bounds/alias checks alone missed the old N/S swap: the art was valid but wrong.
source=Path('/workspace/source-import/source/workspace/graphics/object_events/pics/people')
for body,who in enumerate(['brendan','may']):
    for state,name,width,indices in [
        (0,'walking',16,[(0,1,False),(4,0,False),(8,2,False),(12,2,True)]),
        (0,'running',16,[(16,1,False),(20,0,False),(24,2,False),(28,2,True)]),
        (1,'mach_bike',32,[(0,1,False),(4,0,False),(8,2,False),(12,2,True)]),
        (3,'watering',32,[(0,2,False)]),
        (4,'surfing',32,[(0,2,False),(1,0,False),(2,4,False),(3,4,True)]),
        (6,'fishing',32,[(0,4,False),(4,8,False),(8,0,False),(12,0,True)]),
    ]:
        sheet=Image.open(source/who/(name+'.png'))
        offset,size,stride,_=entries[body*16+state]
        for native_frame,source_frame,mirror in indices:
            pic=sheet.crop((source_frame*width,0,(source_frame+1)*width,32))
            if mirror: pic=ImageOps.mirror(pic)
            canvas=Image.new('P',(32,32),0);canvas.paste(pic,((32-width)//2,0))
            pixels=list(canvas.getdata())
            expected=bytes(pixels[i]|(pixels[i+1]<<4)for i in range(0,1024,2))
            start=offset+32+native_frame*stride
            assert b[start:start+512]==expected,(who,state,native_frame,'wrong directional pose')
    sheet=Image.open(source/who/'walking.png')
    offset,size,stride,_=entries[body*16+12]
    for facing,(source_frame,mirror)in enumerate([(1,False),(0,False),(2,False),(2,True)]):
        pic=sheet.crop((source_frame*16,0,(source_frame+1)*16,32))
        if mirror:pic=ImageOps.mirror(pic)
        field_pose=Image.new('P',(32,32),0);field_pose.paste(pic,(8,0))
        start=offset+32+facing*stride
        assert b[start:start+stride]==preview_tiles(field_pose),(who,facing,'preview facing or anchor differs from source')

# Kanto directions are checked against the pinned raw FireRed sheets, rather
# than relying on generated contact sheets or merely checking nonempty frames.
kanto=folder/'kanto-source/graphics/object_events/pics/people'
for body,who in enumerate(['red','green']):
    for state,name,width,indices in [
        (0,'normal',16,[(0,1,False),(4,0,False),(8,2,False),(12,2,True)]),
        (0,'surf_run',16,[(16,6,False),(20,3,False),(24,9,False),(28,9,True)]),
        (1,'bike',32,[(0,1,False),(4,0,False),(8,2,False),(12,2,True)]),
        (4,'surf_run',16,[(0,1,False),(1,0,False),(2,2,False),(3,2,True)]),
        (6,'fish',32,[(0,4,False),(4,8,False),(8,0,False),(12,0,True)]),
    ]:
        sheet=Image.open(kanto/f'{who}_{name}.png')
        offset,size,stride,_=entries[32+body*16+state]
        for native_frame,source_frame,mirror in indices:
            pic=sheet.crop((source_frame*width,0,(source_frame+1)*width,32))
            if mirror: pic=ImageOps.mirror(pic)
            canvas=Image.new('P',(32,32),0);canvas.paste(pic,((32-width)//2,0))
            pixels=list(canvas.getdata())
            expected=bytes(pixels[i]|(pixels[i+1]<<4)for i in range(0,1024,2))
            start=offset+32+native_frame*stride
            assert b[start:start+512]==expected,(who,state,native_frame,'wrong directional pose')
    sheet=Image.open(kanto/f'{who}_normal.png')
    offset,size,stride,_=entries[32+body*16+12]
    for facing,(source_frame,mirror)in enumerate([(1,False),(0,False),(2,False),(2,True)]):
        pic=sheet.crop((source_frame*16,0,(source_frame+1)*16,32))
        if mirror:pic=ImageOps.mirror(pic)
        field_pose=Image.new('P',(32,32),0);field_pose.paste(pic,(8,0))
        start=offset+32+facing*stride
        assert b[start:start+stride]==preview_tiles(field_pose),(who,facing,'preview facing or anchor differs from source')

for body in range(2):
    offset,size,stride,palette_size=entries[64+body]
    assert palette_size==32 and size==4*4096 and stride==4096 and offset+32+size<=len(b)
    field=Image.open(ROOT/'res/graphics/field_sprites/player'/f'player_{"f" if body else "m"}.png')
    for facing,row in enumerate([0,4,8,12]):
        expected=preview_tiles(field.crop((0,row*32,32,(row+1)*32)))
        start=offset+32+facing*stride
        assert b[start:start+stride]==expected,(body,facing,'Sinnoh preview facing or original standing anchor changed')

# The editable pack must contain authored shapes rather than palettes alone.
# Compare silhouette masks across whole walking/running rigs, independently of
# dye RGB values and contact-sheet rendering.
custom=(folder/'custom.bin').read_bytes()
custom_manifest=json.loads((folder/'custom-provenance.json').read_text())
assert len(custom)==custom_manifest['bytes'] and hashlib.sha256(custom).hexdigest()==custom_manifest['sha256']
assert unpack_from('<4sIII',custom)==(b'AVC1',1,416,0)
custom_entries=[unpack_from('<IIII',custom,16+i*16)for i in range(416)]
for index,(offset,size,stride,palette_size)in enumerate(custom_entries):
    body,state,layer=index//208,index//13%16,index%13
    assert offset>=16+416*16 and offset+size<=len(custom) and size%stride==0 and palette_size==0
    data=custom[offset:offset+size]
    if state<12:assert stride==512 and size==[32,24,4,7,4,16,16,12,2,12,13,32][state]*512
    elif state==12:assert size==2048 and stride==512
    elif state==13:assert size==stride==6144 and max(data)<=15 and not any(data[:64])
    elif state==14:assert size==stride==25600
    elif state==15:assert size==stride==3200
    if state==14 and layer in[1,2,3]:assert not any(data),'Waist-up throw must not invent legwear pixels'
    else:assert any(data),(body,state,layer,'empty supported artwork layer')
for body in range(2):
    for category,layers in [('hairstyle',range(7,11)),('top',range(4,7)),('legwear',range(1,4))]:
        shapes=[];silhouettes=[]
        for layer in layers:
            offset,size,_,_=custom_entries[body*208+layer]
            data=custom[offset:offset+size]
            shapes.append(data)
            silhouettes.append(bytes(component!=0 for value in data for component in[value&15,value>>4]))
        assert len(set(shapes))==len(layers),(body,category,'duplicate editable pixels')
        assert len(set(silhouettes))==len(layers),(body,category,'recolor offered as a shape choice')
print(f'Avatar art: 66 regional entries, {frames} native frame mappings, 24 source-facing stationary previews and 416 editable layer entries pass')
