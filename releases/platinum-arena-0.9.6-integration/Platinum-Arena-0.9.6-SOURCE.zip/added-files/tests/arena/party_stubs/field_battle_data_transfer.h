/* Host model of the native access boundary, not an encrypted-Pokemon test. */
#ifndef ARENA_PARTY_TEST_NATIVE_DTO_H
#define ARENA_PARTY_TEST_NATIVE_DTO_H
#include <stdint.h>
#include "generated/pokemon_data_params.h"
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int BOOL;
#define TRUE 1
#define FALSE 0
#define MAX_PARTY_SIZE 6
#define MAX_BATTLERS 4
#define BATTLE_TYPE_TRAINER (1u << 0)
#define BATTLE_TYPE_DOUBLES (1u << 1)
#define BATTLE_TYPE_2vs2 (1u << 3)
#define BATTLE_TYPE_TAG (1u << 4)
#define BATTLE_IN_PROGRESS 0
#define BATTLE_RESULT_WIN 1
#define BATTLE_RESULT_LOSE 2
#define BATTLE_RESULT_DRAW 3
typedef struct Pokemon { u32 data[180]; } Pokemon;
typedef struct Party { int count; Pokemon mon[MAX_PARTY_SIZE]; } Party;
typedef struct FieldBattleDTO { u32 battleType; Party *parties[MAX_BATTLERS]; } FieldBattleDTO;
int Party_GetCurrentCount(const Party *party);
Pokemon *Party_GetPokemonBySlotIndex(const Party *party, int slot);
#endif
