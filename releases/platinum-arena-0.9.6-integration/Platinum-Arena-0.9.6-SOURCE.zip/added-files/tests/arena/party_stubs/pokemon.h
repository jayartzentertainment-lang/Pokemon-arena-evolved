#ifndef ARENA_PARTY_TEST_POKEMON_H
#define ARENA_PARTY_TEST_POKEMON_H
#include "field_battle_data_transfer.h"
u32 Pokemon_GetValue(Pokemon *mon, enum PokemonDataParam param, void *dest);
void Pokemon_SetValue(Pokemon *mon, enum PokemonDataParam param, const void *value);
#endif
