#include <assert.h>
#include <string.h>
#include "arena/controls.h"
int main(void)
{
    CombatInput input;
    ArenaControls_Reset();
    input=ArenaControls_Map(2048|64,2048);
    assert(input.held==(COMBAT_L|COMBAT_UP)&&input.pressed==COMBAT_L);
    input=ArenaControls_Map(2,2);assert(input.held==COMBAT_B&&input.pressed==COMBAT_B);
    input=ArenaControls_Map(256,256);assert(!input.held&&!input.pressed);
    input=ArenaControls_Map(512|2048,2048);
    assert(!input.held&&input.pressed==COMBAT_CYCLE_LIGHT);
    input=ArenaControls_Map(512|1,1);
    assert(!input.held&&input.pressed==COMBAT_CYCLE_HEAVY);
    input=ArenaControls_Map(256|1024,1024);
    assert(!input.held&&input.pressed==COMBAT_COMMAND);
    input=ArenaControls_Map(512|256|16|1024,512|256|1024);
    assert(input.held==COMBAT_RIGHT&&!input.pressed);
    input=ArenaControls_Map(1|1024|4,1|1024|4);
    assert(input.held==(COMBAT_A|COMBAT_ALT|COMBAT_Y));
    ArenaControls_Cycle(ARENA_CONTROL_STRIKE,1);
    assert(!strcmp(ArenaControls_Label(ARENA_CONTROL_STRIKE),"A"));
    input=ArenaControls_Map(512|1,1);
    assert(input.pressed==COMBAT_CYCLE_LIGHT);
    input=ArenaControls_Map(512|2048,2048);
    assert(input.pressed==COMBAT_CYCLE_HEAVY);
    assert(!strcmp(ArenaControls_Label(ARENA_CONTROL_GUARD),"B"));
    return 0;
}
