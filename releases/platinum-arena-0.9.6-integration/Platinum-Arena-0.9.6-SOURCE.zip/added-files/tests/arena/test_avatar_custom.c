#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "arena/avatar.h"

/* Independently enumerate the documented mixed-radix record. This checks
 * every identity, including the upper bound, rather than selected examples. */
static ArenaAvatarProfile from_index(unsigned index)
{
    ArenaAvatarProfile p;
    ArenaAvatar_CustomDefault(&p, index % 2); index /= 2;
    p.skin = index % 4; index /= 4;
    p.hair = index % 6; index /= 6;
    p.outfit = index % 8; index /= 8;
    p.hairstyle = index % 4; index /= 4;
    p.top = index % 3; index /= 3;
    p.legwear = index % 3; index /= 3;
    p.hat = index % 3; index /= 3;
    p.legColor = index % 4; index /= 4;
    p.shoes = index;
    return p;
}

static unsigned independent_record(unsigned index)
{
    unsigned crc = 0x1d;
    unsigned bit;
    for (bit = 0; bit < 20; bit++) {
        unsigned feedback = ((crc >> 4) ^ (index >> bit)) & 1;
        crc = ((crc << 1) & 31) ^ (feedback ? 5 : 0);
    }
    return 0x5e | (index << 7) | (crc << 27);
}

int main(void)
{
    unsigned index, bit, byte;
    static const unsigned offsets[] = { 2, 3, 42, 43 };
    for (index = 0; index < ARENA_AVATAR_CUSTOM_PROFILE_COUNT; index++) {
        u8 save[ARENA_AVATAR_PLAYER_SAVE_BYTES];
        ArenaAvatarProfile expected = from_index(index);
        ArenaAvatarProfile actual, fallback;
        unsigned record = independent_record(index);
        for (byte = 0; byte < sizeof(save); byte++) save[byte] = byte * 7 + 19;
        assert(ArenaAvatar_IsValid(&expected));
        ArenaAvatar_WriteRecord(save, &expected);
        for (byte = 0; byte < sizeof(save); byte++) {
            if (byte != 2 && byte != 3 && byte != 42 && byte != 43) assert(save[byte] == (u8)(byte * 7 + 19));
        }
        for (byte = 0; byte < 4; byte++) assert(save[offsets[byte]] == ((record >> (byte * 8)) & 255));
        ArenaAvatar_ReadRecord(save, expected.body, &actual);
        assert(!memcmp(&actual, &expected, sizeof(actual)));
        ArenaAvatar_Default(&fallback, expected.body);
        for (bit = 0; bit < 32; bit++) {
            save[offsets[bit / 8]] ^= 1u << (bit % 8);
            ArenaAvatar_ReadRecord(save, expected.body, &actual);
            assert(!memcmp(&actual, &fallback, sizeof(actual)));
            save[offsets[bit / 8]] ^= 1u << (bit % 8);
        }
        ArenaAvatar_ReadRecord(save, !expected.body, &actual);
        ArenaAvatar_Default(&fallback, !expected.body);
        assert(!memcmp(&actual, &fallback, sizeof(actual)));
    }
    {
        u8 save[ARENA_AVATAR_PLAYER_SAVE_BYTES] = {0};
        ArenaAvatarProfile actual, fallback;
        unsigned record = independent_record(ARENA_AVATAR_CUSTOM_PROFILE_COUNT);
        for (byte = 0; byte < 4; byte++) save[offsets[byte]] = record >> (byte * 8);
        ArenaAvatar_ReadRecord(save, 0, &actual);
        ArenaAvatar_Default(&fallback, 0);
        assert(!memcmp(&actual, &fallback, sizeof(actual)));
        actual = from_index(0); actual.hairstyle = ARENA_AVATAR_STYLE_COUNT;
        assert(!ArenaAvatar_IsValid(&actual));
        actual = from_index(0); actual.hat = ARENA_AVATAR_HAT_COUNT;
        assert(!ArenaAvatar_IsValid(&actual));
        actual = from_index(0); actual.shoes = ARENA_AVATAR_SHOE_COLOR_COUNT;
        assert(!ArenaAvatar_IsValid(&actual));
    }
    printf("Avatar custom: %u identities, independent encoding, padding isolation, all 21,233,664 single-bit corruptions and body mismatch pass\n", index);
    return 0;
}
