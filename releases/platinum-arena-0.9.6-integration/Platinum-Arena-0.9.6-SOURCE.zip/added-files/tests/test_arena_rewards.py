#!/usr/bin/env python3
"""Run the unchanged production rewards body against controlled native API doubles."""
import pathlib
import re
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
body = (ROOT / "src/arena/rewards.c").read_text()
body = re.sub(r'^#include[^\n]*\n', '', body, flags=re.M)
# The generated native class table is data, not a mocked reward algorithm.
body = '#include "data/trainer_class_prize_mul.h"\n' + body
harness = (ROOT / "tests/arena_rewards_host.c").read_text().replace('PRODUCTION_BODY\n', body + '\n')
with tempfile.TemporaryDirectory(prefix='platinum-arena-rewards-') as tmp:
    source = pathlib.Path(tmp) / 'test.c'
    binary = pathlib.Path(tmp) / 'test'
    source.write_text(harness)
    subprocess.run(['cc', '-std=c99', '-Wall', '-Wextra', '-Werror', '-g',
                    '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                    '-I' + str(ROOT / 'include'), '-I' + str(ROOT / 'build'),
                    str(source), '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
