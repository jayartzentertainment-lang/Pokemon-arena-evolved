/* Native API doubles exercise the production rewards body, not copied logic. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint16_t charcode_t;
typedef int BOOL;
#define TRUE 1
#define FALSE 0
#include "constants/battle.h"
#include "constants/pokemon.h"
#include "generated/items.h"
#include "generated/item_hold_effects.h"
#include "generated/game_records.h"
#include "generated/trainer_score_events.h"
#define MAX_LEARNSET_ENTRIES 20
#define LEARNED_MOVES_MAX 4
#define LEARNSET_NO_MOVE_TO_LEARN 0
#define LEARNSET_ALL_SLOTS_FILLED 0xFFFF
#define TRAINER_NAME_LEN 7
#define HEAP_ID_BATTLE 5
#define ITEM_PARAM_HOLD_EFFECT 1
#define ITEM_PARAM_EFFECT_PARAM 2
#define FRIENDSHIP_EVENT_LEVEL_UP 0
#define MAX_PC_BOXES 18
typedef struct Pokemon { u32 v[256]; charcode_t otName[8]; } Pokemon;
typedef Pokemon BoxPokemon;
typedef struct Party { int count, capacity, pokerus; Pokemon mons[6]; } Party;
typedef struct TrainerInfo { u32 id, gender, money; int badges; charcode_t name[8]; } TrainerInfo;
typedef struct Bag { int balls; } Bag;
typedef struct Pokedex { u8 caught[600]; int calls, encounters; } Pokedex;
typedef struct PCBoxes { int count, current; Pokemon last; } PCBoxes;
typedef struct Poketch { int count; } Poketch;
typedef struct GameRecords { int values[200]; int catches; } GameRecords;
typedef struct CaptureAttempt { int result, balls, species; } CaptureAttempt;
typedef struct SpeciesData { int yields[6]; } SpeciesData;
typedef struct Trainer { struct { int trainerType; } header; } Trainer;
typedef struct FieldBattleDTO {
    u32 battleType; Party *parties[4]; int resultMask; Trainer trainer[4];
    TrainerInfo *trainerInfo[4]; Bag *bag; Pokedex *pokedex; PCBoxes *pcBoxes;
    Poketch *poketch; CaptureAttempt *captureAttempt; GameRecords *records;
    int mapHeaderID, terrain, caughtBattlerIdx, leveledUpMonsMask;
} FieldBattleDTO;
typedef struct ArenaLearnMove { u8 partySlot, level; u16 move; } ArenaLearnMove;
static const u8 gGameLanguage = 2;
static int itemEffects[600];
static int learnMove = 99;
static int speciesExp = 70;
static int catchRate = 255;
static SpeciesData personal;

static int Party_GetCurrentCount(const Party *p) { return p->count; }
static int Party_GetCapacity(const Party *p) { return p->capacity; }
static Pokemon *Party_GetPokemonBySlotIndex(const Party *p, int slot) { return (Pokemon *)&p->mons[slot]; }
static u32 Pokemon_GetValue(Pokemon *p, int field, void *out) { if(field==MON_DATA_OT_NAME && out) memcpy(out,p->otName,sizeof(p->otName)); return p->v[field]; }
static void Pokemon_SetValue(Pokemon *p, int field, const void *value) { if(field>=MON_DATA_HP_EV && field<=MON_DATA_SPDEF_EV) p->v[field]=*(const u8*)value; else memcpy(&p->v[field],value,4); }
static int Item_LoadParam(int item, int field, int heap) { (void)heap; return field==ITEM_PARAM_HOLD_EFFECT?itemEffects[item]:4; }
static u32 TrainerInfo_ID(TrainerInfo *p) { return p->id; }
static u32 TrainerInfo_Gender(TrainerInfo *p) { return p->gender; }
static charcode_t *TrainerInfo_Name(TrainerInfo *p) { return p->name; }
static int TrainerInfo_BadgeCount(TrainerInfo *p) { return p->badges; }
static int CharCode_CompareNumChars(const charcode_t *a,const charcode_t *b,int count) { return memcmp(a,b,count*2); }
static int SpeciesData_GetSpeciesValue(int species,int field) { (void)species; return field==SPECIES_DATA_BASE_EXP_REWARD?speciesExp:catchRate; }
static SpeciesData *SpeciesData_FromMonForm(int species,int form,int heap) { (void)species;(void)form;(void)heap;return &personal; }
static int SpeciesData_GetValue(SpeciesData *p,int field) { return p->yields[field-SPECIES_DATA_EV_HP_YIELD]; }
static void SpeciesData_Free(SpeciesData *p) { (void)p; }
static int Pokemon_HasPokerus(Party *p,int mask) { return !!(p->pokerus & mask); }
static int Pokemon_ShouldLevelUp(Pokemon *p) { if(p->v[MON_DATA_LEVEL]<100 && p->v[MON_DATA_EXPERIENCE]>=(p->v[MON_DATA_LEVEL]+1)*100) { p->v[MON_DATA_LEVEL]++; return 1; } return 0; }
static void Pokemon_UpdateFriendship(Pokemon *p,int event,int map) { (void)event;(void)map;p->v[MON_DATA_FRIENDSHIP]++; }
static void Pokemon_CalcStats(Pokemon *p) { p->v[MON_DATA_MAX_HP]++;p->v[MON_DATA_HP]++; }
static u16 Pokemon_LevelUpMove(Pokemon *p,int *index,u16 *move) { int i;if((*index)++)return 0;*move=learnMove;for(i=0;i<4;i++)if(!p->v[MON_DATA_MOVE1+i]){p->v[MON_DATA_MOVE1+i]=*move;p->v[MON_DATA_MOVE1_PP+i]=10;return *move;}return 0xFFFF; }
static void Pokemon_ResetMoveSlot(Pokemon *p,int move,int slot) { p->v[MON_DATA_MOVE1+slot]=move;p->v[MON_DATA_MOVE1_PP+slot]=10;p->v[MON_DATA_MOVE1_PP_UPS+slot]=0; }
static void GameRecords_IncrementRecordValue(GameRecords *p,int record) { p->values[record]++; }
static void GameRecords_IncrementTrainerScoreOnCatch(GameRecords *p,Pokedex *dex,int species) { if(!dex->caught[species])p->catches++; }
static void TrainerInfo_GiveMoney(TrainerInfo *p,u32 amount) { p->money=p->money+amount>999999?999999:p->money+amount; }
static void TrainerInfo_TakeMoney(TrainerInfo *p,u32 amount) { p->money=amount>p->money?0:p->money-amount; }
static void CaptureAttempt_Init(CaptureAttempt *p,Pokemon *mon,int result,int balls,int heap) { (void)heap;p->result=result;p->balls=balls;p->species=mon->v[MON_DATA_SPECIES]; }
static int PCBoxes_FirstEmptyBox(PCBoxes *p) { return p->count<540?p->count/30:18; }
static int Bag_GetItemQuantity(Bag *p,int item,int heap) { (void)item;(void)heap;return p->balls; }
static int Bag_TryRemoveItem(Bag *p,int item,int count,int heap) { (void)item;(void)heap;if(p->balls<count)return 0;p->balls-=count;return 1; }
static void Pokemon_SetCatchData(Pokemon *p,TrainerInfo *info,int ball,int map,int terrain,int heap) { (void)terrain;(void)heap;p->v[MON_DATA_OT_ID]=info->id;p->v[MON_DATA_POKEBALL]=ball;p->v[MON_DATA_MET_LOCATION]=map; }
static int Party_AddPokemon(Party *p,Pokemon *mon) { if(p->count>=p->capacity)return 0;p->mons[p->count++]=*mon;return 1; }
static int Pokemon_SetGiratinaFormByHeldItem(Pokemon *p) { (void)p;return -1; }
static BoxPokemon *Pokemon_GetBoxPokemon(Pokemon *p) { return p; }
static int PCBoxes_TryStoreBoxMonInBox(PCBoxes *p,int box,BoxPokemon *mon) { (void)box;if(p->count>=540)return 0;p->last=*mon;p->count++;return 1; }
static void PCBoxes_SetCurrentBox(PCBoxes *p,int box) { p->current=box; }
static void Pokedex_Capture(Pokedex *p,Pokemon *mon) { p->caught[mon->v[MON_DATA_SPECIES]]=1;p->calls++; }
static void Pokedex_Encounter(Pokedex *p,Pokemon *mon) { (void)mon;p->encounters++; }
static void Poketch_PokemonHistoryEnqueue(Poketch *p,BoxPokemon *mon) { (void)mon;p->count++; }
static void Party_SwapSlots(Party *p,int a,int b) { Pokemon tmp=p->mons[a];p->mons[a]=p->mons[b];p->mons[b]=tmp; }

/* PRODUCTION_BODY is substituted by the runner from src/arena/rewards.c. */
PRODUCTION_BODY

static FieldBattleDTO dto;
static Party parties[4];
static TrainerInfo infos[4];
static Bag bag;
static Pokedex dex;
static PCBoxes pc;
static Poketch watch;
static GameRecords records;
static CaptureAttempt attempt;

static void init(void)
{
    int owner;
    memset(&dto,0,sizeof(dto));memset(parties,0,sizeof(parties));memset(infos,0,sizeof(infos));
    memset(&dex,0,sizeof(dex));memset(&records,0,sizeof(records));memset(&pc,0,sizeof(pc));memset(&watch,0,sizeof(watch));
    memset(itemEffects,0,sizeof(itemEffects));memset(&personal,0,sizeof(personal));
    personal.yields[0]=1;bag.balls=2;speciesExp=70;catchRate=255;
    for(owner=0;owner<4;owner++) { dto.parties[owner]=&parties[owner];dto.trainerInfo[owner]=&infos[owner];parties[owner].capacity=6;infos[owner].id=123; }
    dto.bag=&bag;dto.pcBoxes=&pc;dto.pokedex=&dex;dto.poketch=&watch;dto.records=&records;dto.captureAttempt=&attempt;dto.mapHeaderID=42;
    ArenaRewards_Begin(&dto);
}

static Pokemon *add(int owner,int species,int level,int hp)
{
    Pokemon *p=&parties[owner].mons[parties[owner].count++];
    p->v[MON_DATA_SPECIES]=species;p->v[MON_DATA_LEVEL]=level;p->v[MON_DATA_HP]=hp;p->v[MON_DATA_MAX_HP]=20;
    p->v[MON_DATA_EXPERIENCE]=level*100;p->v[MON_DATA_LANGUAGE]=gGameLanguage;p->v[MON_DATA_OT_ID]=123;
    p->v[MON_DATA_MOVE1]=1;p->v[MON_DATA_MOVE1_PP]=3;p->v[MON_DATA_MOVE1_MAX_PP]=20;
    return p;
}

static void test_exp(void)
{
    Pokemon *a,*b,*foe;u32 exp;
    init();a=add(0,1,5,10);b=add(0,2,5,10);foe=add(1,3,7,0);
    ArenaRewards_OnDefeat(&dto,1,0,3);
    assert(a->v[MON_DATA_EXPERIENCE]==535 && b->v[MON_DATA_EXPERIENCE]==535);
    assert(a->v[MON_DATA_HP_EV]==1 && b->v[MON_DATA_HP_EV]==1);
    ArenaRewards_OnDefeat(&dto,1,0,3);assert(a->v[MON_DATA_EXPERIENCE]==535);
    assert(records.values[RECORD_FAINTED_ENEMY_MON]==1);
    init();a=add(0,1,5,10);b=add(0,2,5,10);add(1,3,7,0);
    itemEffects[10]=HOLD_EFFECT_EXP_SHARE;b->v[MON_DATA_HELD_ITEM]=10;
    ArenaRewards_OnDefeat(&dto,1,0,1);assert(a->v[MON_DATA_EXPERIENCE]==535 && b->v[MON_DATA_EXPERIENCE]==535);
    init();dto.battleType=BATTLE_TYPE_TRAINER;a=add(0,1,5,10);add(1,3,7,0);
    a->v[MON_DATA_OT_ID]=999;a->v[MON_DATA_LANGUAGE]=1;a->v[MON_DATA_HELD_ITEM]=10;itemEffects[10]=HOLD_EFFECT_EXP_UP;
    ArenaRewards_OnDefeat(&dto,1,0,1);assert(a->v[MON_DATA_EXPERIENCE]==766);
    assert(a->v[MON_DATA_LEVEL]==7 && a->v[MON_DATA_HP]==12 && a->v[MON_DATA_MOVE1_PP]==3);
    assert(a->v[MON_DATA_MOVE1+1]==99 && dto.leveledUpMonsMask==1);
    exp=a->v[MON_DATA_EXPERIENCE];ArenaRewards_Finalize(&dto,BATTLE_RESULT_WIN);ArenaRewards_OnDefeat(&dto,1,0,1);assert(a->v[MON_DATA_EXPERIENCE]==exp);
    (void)foe;
}

static void test_moves_and_evs(void)
{
    Pokemon *a;ArenaLearnMove move;int i;
    init();a=add(0,1,5,10);add(1,3,10,0);for(i=0;i<4;i++)a->v[MON_DATA_MOVE1+i]=i+1;
    ArenaRewards_OnDefeat(&dto,1,0,1);assert(ArenaRewards_PendingMoveCount()==1);
    assert(ArenaRewards_PendingMove(0,&move) && move.move==99 && move.level==6 && move.partySlot==0);
    assert(a->v[MON_DATA_MOVE1]==1 && a->v[MON_DATA_MOVE1+3]==4);
    assert(ArenaRewards_ResolveMove(&dto,0,2));assert(a->v[MON_DATA_MOVE1+2]==99 && a->v[MON_DATA_MOVE1_PP+2]==10);
    init();a=add(0,1,5,10);add(1,3,7,0);a->v[MON_DATA_HP_EV]=254;a->v[MON_DATA_ATK_EV]=254;
    personal.yields[0]=3;personal.yields[1]=3;parties[0].pokerus=1;itemEffects[10]=HOLD_EFFECT_LVLUP_ATK_EV_UP;a->v[MON_DATA_HELD_ITEM]=10;
    ArenaRewards_OnDefeat(&dto,1,0,1);assert(a->v[MON_DATA_HP_EV]==255 && a->v[MON_DATA_ATK_EV]==255);
}

static void test_money(void)
{
    u32 money;
    init();dto.battleType=BATTLE_TYPE_TRAINER;add(0,1,5,20);add(1,2,10,0);dto.trainer[1].header.trainerType=TRAINER_CLASS_YOUNGSTER;
    infos[0].money=100;ArenaRewards_Finalize(&dto,BATTLE_RESULT_WIN);assert(infos[0].money==260);
    ArenaRewards_Finalize(&dto,BATTLE_RESULT_WIN);assert(infos[0].money==260);
    init();dto.battleType=BATTLE_TYPE_TAG_DOUBLES;add(0,1,5,20);add(1,2,10,0);add(3,3,20,0);
    dto.trainer[1].header.trainerType=TRAINER_CLASS_YOUNGSTER;dto.trainer[3].header.trainerType=TRAINER_CLASS_LASS;
    ArenaRewards_Finalize(&dto,BATTLE_RESULT_WIN);assert(infos[0].money==480);
    init();add(0,1,25,0);infos[0].money=10000;infos[0].badges=4;
    ArenaRewards_Finalize(&dto,BATTLE_RESULT_LOSE);assert(infos[0].money==8800);money=infos[0].money;
    ArenaRewards_Finalize(&dto,BATTLE_RESULT_LOSE);assert(infos[0].money==money);
    init();dto.battleType=BATTLE_TYPE_TRAINER_WITH_AI_PARTNER;add(0,1,5,20);add(2,2,8,20);add(1,3,10,0);add(3,4,20,0);
    dto.trainer[1].header.trainerType=TRAINER_CLASS_YOUNGSTER;dto.trainer[3].header.trainerType=TRAINER_CLASS_LASS;
    parties[2].mons[0].v[MON_DATA_HELD_ITEM]=10;itemEffects[10]=HOLD_EFFECT_MONEY_UP;
    ArenaRewards_OnSendOut(&dto,2,0);ArenaRewards_OnSendOut(&dto,1,0);ArenaRewards_OnSendOut(&dto,1,0);
    assert(dex.encounters==1);ArenaRewards_Finalize(&dto,BATTLE_RESULT_WIN);assert(infos[0].money==960);
}

static void test_capture(void)
{
    Pokemon *p;u32 rng=1;int i;
    init();add(0,1,5,20);p=add(1,25,7,1);p->v[MON_DATA_PERSONALITY]=0x12345678;p->v[MON_DATA_COMBINED_IVS]=0xABCDEF;
    assert(ArenaRewards_CanThrow(&dto));assert(bag.balls==2);assert(!ArenaRewards_ConsumeBall(&dto,ITEM_ULTRA_BALL));
    assert(ArenaRewards_ConsumeBall(&dto,ITEM_POKE_BALL));assert(bag.balls==1);
    p->v[MON_DATA_STATUS]=MON_CONDITION_SLEEP;assert(ArenaRewards_CatchShakes(&dto,1,0,ITEM_POKE_BALL,&rng)==4);
    assert(ArenaRewards_Catch(&dto,1,0,ITEM_POKE_BALL));assert(dto.resultMask==4 && parties[0].count==2);
    assert(parties[0].mons[1].v[MON_DATA_PERSONALITY]==0x12345678 && parties[0].mons[1].v[MON_DATA_COMBINED_IVS]==0xABCDEF);
    assert(parties[0].mons[1].v[MON_DATA_HP]==1 && parties[0].mons[1].v[MON_DATA_MOVE1_PP]==3);
    assert(dex.caught[25] && watch.count==1 && records.values[RECORD_CAUGHT_POKEMON]==1 && records.catches==1);
    assert(attempt.result==4 && attempt.balls==1 && !ArenaRewards_Catch(&dto,1,0,ITEM_POKE_BALL));
    ArenaRewards_Finalize(&dto,4);assert(parties[0].count==2 && dto.resultMask==4);
    init();for(i=0;i<6;i++)add(0,i+1,5,20);add(1,25,5,1);pc.count=539;
    assert(ArenaRewards_ConsumeBall(&dto,ITEM_POKE_BALL));assert(ArenaRewards_Catch(&dto,1,0,ITEM_POKE_BALL));
    assert(pc.count==540 && pc.last.v[MON_DATA_SPECIES]==25 && pc.last.v[MON_DATA_MOVE1_PP]==20 && parties[0].count==6);
    init();for(i=0;i<6;i++)add(0,i+1,5,20);add(1,25,5,1);pc.count=540;
    assert(!ArenaRewards_CanThrow(&dto) && !ArenaRewards_ConsumeBall(&dto,ITEM_POKE_BALL) && bag.balls==2);
    init();add(0,1,5,20);add(1,2,5,1);add(3,3,5,1);assert(!ArenaRewards_CanThrow(&dto));
    parties[1].mons[0].v[MON_DATA_HP]=0;assert(ArenaRewards_CanThrow(&dto));
    init();add(0,1,5,20);add(1,25,5,20);rng=1;
    assert(ArenaRewards_CatchShakes(&dto,1,0,ITEM_POKE_BALL,&rng)==2 && rng==0xD2EEF54Au);
    catchRate=3;rng=1;assert(ArenaRewards_CatchShakes(&dto,1,0,ITEM_POKE_BALL,&rng)==0 && rng==0x41C6AEE0u);
    init();dto.battleType=BATTLE_TYPE_TRAINER;add(0,1,5,20);add(1,25,5,1);
    assert(!ArenaRewards_CanThrow(&dto) && !ArenaRewards_ConsumeBall(&dto,ITEM_POKE_BALL) && bag.balls==2);
    init();add(0,1,5,20);add(1,25,5,0);add(1,26,6,1);
    assert(ArenaRewards_ConsumeBall(&dto,ITEM_POKE_BALL) && ArenaRewards_Catch(&dto,1,1,ITEM_POKE_BALL));
    assert(dto.caughtBattlerIdx==1 && parties[1].mons[0].v[MON_DATA_SPECIES]==26 && parties[0].mons[1].v[MON_DATA_SPECIES]==26);
}

int main(void)
{
    test_exp();test_moves_and_evs();test_money();test_capture();puts("arena native rewards: EXP/EV/dedupe, move choices, money and capture transactions pass");return 0;
}
