#include "arena/controls.h"
/* Raw Nitro PAD values. B is fixed defence; L and R remain modifiers. */
static const uint16_t sPhysical[]={2048,1,1024,4};
static const char *const sLabels[]={"Y","A","X","SELECT"};
static const uint8_t sMutable[]={ARENA_CONTROL_STRIKE,ARENA_CONTROL_MOVE,ARENA_CONTROL_NEXT,ARENA_CONTROL_AIM};
static uint8_t sBinding[]={0,0,1,2,0,3};
const char *ArenaControls_Label(unsigned action)
{
    if(action==ARENA_CONTROL_GUARD)return "B";
    if(action==ARENA_CONTROL_CYCLE)return "L";
    return action<ARENA_CONTROL_COUNT?sLabels[sBinding[action]]:"?";
}
void ArenaControls_Reset(void)
{
    sBinding[ARENA_CONTROL_STRIKE]=0;sBinding[ARENA_CONTROL_MOVE]=1;
    sBinding[ARENA_CONTROL_NEXT]=2;sBinding[ARENA_CONTROL_AIM]=3;
}
void ArenaControls_Cycle(unsigned action,int direction)
{
    unsigned i,old,next;
    if(action>=ARENA_CONTROL_COUNT||action==ARENA_CONTROL_GUARD||action==ARENA_CONTROL_CYCLE)return;
    old=sBinding[action];next=(old+(direction<0?3:1))&3;
    for(i=0;i<4;i++)if(sMutable[i]!=action&&sBinding[sMutable[i]]==next)sBinding[sMutable[i]]=(uint8_t)old;
    sBinding[action]=(uint8_t)next;
}
CombatInput ArenaControls_Map(uint32_t held,uint32_t pressed)
{
    static const uint16_t directions[]={64,128,32,16};
    static const uint16_t commands[]={COMBAT_UP,COMBAT_DOWN,COMBAT_LEFT,COMBAT_RIGHT};
    CombatInput input={0,0};unsigned i;
    uint16_t natural=sPhysical[sBinding[ARENA_CONTROL_STRIKE]];
    uint16_t attack=sPhysical[sBinding[ARENA_CONTROL_MOVE]];
    uint16_t special=sPhysical[sBinding[ARENA_CONTROL_NEXT]];
    uint16_t aim=sPhysical[sBinding[ARENA_CONTROL_AIM]];
    int capture=(held&(512|256))==(512|256);
    for(i=0;i<4;i++){
        if(held&directions[i])input.held|=commands[i];
        if(pressed&directions[i])input.pressed|=commands[i];
    }
    if(held&2)input.held|=COMBAT_B;
    if(pressed&2)input.pressed|=COMBAT_B;
    if(capture)return input;
    if(held&aim)input.held|=COMBAT_Y;
    if(pressed&aim)input.pressed|=COMBAT_Y;
    if(held&512) {
        if(pressed&natural)input.pressed|=COMBAT_CYCLE_LIGHT;
        if(pressed&attack)input.pressed|=COMBAT_CYCLE_HEAVY;
    } else {
        if(held&natural)input.held|=COMBAT_L;
        if(pressed&natural)input.pressed|=COMBAT_L;
        if(held&attack)input.held|=COMBAT_A;
        if(pressed&attack)input.pressed|=COMBAT_A;
    }
    if(held&256) {
        if(pressed&special)input.pressed|=COMBAT_COMMAND;
    } else {
        if(held&special)input.held|=COMBAT_ALT;
        if(pressed&special)input.pressed|=COMBAT_ALT;
    }
    return input;
}
