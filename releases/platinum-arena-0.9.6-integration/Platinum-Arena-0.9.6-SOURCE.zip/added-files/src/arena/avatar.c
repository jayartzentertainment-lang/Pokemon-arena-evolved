#include "arena/avatar.h"

#ifndef ARENA_AVATAR_HOST
#include <nnsys.h>
#include <stddef.h>
#include <string.h>
#include "save_player.h"
#include "trainer_info.h"

typedef char AvatarPlayerSaveSizeCheck[(sizeof(PlayerSave) == ARENA_AVATAR_PLAYER_SAVE_BYTES) ? 1 : -1];
typedef char AvatarTagOffsetCheck[(offsetof(PlayerSave, avatarTag) == 2) ? 1 : -1];
typedef char AvatarValueOffsetCheck[(offsetof(PlayerSave, avatarValue) == 42) ? 1 : -1];
#endif

#define RGB5(r, g, b) ((u16)((r) | ((g) << 5) | ((b) << 10)))

static ArenaAvatarProfile sAvatar;

void ArenaAvatar_Default(ArenaAvatarProfile *profile, int body)
{
    profile->body = body == 1;
    profile->skin = 0;
    profile->hair = 0;
    profile->outfit = 0;
    profile->regional = 0;
    profile->hairstyle = 0;
    profile->top = 0;
    profile->legwear = 0;
    profile->hat = 0;
    profile->legColor = 0;
    profile->shoes = 0;
}

void ArenaAvatar_CustomDefault(ArenaAvatarProfile *profile, int body)
{
    ArenaAvatar_Default(profile, body);
    profile->regional = ARENA_AVATAR_CUSTOM_REGION;
}

int ArenaAvatar_IsValid(const ArenaAvatarProfile *profile)
{
    return profile && profile->body < 2
        && profile->skin < ARENA_AVATAR_SKIN_COUNT
        && profile->hair < ARENA_AVATAR_HAIR_COUNT
        && profile->outfit < ARENA_AVATAR_OUTFIT_COUNT && profile->regional < ARENA_AVATAR_REGION_COUNT
        && profile->hairstyle < ARENA_AVATAR_STYLE_COUNT
        && profile->top < ARENA_AVATAR_TOP_COUNT
        && profile->legwear < ARENA_AVATAR_LEGWEAR_COUNT
        && profile->hat < ARENA_AVATAR_HAT_COUNT
        && profile->legColor < ARENA_AVATAR_LEG_COLOR_COUNT
        && profile->shoes < ARENA_AVATAR_SHOE_COLOR_COUNT
        && (profile->regional == ARENA_AVATAR_CUSTOM_REGION
            || !(profile->hairstyle | profile->top | profile->legwear | profile->hat | profile->legColor | profile->shoes));
}

static u32 Avatar_CustomCheckBits(u32 value)
{
    unsigned crc = 0x1d;
    int bit;
    for (bit = 0; bit < 20; bit++) {
        unsigned feedback = ((crc >> 4) ^ (value >> bit)) & 1;
        crc = ((crc << 1) & 31) ^ (feedback ? 0x05 : 0);
    }
    return (u32)crc << 27;
}

static u32 Avatar_CustomIndex(const ArenaAvatarProfile *profile)
{
    u32 value = profile->shoes;
    value = value * ARENA_AVATAR_LEG_COLOR_COUNT + profile->legColor;
    value = value * ARENA_AVATAR_HAT_COUNT + profile->hat;
    value = value * ARENA_AVATAR_LEGWEAR_COUNT + profile->legwear;
    value = value * ARENA_AVATAR_TOP_COUNT + profile->top;
    value = value * ARENA_AVATAR_STYLE_COUNT + profile->hairstyle;
    value = value * ARENA_AVATAR_OUTFIT_COUNT + profile->outfit;
    value = value * ARENA_AVATAR_HAIR_COUNT + profile->hair;
    value = value * ARENA_AVATAR_SKIN_COUNT + profile->skin;
    return value * 2 + profile->body;
}

static void Avatar_CustomFromIndex(u32 value, ArenaAvatarProfile *profile)
{
    ArenaAvatar_CustomDefault(profile, value % 2); value /= 2;
    profile->skin = value % ARENA_AVATAR_SKIN_COUNT; value /= ARENA_AVATAR_SKIN_COUNT;
    profile->hair = value % ARENA_AVATAR_HAIR_COUNT; value /= ARENA_AVATAR_HAIR_COUNT;
    profile->outfit = value % ARENA_AVATAR_OUTFIT_COUNT; value /= ARENA_AVATAR_OUTFIT_COUNT;
    profile->hairstyle = value % ARENA_AVATAR_STYLE_COUNT; value /= ARENA_AVATAR_STYLE_COUNT;
    profile->top = value % ARENA_AVATAR_TOP_COUNT; value /= ARENA_AVATAR_TOP_COUNT;
    profile->legwear = value % ARENA_AVATAR_LEGWEAR_COUNT; value /= ARENA_AVATAR_LEGWEAR_COUNT;
    profile->hat = value % ARENA_AVATAR_HAT_COUNT; value /= ARENA_AVATAR_HAT_COUNT;
    profile->legColor = value % ARENA_AVATAR_LEG_COLOR_COUNT; value /= ARENA_AVATAR_LEG_COLOR_COUNT;
    profile->shoes = value;
}

static u16 Avatar_LegacyCheckBits(u16 value)
{
    unsigned crc = 0x35;
    int bit;
    for (bit = 0; bit < 10; bit++) {
        unsigned feedback = ((crc >> 5) ^ (value >> bit)) & 1;
        crc = ((crc << 1) & 63) ^ (feedback ? 0x27 : 0);
    }
    return crc << 10;
}

static u16 Avatar_CheckBits(u16 value)
{
    unsigned crc = 0x1d;
    int bit;
    for (bit = 0; bit < 11; bit++) {
        unsigned feedback = ((crc >> 4) ^ (value >> bit)) & 1;
        crc = ((crc << 1) & 31) ^ (feedback ? 0x15 : 0);
    }
    return crc << 11;
}

void ArenaAvatar_ReadRecord(const u8 *playerSave, int body, ArenaAvatarProfile *profile)
{
    u16 tag = playerSave[2] | (playerSave[3] << 8);
    u16 packed = playerSave[42] | (playerSave[43] << 8);
    u16 value;

    ArenaAvatar_Default(profile, body);
    if ((tag & 127) == ARENA_AVATAR_CUSTOM_RECORD_MARKER) {
        u32 record = (u32)tag | ((u32)packed << 16);
        u32 index = (record >> 7) & 0xfffff;
        if (index >= ARENA_AVATAR_CUSTOM_PROFILE_COUNT
            || (record & 0xf8000000) != Avatar_CustomCheckBits(index)) return;
        Avatar_CustomFromIndex(index, profile);
        if (profile->body != (body == 1)) ArenaAvatar_Default(profile, body);
        return;
    } else if (tag == ARENA_AVATAR_LEGACY_RECORD_TAG) {
        value = packed & 1023;
        if ((packed & 0xfc00) != Avatar_LegacyCheckBits(value)) return;
    } else if (tag == ARENA_AVATAR_RECORD_TAG) {
        value = packed & 2047;
        if ((packed & 0xf800) != Avatar_CheckBits(value)) return;
    } else {
        return;
    }
    profile->body = value & 1;
    profile->skin = (value >> 1) & 3;
    profile->hair = (value >> 3) & 7;
    profile->outfit = (value >> 6) & 7;
    profile->regional = (value >> 9) & 3;
    if (!ArenaAvatar_IsValid(profile) || profile->regional >= ARENA_AVATAR_PRESET_COUNT
        || profile->body != (body == 1)) {
        ArenaAvatar_Default(profile, body);
    }
}

void ArenaAvatar_WriteRecord(u8 *playerSave, const ArenaAvatarProfile *profile)
{
    u16 value;
    if (!ArenaAvatar_IsValid(profile)) {
        return;
    }
    if (profile->regional == ARENA_AVATAR_CUSTOM_REGION) {
        u32 index = Avatar_CustomIndex(profile);
        u32 record = ARENA_AVATAR_CUSTOM_RECORD_MARKER | (index << 7) | Avatar_CustomCheckBits(index);
        playerSave[2] = record & 255;
        playerSave[3] = (record >> 8) & 255;
        playerSave[42] = (record >> 16) & 255;
        playerSave[43] = record >> 24;
        return;
    }
    value = profile->body | (profile->skin << 1) | (profile->hair << 3) | (profile->outfit << 6) | (profile->regional << 9);
    value |= Avatar_CheckBits(value);
    playerSave[2] = ARENA_AVATAR_RECORD_TAG & 255;
    playerSave[3] = ARENA_AVATAR_RECORD_TAG >> 8;
    playerSave[42] = value & 255;
    playerSave[43] = value >> 8;
}

#ifndef ARENA_AVATAR_HOST
void ArenaAvatar_Load(SaveData *saveData, ArenaAvatarProfile *profile)
{
    const PlayerSave *playerSave = SaveData_SaveTable(saveData, SAVE_TABLE_ENTRY_PLAYER);
    ArenaAvatar_ReadRecord((const u8 *)playerSave, TrainerInfo_Gender(&playerSave->info), profile);
}

void ArenaAvatar_Save(SaveData *saveData, const ArenaAvatarProfile *profile)
{
    PlayerSave *playerSave = SaveData_SaveTable(saveData, SAVE_TABLE_ENTRY_PLAYER);
    ArenaAvatar_WriteRecord((u8 *)playerSave, profile);
    sAvatar = *profile;
}

void ArenaAvatar_Bind(SaveData *saveData)
{
    ArenaAvatar_Load(saveData, &sAvatar);
}
#endif

const ArenaAvatarProfile *ArenaAvatar_CurrentProfile(void)
{
    return &sAvatar;
}

/* Source RGB555 pairs are audited from native field, Rowan, card and trainer
 * art. Match colors, not palette indices: bike/surf palettes reorder them. */
void ArenaAvatar_ApplyPalette(const ArenaAvatarProfile *profile, u16 *colors, int count)
{
    static const u16 skin[ARENA_AVATAR_SKIN_COUNT][2] = {
        { RGB5(31, 26, 23), RGB5(27, 20, 15) },
        { RGB5(31, 27, 25), RGB5(29, 22, 19) },
        { RGB5(25, 18, 12), RGB5(20, 13, 8) },
        { RGB5(17, 11, 8), RGB5(12, 7, 5) }
    };
    static const u16 hair[ARENA_AVATAR_HAIR_COUNT][2] = {
        { RGB5(7, 8, 10), RGB5(7, 12, 17) },
        { RGB5(4, 4, 5), RGB5(8, 8, 10) },
        { RGB5(9, 5, 3), RGB5(15, 9, 5) },
        { RGB5(16, 11, 4), RGB5(28, 22, 10) },
        { RGB5(13, 4, 3), RGB5(23, 10, 5) },
        { RGB5(13, 14, 17), RGB5(24, 25, 27) }
    };
    static const u16 outfit[ARENA_AVATAR_OUTFIT_COUNT][2] = {
        { RGB5(23, 7, 9), RGB5(27, 13, 15) },
        { RGB5(5, 11, 23), RGB5(12, 19, 30) },
        { RGB5(5, 16, 9), RGB5(13, 24, 14) },
        { RGB5(14, 7, 22), RGB5(22, 14, 29) },
        { RGB5(25, 11, 3), RGB5(31, 20, 8) },
        { RGB5(3, 16, 17), RGB5(9, 25, 24) },
        { RGB5(6, 7, 9), RGB5(14, 15, 18) },
        { RGB5(22, 19, 13), RGB5(30, 28, 22) }
    };
    int i;
    if (!ArenaAvatar_IsValid(profile)) {
        return;
    }
    if (profile->regional == ARENA_AVATAR_CUSTOM_REGION) {
        static const u16 legs[ARENA_AVATAR_LEG_COLOR_COUNT][2] = {
            { RGB5(7, 11, 18), RGB5(14, 19, 27) },
            { RGB5(5, 6, 8), RGB5(12, 13, 16) },
            { RGB5(15, 12, 7), RGB5(25, 22, 15) },
            { RGB5(8, 15, 10), RGB5(17, 24, 17) }
        };
        static const u16 shoes[ARENA_AVATAR_SHOE_COLOR_COUNT][2] = {
            { RGB5(4, 4, 6), RGB5(10, 11, 14) },
            { RGB5(11, 6, 4), RGB5(21, 13, 8) },
            { RGB5(5, 10, 19), RGB5(13, 20, 29) },
            { RGB5(19, 18, 14), RGB5(30, 29, 25) }
        };
        for (i = 0; i < count; i++) {
            switch (i & 15) {
            case 0: colors[i] = 0; break;
            case 1: colors[i] = RGB5(3, 3, 4); break;
            case 2: colors[i] = skin[profile->skin][0]; break;
            case 3: colors[i] = skin[profile->skin][1]; break;
            case 4: colors[i] = (skin[profile->skin][1] >> 1) & RGB5(15, 15, 15); break;
            case 5: colors[i] = hair[profile->hair][1]; break;
            case 6: colors[i] = hair[profile->hair][0]; break;
            case 7: colors[i] = (hair[profile->hair][0] >> 1) & RGB5(15, 15, 15); break;
            case 8: colors[i] = outfit[profile->outfit][1]; break;
            case 9: colors[i] = outfit[profile->outfit][0]; break;
            case 10: colors[i] = (outfit[profile->outfit][0] >> 1) & RGB5(15, 15, 15); break;
            case 11: colors[i] = legs[profile->legColor][1]; break;
            case 12: colors[i] = legs[profile->legColor][0]; break;
            case 13: colors[i] = shoes[profile->shoes][1]; break;
            case 14: colors[i] = shoes[profile->shoes][0]; break;
            case 15: colors[i] = RGB5(29, 29, 28); break;
            }
        }
        return;
    }
    if (profile->regional == 2) {
        for (i = 0; i < count; i++) {
            int slot = i & 15;
            if (profile->skin && (slot == 2 || slot == 3)) {
                colors[i] = skin[profile->skin][slot == 3];
            } else if (profile->hair && (slot == 1 || slot == 4 || slot == 8)) {
                colors[i] = hair[profile->hair][slot == 1];
            } else if (profile->outfit && ((profile->body == 0 && (slot == 11 || slot == 12))
                || (profile->body == 1 && (slot == 5 || slot == 6 || slot == 7)))) {
                colors[i] = outfit[profile->outfit][slot == 11 || slot == 7];
            }
        }
        return;
    }
    if (profile->regional) {
        for (i = 0; i < count; i++) {
            int slot = i & 15;
            if (profile->skin && slot >= 1 && slot <= 3) {
                colors[i] = skin[profile->skin][slot == 1 ? 0 : 1];
            } else if (profile->hair && ((profile->body == 0 && slot >= 5 && slot <= 8)
                || (profile->body == 1 && (slot == 4 || slot == 7 || slot == 8)))) {
                colors[i] = hair[profile->hair][slot == 5 || slot == 7];
            } else if (profile->outfit && (slot == 10 || slot == 11 || slot == 12 || slot == 13)) {
                colors[i] = outfit[profile->outfit][slot == 10 || slot == 12];
            }
        }
        return;
    }
    for (i = 0; i < count; i++) {
        u16 c = colors[i] & 0x7fff;
        u16 extra = colors[i] & 0x8000;
        if (profile->skin && (c == RGB5(31, 26, 23) || c == RGB5(31, 25, 22))) {
            c = skin[profile->skin][0];
        } else if (profile->skin && (c == RGB5(27, 20, 15) || c == RGB5(26, 19, 15))) {
            c = skin[profile->skin][1];
        } else if (profile->hair && (c == RGB5(7, 8, 10) || c == RGB5(7, 8, 8))) {
            c = hair[profile->hair][0];
        } else if (profile->hair && (c == RGB5(7, 12, 17) || c == RGB5(7, 10, 15) || c == RGB5(10, 12, 17) || c == RGB5(9, 12, 12))) {
            c = hair[profile->hair][1];
        } else if (profile->outfit && (c == RGB5(23, 7, 9) || c == RGB5(23, 5, 9) || c == RGB5(24, 13, 19) || c == RGB5(23, 13, 19) || c == RGB5(24, 7, 7) || c == RGB5(12, 17, 26))) {
            c = outfit[profile->outfit][0];
        } else if (profile->outfit && (c == RGB5(27, 13, 15) || c == RGB5(28, 9, 11) || c == RGB5(29, 18, 24) || c == RGB5(31, 18, 24) || c == RGB5(30, 13, 9))) {
            c = outfit[profile->outfit][1];
        }
        colors[i] = c | extra;
    }
}

#ifndef ARENA_AVATAR_HOST
typedef struct AvatarArtEntry {
    u32 offset;
    u32 size;
    u32 stride;
    u32 paletteSize;
} AvatarArtEntry;

/* A state is composited once when its shape changes. NitroFS reads and GX
 * transfers use aligned main RAM; no per-frame allocation or layer I/O. */
static u32 sCustomPixels[8192];
static u32 sCustomLayer[128];
static u32 sPreviewNative[1536];
static AvatarArtEntry sCustomEntry;
static ArenaAvatarProfile sCustomProfile;
static int sCustomState = -1;

static int Avatar_LoadCustomState(const ArenaAvatarProfile *profile, int state)
{
    FSFile file;
    static u32 header[4];
    static AvatarArtEntry entry;
    int layers[5];
    int layerCount = profile->hat ? 5 : 4;
    int layer;
    int success = FALSE;
    u32 total = 0;
    u32 stride = 0;
    u8 *pixels = (u8 *)sCustomPixels;
    if (!ArenaAvatar_IsValid(profile) || profile->regional != ARENA_AVATAR_CUSTOM_REGION
        || state < 0 || state >= 16) return FALSE;
    if (sCustomState == state && !memcmp(profile, &sCustomProfile, sizeof(*profile))) return TRUE;
    sCustomState = -1;
    layers[0] = 0;
    layers[1] = 1 + profile->legwear;
    layers[2] = 4 + profile->top;
    layers[3] = 7 + profile->hairstyle;
    layers[4] = 10 + profile->hat;
    FS_InitFile(&file);
    if (!FS_OpenFile(&file, "data/arena/custom.bin")) return FALSE;
    if (FS_ReadFile(&file, header, sizeof(header)) != sizeof(header)
        || header[0] != 0x31435641 || header[1] != 1 || header[2] != 416) goto close;
    for (layer = 0; layer < layerCount; layer++) {
        int index = (profile->body * 16 + state) * 13 + layers[layer];
        u32 position;
        FS_SeekFile(&file, 16 + index * sizeof(entry), FS_SEEK_SET);
        if (FS_ReadFile(&file, &entry, sizeof(entry)) != sizeof(entry)
            || entry.paletteSize || !entry.stride || !entry.size
            || entry.size > sizeof(sCustomPixels) || entry.size % entry.stride
            || entry.offset > FS_GetLength(&file)
            || entry.size > FS_GetLength(&file) - entry.offset) goto close;
        if (!layer) {
            total = entry.size;
            stride = entry.stride;
            MI_CpuClear32(sCustomPixels, sizeof(sCustomPixels));
        } else if (entry.size != total || entry.stride != stride) goto close;
        FS_SeekFile(&file, entry.offset, FS_SEEK_SET);
        for (position = 0; position < total; position += sizeof(sCustomLayer)) {
            u32 chunk = total - position;
            u32 i;
            const u8 *source = (const u8 *)sCustomLayer;
            if (chunk > sizeof(sCustomLayer)) chunk = sizeof(sCustomLayer);
            if (FS_ReadFile(&file, sCustomLayer, chunk) != chunk) goto close;
            for (i = 0; i < chunk; i++) {
                u8 value = source[i];
                u8 *target = pixels + position + i;
                if (state == 13) {
                    if (value > 15) goto close;
                    if (value) *target = value;
                } else {
                    if (value & 15) *target = (*target & 0xf0) | (value & 15);
                    if (value & 0xf0) *target = (*target & 15) | (value & 0xf0);
                }
            }
        }
    }
    sCustomEntry.offset = 0;
    sCustomEntry.size = total;
    sCustomEntry.stride = stride;
    sCustomEntry.paletteSize = 0;
    sCustomProfile = *profile;
    sCustomState = state;
    success = TRUE;
close:
    FS_CloseFile(&file);
    return success;
}

static int Avatar_CustomPreview(const ArenaAvatarProfile *profile, int frame, void *destination, u32 size)
{
    int x, y;
    const u8 *source;
    u8 *output = destination;
    if (size != 4096 || frame < 0 || frame > 3 || !Avatar_LoadCustomState(profile, 12)
        || sCustomEntry.stride != 512 || sCustomEntry.size != 2048) return FALSE;
    source = (const u8 *)sCustomPixels + frame * 512;
    MI_CpuClear32(destination, size);
    for (y = 0; y < 64; y++) {
        for (x = 0; x < 64; x++) {
            int sx = x / 2;
            int sy = y / 2;
            u8 pixel = (source[sy * 16 + sx / 2] >> ((sx & 1) * 4)) & 15;
            int dy = y + 32;
            int offset = ((dy / 8) * 8 + x / 8) * 32 + (dy & 7) * 4 + (x & 7) / 2;
            output[offset] |= pixel << ((x & 1) * 4);
        }
    }
    return TRUE;
}

static void Avatar_ExpandPreview(const u8 *source, u8 *output)
{
    int x, y;
    MI_CpuClear32(output, 6144);
    for (y = 0; y < 96; y++) {
        for (x = 0; x < 96; x++) {
            int sx = x / 3;
            int sy = y / 3;
            int dy = y + 16;
            int offset = ((dy / 8) * 12 + x / 8) * 32 + (dy & 7) * 4 + (x & 7) / 2;
            u8 pixel = (source[sy * 16 + sx / 2] >> ((sx & 1) * 4)) & 15;
            output[offset] |= pixel << ((x & 1) * 4);
        }
    }
}

static int Avatar_OpenArt(FSFile *file, const ArenaAvatarProfile *profile, int state, AvatarArtEntry *entry)
{
    static u32 header[4]; // NitroFS transfers must not target DTCM stack.
    static AvatarArtEntry diskEntry;
    int artIndex;
    if (!ArenaAvatar_IsValid(profile) || state < 0 || state >= 16
        || (!profile->regional && state != 12)) return FALSE;
    artIndex = profile->regional ? (profile->regional - 1) * 32 + profile->body * 16 + state : 64 + profile->body;
    FS_InitFile(file);
    if (!FS_OpenFile(file, "data/arena/avatar.bin")) return FALSE;
    if (FS_ReadFile(file, header, sizeof(header)) != sizeof(header)
        || header[0] != 0x31415641 || header[1] != 3 || header[2] != 66) {
        FS_CloseFile(file); return FALSE;
    }
    FS_SeekFile(file, 16 + artIndex * sizeof(*entry), FS_SEEK_SET);
    if (FS_ReadFile(file, &diskEntry, sizeof(diskEntry)) != sizeof(diskEntry)
        || diskEntry.paletteSize != 32 || !diskEntry.stride
        || diskEntry.offset + diskEntry.size + 32 > FS_GetLength(file)) {
        FS_CloseFile(file); return FALSE;
    }
    *entry = diskEntry;
    return TRUE;
}

int ArenaAvatar_LoadArt(const ArenaAvatarProfile *profile, int state, int frame,
    void *destination, u32 size, u16 palette[16])
{
    FSFile file;
    AvatarArtEntry entry;
    int success;
    if (!ArenaAvatar_IsValid(profile)) return FALSE;
    if (profile->regional == ARENA_AVATAR_CUSTOM_REGION) {
        if (state == 12) {
            success = Avatar_CustomPreview(profile, frame, destination, size);
        } else {
            if (!Avatar_LoadCustomState(profile, state) || frame < 0 || size > sCustomEntry.stride
                || (u32)frame >= sCustomEntry.size / sCustomEntry.stride) return FALSE;
            MI_CpuCopy8((const u8 *)sCustomPixels + frame * sCustomEntry.stride, destination, size);
            success = TRUE;
        }
        if (success) ArenaAvatar_ApplyPalette(profile, palette, 16);
        return success;
    }
    if (!Avatar_OpenArt(&file, profile, state, &entry)) return FALSE;
    if (frame < 0 || (u32)frame * entry.stride + size > entry.size || size > entry.stride) {
        FS_CloseFile(&file); return FALSE;
    }
    FS_SeekFile(&file, entry.offset, FS_SEEK_SET);
    success = FS_ReadFile(&file, palette, 32) == 32;
    FS_SeekFile(&file, entry.offset + 32 + frame * entry.stride, FS_SEEK_SET);
    success &= FS_ReadFile(&file, destination, size) == size;
    FS_CloseFile(&file);
    if (success) ArenaAvatar_ApplyPalette(profile, palette, 16);
    return success;
}

int ArenaAvatar_LoadPreview(const ArenaAvatarProfile *profile, int facing, int step,
    void *destination, u32 size, u16 palette[16])
{
    const u8 *source;
    if (!ArenaAvatar_IsValid(profile) || facing < 0 || facing > 3 || step < 0 || step > 3
        || (size != 6144 && size != 512)) return FALSE;
    if (profile->regional == ARENA_AVATAR_CUSTOM_REGION) {
        if (!Avatar_LoadCustomState(profile, 0) || sCustomEntry.stride != 512 || sCustomEntry.size < 8192) return FALSE;
        source = (const u8 *)sCustomPixels + (facing * 4 + step) * 512;
        ArenaAvatar_ApplyPalette(profile, palette, 16);
    } else if (profile->regional) {
        if (!ArenaAvatar_LoadArt(profile, 0, facing * 4 + step, sCustomLayer, 512, palette)) return FALSE;
        source = (const u8 *)sCustomLayer;
    } else {
        int x, y;
        const u8 *native = (const u8 *)sPreviewNative;
        u8 *linear = (u8 *)sCustomLayer;
        if (!ArenaAvatar_LoadArt(profile, 12, facing, sPreviewNative, 4096, palette)
            && !ArenaAvatar_LoadArt(profile, 12, 0, sPreviewNative, 4096, palette)) return FALSE;
        MI_CpuClear32(sCustomLayer, sizeof(sCustomLayer));
        for (y = 0; y < 32; y++) {
            for (x = 0; x < 32; x++) {
                int sx = x * 2;
                int sy = y * 2 + 32;
                int offset = ((sy / 8) * 8 + sx / 8) * 32 + (sy & 7) * 4 + (sx & 7) / 2;
                u8 pixel = (native[offset] >> ((sx & 1) * 4)) & 15;
                linear[y * 16 + x / 2] |= pixel << ((x & 1) * 4);
            }
        }
        source = linear;
    }
    if (size == 512) {
        int x, y;
        u8 *output = destination;
        MI_CpuClear32(destination, size);
        for (y = 0; y < 32; y++) {
            for (x = 0; x < 32; x++) {
                int offset = ((y / 8) * 4 + x / 8) * 32 + (y & 7) * 4 + (x & 7) / 2;
                u8 pixel = (source[y * 16 + x / 2] >> ((x & 1) * 4)) & 15;
                output[offset] |= pixel << ((x & 1) * 4);
            }
        }
    } else Avatar_ExpandPreview(source, destination);
    return TRUE;
}

int ArenaAvatar_LoadCreatorPortrait(const ArenaAvatarProfile *profile, void *destination,
    u32 size, u16 palette[16])
{
    int x, y;
    u8 *output = destination;
    const u8 *source = (const u8 *)sPreviewNative;
    if (size != 6144 || !ArenaAvatar_LoadArt(profile, 13, 0, sPreviewNative, 6144, palette)) return FALSE;
    MI_CpuClear32(destination, size);
    for (y = 0; y < 120; y++) {
        for (x = 0; x < 72; x++) {
            int sx = x * 2 / 3;
            int sy = y * 2 / 3;
            int tile = 1 + (sy / 8) * 6 + sx / 8;
            int dx = x + 12;
            int dy = y + 8;
            int offset = ((dy / 8) * 12 + dx / 8) * 32 + (dy & 7) * 4 + (dx & 7) / 2;
            u8 pixel = source[tile * 64 + (sy & 7) * 8 + (sx & 7)] & 15;
            output[offset] |= pixel << ((dx & 1) * 4);
        }
    }
    return TRUE;
}

int ArenaAvatar_LoadCardArt(const ArenaAvatarProfile *profile, void *characters, u32 characterSize,
    void *tilemap, u32 tilemapSize, u16 palette[16])
{
    FSFile file;
    AvatarArtEntry entry;
    int success;
    if (profile->regional == ARENA_AVATAR_CUSTOM_REGION) {
        int tx, ty;
        u32 i;
        u8 *output = characters;
        u16 *map = tilemap;
        const u8 *pixels = (const u8 *)sCustomPixels;
        if (characterSize != 6144 || tilemapSize != 2048
            || !Avatar_LoadCustomState(profile, 13) || sCustomEntry.size != characterSize) return FALSE;
        for (i = 0; i < characterSize; i++) output[i] = pixels[i] ? 64 + profile->body * 16 + pixels[i] : 0;
        MI_CpuClear16(tilemap, tilemapSize);
        for (ty = 0; ty < 10; ty++) {
            for (tx = 0; tx < 6; tx++) map[(6 + ty) * 32 + 22 + tx] = 1 + ty * 6 + tx;
        }
        ArenaAvatar_ApplyPalette(profile, palette, 16);
        return TRUE;
    }
    if (characterSize != 6144 || tilemapSize != 2048 || !Avatar_OpenArt(&file, profile, 13, &entry)) return FALSE;
    FS_SeekFile(&file, entry.offset, FS_SEEK_SET);
    success = FS_ReadFile(&file, palette, 32) == 32;
    success &= FS_ReadFile(&file, characters, characterSize) == characterSize;
    success &= FS_ReadFile(&file, tilemap, tilemapSize) == tilemapSize;
    FS_CloseFile(&file);
    if (success) ArenaAvatar_ApplyPalette(profile, palette, 16);
    return success;
}

static void Avatar_ApplyRegionalTexture(NNSG3dResTex *texture, int state)
{
    FSFile file;
    AvatarArtEntry entry;
    int i;
    static u16 colors[16]; // Main RAM for NitroFS palette reads.
    u8 *pixels = (u8 *)texture + texture->texInfo.ofsTex;
    int custom = sAvatar.regional == ARENA_AVATAR_CUSTOM_REGION;
    if (custom) {
        if (!Avatar_LoadCustomState(&sAvatar, state) || sCustomEntry.stride != 512) return;
        entry = sCustomEntry;
    } else {
        if (!Avatar_OpenArt(&file, &sAvatar, state, &entry)) return;
        FS_SeekFile(&file, entry.offset, FS_SEEK_SET);
        if (FS_ReadFile(&file, colors, sizeof(colors)) != sizeof(colors)) { FS_CloseFile(&file); return; }
    }
    for (i = 0; i < texture->dict.numEntry; i++) {
        const NNSG3dResName *name = NNS_G3dGetTexNameByIdx(texture, i);
        const NNSG3dResDictTexData *data = NNS_G3dGetResDataByIdx(&texture->dict, i);
        unsigned offset = (data->texImageParam & 0xffff) * 8;
        unsigned frame = 0;
        int index;
        for (index = 0; index < 15 && name->name[index] != '.'; index++);
        for (index++; index < 16 && name->name[index] >= '0' && name->name[index] <= '9'; index++) {
            frame = frame * 10 + name->name[index] - '0';
        }
        if (!frame || frame * 512 > entry.size || offset + 512 > texture->texInfo.sizeTex * 8) continue;
        if (custom) {
            MI_CpuCopy32((const u8 *)sCustomPixels + (frame - 1) * 512, pixels + offset, 512);
        } else {
            FS_SeekFile(&file, entry.offset + 32 + (frame - 1) * 512, FS_SEEK_SET);
            if (FS_ReadFile(&file, pixels + offset, 512) != 512) break;
        }
    }
    if (!custom) FS_CloseFile(&file);
    ArenaAvatar_ApplyPalette(&sAvatar, colors, 16);
    MI_CpuCopy16(colors, (u8 *)texture + texture->plttInfo.ofsPlttData, sizeof(colors));
}

void ArenaAvatar_ApplyPlayerTexture(void *textureResource)
{
    static const char *const names[] = {
        "pl_boy01c", "pl_girl01c", "pl_cyclehero", "pl_cycheroine",
        "pl_sphero", "pl_spheroine", "pl_whelo", "pl_wheroine",
        "pl_swimhiro", "pl_swimhiroine", "contesthero", "cont_heroine",
        "pl_fishhero", "pl_fheroine", "pl_pokehero", "pl_pkheroine",
        "pl_savehero", "pl_saveheroine", "pl_banhero", "pl_banheroine",
        "pl_bshero", "pl_bsheroine", "hero", "heroine"
    };
    NNSG3dResTex *texture = textureResource;
    int i;
    int j;
    if (!texture || !texture->dict.numEntry || !texture->plttInfo.sizePltt) {
        return;
    }
    for (i = 0; i < texture->dict.numEntry; i++) {
        const NNSG3dResName *name = NNS_G3dGetTexNameByIdx(texture, i);
        for (j = 0; j < NELEMS(names); j++) {
            int len = strlen(names[j]);
            /* Sprite frame texture names may append a frame number. */
            if ((j & 1) == sAvatar.body && !strncmp(name->name, names[j], len)
                && (name->name[len] == 0 || name->name[len] == '.' || (name->name[len] >= '0' && name->name[len] <= '9'))) {
                u16 *palette = (u16 *)((u8 *)texture + texture->plttInfo.ofsPlttData);
                if (sAvatar.regional) {
                    Avatar_ApplyRegionalTexture(texture, j / 2);
                    return;
                }
                ArenaAvatar_ApplyPalette(&sAvatar, palette, texture->plttInfo.sizePltt * 4);
                return;
            }
        }
    }
}
#endif
