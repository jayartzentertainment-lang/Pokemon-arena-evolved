/* Live capture timing follows the accepted Arena source adaptation. Native
 * Platinum owns Pokemon identity, Gen IV odds, inventory and actual storage. */
#include "arena/capture.h"
#include "arena/rewards.h"
#include "arena/vendor/arena_navigation.h"
#include "constants/items.h"
#include <string.h>
#define Q 256
static s32 Clamp(s32 n,s32 lo,s32 hi){return n<lo?lo:n>hi?hi:n;}
static void Phase(ArenaCapture *s,unsigned p){s->phase=p;s->age=0;}
static void Notice(ArenaCapture *s,const char *message){s->message=message;s->notice=100;}
static CombatFighter *Player(ArenaCapture *s){return &s->party->combat->fighters[s->party->controlActor];}
static void Clear(CombatFighter *p){p->buffered=0;p->bufferTimer=0;p->vx=p->vy=0;}
static void Reset(ArenaCapture *s){Phase(s,ARENA_CAPTURE_IDLE);Clear(Player(s));}
static BOOL WildTarget(ArenaCapture *s)
{
    unsigned i,count=0,target=COMBAT_FIGHTERS;
    if(s->party->dto->battleType&BATTLE_TYPE_TRAINER)return FALSE;
    for(i=1;i<s->party->actorCount;i+=2)if(s->party->combat->fighters[i].hp){count++;target=i;}
    if(count!=1)return FALSE;
    s->target=target;return TRUE;
}
void ArenaCapture_Init(ArenaCapture *s,ArenaPartyBridge *party,u32 seed,u32 held)
{
    memset(s,0,sizeof(*s));s->party=party;s->random=seed;
    s->heldLatch=(held&(PAD_BUTTON_L|PAD_BUTTON_R))==(PAD_BUTTON_L|PAD_BUTTON_R);
}
static BOOL CanThrow(ArenaCapture *s)
{
    if(!WildTarget(s)){Notice(s,"Catching: one wild foe must remain.");return FALSE;}
    if(!ArenaRewards_CanThrow(s->party->dto)){Notice(s,"No Poke Balls, or your storage is full.");return FALSE;}
    return TRUE;
}
static void Step(ArenaCapture *s)
{
    Combat *c=s->party->combat;CombatFighter *enemy=&c->fighters[s->target];
    int t=++s->age;unsigned i;
    switch(s->phase){
    case ARENA_CAPTURE_THROW:
        s->ballX=s->startX+(s->aimX-s->startX)*t/24;
        s->ballY=s->startY+(s->aimY-s->startY)*t/24-Q*(8*t/24+104*t*(24-t)/576);
        if(t==24){
            if(!enemy->hp||ArenaNav_Distance(s->aimX/Q,s->aimY/Q,enemy->x/Q,enemy->y/Q)>22
                ||ArenaNav_FirstObstacle(s->aimX/Q,s->aimY/Q,s->aimX/Q,s->aimY/Q,2)>=0){
                Phase(s,ARENA_CAPTURE_MISS);Notice(s,"The Poke Ball missed!");
            }else{
                ArenaParty_Store(s->party);
                s->shakes=ArenaRewards_CatchShakes(s->party->dto,s->party->actor[s->target].owner,
                    s->party->actor[s->target].slot,ITEM_POKE_BALL,&s->random);
                Phase(s,ARENA_CAPTURE_ABSORB);memset(c->projectiles,0,sizeof(c->projectiles));
                for(i=0;i<c->fighterCount;i++){
                    CombatFighter *f=&c->fighters[i];f->phase=COMBAT_READY;f->actionMove=0;
                    f->actionTick=f->actionDistance=0;f->basicAttack=f->dashTimer=0;
                    f->guardTimer=f->guardHeld=0;Clear(f);
                }
                c->hitstop=0;
            }
        }break;
    case ARENA_CAPTURE_ABSORB:
        s->ballX=s->aimX;s->ballY=s->aimY-8*Q;if(t>=24)Phase(s,ARENA_CAPTURE_DROP);break;
    case ARENA_CAPTURE_DROP:
        s->ballY=s->aimY+Q*(t<=16?-8+8*t/16:-4*(t-16)*(24-t)/16);
        if(t>=24){s->ballY=s->aimY;Phase(s,ARENA_CAPTURE_SHAKE);}break;
    case ARENA_CAPTURE_SHAKE:
        s->ballX=s->aimX;s->ballY=s->aimY;
        if(t>=20&&t<104){int local=(t-20)%34;if(local<16)s->ballX+=Q*(local<4?-3:local<12?3:-3);}
        if((t==20||t==54||t==88)&&(unsigned)((t-20)/34)>=s->shakes){
            Phase(s,ARENA_CAPTURE_BREAK);Notice(s,"It broke free!");
        }else if(t==122){
            ArenaParty_Store(s->party);
            if(s->shakes==4&&ArenaRewards_Catch(s->party->dto,s->party->actor[s->target].owner,
                s->party->actor[s->target].slot,ITEM_POKE_BALL)){
                Phase(s,ARENA_CAPTURE_CAUGHT);Notice(s,"Gotcha! The Pokemon was caught!");
            }else{Phase(s,ARENA_CAPTURE_BREAK);Notice(s,"It broke free!");}
        }break;
    case ARENA_CAPTURE_BREAK:
        s->ballX=s->aimX;s->ballY=s->aimY-8*Q;
        if(t>=22){Reset(s);s->recovery=12;if(enemy->aiCooldown<30)enemy->aiCooldown=30;enemy->aiTimer=0;}
        break;
    case ARENA_CAPTURE_CAUGHT:if(t>=100){s->finished=1;s->age=100;}break;
    case ARENA_CAPTURE_MISS:
        s->ballX=s->aimX+Q*t/3;s->ballY=s->aimY-Q*24*t*(24-t)/576;
        if(t>=24)Reset(s);
        break;
    default:break;
    }
}
BOOL ArenaCapture_Process(ArenaCapture *s,u32 held,u32 pressed,CombatInput *input)
{
    Combat *c=s->party->combat;CombatFighter *p=Player(s),*enemy;
    BOOL both=(held&(PAD_BUTTON_L|PAD_BUTTON_R))==(PAD_BUTTON_L|PAD_BUTTON_R);
    if(both)input->pressed&=~(COMBAT_L|COMBAT_R);
    if(s->party->dto->battleType&BATTLE_TYPE_TRAINER)return TRUE;
    if(!both)s->heldLatch=0;
    if(s->notice&&s->phase==ARENA_CAPTURE_IDLE)s->notice--;
    if(c->winner){if(s->phase!=ARENA_CAPTURE_CAUGHT)Reset(s);return TRUE;}
    s->clock++;
    if(s->recovery){s->recovery--;input->held&=~(COMBAT_A|COMBAT_X|COMBAT_ALT);input->pressed&=~(COMBAT_A|COMBAT_X|COMBAT_ALT);Clear(p);}
    if(s->phase==ARENA_CAPTURE_IDLE&&both&&!s->heldLatch&&p->phase==COMBAT_READY&&!p->dashTimer&&!p->guardTimer){
        s->heldLatch=1;
        if(CanThrow(s)){
            enemy=&c->fighters[s->target];s->aimX=enemy->x;s->aimY=enemy->y;
            s->previousX=enemy->x;s->previousY=enemy->y;s->velocityX=s->velocityY=0;
            s->manual=0;Phase(s,ARENA_CAPTURE_AIM);Clear(p);Notice(s,"Aim: release L/R to throw. B cancels.");
        }
    }
    if(s->phase==ARENA_CAPTURE_AIM){
        int dx,dy;
        enemy=&c->fighters[s->target];input->held=input->pressed=0;Clear(p);
        s->velocityX=Clamp(enemy->x-s->previousX,-2*Q,2*Q);s->velocityY=Clamp(enemy->y-s->previousY,-2*Q,2*Q);
        s->previousX=enemy->x;s->previousY=enemy->y;
        if(pressed&(PAD_BUTTON_B|PAD_BUTTON_START|PAD_BUTTON_SELECT)){Reset(s);Notice(s,"Throw cancelled.");return TRUE;}
        if(both){
            dx=!!(held&PAD_KEY_RIGHT)-!!(held&PAD_KEY_LEFT);dy=!!(held&PAD_KEY_DOWN)-!!(held&PAD_KEY_UP);
            if(dx||dy)s->manual=1;
            if(!s->manual){s->aimX=enemy->x;s->aimY=enemy->y;}
            s->aimX=Clamp(s->aimX+dx*2*Q,ARENA_MIN_X*Q,ARENA_MAX_X*Q);
            s->aimY=Clamp(s->aimY+dy*2*Q,ARENA_MIN_Y*Q,ARENA_MAX_Y*Q);
            return (s->clock%3)==0;
        }
        if(!enemy->hp||!CanThrow(s)||!ArenaRewards_ConsumeBall(s->party->dto,ITEM_POKE_BALL)){Reset(s);return TRUE;}
        if(ArenaNav_Distance(s->aimX/Q,s->aimY/Q,enemy->x/Q,enemy->y/Q)<18){
            s->aimX=Clamp(enemy->x+Clamp(s->velocityX*8,-16*Q,16*Q),ARENA_MIN_X*Q,ARENA_MAX_X*Q);
            s->aimY=Clamp(enemy->y+Clamp(s->velocityY*8,-16*Q,16*Q),ARENA_MIN_Y*Q,ARENA_MAX_Y*Q);
        }
        s->startX=Clamp(p->x-24*Q,ARENA_MIN_X*Q,ARENA_MAX_X*Q);
        s->startY=Clamp(p->y+8*Q,ARENA_MIN_Y*Q,ARENA_MAX_Y*Q);
        Phase(s,ARENA_CAPTURE_THROW);Notice(s,"...");
    }
    if(s->phase!=ARENA_CAPTURE_IDLE){
        BOOL locked=s->phase>=ARENA_CAPTURE_ABSORB&&s->phase<=ARENA_CAPTURE_CAUGHT;
        if(locked){input->held=input->pressed=0;Clear(p);}
        Step(s);
        if(s->phase>=ARENA_CAPTURE_ABSORB&&s->phase<=ARENA_CAPTURE_CAUGHT)return FALSE;
        if(s->phase==ARENA_CAPTURE_THROW)return (s->clock%3)==0;
    }
    return TRUE;
}
