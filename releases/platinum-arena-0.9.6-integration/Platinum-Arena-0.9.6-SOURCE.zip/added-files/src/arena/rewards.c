#include "arena/rewards.h"

#include <string.h>

#include "constants/heap.h"
#include "constants/items.h"
#include "constants/string.h"
#include "generated/game_records.h"
#include "generated/item_hold_effects.h"
#include "generated/items.h"
#include "generated/trainer_score_events.h"

#include "charcode_util.h"
#include "game_records.h"
#include "global/pm_version.h"
#include "item.h"
#include "pokemon.h"
#include "tv_segment.h"

#include "data/trainer_class_prize_mul.h"

/* Native learnsets contain at most 20 entries; evolution occurs after battle. */
#define ARENA_PENDING_MOVES (MAX_PARTY_SIZE * MAX_LEARNSET_ENTRIES)

static struct {
    FieldBattleDTO *dto;
    u32 defeated[MAX_BATTLERS];
    u32 encountered[MAX_BATTLERS];
    ArenaLearnMove pending[ARENA_PENDING_MOVES];
    u16 pendingCount;
    u16 ballsThrown;
    u16 paidBall;
    u8 moneyMultiplier;
    BOOL caught;
    BOOL finalized;
} sRewards;

static BOOL ArenaRewards_ValidMon(FieldBattleDTO *dto, int owner, int slot)
{
    return dto != NULL && owner >= 0 && owner < MAX_BATTLERS
        && dto->parties[owner] != NULL && slot >= 0
        && slot < Party_GetCurrentCount(dto->parties[owner]);
}

static int ArenaRewards_ItemEffect(Pokemon *mon)
{
    int item = Pokemon_GetValue(mon, MON_DATA_HELD_ITEM, NULL);
    return Item_LoadParam(item, ITEM_PARAM_HOLD_EFFECT, HEAP_ID_BATTLE);
}

static BOOL ArenaRewards_IsOT(FieldBattleDTO *dto, Pokemon *mon)
{
    charcode_t name[TRAINER_NAME_LEN + 1];
    TrainerInfo *info = dto->trainerInfo[0];
    Pokemon_GetValue(mon, MON_DATA_OT_NAME, name);
    return TrainerInfo_ID(info) == Pokemon_GetValue(mon, MON_DATA_OT_ID, NULL)
        && TrainerInfo_Gender(info) == Pokemon_GetValue(mon, MON_DATA_OT_GENDER, NULL)
        && CharCode_CompareNumChars(TrainerInfo_Name(info), name, TRAINER_NAME_LEN) == 0;
}

/* Equivalent to BattleScript_CalcEffortValues, including Gen IV 255/510 caps. */
static void ArenaRewards_GiveEVs(Party *party, int slot, Pokemon *foe)
{
    static const int yieldParams[STAT_MAX] = {
        SPECIES_DATA_EV_HP_YIELD, SPECIES_DATA_EV_ATK_YIELD,
        SPECIES_DATA_EV_DEF_YIELD, SPECIES_DATA_EV_SPEED_YIELD,
        SPECIES_DATA_EV_SP_ATK_YIELD, SPECIES_DATA_EV_SP_DEF_YIELD
    };
    static const int powerEffects[STAT_MAX] = {
        HOLD_EFFECT_LVLUP_HP_EV_UP, HOLD_EFFECT_LVLUP_ATK_EV_UP,
        HOLD_EFFECT_LVLUP_DEF_EV_UP, HOLD_EFFECT_LVLUP_SPEED_EV_UP,
        HOLD_EFFECT_LVLUP_SPATK_EV_UP, HOLD_EFFECT_LVLUP_SPDEF_EV_UP
    };
    Pokemon *mon = Party_GetPokemonBySlotIndex(party, slot);
    int item = Pokemon_GetValue(mon, MON_DATA_HELD_ITEM, NULL);
    int effect = Item_LoadParam(item, ITEM_PARAM_HOLD_EFFECT, HEAP_ID_BATTLE);
    int power = Item_LoadParam(item, ITEM_PARAM_EFFECT_PARAM, HEAP_ID_BATTLE);
    int species = Pokemon_GetValue(foe, MON_DATA_SPECIES, NULL);
    int form = Pokemon_GetValue(foe, MON_DATA_FORM, NULL);
    SpeciesData *personal = SpeciesData_FromMonForm(species, form, HEAP_ID_BATTLE);
    u8 evs[STAT_MAX];
    int total = 0;
    int stat;

    for (stat = 0; stat < STAT_MAX; stat++) {
        evs[stat] = Pokemon_GetValue(mon, MON_DATA_HP_EV + stat, NULL);
        total += evs[stat];
    }
    for (stat = 0; stat < STAT_MAX && total < MAX_EVS_ALL_STATS; stat++) {
        int gain = SpeciesData_GetValue(personal, yieldParams[stat]);
        if (effect == powerEffects[stat]) {
            gain += power;
        }
        if (Pokemon_HasPokerus(party, 1u << slot)) {
            gain *= 2;
        }
        if (effect == HOLD_EFFECT_EVS_UP_SPEED_DOWN) {
            gain *= 2;
        }
        if (gain > MAX_EVS_ALL_STATS - total) {
            gain = MAX_EVS_ALL_STATS - total;
        }
        if (gain > MAX_EVS_SINGLE_STAT - evs[stat]) {
            gain = MAX_EVS_SINGLE_STAT - evs[stat];
        }
        evs[stat] += gain;
        total += gain;
        Pokemon_SetValue(mon, MON_DATA_HP_EV + stat, &evs[stat]);
    }
    SpeciesData_Free(personal);
}

void ArenaRewards_Begin(FieldBattleDTO *dto)
{
    memset(&sRewards, 0, sizeof(sRewards));
    sRewards.dto = dto;
    sRewards.moneyMultiplier = 1;
}

void ArenaRewards_OnSendOut(FieldBattleDTO *dto, int owner, int partySlot)
{
    Pokemon *mon;
    if (dto != sRewards.dto || sRewards.finalized || !ArenaRewards_ValidMon(dto, owner, partySlot)) {
        return;
    }
    mon = Party_GetPokemonBySlotIndex(dto->parties[owner], partySlot);
    if (ArenaRewards_ItemEffect(mon) == HOLD_EFFECT_MONEY_UP) {
        sRewards.moneyMultiplier = 2;
    }
    if ((owner & 1) && !(sRewards.encountered[owner] & (1u << partySlot))) {
        sRewards.encountered[owner] |= 1u << partySlot;
        if (dto->pokedex) {
            Pokedex_Encounter(dto->pokedex, mon);
        }
    }
}

void ArenaRewards_OnDefeat(FieldBattleDTO *dto, int enemyOwner, int partySlot, u32 playerParticipants)
{
    int count;
    int slot;
    int participants = 0;
    int shares = 0;
    u32 gainedExp;
    u32 sharedExp;
    u32 baseExp;
    Pokemon *foe;

    if (dto != sRewards.dto || sRewards.finalized || (enemyOwner & 1) == 0
        || !ArenaRewards_ValidMon(dto, enemyOwner, partySlot)
        || (sRewards.defeated[enemyOwner] & (1u << partySlot))) {
        return;
    }
    foe = Party_GetPokemonBySlotIndex(dto->parties[enemyOwner], partySlot);
    if (Pokemon_GetValue(foe, MON_DATA_HP, NULL) != 0) {
        return;
    }
    sRewards.defeated[enemyOwner] |= 1u << partySlot;
    if (dto->battleType & BATTLE_TYPE_NO_EXPERIENCE) {
        return;
    }

    count = Party_GetCurrentCount(dto->parties[0]);
    for (slot = 0; slot < count; slot++) {
        Pokemon *mon = Party_GetPokemonBySlotIndex(dto->parties[0], slot);
        int effect = ArenaRewards_ItemEffect(mon);
        if (playerParticipants & (1u << slot)) {
            if (effect == HOLD_EFFECT_MONEY_UP) {
                sRewards.moneyMultiplier = 2;
            }
        }
        if (!Pokemon_GetValue(mon, MON_DATA_SPECIES, NULL)
            || Pokemon_GetValue(mon, MON_DATA_IS_EGG, NULL)
            || !Pokemon_GetValue(mon, MON_DATA_HP, NULL)) {
            continue;
        }
        if (playerParticipants & (1u << slot)) {
            participants++;
        }
        if (effect == HOLD_EFFECT_EXP_SHARE) {
            shares++;
        }
    }
    baseExp = SpeciesData_GetSpeciesValue(Pokemon_GetValue(foe, MON_DATA_SPECIES, NULL), SPECIES_DATA_BASE_EXP_REWARD);
    baseExp = baseExp * Pokemon_GetValue(foe, MON_DATA_LEVEL, NULL) / 7;
    gainedExp = participants ? (shares ? baseExp / 2 : baseExp) / participants : 0;
    if (participants && gainedExp == 0) {
        gainedExp = 1;
    }
    sharedExp = shares ? (baseExp / 2) / shares : 0;
    if (shares && sharedExp == 0) {
        sharedExp = 1;
    }

    for (slot = 0; slot < count; slot++) {
        Pokemon *mon = Party_GetPokemonBySlotIndex(dto->parties[0], slot);
        int effect = ArenaRewards_ItemEffect(mon);
        u32 totalExp = (playerParticipants & (1u << slot)) ? gainedExp : 0;
        u32 exp;
        if (!Pokemon_GetValue(mon, MON_DATA_HP, NULL)
            || Pokemon_GetValue(mon, MON_DATA_IS_EGG, NULL)
            || Pokemon_GetValue(mon, MON_DATA_LEVEL, NULL) == MAX_POKEMON_LEVEL) {
            continue;
        }
        if (effect == HOLD_EFFECT_EXP_SHARE) {
            totalExp += sharedExp;
        }
        if (totalExp == 0) {
            continue;
        }
        if (effect == HOLD_EFFECT_EXP_UP) {
            totalExp = totalExp * 150 / 100;
        }
        if (dto->battleType & BATTLE_TYPE_TRAINER) {
            totalExp = totalExp * 150 / 100;
        }
        if (!ArenaRewards_IsOT(dto, mon)) {
            totalExp = totalExp * (Pokemon_GetValue(mon, MON_DATA_LANGUAGE, NULL) != gGameLanguage ? 170 : 150) / 100;
        }
        exp = Pokemon_GetValue(mon, MON_DATA_EXPERIENCE, NULL) + totalExp;
        Pokemon_SetValue(mon, MON_DATA_EXPERIENCE, &exp);
        ArenaRewards_GiveEVs(dto->parties[0], slot, foe);

        while (Pokemon_ShouldLevelUp(mon)) {
            int index = 0;
            u16 move;
            u16 result;
            Pokemon_UpdateFriendship(mon, FRIENDSHIP_EVENT_LEVEL_UP, dto->mapHeaderID);
            Pokemon_CalcStats(mon);
            dto->leveledUpMonsMask |= 1u << slot;
            while ((result = Pokemon_LevelUpMove(mon, &index, &move)) != LEARNSET_NO_MOVE_TO_LEARN) {
                if (result == LEARNSET_ALL_SLOTS_FILLED && sRewards.pendingCount < ARENA_PENDING_MOVES) {
                    ArenaLearnMove *pending = &sRewards.pending[sRewards.pendingCount++];
                    pending->partySlot = slot;
                    pending->level = Pokemon_GetValue(mon, MON_DATA_LEVEL, NULL);
                    pending->move = move;
                }
            }
        }
    }
    if (dto->records) {
        GameRecords_IncrementRecordValue(dto->records, RECORD_FAINTED_ENEMY_MON);
    }
}

static u32 ArenaRewards_Prize(FieldBattleDTO *dto, int owner)
{
    Party *party = dto->parties[owner];
    int count = Party_GetCurrentCount(party);
    int trainerClass = dto->trainer[owner].header.trainerType;
    u32 prize;
    if (!count || trainerClass < 0 || trainerClass >= (int)sizeof(sTrainerClassPrizeMul)) {
        return 0;
    }
    prize = Pokemon_GetValue(Party_GetPokemonBySlotIndex(party, count - 1), MON_DATA_LEVEL, NULL)
        * 4 * sRewards.moneyMultiplier * sTrainerClassPrizeMul[trainerClass];
    if ((dto->battleType & BATTLE_TYPE_DOUBLES)
        && !(dto->battleType & BATTLE_TYPE_TAG)
        && dto->battleType != BATTLE_TYPE_TRAINER_WITH_AI_PARTNER) {
        prize *= 2;
    }
    return prize;
}

void ArenaRewards_Finalize(FieldBattleDTO *dto, int result)
{
    if (dto != sRewards.dto || sRewards.finalized || result < BATTLE_RESULT_WIN || result > BATTLE_RESULT_ENEMY_FLED) {
        return;
    }
    sRewards.finalized = TRUE;
    dto->resultMask = result;
    if (result == BATTLE_RESULT_WIN && (dto->battleType & BATTLE_TYPE_TRAINER)) {
        u32 prize = ArenaRewards_Prize(dto, 1);
        if ((dto->battleType & BATTLE_TYPE_TAG) || dto->battleType == BATTLE_TYPE_TRAINER_WITH_AI_PARTNER) {
            prize += ArenaRewards_Prize(dto, 3);
        }
        TrainerInfo_GiveMoney(dto->trainerInfo[0], prize);
    } else if (result == BATTLE_RESULT_LOSE || result == BATTLE_RESULT_DRAW) {
        static const u8 badgeMul[] = { 2, 4, 6, 9, 12, 16, 20, 25, 30 };
        int badge = TrainerInfo_BadgeCount(dto->trainerInfo[0]);
        int maxLevel = 1;
        int slot;
        if (badge > 8) {
            badge = 8;
        }
        for (slot = 0; slot < Party_GetCurrentCount(dto->parties[0]); slot++) {
            Pokemon *mon = Party_GetPokemonBySlotIndex(dto->parties[0], slot);
            int level;
            if (!Pokemon_GetValue(mon, MON_DATA_SPECIES, NULL) || Pokemon_GetValue(mon, MON_DATA_IS_EGG, NULL)) {
                continue;
            }
            level = Pokemon_GetValue(mon, MON_DATA_LEVEL, NULL);
            if (level > maxLevel) {
                maxLevel = level;
            }
        }
        TrainerInfo_TakeMoney(dto->trainerInfo[0], maxLevel * 4 * badgeMul[badge]);
    }
    if (dto->captureAttempt && !sRewards.caught && Party_GetCurrentCount(dto->parties[1])) {
        CaptureAttempt_Init(dto->captureAttempt, Party_GetPokemonBySlotIndex(dto->parties[1], 0), result, sRewards.ballsThrown, HEAP_ID_BATTLE);
    }
    /* Encounter's UpdateGameRecords owns victory trainer scores and story flags. */
}

int ArenaRewards_PendingMoveCount(void)
{
    return sRewards.pendingCount;
}

BOOL ArenaRewards_PendingMove(int index, ArenaLearnMove *out)
{
    if (out == NULL || index < 0 || index >= sRewards.pendingCount) {
        return FALSE;
    }
    *out = sRewards.pending[index];
    return TRUE;
}

BOOL ArenaRewards_ResolveMove(FieldBattleDTO *dto, int index, int replaceSlot)
{
    ArenaLearnMove *pending;
    if (dto != sRewards.dto || index < 0 || index >= sRewards.pendingCount || replaceSlot < -1 || replaceSlot >= LEARNED_MOVES_MAX) {
        return FALSE;
    }
    pending = &sRewards.pending[index];
    if (replaceSlot >= 0) {
        Pokemon *mon = Party_GetPokemonBySlotIndex(dto->parties[0], pending->partySlot);
        Pokemon_ResetMoveSlot(mon, pending->move, replaceSlot);
    }
    sRewards.pendingCount--;
    memmove(pending, pending + 1, (sRewards.pendingCount - index) * sizeof(*pending));
    return TRUE;
}

static BOOL ArenaRewards_HasCapacity(FieldBattleDTO *dto)
{
    return Party_GetCurrentCount(dto->parties[0]) < Party_GetCapacity(dto->parties[0])
        || (dto->pcBoxes && PCBoxes_FirstEmptyBox(dto->pcBoxes) < MAX_PC_BOXES);
}

BOOL ArenaRewards_CanThrow(FieldBattleDTO *dto)
{
    int owner;
    int slot;
    int living = 0;
    if (dto != sRewards.dto || sRewards.finalized || sRewards.caught
        || (dto->battleType & (BATTLE_TYPE_TRAINER | BATTLE_TYPE_NO_EXPERIENCE | BATTLE_TYPE_CATCH_TUTORIAL))
        || !dto->bag || !ArenaRewards_HasCapacity(dto)
        || Bag_GetItemQuantity(dto->bag, ITEM_POKE_BALL, HEAP_ID_BATTLE) == 0) {
        return FALSE;
    }
    for (owner = 1; owner < MAX_BATTLERS; owner += 2) {
        for (slot = 0; slot < Party_GetCurrentCount(dto->parties[owner]); slot++) {
            if (Pokemon_GetValue(Party_GetPokemonBySlotIndex(dto->parties[owner], slot), MON_DATA_HP, NULL)) {
                living++;
            }
        }
    }
    return living == 1;
}

BOOL ArenaRewards_ConsumeBall(FieldBattleDTO *dto, int ball)
{
    if (ball != ITEM_POKE_BALL || !ArenaRewards_CanThrow(dto)
        || !Bag_TryRemoveItem(dto->bag, ball, 1, HEAP_ID_BATTLE)) {
        return FALSE;
    }
    if (sRewards.ballsThrown != 0xFFFF) {
        sRewards.ballsThrown++;
    }
    sRewards.paidBall = ball;
    return TRUE;
}

static u32 ArenaRewards_ISqrt(u32 value)
{
    u32 result = 0;
    u32 bit = 1u << 30;
    while (bit > value) {
        bit >>= 2;
    }
    while (bit) {
        if (value >= result + bit) {
            value -= result + bit;
            result = (result >> 1) + bit;
        } else {
            result >>= 1;
        }
        bit >>= 2;
    }
    return result;
}

int ArenaRewards_CatchShakes(FieldBattleDTO *dto, int enemyOwner, int partySlot, int ball, u32 *rngState)
{
    Pokemon *mon;
    u32 hp;
    u32 maxHP;
    u32 status;
    u32 rate;
    int shakes;
    if (dto != sRewards.dto || ball != ITEM_POKE_BALL || !rngState || (enemyOwner & 1) == 0
        || !ArenaRewards_ValidMon(dto, enemyOwner, partySlot)) {
        return 0;
    }
    mon = Party_GetPokemonBySlotIndex(dto->parties[enemyOwner], partySlot);
    hp = Pokemon_GetValue(mon, MON_DATA_HP, NULL);
    maxHP = Pokemon_GetValue(mon, MON_DATA_MAX_HP, NULL);
    if (!hp || !maxHP) {
        return 0;
    }
    rate = SpeciesData_GetSpeciesValue(Pokemon_GetValue(mon, MON_DATA_SPECIES, NULL), SPECIES_DATA_CATCH_RATE);
    rate = rate * (maxHP * 3 - hp * 2) / (maxHP * 3);
    status = Pokemon_GetValue(mon, MON_DATA_STATUS, NULL);
    if (status & (MON_CONDITION_SLEEP | MON_CONDITION_FREEZE)) {
        rate *= 2;
    }
    if (status & (MON_CONDITION_POISON | MON_CONDITION_BURN | MON_CONDITION_PARALYSIS | MON_CONDITION_TOXIC)) {
        rate = rate * 15 / 10;
    }
    if (rate >= 255) {
        return 4;
    }
    if (!rate) {
        return 0;
    }
    rate = (0xFFFFu << 4) / ArenaRewards_ISqrt(ArenaRewards_ISqrt((0xFFu << 16) / rate));
    for (shakes = 0; shakes < 4; shakes++) {
        *rngState = *rngState * 0x41C64E6Du + 0x6073;
        if ((*rngState >> 16) >= rate) {
            break;
        }
    }
    return shakes;
}

BOOL ArenaRewards_Catch(FieldBattleDTO *dto, int enemyOwner, int partySlot, int ball)
{
    Pokemon *mon;
    int species;
    int firstBox;
    int slot;
    if (dto != sRewards.dto || sRewards.finalized || sRewards.caught || sRewards.paidBall != ball
        || ball != ITEM_POKE_BALL || (enemyOwner & 1) == 0
        || (dto->battleType & BATTLE_TYPE_TRAINER)
        || !ArenaRewards_ValidMon(dto, enemyOwner, partySlot) || !ArenaRewards_HasCapacity(dto)) {
        return FALSE;
    }
    mon = Party_GetPokemonBySlotIndex(dto->parties[enemyOwner], partySlot);
    if (Pokemon_GetValue(mon, MON_DATA_HP, NULL) == 0) {
        return FALSE;
    }
    Pokemon_SetCatchData(mon, dto->trainerInfo[0], ball, dto->mapHeaderID, dto->terrain, HEAP_ID_BATTLE);
    species = Pokemon_GetValue(mon, MON_DATA_SPECIES, NULL);
    if (Party_GetCurrentCount(dto->parties[0]) < Party_GetCapacity(dto->parties[0])) {
        if (!Party_AddPokemon(dto->parties[0], mon)) {
            return FALSE;
        }
    } else {
        firstBox = PCBoxes_FirstEmptyBox(dto->pcBoxes);
        for (slot = 0; slot < LEARNED_MOVES_MAX; slot++) {
            int pp = Pokemon_GetValue(mon, MON_DATA_MOVE1_MAX_PP + slot, NULL);
            Pokemon_SetValue(mon, MON_DATA_MOVE1_PP + slot, &pp);
        }
        Pokemon_SetGiratinaFormByHeldItem(mon);
        if (!PCBoxes_TryStoreBoxMonInBox(dto->pcBoxes, firstBox, Pokemon_GetBoxPokemon(mon))) {
            return FALSE;
        }
        PCBoxes_SetCurrentBox(dto->pcBoxes, firstBox);
    }
    if (dto->records) {
        GameRecords_IncrementTrainerScoreOnCatch(dto->records, dto->pokedex, species);
        GameRecords_IncrementRecordValue(dto->records, RECORD_CAUGHT_POKEMON);
    }
    Pokedex_Capture(dto->pokedex, mon);
    if (dto->poketch) {
        Poketch_PokemonHistoryEnqueue(dto->poketch, Pokemon_GetBoxPokemon(mon));
    }
    dto->caughtBattlerIdx = enemyOwner;
    dto->resultMask = BATTLE_RESULT_CAPTURED_MON;
    if (dto->captureAttempt) {
        CaptureAttempt_Init(dto->captureAttempt, mon, BATTLE_RESULT_CAPTURED_MON, sRewards.ballsThrown, HEAP_ID_BATTLE);
    }
    /* Native field journal reads source-party slot 0 after the app exits. */
    if (partySlot != 0) {
        Party_SwapSlots(dto->parties[enemyOwner], 0, partySlot);
    }
    sRewards.caught = TRUE;
    sRewards.paidBall = 0;
    return TRUE;
}
