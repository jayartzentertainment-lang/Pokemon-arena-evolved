from pathlib import Path
from PIL import Image
import numpy as np
import argparse,struct,json,hashlib,statistics,math
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser(description='Compile pinned eight-direction sprites into bounded native tile dictionaries.')
parser.add_argument('--source',type=Path,default=ROOT/'res/arena/gen4/source')
parser.add_argument('--cache-limit',type=int,default=160*1024)
parser.add_argument('--pack-name',default='gen4.pack')
args=parser.parse_args();P=args.source
assert 0<args.cache_limit<=160*1024
manifest=json.loads((P/'download-manifest.json').read_text());pack=bytearray();entries=[];errors=[];known={}
def compile_one(species,minimum_factor):
  dex=species['dex'];d=P/f'{dex:04}'
  unique_images={a['actual']:Image.open(d/(a['actual']+'-Anim.png')).convert('RGBA') for a in species['animations']}
  originals=[]
  for a in species['animations']:
   im=unique_images[a['actual']];w,h=a['width'],a['height'];assert im.size==(w*len(a['durations']),h*8),('Not eight genuine source directions',im.size)
   for direction in range(8):
    for f in range(len(a['durations'])):
     originals.append(im.crop((f*w,direction*h,(f+1)*w,(direction+1)*h)))
  factor=0
  for candidate in range(minimum_factor,5):
   frames=[im if candidate==1 else im.resize((math.ceil(im.width/candidate),math.ceil(im.height/candidate)),Image.Resampling.NEAREST) for im in originals]
   bounds=[im.getchannel('A').getbbox() for im in frames];assert all(bounds)
   left=min(b[0]-im.width//2 for b,im in zip(bounds,frames));right=max(b[2]-im.width//2 for b,im in zip(bounds,frames));top=min(b[1]-im.height//2 for b,im in zip(bounds,frames));bottom=max(b[3]-im.height//2 for b,im in zip(bounds,frames))
   if all(b[2]-b[0]<=64 and b[3]-b[1]<=64 for b in bounds):
    dx=max(0,-32-left)-max(0,right-32) if right-left<=64 else 0
    dy=max(0,-32-top)-max(0,bottom-32) if bottom-top<=64 else 0
    factor=candidate;break
  assert factor,('Source registration exceeds bounded canvas',left,top,right,bottom)
  palette=[]
  for im in frames:
   rgba=np.asarray(im,dtype=np.uint16);alpha=rgba[:,:,3];assert np.all((alpha==0)|(alpha==255)),'Partial alpha requires art review'
   color=(rgba[:,:,0]>>3)|((rgba[:,:,1]>>3)<<5)|((rgba[:,:,2]>>3)<<10)
   for c in np.unique(color[alpha!=0]).tolist():
    if c not in palette:palette.append(c)
  assert len(palette)<=15,('More than15 opaque DS colors',len(palette))
  lookup=np.zeros(32768,dtype=np.uint8)
  for ix,c in enumerate(palette,1):lookup[c]=ix
  pal=[0]+palette+[0]*(15-len(palette));frame_index=0;anims=[];ranges=set()
  for a in species['animations']:
   tiles=[];indices={};maps=[];grounds=[];translations=[]
   for direction in range(8):
    bottoms=[]
    for f in range(len(a['durations'])):
     im=frames[frame_index];bound=bounds[frame_index];frame_index+=1;left,top,right,bottom=bound;ox=32-im.width//2+dx;oy=32-im.height//2+dy
     tx=max(0,-left-ox)-max(0,right+ox-64);ty=max(0,-top-oy)-max(0,bottom+oy-64)
     ox+=tx;oy+=ty
     if tx or ty:translations.append([direction,f,tx,ty])
     assert 0<=left+ox<right+ox<=64 and 0<=top+oy<bottom+oy<=64
     rgba=np.asarray(im,dtype=np.uint16);alpha=rgba[:,:,3];colors=(rgba[:,:,0]>>3)|((rgba[:,:,1]>>3)<<5)|((rgba[:,:,2]>>3)<<10);pixels=np.where(alpha!=0,lookup[colors],0).astype(np.uint8);canvas=np.zeros((64,64),dtype=np.uint8);canvas[top+oy:bottom+oy,left+ox:right+ox]=pixels[top:bottom,left:right]
     assert np.count_nonzero(canvas)==np.count_nonzero(pixels),'Opaque pixels lost during registration'
     cells=canvas.reshape(8,8,8,8).transpose(0,2,1,3);packed=(cells[:,:,:,::2]|(cells[:,:,:,1::2]<<4)).reshape(64,32)
     for tile in packed:
      raw=tile.tobytes()
      if raw not in indices:indices[raw]=len(tiles);tiles.append(raw)
      maps.append(indices[raw])
     bottoms.append(bottom+oy-32)
    grounds.append(int(statistics.median(bottoms)))
   blob=struct.pack('<II',8+len(maps)*2,len(tiles))+struct.pack('<%dH'%len(maps),*maps)+b''.join(tiles);digest=hashlib.sha256(blob).hexdigest()
   if digest not in known:known[digest]=(len(pack),len(blob));pack.extend(blob)
   off,size=known[digest];ranges.add((off,size));anims.append(dict(name=a['pose'],source_animation=a['actual'],offset=off,size=size,frames=len(a['durations']),durations=a['durations'],total_ticks=sum(a['durations']),hit_tick=sum(a['durations'][:a['hit_frame']]),ground=grounds,edge_registration_translations=translations,sha256=digest))
  cache=sum(s for o,s in ranges);assert cache<=args.cache_limit,('Pose cache exceeds configured limit',cache,args.cache_limit)
  return dict(dex=dex,species=species['species'],palette=pal,animations=anims,cache_bytes=cache,source_integer_reduction=factor,registration_offset=[dx,dy],registration_note='Common integer nearest-neighbour reduction for every pose/direction; minimal recorded edge translations retain all body pixels within64px cells while real-time controller provides world displacement; source animations/timings retained',credits=species['credits'],xml_sha256=species['xml_sha256'],source_files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()})
for species in manifest['species']:
 dex=species['dex'];error=None
 for minimum_factor in (1,2,3):
  before=len(pack);before_known=dict(known)
  try:
   entry=compile_one(species,minimum_factor);entries.append(entry);error=None;break
  except Exception as e:
   del pack[before:];known.clear();known.update(before_known);error=str(e)
   if 'Pose cache exceeds configured limit' not in error:break
 if error:errors.append(dict(dex=dex,error=error))
 print(json.dumps(dict(dex=dex,success=len(entries),errors=len(errors))),flush=True)
out=dict(cache_limit_bytes=args.cache_limit,repo=manifest['repo'],commit=manifest['commit'],source_base=manifest['source_base'],pack_sha256=hashlib.sha256(pack).hexdigest(),pack_bytes=len(pack),species=entries,errors=manifest['errors']+errors,license='CC BY-NC4.0; source credits retained; Nintendo/Chunsoft original rights remain',license_sha256=hashlib.sha256((P/'LICENSE.md').read_bytes()).hexdigest())
(P.parent/args.pack_name).write_bytes(pack);(P.parent/'manifest.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='species'},indent=2))
