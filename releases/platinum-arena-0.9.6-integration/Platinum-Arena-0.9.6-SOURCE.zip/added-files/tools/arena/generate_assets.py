#!/usr/bin/env python3
"""Convert accepted Arena art to native Platinum tiles; preserve directional data.

Run from any directory with --arena pointing to the accepted ds directory.
The native front/back files are explicit still-image fallbacks, not directional
animations. Output is fully staged; ROM builds do not require the import source.
"""
import argparse, json, re, struct, hashlib
from pathlib import Path
from PIL import Image
P=Path(__file__).resolve().parents[2]
a=argparse.ArgumentParser();a.add_argument('--arena',type=Path,default=Path('/workspace/Pokemon-arena-evolved/ds'));a.add_argument('--species-only',action='store_true',help='Preserve independently edited effects and background assets');args=a.parse_args();A=args.arena
out=P/'res/arena';out.mkdir(parents=True,exist_ok=True)
source=(A/'source/assets_data.c').read_text();pack=bytearray((A/'assets/assets.pack').read_bytes())
# Existing 187 species retain their palette, dictionary maps, poses and timings.
blocks=re.findall(r'    \{"[^\n]+\n(?:        [^\n]+\n){5}    \}\}',source)
assert len(blocks)==386,len(blocks)
styles=list(map(int,re.search(r'asset_species_animation_style\[\] = \{([^}]+)',source)[1].split(',')))
# The accepted Arena roster stores directional species first, followed by the
# remaining Emerald species. Its array index is deliberately NOT a Dex ID.
# Resolve both records and style through the ID carried by each record before
# constructing Platinum's direct Dex-indexed table.
assert len(styles)==len(blocks)
accepted={}
for block,style in zip(blocks,styles):
    match=re.match(r'\s*\{"([^"]+)",(\d+),',block)
    assert match,block[:80]
    name,dex=match[1],int(match[2])
    assert dex not in accepted,dex
    accepted[dex]=(name,block,style)
assert set(accepted)==set(range(1,387))
blocks=[];styles=[]
names=(P/'generated/species.txt').read_text().splitlines()[1:494]
static_time='static const uint8_t arena_static_time[] = {1};\n'
body_extents={}
metadata=[];form_entries=[]
# Pinned extensions contain only species absent from the original directional
# roster. Preserve all accepted original records and the existing Gen IV pack.
# Reproducible ROM builds consume staged bytes without network requests.
extensions={};extra_times=[];extension_manifests=[];source_reductions={}
for directory,pack_name in [('gen4','gen4.pack'),('directional','directional.pack')]:
    extension_path=out/directory/'manifest.json'
    if not extension_path.exists():continue
    extension=json.loads(extension_path.read_text())
    extension_pack=(extension_path.parent/pack_name).read_bytes()
    assert hashlib.sha256(extension_pack).hexdigest()==extension['pack_sha256']
    extension_base=len(pack);pack.extend(extension_pack)
    extension_manifests.append(extension)
    for entry in extension['species']:
        dex=entry['dex'];assert 1<=dex<=493 and dex not in extensions
        assert dex not in accepted or not accepted[dex][2],('Cannot replace supplied directional artwork',dex)
        source_reductions[dex]=entry['source_integer_reduction']
        animations=[]
        for slot,anim in enumerate(entry['animations']):
            key='arena_%s_%04d_%d'%(directory,dex,slot)
            extra_times.append('static const uint8_t %s[]={%s};\n'%(key,','.join(map(str,anim['durations']))))
            animations.append('{%du,%du,%du,%du,%du,%s,{%s}}'%(extension_base+anim['offset'],anim['size'],anim['frames'],anim['total_ticks'],anim['hit_tick'],key,','.join(map(str,anim['ground']))))
        extensions[dex]='    {"%s",%d,{%s},0,0,0,0,0,0,0,0,{%s}}'%(entry['species'],dex,','.join('0x%04x'%c for c in entry['palette']),','.join(animations))

def rgb15(c):return (c[0]>>3)|((c[1]>>3)<<5)|((c[2]>>3)<<10)
def make_still(dex,name,front,back,palette_path=None):
    # Preserve indexed colors and index-zero transparency, fit authentic 80px
    # art into the accepted 64px canvas with nearest-neighbour sampling.
    ims=[]
    for path in [front,back]:
        im=Image.open(path);im=im.crop((0,0,80,80)).resize((64,64),Image.Resampling.NEAREST);ims.append(im)
    colors=ims[0].getpalette();pal=[rgb15(colors[i*3:i*3+3]) for i in range(16)]
    # Native source indices share normal.pal; front/back PNG palette may differ
    # but art indices are canonically aligned by the decomp resource pipeline.
    if palette_path and palette_path.exists():
        words=palette_path.read_text().splitlines()
        trip=[tuple(map(int,w.split())) for w in words if re.fullmatch(r'\d+ \d+ \d+',w.strip())]
        if len(trip)>=16:pal=[rgb15(c) for c in trip[:16]]
    tiles=[];indices={};maps=[];grounds=[]
    for direction in range(8):
        im=ims[1 if direction in (3,4,5) else 0];pixels=list(im.getdata());tilemap=[]
        ground=max((y for y in range(64) if any(pixels[y*64+x] for x in range(64))),default=32)-32;grounds.append(ground)
        for ty in range(8):
            for tx in range(8):
                tile=bytes(pixels[(ty*8+y)*64+tx*8+x] | (pixels[(ty*8+y)*64+tx*8+x+1]<<4) for y in range(8) for x in range(0,8,2))
                if tile not in indices:indices[tile]=len(tiles);tiles.append(tile)
                tilemap.append(indices[tile])
        maps.extend(tilemap)
    blob=struct.pack('<II',8+1024,len(tiles))+struct.pack('<512H',*maps)+b''.join(tiles)
    offset=len(pack);pack.extend(blob)
    p=','.join('0x%04x'%c for c in pal);g=','.join(map(str,grounds))
    anim='{%du,%du,1u,1u,0u,arena_static_time,{%s}}'%(offset,len(blob),g)
    bounds=[im.getbbox() for im in ims]
    extent=max(max(b[2]-b[0],b[3]-b[1]) for b in bounds)
    assert 1<=extent<=64,(dex,name,bounds)
    body_extents[offset]=extent
    metadata.append(dict(dex=dex,name=name,bytes=len(blob),style='Platinum front/back still',body_extent=extent))
    return '{"%s",%d,{%s},0,0,0,0,0,0,0,0,{%s}}'%(name,dex,p,','.join([anim]*5))
for dex,s in enumerate(names,1):
    folder=s.removeprefix('SPECIES_').lower();d=P/'res/pokemon'/folder
    if dex in extensions:
        blocks.append(extensions[dex]);styles.append(1)
        continue
    if dex in accepted and accepted[dex][2]:
        name,block,style=accepted[dex]
        assert name==s.removeprefix('SPECIES_'),(dex,name,s)
        blocks.append(block);styles.append(style)
        continue
    front=d/'male_front.png';back=d/'male_back.png';pal=d/'normal.pal'
    if not front.exists():front=d/'female_front.png';back=d/'female_back.png'
    if not front.exists():front=d/'forms/base/front.png';back=d/'forms/base/back.png';pal=d/'forms/base/normal.pal'
    b=make_still(dex,folder.upper(),front,back,pal)
    blocks.append('    '+b);styles.append(0)
# Explicit alternate forms use genuine native stills, never unrelated species.
formmap={201:list('bcdefghijklmnopqrstuvwxyz')+['exc','que'],351:['sunny','rainy','snowy'],386:['attack','defense','speed'],412:['sandy','trash'],413:['sandy','trash'],421:['sunny'],422:['east_sea'],423:['east_sea'],479:['heat','wash','frost','fan','mow'],487:['origin'],492:['sky'],493:['fighting','flying','poison','ground','rock','bug','ghost','steel','mystery','fire','water','grass','electric','psychic','ice','dragon','dark']}
formdefs=[]
for dex,forms in formmap.items():
    base=P/'res/pokemon'/names[dex-1].removeprefix('SPECIES_').lower()/'forms'
    for form,name in enumerate(forms,1):
        d=base/name
        if not (d/'front.png').exists():continue
        b=make_still(dex,names[dex-1].removeprefix('SPECIES_'),d/'front.png',d/'back.png',d/'normal.pal' if (d/'normal.pal').exists() else base/'base/normal.pal')
        formdefs.append('static const AssetSpecies form_%d_%d = %s;'%(dex,form,b));form_entries.append((dex,form))
times=source[source.index('static const uint8_t'):source.index('const AssetSpecies asset_species[]')]
src='/* Generated by tools/arena/generate_assets.py. */\n#include "arena/assets.h"\n'+times+''.join(extra_times)+static_time+'\nconst AssetSpecies asset_species[]={\n'+',\n'.join(blocks)+'\n};\n'
src+='const unsigned asset_species_count=493u;\nconst uint32_t asset_pack_size=%du;\n'%len(pack)
src+='const uint8_t asset_species_animation_style[]={'+','.join(map(str,styles))+'};\n'+'\n'.join(formdefs)+'\n'
src+='const AssetSpecies *ArenaAssets_FindSpecies(unsigned dex,unsigned form) {\n'
for dex,form in form_entries:src+='if(dex==%d && form==%d) return &form_%d_%d;\n'%(dex,form,dex,form)
src+='return dex>=1&&dex<=493?&asset_species[dex-1]:0;\n}\n'
# Native battle portraits fill most of their 64px canvas, whereas the supplied
# directional sprites generally occupy 20..40px. Measure the authentic still
# body once during import; runtime scales only from this resident metadata.
def still_extent(block):
    offset=int(re.search(r'\{(\d+)u,\d+u,\d+u,\d+u,\d+u,',block)[1])
    return body_extents[offset]
canonical_extents=[0 if style else still_extent(block) for block,style in zip(blocks,styles)]
src+='static const uint8_t arena_native_body_extent[]={'+','.join(map(str,canonical_extents))+'};\n'
reductions=[source_reductions.get(dex,1) for dex in range(1,494)]
src+='static const uint8_t arena_directional_reduction[]={'+','.join(map(str,reductions))+'};\n'
src+='unsigned ArenaAssets_BodyExtent(unsigned dex,unsigned form) {\n'
for (dex,form),definition in zip(form_entries,formdefs):
    src+='if(dex==%d && form==%d) return %du;\n'%(dex,form,still_extent(definition))
src+='return dex>=1&&dex<=493?arena_native_body_extent[dex-1]:0;\n}\n'
src+='unsigned ArenaAssets_DisplaySize(unsigned dex,unsigned form,unsigned nominal) {\nunsigned extent=ArenaAssets_BodyExtent(dex,form);\nunsigned reduction=dex>=1&&dex<=493?arena_directional_reduction[dex-1]:1;\nunsigned size=extent?(nominal*30+extent/2)/extent:nominal*reduction;\nreturn size<24?24:size>128?128:size;\n}\n'

(P/'src/arena/assets_data.c').write_text(src);(out/'arena.pack').write_bytes(pack)
# Convert the accepted 384x256 arena into a bounded 4bpp text BG. Global
# quantization/dedup avoids exceeding the DS text BG's 1024 character limit.
bgsource=(A/'source/battle_backgrounds.c').read_text();vals=[int(x,16) for x in re.findall(r'0x[0-9a-fA-F]+',bgsource)];assert len(vals)==2*384*256
directional_dex=[dex for dex in range(1,494) if styles[dex-1]]
report={'directional_species':sum(styles),'directional_dex':directional_dex,'static_canonical_species':493-sum(styles),'native_forms':form_entries,'pack_bytes':len(pack),'backgrounds':[],
        'accepted_asset_pack_sha256':hashlib.sha256((A/'assets/assets.pack').read_bytes()).hexdigest(),
        'species_order':'National Dex 1..493; imported records resolved by their explicit Dex ID',
        'directional_source':'Accepted Arena directional tile dictionaries, palettes, registration and timings preserved byte-for-byte',
        'native_body_extents':canonical_extents,'directional_source_reductions':reductions,'native_size_reference_pixels':30,
        'native_size_rule':'Scale native stills by measured opaque front/back bounds; retain species size classes without counting transparent canvas padding'}
if extension_manifests:
    report['upstream_directional_extensions']=[]
    for extension in extension_manifests:
        entry={key:extension[key] for key in ['repo','commit','source_base','pack_bytes','pack_sha256']}
        entry['species_count']=len(extension['species']);entry['dex']=[row['dex'] for row in extension['species']]
        report['upstream_directional_extensions'].append(entry)
    # Retain the original report key for older packaging tools.
    report['upstream_directional_extension']=report['upstream_directional_extensions'][0]
if args.species_only:
    previous=json.loads((out/'provenance.json').read_text())
    report['backgrounds']=previous['backgrounds']
    report['pack_sha256']=hashlib.sha256(pack).hexdigest()
    (out/'provenance.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key not in ['directional_dex','native_body_extents','directional_source_reductions']},indent=2))
    raise SystemExit(0)
for bg in range(2):
    im=Image.new('RGB',(384,256));im.putdata([((v&31)*255//31,((v>>5)&31)*255//31,((v>>10)&31)*255//31) for v in vals[bg*384*256:(bg+1)*384*256]])
    from collections import Counter
    import numpy as np
    q=im.quantize(colors=16,dither=Image.Dither.NONE);px=list(q.getdata());dic={};tiles=[];tm=[];step=1
    for ty in range(32):
        for tx in range(64):
            tile=bytes(px[(ty*8+y)*384+tx*8+x]|(px[(ty*8+y)*384+tx*8+x+1]<<4) for y in range(8) for x in range(0,8,2)) if tx<48 else bytes(32)
            if tile not in dic:dic[tile]=len(tiles);tiles.append(tile)
            tm.append(dic[tile])
    if len(tiles)>1024:
        freq=Counter(tm);selected=sorted(range(len(tiles)),key=lambda i:-freq[i])[:1024]
        kept={v:i for i,v in enumerate(selected)};colors=np.array(q.getpalette(),dtype=np.int16).reshape(-1,3)
        def unpack(b):
            v=np.frombuffer(b,dtype=np.uint8);ix=np.stack((v&15,v>>4),axis=1).reshape(-1);return colors[ix].astype(np.int16).reshape(-1)
        vectors=np.stack([unpack(tiles[i]) for i in selected])
        for i in range(len(tiles)):
            if i not in kept:
                delta=(vectors-unpack(tiles[i])).astype(np.int32);kept[i]=int(np.argmin(np.sum(delta*delta,axis=1)))
        tm=[kept[i] for i in tm];tiles=[tiles[i] for i in selected]
    rawmap=[tm[y*64+x] for block in range(2) for y in range(32) for x in range(block*32,block*32+32)]
    pal=q.getpalette();nativepal=[rgb15(pal[i*3:i*3+3]) for i in range(16)]
    data=struct.pack('<I16H2048H',len(tiles)*32,*nativepal,*rawmap)+b''.join(tiles);(out/('arena_bg%d.bin'%bg)).write_bytes(data)
    report['backgrounds'].append({'tiles':len(tiles),'pixel_step':step,'bytes':len(data)})
# Quantize the supplied props/flame/guard/spark frames separately, preserving
# transparency and use one OBJ palette for each currently displayed effect.
effects=(A/'source/effects_data.c').read_text();es=[];ep=[]
for key,count in [('asset_props',15),('asset_flame',8),('asset_guard',8),('asset_spark',1)]:
    body=effects.split('const uint16_t '+key,1)[1].split('};',1)[0];vv=[int(v,16) for v in re.findall(r'0x[0-9a-fA-F]+',body)];assert len(vv)==count*1024
    for frame in range(count):
        f=vv[frame*1024:(frame+1)*1024];im=Image.new('RGB',(32,32));im.putdata([((v&31)*255//31,((v>>5)&31)*255//31,((v>>10)&31)*255//31) for v in f]);q=im.quantize(colors=15,dither=Image.Dither.NONE);px=list(q.getdata());pal=q.getpalette();pal+= [0]*(48-len(pal));p=[0]+[rgb15(pal[i*3:i*3+3]) for i in range(15)];pix=[0 if not f[i] else px[i]+1 for i in range(1024)];tile=bytes(pix[(ty*8+y)*32+tx*8+x]|(pix[(ty*8+y)*32+tx*8+x+1]<<4) for ty in range(4) for tx in range(4) for y in range(8) for x in range(0,8,2));es.append(tile);ep.append(p)
capture=(A/'source/capture_art.c').read_text().split('= {',1)[1];cv=[int(v,0) for v in re.findall(r'0x[0-9a-fA-F]+|(?<![A-Za-z_])\b\d+\b',capture)];assert len(cv)==768
for frame in range(3):
    f=[0]*1024
    for y in range(16):
        for x in range(16):f[(y+8)*32+x+8]=cv[frame*256+y*16+x]
    colors=list(dict.fromkeys(v for v in f if v));assert len(colors)<=15
    p=[0]+[v&32767 for v in colors];p += [0]*(16-len(p));ix={v:i+1 for i,v in enumerate(colors)};pix=[ix.get(v,0) for v in f]
    es.append(bytes(pix[(ty*8+y)*32+tx*8+x]|(pix[(ty*8+y)*32+tx*8+x+1]<<4) for ty in range(4) for tx in range(4) for y in range(8) for x in range(0,8,2)));ep.append(p)
fx='/* Generated from supplied Arena artwork. */\n#include "arena/assets.h"\nconst uint8_t arena_effect_tiles[35][512]={\n'+',\n'.join('{'+','.join(map(str,x))+'}' for x in es)+'\n};\nconst uint16_t arena_effect_palettes[35][16]={\n'+',\n'.join('{'+','.join(map(str,x))+'}' for x in ep)+'\n};\n'
# Reuse the real Platinum healthbox silhouettes in the shared HUD palette.
ui_palette=[0,0x18c6,0x6318,0x2529,0x7fff,0x56b5,0x3def,0x2328,0x03ff,0x019f,0x7e60,0x7b94,0x67bb,0x4e73,0x77bd,0x7fff]
ui_rgb=[((c&31)*8,((c>>5)&31)*8,((c>>10)&31)*8) for c in ui_palette]
boxes=[]
for name in ['player_doubles','enemy']:
    im=Image.open(P/'res/graphics/battle/healthbox'/(name+'.png'));pal=im.getpalette();mapping=[0]
    for color in range(1,16):
        c=pal[color*3:color*3+3];mapping.append(min(range(1,16),key=lambda k:sum((c[j]-ui_rgb[k][j])**2 for j in range(3))))
    # Original silhouette and native accents; use the shared light text surface.
    mapping[15]=2;mapping[1]=2
    im=im.crop((0,10,128,46)).resize((120,36),Image.Resampling.NEAREST);pix=list(im.getdata());pix += [0]*(120*4)
    boxes.append(bytes(mapping[pix[(ty*8+y)*120+tx*8+x]]|(mapping[pix[(ty*8+y)*120+tx*8+x+1]]<<4) for ty in range(5) for tx in range(15) for y in range(8) for x in range(0,8,2)))
fx+='const uint8_t arena_ui_healthbox[2][2400]={\n'+',\n'.join('{'+','.join(map(str,b))+'}' for b in boxes)+'\n};\n'
(P/'src/arena/effects_data.c').write_text(fx)
report['pack_sha256']=hashlib.sha256(pack).hexdigest();(out/'provenance.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
