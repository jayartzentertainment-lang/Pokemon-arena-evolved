#!/usr/bin/env python3
"""Generate canonical Platinum metadata and conservative arena fallback actions.

All input is local source data. No battle IDs, power, PP, types or damage classes
are inferred from the previous Emerald port. The fallback actions deliberately
describe geometry only; they do not claim to reproduce every native move effect.
"""

import argparse
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / "src/arena/move_data.c"
CLASSES = {"CLASS_PHYSICAL": 0, "CLASS_SPECIAL": 1, "CLASS_STATUS": 2}
SELF_RANGES = {"RANGE_USER", "RANGE_USER_SIDE"}
SPREAD_RANGES = {"RANGE_ADJACENT_OPPONENTS", "RANGE_ALL_ADJACENT", "RANGE_ALL"}
VISUALS = {
    "TYPE_FIGHTING": ("SLAM", "CREAM"),
    "TYPE_FLYING": ("GUST", "WHITE"),
    "TYPE_POISON": ("ACID", "PURPLE"),
    "TYPE_GROUND": ("MUD", "CREAM"),
    "TYPE_ROCK": ("ROCK", "CREAM"),
    "TYPE_BUG": ("LEAF", "GREEN"),
    "TYPE_GHOST": ("SHADE", "PURPLE"),
    "TYPE_STEEL": ("STAR", "WHITE"),
    "TYPE_FIRE": ("EMBER", "CREAM"),
    "TYPE_WATER": ("WATER", "BLUE"),
    "TYPE_GRASS": ("LEAF", "GREEN"),
    "TYPE_ELECTRIC": ("STAR", "CREAM"),
    "TYPE_PSYCHIC": ("PSYCHIC", "PURPLE"),
    "TYPE_ICE": ("GUST", "BLUE"),
    "TYPE_DRAGON": ("STAR", "GREEN"),
    "TYPE_DARK": ("SHADOW", "PURPLE"),
}


def enum_values(filename, prefix):
    return {
        name: index
        for index, name in enumerate((ROOT / "generated" / filename).read_text().splitlines())
        if name.startswith(prefix)
    }


def action_profile(move_id, data):
    visual, palette = VISUALS.get(data["type"], ("STAR", "CREAM"))
    category = CLASSES[data["class"]]
    power = data["power"]
    windup = min(40, 8 + power // 8)
    recovery = min(100, 22 + power // 3)
    if move_id == 0:
        kind, speed, animation, windup, active, recovery, reach, radius, cone = (
            "NONE", 0, 0, 0, 0, 0, 0, 0, 0)
    elif category == 2:
        animation, speed, windup, active, recovery, radius = 4, 0, 16, 16, 84, 0
        if data["range"] in SELF_RANGES:
            kind, reach, cone = "SELF", 0, 1
        else:
            kind, reach, cone = "CONE", 100, 1
            active, recovery = 12, 54
            visual = "LEER"
    elif category == 0 and "MOVE_FLAG_MAKES_CONTACT" in data["flags"]:
        animation, cone = 3, 1
        if power >= 80:
            kind, speed, active, reach, radius = "RUSH", 896, 16, 72, 24
        else:
            kind, speed, active, reach, radius = "MELEE", 0, 8, 36 + min(12, power // 12), 0
        visual = "ARC" if data["type"] == "TYPE_NORMAL" else visual
    elif data["range"] in SPREAD_RANGES:
        kind, speed, animation, active, reach, radius, cone = "CONE", 0, 2, 24, 112, 14, 1
    else:
        kind, speed, animation, active, reach, radius, cone = (
            "PROJECTILE", 1024, 2, 1, 176, 10 + min(8, power // 20), 1)
    fields = [move_id, speed, "ARENA_MOVE_" + kind, animation, windup, active,
              recovery, reach, radius, "ARENA_VIS_" + visual,
              "ARENA_MOVE_" + palette, cone]
    assert all(0 <= field <= 255 for field in (animation, windup, active, recovery, reach, radius, cone))
    return "    {" + ", ".join(map(str, fields)) + "},"


def status_effect(data):
    if data["class"] != "CLASS_STATUS":
        return "NONE"
    effect = data["effect"]["type"].removeprefix("BATTLE_EFFECT_")
    if effect == "DO_NOTHING":
        return "NONE"
    if "CONFUS" in effect or effect.startswith("STATUS_"):
        return "SLOW"
    if ("HEAL" in effect and "PREVENT" not in effect) or effect in {
        "REST", "RESTORE_HALF_HP", "RESTORE_HP_EVERY_TURN", "SWALLOW",
        "CURE_PARTY_STATUS", "FAINT_FULL_RESTORE_NEXT_MON",
    }:
        return "HEAL"
    if effect.startswith(("ATK_DOWN", "SP_ATK_DOWN", "FAINT_AND_ATK")):
        return "ATTACK_DOWN"
    if effect.startswith(("DEF_DOWN", "SP_DEF_DOWN")):
        return "DEFENSE_DOWN"
    if effect.startswith("ATK_DEF_DOWN"):
        return "DEFENSE_DOWN"
    if effect.startswith(("SPEED_DOWN", "DOUBLE_SPEED")):
        return "SPEED_UP" if effect.startswith("DOUBLE_SPEED") else "SLOW"
    if effect.startswith(("SPEED_UP", "ATK_SPD_UP")):
        return "SPEED_UP"
    if effect.startswith(("ATK_UP", "SP_ATK_UP", "ATK_DEF_UP", "SP_ATK_SP_DEF_UP", "MAX_ATK", "CRIT_UP")):
        return "ATTACK_UP"
    if effect.startswith(("DEF_UP", "SP_DEF_UP", "DEF_SPD_UP")):
        return "DEFENSE_UP"
    return "GUARD" if data["range"] in SELF_RANGES else "SLOW"


def generate():
    moves = enum_values("moves.txt", "MOVE_")
    types = enum_values("pokemon_types.txt", "TYPE_")
    assert len(moves) == 468 and moves["MOVE_NONE"] == 0 and moves["MOVE_SHADOW_FORCE"] == 467
    info_rows = []
    action_rows = []
    status_rows = []
    for symbol, move_id in moves.items():
        data = json.loads((ROOT / "res/moves" / symbol[5:].lower() / "data.json").read_text())
        category = CLASSES[data["class"]]
        for value in (data["power"], data["pp"], types[data["type"]]):
            assert 0 <= value <= 255, (symbol, value)
        name = json.dumps(data["name"], ensure_ascii=True)
        info_rows.append(f'    {{{move_id}, {types[data["type"]]}, {data["power"]}, {data["pp"]}, {category}, {name}}}, /* {symbol} */')
        action_rows.append(action_profile(move_id, data) + f" /* {symbol} */")
        status_rows.append(f"    ARENA_STATUS_{status_effect(data)}, /* {symbol} */")
    return "\n".join([
        "/* Generated by tools/arena/generate_moves.py. Do not edit by hand.",
        " * Metadata: generated/moves.txt, generated/pokemon_types.txt and",
        " * each res/moves move directory's data.json. Fallbacks are generic arena geometry.",
        " */",
        '#include "arena/move_data.h"',
        "",
        "static const CombatMoveInfo sMoveInfo[ARENA_PLATINUM_MOVE_COUNT] = {",
        *info_rows,
        "};",
        "",
        "static const struct ArenaMoveProfile sFallbackProfiles[ARENA_PLATINUM_MOVE_COUNT] = {",
        *action_rows,
        "};",
        "",
        "static const uint8_t sStatusEffects[ARENA_PLATINUM_MOVE_COUNT] = {",
        *status_rows,
        "};",
        "",
        "const CombatMoveInfo *ArenaPlatinum_GetMoveInfo(uint16_t move)",
        "{",
        "    if (move == 0 || move >= ARENA_PLATINUM_MOVE_COUNT) return 0;",
        "    return &sMoveInfo[move];",
        "}",
        "",
        "uint8_t ArenaPlatinum_GetStatusEffect(uint16_t move)",
        "{",
        "    if (move == 0 || move >= ARENA_PLATINUM_MOVE_COUNT) return ARENA_STATUS_NONE;",
        "    return sStatusEffects[move];",
        "}",
        "",
        "const struct ArenaMoveProfile *ArenaPlatinum_GetFallbackProfile(uint16_t move)",
        "{",
        "    if (move == 0 || move >= ARENA_PLATINUM_MOVE_COUNT) return 0;",
        "    return &sFallbackProfiles[move];",
        "}",
        "",
    ])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="fail if generated C is stale")
    args = parser.parse_args()
    content = generate()
    if args.check:
        if not OUTPUT.exists() or OUTPUT.read_text() != content:
            raise SystemExit(f"stale generated move data: run {Path(__file__).relative_to(ROOT)}")
        print("Platinum move metadata: 468 canonical IDs verified")
    else:
        OUTPUT.parent.mkdir(parents=True, exist_ok=True)
        OUTPUT.write_text(content)
        print(f"Generated {OUTPUT.relative_to(ROOT)} (468 canonical IDs)")


if __name__ == "__main__":
    main()
