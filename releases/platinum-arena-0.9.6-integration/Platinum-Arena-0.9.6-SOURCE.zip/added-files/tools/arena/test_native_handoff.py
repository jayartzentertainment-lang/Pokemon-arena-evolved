#!/usr/bin/env python3
"""Exercise the actual native intro controller boundary with fake display I/O.

This proves no controller turn slips through either of the two native updates
in a frame and pending animation messages drain before teardown. Emulator
validation remains necessary for graphics, heap and overlay lifetime checks.
"""
import pathlib
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]


def function(source, signature):
    start = source.index(signature + "\n{")
    body = source.index("{", start)
    depth = 1
    end = body + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


source = (ROOT / "src/battle/battle_main.c").read_text()
functions = "\n\n".join(function(source, name) for name in (
    "static int BattleMain_ExecuteBattlerCommands(ApplicationManager *appMan)",
    "static BOOL BattleMain_ArenaIntroIsReady(BattleSystem *battleSys)",
))
harness = r'''
#include <assert.h>
#include <stdio.h>
#include <string.h>
typedef int BOOL;
enum { FALSE, TRUE };
enum { BATTLE_TYPE_LINK = 1, BATTLE_STATUS_RECORDING = 2 };
enum { COMM_RECIPIENT_CLIENT, COMM_RECIPIENT_SERVER };
enum { BATTLE_COMMAND_NONE, BATTLE_CONTROL_SHOW_BATTLE_MON = 3 };
typedef struct { int command; int queueBusy; } BattleContext;
typedef struct { unsigned char data[256]; } BattlerData;
typedef struct {
    int battleType, battleStatusMask, battleInitialized, maxBattlers;
    int commandIsEndWait;
    BattleContext *battleCtx;
    BattlerData *battlers[4];
    unsigned short clientRead, clientWrite, serverRead, serverWrite;
} BattleSystem;
typedef struct { BattleSystem *data; } ApplicationManager;
static BOOL sArenaIntroPending;
static int contextCalls, clientReceives, serverReceives, displayed;
static BattleSystem *ApplicationManager_Data(ApplicationManager *app) { return app->data; }
static BOOL BattleContext_Main(BattleSystem *sys, BattleContext *ctx)
{
    (void)sys;
    contextCalls++;
    ctx->command++;
    return FALSE;
}
static void BattleController_TryRecvLocalMessage(BattleSystem *sys, int recipient)
{
    if (recipient == COMM_RECIPIENT_CLIENT) {
        clientReceives++;
        if (sys->clientRead != sys->clientWrite) sys->clientRead++;
    } else {
        serverReceives++;
        if (sys->serverRead != sys->serverWrite) sys->serverRead++;
    }
}
static void BattleSystem_ExecuteBattlerCommand(BattleSystem *sys, BattlerData *battler)
{
    (void)sys;
    displayed++;
    battler->data[0] = BATTLE_COMMAND_NONE;
}
static BOOL BattleIO_QueueIsEmpty(BattleContext *ctx) { return !ctx->queueBusy; }
static unsigned short *BattleSystem_GetClientReadIndex(BattleSystem *sys) { return &sys->clientRead; }
static unsigned short *BattleSystem_GetClientWriteIndex(BattleSystem *sys) { return &sys->clientWrite; }
static unsigned short *BattleSystem_GetServerReadIndex(BattleSystem *sys) { return &sys->serverRead; }
static unsigned short *BattleSystem_GetServerWriteIndex(BattleSystem *sys) { return &sys->serverWrite; }
'''
tests = r'''
int main(void)
{
    BattleContext ctx = {0};
    BattlerData actors[4] = {{{0}}};
    BattleSystem sys = {0};
    ApplicationManager app = { &sys };
    int i;
    sys.battleCtx = &ctx;
    sys.battleInitialized = TRUE;
    sys.maxBattlers = 4;
    for (i = 0; i < 4; ++i) sys.battlers[i] = &actors[i];

    /* Crossing the boundary on the first half of a frame must suppress the
       second context update, while all four clients continue processing. */
    sArenaIntroPending = TRUE;
    ctx.command = BATTLE_CONTROL_SHOW_BATTLE_MON - 1;
    BattleMain_ExecuteBattlerCommands(&app);
    assert(contextCalls == 1);
    assert(ctx.command == BATTLE_CONTROL_SHOW_BATTLE_MON);
    assert(clientReceives == 2 && serverReceives == 8 && displayed == 8);
    assert(BattleMain_ArenaIntroIsReady(&sys));

    /* Keep processing outstanding background/animation acknowledgments. */
    sys.clientWrite = 3;
    sys.serverWrite = 9;
    actors[2].data[0] = 6;
    ctx.queueBusy = 1;
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    BattleMain_ExecuteBattlerCommands(&app);
    assert(contextCalls == 1);
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    BattleMain_ExecuteBattlerCommands(&app);
    assert(contextCalls == 1);
    assert(sys.clientRead == sys.clientWrite && sys.serverRead == sys.serverWrite);
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    ctx.queueBusy = 0;
    assert(BattleMain_ArenaIntroIsReady(&sys));

    actors[3].data[0] = 1;
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    actors[3].data[0] = 0;
    sys.battleInitialized = FALSE;
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    sys.battleInitialized = TRUE;
    ctx.command--;
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    ctx.command++;

    /* Unsupported native battles and the one-shot initialization fallback
       keep the original twice-per-frame controller behavior. */
    sArenaIntroPending = FALSE;
    assert(!BattleMain_ArenaIntroIsReady(&sys));
    BattleMain_ExecuteBattlerCommands(&app);
    assert(contextCalls == 3);
    assert(ctx.command == BATTLE_CONTROL_SHOW_BATTLE_MON + 2);
    puts("Native handoff controller/async-queue regressions passed");
    return 0;
}
'''
with tempfile.TemporaryDirectory(prefix="arena-native-handoff-") as tmp:
    tmp = pathlib.Path(tmp)
    (tmp / "test.c").write_text(harness + functions + tests)
    subprocess.run(["cc", "-std=c99", "-Wall", "-Wextra", "-Werror",
                    "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                    str(tmp / "test.c"), "-o", str(tmp / "test")], check=True)
    subprocess.run([str(tmp / "test")], check=True)
