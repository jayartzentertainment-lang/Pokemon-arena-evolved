#!/usr/bin/env python3
"""Convert supplied editable trainer PNG layers into the native AVC1 bank.

No image synthesis, rig replacement, automatic per-frame centering or palette
quantizer is used. The source sheets are pixel art exported at exactly 2x.
All layers of a state use the same source rectangle and transform.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import struct

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SOURCE = Path('/workspace/asset-review/arsenal-2026-10-21/pokemon-trainer-png/source/pokemon png')
COUNTS = [32, 24, 4, 7, 4, 16, 16, 12, 2, 12, 13, 32]
LAYERS = ['body', 'jeans', 'shorts', 'capris', 't-shirt', 'hoodie', 'open jacket',
          'hair 1', 'hair 2', 'hair 3', 'hair 4', 'beanie', 'fedora']
PALETTE = [(0, 0, 0), (24, 24, 32), (248, 208, 184), (216, 160, 120),
           (120, 64, 64), (112, 80, 48), (80, 48, 32), (48, 32, 24),
           (208, 80, 80), (152, 48, 56), (88, 32, 40), (88, 128, 184),
           (48, 72, 112), (112, 104, 96), (56, 56, 64), (232, 232, 248)]
FLAT_PALETTE = [c for rgb in PALETTE for c in rgb] + [0] * (768 - 48)
NEAREST = Image.Resampling.NEAREST


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def indexed(size):
    im = Image.new('P', size, 0)
    im.putpalette(FLAT_PALETTE)
    return im


def nibble(im):
    data = list(im.getdata())
    return bytes(data[i] | (data[i + 1] << 4) for i in range(0, len(data), 2))


def tiles(im, bpp=4):
    out = bytearray()
    for y in range(0, im.height, 8):
        for x in range(0, im.width, 8):
            tile = im.crop((x, y, x + 8, y + 8))
            out.extend(nibble(tile) if bpp == 4 else tile.tobytes())
    return bytes(out)


def oam80(im):
    # The six OAM rectangles in the existing native player front/back NCER.
    # Nitro's mapping64 reserves contiguous tile groups in this exact order.
    rects = [(0, 0, 64, 64), (64, 0, 80, 32), (64, 32, 80, 64),
             (0, 64, 32, 80), (32, 64, 64, 80), (64, 64, 80, 80)]
    data = b''.join(tiles(im.crop(rect)) for rect in rects)
    assert len(data) == 3200
    return data


class Converter:
    def __init__(self, source, out):
        self.source = source
        self.out = out
        self.proof = {}
        self.cleaning = {}
        self.raw = {}
        self.aliases = {}
        self.layers = {}

    def choose(self, state, category, family=None, color='black'):
        folder = self.source / state / category
        if family:
            choices = [p for p in folder.iterdir() if p.stem.lower().replace(' ', '') == family.replace(' ', '').lower()]
            assert len(choices) == 1, (folder, family, choices)
            folder = choices[0]
        if folder.is_file():
            return folder
        files = sorted(folder.rglob('*.png'))
        preferred = [p for p in files if color.lower() in p.name.lower()]
        assert preferred, (folder, color)
        return preferred[0]

    def read(self, path, role):
        key = (path, role)
        if key in self.raw:
            return self.raw[key].copy()
        self.proof[str(path.relative_to(self.source))] = {'sha256': sha(path), 'bytes': path.stat().st_size}
        source = Image.open(path).convert('RGBA')
        result = indexed(source.size)
        pixels = []
        removed = Counter()
        for r, g, b, a in source.getdata():
            if a < 128:
                pixels.append(0)
                if a:
                    removed['low_alpha_reference_or_antialias_pixels'] += 1
                continue
            rgb = (r, g, b)
            lum = (r * 3 + g * 6 + b) / 10
            if role == 'body':
                if rgb in [(248, 208, 184), (255, 213, 189)]:
                    value = 2
                elif rgb in [(216, 160, 120), (222, 164, 123), (189, 123, 98)]:
                    value = 3
                elif rgb in [(120, 64, 64), (123, 74, 90), (144, 96, 72)]:
                    value = 4
                elif max(rgb) < 48:
                    value = 1
                elif max(rgb) - min(rgb) < 32:
                    value = 15 if lum > 145 else 1
                else:
                    # The purple/blue/red editor swatches are not body pixels.
                    # Bicycle metal is neutralized into fixed white/outline.
                    value = 15 if lum > 145 else 1
            elif role == 'hair':
                if max(rgb) > 170 or max(rgb) - min(rgb) > 90:
                    value = 0
                    removed['foreign_hair_reference_colors'] += 1
                elif max(rgb) < 24:
                    value = 1
                else:
                    value = 5 if lum >= 74 else (6 if lum >= 48 else 7)
            elif role == 'leg':
                value = 1 if max(rgb) < 25 else (15 if lum > 190 else (11 if lum > 68 else 12))
            else:  # Top and hat share their independently chosen top dye.
                value = 1 if max(rgb) < 25 else (15 if lum > 180 else (8 if lum > 72 else (9 if lum > 48 else 10)))
            pixels.append(value)
        result.putdata(pixels)
        self.cleaning[str(path.relative_to(self.source))] = dict(removed)
        self.raw[key] = result.copy()
        return result

    def paths(self, state, body, front=False, back=False):
        if front or back:
            base = self.choose(state, 'base', color='light')
            haircat = 'hair'
            hairnames = ['hair ' + str(i) for i in range(1, 5)]
        else:
            base = self.source / state / 'bases mf' / (('f' if body else 'm') + ' base light.png')
            haircat = 'hair'
            hairnames = [('girl ' if body else 'boy ') + str(i) for i in range(1, 5)]
        paths = [(base, 'body')]
        if back:
            paths += [(None, 'leg')] * 3  # This source is explicitly waist-up.
        else:
            names = ['jeans', 'shorts', 'capri' if front else 'capris']
            paths += [(self.choose(state, 'bottoms', name), 'leg') for name in names]
        for name in ['t-shirt', 'hoodie', 'open jacket']:
            paths.append((self.choose(state, 'clothing' if back else 'tops', name,
                                      'red' if name == 'open jacket' else 'black'), 'top'))
        paths += [(self.choose(state, haircat, name), 'hair') for name in hairnames]
        paths += [(self.choose(state, 'hat' if back else 'hats', 'beanie'), 'hat'),
                  (self.choose(state, 'hat' if back else 'hats', 'fedora'), 'hat')]
        assert len(paths) == 13
        return paths

    def field(self, body, action):
        state = 'overworld ' + action
        banks = []
        for layer, (path, role) in enumerate(self.paths(state, body)):
            sheet = self.read(path, role)
            assert sheet.size == (256, 256), path
            frames = []
            for direction, row in enumerate([3, 0, 1, 2]):
                for col in range(4):
                    frame = sheet.crop((col * 64, row * 64, col * 64 + 64, row * 64 + 64)).resize((32, 32), NEAREST)
                    # Source base feet are bare. Give those same authored pixels
                    # an independent shoe dye; never add a new silhouette.
                    if layer == 0:
                        pix = list(frame.getdata())
                        foot_y = 26 if action == 'bike' else (28 if action == 'walk' else (28 if direction else 27))
                        for y in range(foot_y, 32):
                            for x in range(32):
                                v = pix[y * 32 + x]
                                if v in [2, 3, 4]:
                                    pix[y * 32 + x] = 13 if v == 2 else 14
                        frame.putdata(pix)
                    frames.append(frame)
            banks.append(frames)
        return banks

    def native_alias_groups(self, body, state):
        key = (body, state)
        if key in self.aliases:
            return self.aliases[key]
        stem = ['player_{s}', 'player_{s}_bike', 'player_{s}_holding_pokeball',
                'player_{s}_sprayduck', 'player_{s}_surf', 'player_{s}_contest',
                'player_{s}_fishing', 'player_{s}_poketch', 'player_{s}_save',
                'player_{s}_pokecenter_heal', 'player_{s}_vs_seeker', 'dp_player_{s}'][state].format(s='f' if body else 'm')
        path = ROOT / 'build/res/graphics/field_sprites/field_sprites.narc.p' / (stem + '.nsbtx')
        contents = path.read_bytes()
        native = contents[contents.index(b'TEX0'):]
        dictionary = native[60:]
        count = dictionary[1]
        entryoff = struct.unpack_from('<H', dictionary, 6)[0]
        unit, namesoff = struct.unpack_from('<HH', dictionary, entryoff)
        aliases = {}
        for i in range(count):
            name = dictionary[entryoff + namesoff + i * 16:entryoff + namesoff + (i + 1) * 16].split(b'\0')[0].decode()
            index = int(name.rsplit('.', 1)[1]) - 1
            offset = (struct.unpack_from('<I', dictionary, entryoff + 4 + i * unit)[0] & 65535) * 8
            aliases.setdefault(offset, []).append(index)
        assert count == COUNTS[state]
        self.aliases[key] = list(aliases.values())
        return self.aliases[key]

    def field_states(self, body):
        walk, run, bike = (self.field(body, action) for action in ['walk', 'run', 'bike'])
        for layer in range(13):
            w, r, b = walk[layer], run[layer], bike[layer]
            states = [w + r, b + [b[i] for i in [8, 12, 9, 13, 0, 4, 10, 14]],
                      [w[i] for i in [4, 5, 4, 7]], [w[i] for i in [0, 0, 1, 0, 3, 0, 0]],
                      [w[d * 4] for d in range(4)], w,
                      w, [w[d * 4] for d in range(4) for _ in range(3)], [w[4], w[5]],
                      [w[d * 4] for d in [2, 2, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0]],
                      [w[i] for i in [4, 5, 4, 7, 4, 5, 4, 7, 4, 5, 4, 7, 4]], w + r]
            for state, frames in enumerate(states):
                assert len(frames) == COUNTS[state]
                frames = [im.copy() for im in frames]
                # A native texture address can have multiple frame-name aliases.
                # Every layer must agree at those aliases before composition.
                for group in self.native_alias_groups(body, state):
                    for index in group:
                        frames[index] = frames[min(group)].copy()
                self.layers[(body, state, layer)] = (b''.join(nibble(im) for im in frames), 512)
            self.layers[(body, 12, layer)] = (b''.join(nibble(w[d * 4]) for d in range(4)), 512)
        return walk, run, bike

    def portraits(self, body):
        frontstate = 'trainer front ' + ('female' if body else 'male')
        backstate = 'trainer back ' + ('female' if body else 'male')
        fronts = []
        backs = []
        for layer, (path, role) in enumerate(self.paths(frontstate, body, front=True)):
            front = self.read(path, role).resize((80, 80), NEAREST)
            if layer == 0:
                pix = list(front.getdata())
                for y in range(70, 80):
                    for x in range(80):
                        if pix[y * 80 + x] in [2, 3, 4]:
                            pix[y * 80 + x] = 13 if pix[y * 80 + x] == 2 else 14
                front.putdata(pix)
            fronts.append(front)
            self.layers[(body, 15, layer)] = (oam80(front), 3200)
            portrait = front.crop((16, 0, 64, 80))
            card = bytearray(6144)
            for ty in range(10):
                for tx in range(6):
                    index = 1 + ty * 6 + tx
                    card[index * 64:(index + 1) * 64] = portrait.crop((tx * 8, ty * 8, tx * 8 + 8, ty * 8 + 8)).tobytes()
            self.layers[(body, 13, layer)] = (bytes(card), 6144)
        for layer, (path, role) in enumerate(self.paths(backstate, body, back=True)):
            frames = []
            for index in range(5):
                canvas = indexed((80, 80))
                if path:
                    sheet = self.read(path, role)
                    # Crop all parts using the same unmodified frame anchor.
                    # Common fit keeps the far throwing hand inside native80.
                    crop = sheet.crop((index * 175, 36, (index + 1) * 175, 196)).resize((80, 73), NEAREST)
                    canvas.paste(crop, (0, 7))
                frames.append(canvas)
            backs.append(frames)
            raw = b''.join(oam80(frames[index]) for index in [0, 0, 1, 2, 2, 3, 4, 4])
            self.layers[(body, 14, layer)] = (raw, 25600)
        return fronts, backs

    def compose(self, images):
        result = indexed(images[0].size)
        for im in images:
            result.paste(im, (0, 0), im.point(lambda p: 255 if p else 0, 'L'))
        return result

    def proof_grid(self, category, count, banks):
        width, cell_height = 264, 452
        canvas = Image.new('RGB', (count * width, cell_height * 2), '#b9c9bc')
        draw = ImageDraw.Draw(canvas)
        metrics = []
        for body, (walk, fronts) in enumerate(banks):
            fingerprints = []
            for option in range(count):
                hair = option if category == 'hair' else 0
                top = option if category == 'top' else 0
                leg = option if category == 'legwear' else 0
                selected = [0, 1 + leg, 4 + top, 7 + hair]
                x, y = option * width, body * cell_height
                names = {'hair': ['Hair 1', 'Hair 2', 'Hair 3', 'Hair 4'],
                         'top': ['T-shirt', 'Hoodie', 'Open jacket'],
                         'legwear': ['Jeans', 'Shorts', 'Capris']}
                draw.text((x + 4, y + 4), f'Body {body + 1}: {names[category][option]}', fill='black')
                draw.text((x + 4, y + 19), 'Same dyes / no hat', fill='black')
                rendered = []
                masks = []
                for d in range(4):
                    im = self.compose([walk[layer][d * 4] for layer in selected])
                    rgb = im.convert('RGB')
                    # Display transparency using the surrounding review color.
                    rgb.paste((185, 201, 188), (0, 0, 32, 32), im.point(lambda p: 0 if p else 255, 'L'))
                    canvas.paste(rgb.resize((128, 128), NEAREST), (x + d % 2 * 132, y + 37 + d // 2 * 132))
                    rendered.append(im.tobytes())
                    masks.append(bytes(bool(p) for p in im.getdata()))
                front = self.compose([fronts[layer] for layer in selected])
                rgb = front.convert('RGB')
                rgb.paste((185, 201, 188), (0, 0, 80, 80), front.point(lambda p: 0 if p else 255, 'L'))
                canvas.paste(rgb.resize((144, 144), NEAREST), (x + 60, y + 304))
                layer = (7 + hair) if category == 'hair' else ((4 + top) if category == 'top' else (1 + leg))
                shape = b''.join(im.tobytes() for im in walk[layer])
                mask = b''.join(bytes(bool(p) for p in im.getdata()) for im in walk[layer])
                fingerprints.append(hashlib.sha256(shape).hexdigest())
                metrics.append({'body': body, 'category': category, 'option': option,
                                'layer_pixels_sha256': fingerprints[-1],
                                'layer_alpha_silhouette_sha256': hashlib.sha256(mask).hexdigest(),
                                'composed_four_facing_sha256': hashlib.sha256(b''.join(rendered)).hexdigest()})
            assert len(set(fingerprints)) == count, (body, category, 'duplicate shape')
            silhouettes = [row['layer_alpha_silhouette_sha256'] for row in metrics
                           if row['body'] == body and row['category'] == category]
            assert len(set(silhouettes)) == count, (body, category, 'duplicate silhouette')
        canvas.save(self.out / ('editable-' + category + '-proof.png'))
        return metrics

    def run(self):
        self.out.mkdir(parents=True, exist_ok=True)
        review = Image.new('RGB', (960, 700), '#b9c9bc')
        draw = ImageDraw.Draw(review)
        shape_proofs = []
        proof_banks = []
        for body in range(2):
            walk, run, bike = self.field_states(body)
            fronts, backs = self.portraits(body)
            proof_banks.append((walk, fronts))
            for variant in range(6):
                hair, top, leg, hat = variant % 4, variant % 3, (variant // 2) % 3, variant % 3
                selected = [0, 1 + leg, 4 + top, 7 + hair] + ([10 + hat] if hat else [])
                x = variant * 160
                y = body * 350
                draw.text((x + 2, y + 3), ('Body ' + str(body + 1) + ' / look ' + str(variant + 1)), fill='black')
                for d in range(4):
                    im = self.compose([walk[layer][d * 4] for layer in selected])
                    shape_proofs.append(hashlib.sha256(im.tobytes()).hexdigest())
                    review.paste(im.resize((64, 64), NEAREST).convert('RGB'), (x + d % 2 * 70, y + 25 + d // 2 * 70))
                for offset, bank in enumerate([run, bike]):
                    im = self.compose([bank[layer][4] for layer in selected])
                    review.paste(im.resize((64, 64), NEAREST).convert('RGB'), (x + offset * 70, y + 165))
                front = self.compose([fronts[layer] for layer in selected])
                back = self.compose([backs[layer][3] for layer in selected])
                review.paste(front.convert('RGB'), (x, y + 240))
                review.paste(back.convert('RGB'), (x + 80, y + 240))
        review.save(self.out / 'editable-contact-sheet.png')
        assert len(set(shape_proofs)) >= 32, 'Contact-sheet custom silhouettes must be distinct.'
        shape_metrics = []
        for category, count in [('hair', 4), ('top', 3), ('legwear', 3)]:
            shape_metrics.extend(self.proof_grid(category, count, proof_banks))
        keys = [(body, state, layer) for body in range(2) for state in range(16) for layer in range(13)]
        assert len(keys) == 416 and all(key in self.layers for key in keys)
        base = 16 + len(keys) * 16
        table, blob = bytearray(), bytearray()
        payloads = {}
        entries = []
        for key in keys:
            data, stride = self.layers[key]
            if data not in payloads:
                payloads[data] = base + len(blob)
                blob.extend(data)
            offset = payloads[data]
            table.extend(struct.pack('<IIII', offset, len(data), stride, 0))
            entries.append({'body': key[0], 'state': key[1], 'layer': key[2], 'offset': offset, 'size': len(data), 'stride': stride})
        pack = struct.pack('<4sIII', b'AVC1', 1, len(keys), 0) + table + blob
        (self.out / 'custom.bin').write_bytes(pack)
        manifest = {
            'format': 'AVC1', 'version': 1, 'entries': len(keys), 'bytes': len(pack),
            'sha256': hashlib.sha256(pack).hexdigest(), 'source_root': str(self.source),
            'source_archive': {'name': 'pokemon png.rar', 'sha256': '133c8ab405d57e17e67c0239c21b52cb32b8142c63be052d851b55c96e773bc5'},
            'layers': LAYERS, 'direction_order': ['north', 'south', 'west', 'east'],
            'semantic_palette_rgb': PALETTE,
            'counts': {'body': 2, 'hairstyle_per_body': 4, 'top': 3, 'legwear': 3, 'hat': 3},
            'field_state_counts': COUNTS, 'entry_table': entries,
            'source_art': self.proof, 'clean_export_actions': self.cleaning,
            'independent_shape_validation': shape_metrics,
            'limitations': [
                'The archive supplies exact walk, run, bicycle, front and five throwing poses. Other scripted field states retain the custom identity using directionally correct walk poses; no unsupported fishing rod, watering can or surf rig is invented.',
                'Throwing artwork is waist-up. Legwear layers are empty only in state14 because no legs are visible.',
                'The supplied base feet are recolored for shoe dye; there is no shoe shape selector.',
                'Hats share the top color. The finite palette maps source shading to semantic slots; source accent hues are consolidated.',
                'Back poses use a common80x73 fit and seven-pixel top margin; native eight-cell timing repeats source five poses [0,0,1,2,2,3,4,4].',
                'No separate licence or verified artist attribution was present in the supplied archive; document metadata names Chris Loesche and does not establish authorship.'
            ]}
        (self.out / 'custom-provenance.json').write_text(json.dumps(manifest, indent=2) + '\n')
        print(json.dumps({key: manifest[key] for key in ['format', 'entries', 'bytes', 'sha256']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--out', type=Path, default=ROOT / 'res/arena/avatar')
    args = parser.parse_args()
    Converter(args.source, args.out).run()
