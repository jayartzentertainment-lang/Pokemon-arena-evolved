#!/usr/bin/env python3
"""Exercise the real native bridge/controller with a host Pokemon-access model."""
import argparse
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument("--sanitize", action="store_true")
args = parser.parse_args()
out = ROOT / "build/arena-party-checks"
out.mkdir(parents=True, exist_ok=True)
flags = ["-std=c11", "-Wall", "-Wextra", "-Werror", "-O2",
         "-DPOKEPLATINUM_GENERATED_ENUM", "-Itests/arena/party_stubs", "-Iinclude", "-Ibuild"]
if args.sanitize:
    flags += ["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
sources = ["tests/arena/test_party_bridge.c", "src/arena/party_bridge.c",
           "src/arena/combat.c", "src/arena/move_data.c",
           "src/arena/vendor/arena_moves.c", "src/arena/vendor/arena_navigation.c",
           "src/arena/vendor/arena_physics.c"]
subprocess.run(["cc", *flags, *sources, "-o", str(out / "test_party_bridge")], cwd=ROOT, check=True)
subprocess.run([str(out / "test_party_bridge")], cwd=ROOT, check=True)
