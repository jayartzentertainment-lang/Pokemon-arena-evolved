#!/usr/bin/env python3
"""Stage optional authored Hurt/Charge poses from the supplied complete sheets.

The common actor pack remains compatible. Reactions are small resident tile
maps using the actor's existing palette; no runtime file or palette swaps.
"""
from pathlib import Path
import re,struct,statistics,json,hashlib,xml.etree.ElementTree as ET
from PIL import Image
P=Path(__file__).resolve().parents[2]
source=P/'res/arena/reactions/source/0003'
records=(P/'src/arena/assets_data.c').read_text()
match=re.search(r'\{"VENUSAUR",3,\{([^}]+)\}',records)
assert match
palette=[int(v,0) for v in match[1].split(',')];indices={v&32767:i for i,v in enumerate(palette) if i}
xml=ET.parse(source/'AnimData.xml');output=['/* Generated authored reaction poses; tools/arena/import_reaction_poses.py. */'];entries=[];report=[]
for name in ['Hurt','Charge']:
 node=next(n for n in xml.findall('./Anims/Anim') if n.findtext('Name')==name)
 w=int(node.findtext('FrameWidth'));h=int(node.findtext('FrameHeight'));times=[int(n.text) for n in node.findall('./Durations/Duration')]
 image=Image.open(source/(name+'-Anim.png')).convert('RGBA');assert image.size==(w*len(times),h*8)
 tiles=[];mapping=[];dictionary={};grounds=[]
 for direction in range(8):
  bottoms=[]
  for frame in range(len(times)):
   im=image.crop((frame*w,direction*h,(frame+1)*w,(direction+1)*h));bounds=im.getchannel('A').getbbox();assert bounds
   left,top,right,bottom=bounds;ox=32-w//2;oy=32-h//2
   dx=max(0,-(left+ox))-max(0,right+ox-64);dy=max(0,-(top+oy))-max(0,bottom+oy-64)
   assert right-left<=64 and bottom-top<=64 and abs(dx)<=3 and abs(dy)<=3
   pixels=[0]*4096
   for y in range(top,bottom):
    for x in range(left,right):
     r,g,b,a=im.getpixel((x,y))
     if not a:continue
     color=(r>>3)|((g>>3)<<5)|((b>>3)<<10);assert color in indices,(name,color)
     pixels[(y+oy+dy)*64+x+ox+dx]=indices[color]
   bottoms.append(bottom+oy+dy-32)
   for ty in range(8):
    for tx in range(8):
     tile=bytes(pixels[(ty*8+y)*64+tx*8+x]|pixels[(ty*8+y)*64+tx*8+x+1]<<4 for y in range(8) for x in range(0,8,2))
     if tile not in dictionary:dictionary[tile]=len(tiles);tiles.append(tile)
     mapping.append(dictionary[tile])
  grounds.append(int(statistics.median(bottoms)))
 blob=struct.pack('<II',8+len(mapping)*2,len(tiles))+struct.pack('<%dH'%len(mapping),*mapping)+b''.join(tiles)
 key='arena_reaction_3_'+name.lower();output.append('static const u8 '+key+'_data[]={\n'+''.join('    '+','.join(str(v) for v in blob[i:i+24])+',\n' for i in range(0,len(blob),24))+'};')
 output.append('static const u8 '+key+'_ticks[]={'+','.join(map(str,times))+'};')
 hit=sum(times[:int(node.findtext('HitFrame') or '0')]);anim='{0,%d,%d,%d,%d,%s_ticks,{%s}}'%(len(blob),len(times),sum(times),hit,key,','.join(map(str,grounds)))
 entries.append(anim+','+key+'_data')
 report.append({'dex':3,'pose':name,'frames':len(times),'durations':times,'hit_tick':hit,'data_bytes':len(blob),'palette_conversion':'exact existing species palette; no quantization','source_sha256':hashlib.sha256((source/(name+'-Anim.png')).read_bytes()).hexdigest()})
output.append('static const ArenaReactionArt arena_reaction_art[]={\n    {3,'+','.join(entries)+'}\n};')
(P/'src/arena/reaction_art.inc').write_text('\n'.join(output)+'\n');(P/'res/arena/reaction-provenance.json').write_text(json.dumps({'source_directory':str(source),'reactions':report,'coverage':'Only Venusaur has locally supplied full Hurt/Charge sheets; all other species retain compatible authored idle/attack frames with physical recoil.'},indent=2)+'\n');print(json.dumps(report,indent=2))
