#!/usr/bin/env python3
"""Import selected supplied VFX into the existing 56-frame DS OBJ allocation.

No game-time filesystem access, generated replacement art, random processing,
or additional 32x32 OBJ slots. Original full sheets/frames are retained beside
the manifest; all crops, compositing, timing and anchors are explicit below.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "res/arena/v096-effects"
EXTRA_DEFAULT = Path("/workspace/platinum-port/extra-effects")
DP_DEFAULT = Path("/workspace/asset-review/arsenal-2026-10-21/diamond-pearl-attack-graphics/source")
COLORS = [(248,248,248),(248,216,72),(248,120,32),(200,48,40),
          (64,144,232),(120,224,248),(40,64,144),(80,192,48),
          (24,88,40),(152,88,184),(216,168,232),(64,24,88),
          (144,160,152),(40,40,48),(232,240,224)]
WIND_COLORS = {1:(248,248,248),13:(152,192,184),
               14:(208,232,216),15:(168,152,120)}
FAMILIES = [
    ("FIRE",0,4,6,["Ember","Fire Punch","Flame Wheel","Fire Spin"]),
    ("WATER",8,4,6,["Water Gun","Bubble Beam","Aqua Jet","Surf splash"]),
    ("ELECTRIC",16,4,6,["Thunder Shock","Thunderbolt","Thunder Wave","Spark"]),
    ("ICE",24,4,6,["Ice Shard","Ice Beam contact","Icy Wind","freeze status"]),
    ("HIT",32,4,6,["Tackle","Pound","Quick Attack","body contact"]),
    ("GUARD",40,8,3,["guard startup","held guard","successful block"]),
    ("CLASH",48,4,6,["compatible projectile clash","heavy contact"]),
    ("SLASH",4,4,3,["Scratch","Slash","Night Slash","Shadow Claw","Cut"]),
    ("LEAF",12,4,3,["Razor Leaf","Magical Leaf","Leaf Storm","grass projectile"]),
    ("PSYCHIC",20,4,3,["Psycho Cut","Confusion","Psychic","Hypnosis"]),
    ("SHADOW",28,4,3,["Shadow Ball","Shadow Sneak","Shadow Force","Dark Pulse","poison status"]),
    ("BUFF",36,4,3,["Swords Dance","Agility","Calm Mind","stat stage increase","healing"]),
    ("DEBUFF",52,4,3,["Growl","Tail Whip","Scary Face","stat stage decrease","status application"]),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bgr555(color):
    r,g,b=color
    return (r>>3)|((g>>3)<<5)|((b>>3)<<10)


def pixels(im):
    # Pillow 14 renamed getdata; keep the converter usable with older Pillow.
    return im.get_flattened_data() if hasattr(im,"get_flattened_data") else im.getdata()


def pack(indices,width,height):
    """Native tile-major 4bpp OBJ format, low nibble is left pixel."""
    return bytes(indices[(ty*8+y)*width+tx*8+x] |
                 (indices[(ty*8+y)*width+tx*8+x+1]<<4)
                 for ty in range(height//8) for tx in range(width//8)
                 for y in range(8) for x in range(0,8,2))


def decode(data,width,height,palette):
    indices=[0]*(width*height)
    for ty in range(height//8):
        for tx in range(width//8):
            for y in range(8):
                for x in range(8):
                    value=data[(ty*(width//8)+tx)*32+y*4+x//2]
                    indices[(ty*8+y)*width+tx*8+x]=(value>>((x&1)*4))&15
    im=Image.new("RGBA",(width,height))
    im.putdata([(0,0,0,0) if i==0 else (*palette[i],255) for i in indices])
    return im


def quantize(im,colors):
    palette={index:color for index,color in colors.items() if index}
    return [0 if a<96 else min(palette,key=lambda k:sum(
            (palette[k][c]-(r,g,b)[c])**2 for c in range(3)))
            for r,g,b,a in pixels(im)]


class Importer:
    def __init__(self,extra,dp,retained):
        self.extra,self.dp,self.retained=extra,dp,retained
        self.records=[]
        self.selected={}

    def source(self,package,path):
        relative=Path(package)/path
        target=DEST/"source"/relative
        origin=(self.dp if package=="dp" else self.extra)/path
        if self.retained:
            origin=target
        if not origin.is_file():
            raise ValueError("Missing selected original source: "+str(origin))
        raw=origin.read_bytes()
        if not target.exists() or target.read_bytes()!=raw:
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(origin,target)
        im=Image.open(origin).convert("RGBA")
        self.selected[relative.as_posix()]={"sha256":sha(raw),"bytes":len(raw),
            "size":list(im.size),"source":relative.as_posix()}
        return im,relative.as_posix()

    def frame(self,package,path,crop=None,remove_markers=False,mask=None):
        im,source=self.source(package,path)
        if crop is not None:
            im=im.crop(crop)
        if remove_markers:
            im.putdata([(0,0,0,0) if r>190 and b>190 and g<100 else (r,g,b,a)
                        for r,g,b,a in pixels(im)])
        if mask=="up-arrow":
            im.putdata([(r,g,b,255 if g>=204 else 0) for r,g,b,a in pixels(im)])
        elif mask=="down-arrow":
            im.putdata([(r,g,b,255 if r>=90 and g>=220 else 0) for r,g,b,a in pixels(im)])
        return im,{"source":source,"source_sha256":self.selected[source]["sha256"],
                   "crop":crop,"remove_magenta_registration":remove_markers,
                   "alpha_extraction":mask}

    def pmd(self,number,indices):
        folder=Path("2/move_VFX")/f"{number:04d}"/"000"
        paths=sorted((self.extra/folder).glob("*.png"))
        if self.retained:
            # Explicit selected source filenames are persisted for exact rebuilds.
            old=json.loads((DEST/"manifest.json").read_text())
            group={5:"FIRE",103:"WATER",215:"ELECTRIC",141:"ICE"}[number]
            return [self.frame("extra",f["source"].removeprefix("extra/"))
                    for f in old["frames"] if f["family"]==group]
        # Skip almost-empty first/last source cels: four native slots should
        # carry readable active silhouettes rather than long invisible holds.
        return [self.frame("extra",(folder/paths[round((i+1)*(len(paths)-1)/5)].name).as_posix())
                for i in range(4)]

    def sequence(self,name,items,cap=(30,30),canvas=(32,32)):
        # Every source frame is registered to the same center before measuring
        # a single union crop/scale. Growth/decay is retained, never auto-fitted
        # separately per frame.
        width=max(im.width for im,_ in items)
        height=max(im.height for im,_ in items)
        aligned=[]
        for im,_ in items:
            frame=Image.new("RGBA",(width,height))
            frame.alpha_composite(im,((width-im.width)//2,(height-im.height)//2))
            aligned.append(frame)
        boxes=[im.getbbox() for im in aligned if im.getbbox()]
        box=(min(b[0] for b in boxes),min(b[1] for b in boxes),
             max(b[2] for b in boxes),max(b[3] for b in boxes))
        scale=min(cap[0]/(box[2]-box[0]),cap[1]/(box[3]-box[1]),1)
        size=(max(1,round((box[2]-box[0])*scale)),max(1,round((box[3]-box[1])*scale)))
        result=[]
        for i,(im,(_,record)) in enumerate(zip(aligned,items)):
            frame=Image.new("RGBA",canvas)
            cut=im.crop(box).resize(size,Image.Resampling.NEAREST)
            frame.alpha_composite(cut,((canvas[0]-size[0])//2,(canvas[1]-size[1])//2))
            record.update(family=name,sequence_frame=i,sequence_bounds=list(box),
                          shared_display_size=list(size),native_anchor=[canvas[0]//2,canvas[1]//2])
            result.append((frame,record))
        return result


def c_array(name,frames):
    text=f"static const unsigned char {name}[{len(frames)}][{len(frames[0])}]={{\n"
    for frame in frames:
        text+="{\n"+"\n".join(" "+",".join(f"0x{b:02x}" for b in frame[n:n+32])+"," for n in range(0,len(frame),32))+"\n},\n"
    return text+"};\n"


def make_inventory(extra,dp,selected):
    inventory={"scope":"File inventory and source contact-sheet inspection; selected original frame hashes are in manifest.json.","packages":[]}
    for label,root in [("Diamond/Pearl",dp),("Ranger",extra/"0"),("King of Fighters",extra/"1"),("Mystery Dungeon",extra/"2")]:
        files=sorted(root.rglob("*.png"))
        package={"name":label,"png_files":len(files),"bytes":sum(p.stat().st_size for p in files),
                 "timing_metadata_files":[str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and p.suffix.lower() in (".xml",".json")],
                 "selection_policy":"Use compatible actor/particle silhouettes; composite backgrounds, side-view-only pieces and redundant/unmapped effects are deferred under the fixed DS OBJ budget."}
        if label=="Diamond/Pearl":
            package["files"]=[{"file":p.name,"size":list(Image.open(p).size),
                "sha256":sha(p.read_bytes()),"selected":"dp/"+p.name in selected,
                "disposition":"selected runtime crop" if "dp/"+p.name in selected else "deferred: not part of the selected family slice; full sheet reviewed in source-dp-page contact sheets"} for p in files]
        if label=="Mystery Dungeon":
            groups=sorted((root/"move_VFX").iterdir())
            package["move_sequences"]=[{"folder":g.name,"frames":len(list(g.rglob("*.png"))),
                "selected":any(k.startswith("extra/2/move_VFX/"+g.name+"/") for k in selected)} for g in groups if g.is_dir()]
        inventory["packages"].append(package)
    return inventory


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--extra-source",type=Path,default=EXTRA_DEFAULT)
    parser.add_argument("--dp-source",type=Path,default=DP_DEFAULT)
    parser.add_argument("--retained-source",action="store_true",help="Rebuild only from committed selected originals and prior manifest")
    args=parser.parse_args()
    DEST.mkdir(parents=True,exist_ok=True)
    imp=Importer(args.extra_source,args.dp_source,args.retained_source)
    sequences={}
    for name,number in [("FIRE",5),("WATER",103),("ELECTRIC",215),("ICE",141)]:
        sequences[name]=imp.sequence(name,imp.pmd(number,range(4)))
    sequences["HIT"]=imp.sequence("HIT",[imp.frame("extra",f"1/Effects/Effects_{i}.png") for i in (0,1,3,6)])
    rings=[(0,7,120,17),(0,33,120,55),(0,74,120,110),(0,124,120,172),(0,187,120,236)]
    sequences["GUARD"]=imp.sequence("GUARD",[imp.frame("extra","0/24.png",rings[i],True) for i in (0,1,2,3,4,3,2,1)])
    sequences["CLASH"]=imp.sequence("CLASH",[imp.frame("extra",f"1/Effects/Effects_{i}.png") for i in (390,392,394,397)])
    slash=[]
    for phase,(low,high) in enumerate(((28,78),(0,78),(0,78),(0,48))):
        im,record=imp.frame("dp","Scratch-Shadow-Claw.png",(122,0,185,78))
        im.putdata([(r,g,b,a if low<=y<high else 0) for y in range(im.height) for r,g,b,a in [im.getpixel((x,y)) for x in range(im.width)]])
        record["adaptation"]={"reveal_source_rows":[low,high],"purpose":"source claw strokes reveal, hold and retract; source position stays fixed"}
        slash.append((im,record))
    sequences["SLASH"]=imp.sequence("SLASH",slash)
    leaves=[]
    for i in range(4):
        im,record=imp.frame("dp","Leaves.png",(0 if i%2==0 else 21,0 if i<2 else 17,21 if i%2==0 else 42,17 if i<2 else 35))
        canvas=Image.new("RGBA",(32,32))
        canvas.alpha_composite(im,(0,2))
        canvas.alpha_composite(im.transpose(Image.Transpose.FLIP_LEFT_RIGHT),(11,13))
        record["adaptation"]="Two supplied directional leaves at fixed offsets (0,2) and (11,13); second is horizontally mirrored"
        leaves.append((canvas,record))
    sequences["LEAF"]=imp.sequence("LEAF",leaves)
    sequences["PSYCHIC"]=imp.sequence("PSYCHIC",[imp.frame("dp","Psycho-Cut.png",box) for box in ((0,0,44,96),(44,0,101,96),(101,0,161,96),(161,0,217,96))])
    sequences["SHADOW"]=imp.sequence("SHADOW",[imp.frame("dp","Shadow-Force.png",box) for box in ((0,60,28,103),(28,60,56,103),(56,60,86,103),(86,60,144,103))])
    for name,box,mask,sign in [("BUFF",(0,3,9,13),"up-arrow",-1),("DEBUFF",(353,7,360,17),"down-arrow",1)]:
        frames=[]
        for i in range(4):
            arrow,record=imp.frame("dp","Status.png",box,mask=mask)
            frame=Image.new("RGBA",(32,32))
            for x,y in [(2,15),(12,8),(22,15)]:
                frame.alpha_composite(arrow,(x,y+sign*(i*2-3)))
            record["adaptation"]={"composite":"three original arrow silhouettes", "offset_per_tick":sign*2,
                                  "background_removal":"up: G>=204; down: R>=90 and G>=220; authored isolated source-cell crops"}
            frames.append((frame,record))
        sequences[name]=imp.sequence(name,frames)

    atlas=[None]*56
    records=[None]*56
    for name,start,count,ticks,moves in FAMILIES:
        assert len(sequences[name])==count
        for i,(im,record) in enumerate(sequences[name]):
            atlas[start+i]=im
            record.update(atlas_frame=start+i,ticks_per_frame=ticks,compatible_moves=moves)
            records[start+i]=record
    palette={i+1:c for i,c in enumerate(COLORS)}
    tiles=[pack(quantize(im,palette),32,32) for im in atlas]
    assert len(tiles)==56 and all(len(t)==512 and any(t) for t in tiles)

    # KOF 164/165 are thin curved sweeps, not impact bursts. Re-tint their
    # tapered silhouettes into quiet gray-green air streaks and layer a shorter
    # copy below. A tiny open Ranger curl adds dissipating air at the rear.
    winditems=[imp.frame("extra",f"1/Effects/Effects_{i}.png") for i in (164,165)]
    windseq=imp.sequence("WIND",winditems,cap=(30,6),canvas=(32,16))
    curl,curlrecord=imp.frame("extra","0/124.png",(0,160,72,200),True)
    curl=curl.resize((7,4),Image.Resampling.NEAREST)
    wind=[]
    for im,record in windseq:
        layered=Image.new("RGBA",(32,16))
        layered.alpha_composite(im,(0,-3))
        layered.alpha_composite(im.resize((26,13),Image.Resampling.NEAREST),(-1,4))
        layered.alpha_composite(curl,(24,10))
        # Gray-green air streaks retain the supplied luminance/highlights.
        indices=[0 if a<96 else (1 if max(r,g,b)>=240 else 14 if max(r,g,b)>=200 else 13)
                 for r,g,b,a in pixels(layered)]
        wind.append(pack(indices,32,16))
        record.update(native_anchor=[16,8],ticks_per_frame=3,
                      adaptation="two layered tapered KOF sweeps and a tiny open Ranger air curl, neutral arena tint; no opaque field or full ring",
                      composite_sources=[curlrecord],
                      layers=[{"source":"main","offset":[0,-3]},
                              {"source":"main","resize":[26,13],"offset":[-1,4]},
                              {"source":"curl","resize":[7,4],"offset":[24,10]}])
    assert all(len(t)==256 and any(t) for t in wind)

    text="/* Generated by tools/arena/import_v096_effects.py. Supplied source credits/anchors: res/arena/v096-effects. */\n"
    text+="enum ArenaV096Family { ARENA_V096_SLASH=7, ARENA_V096_LEAF, ARENA_V096_PSYCHIC, ARENA_V096_SHADOW, ARENA_V096_BUFF, ARENA_V096_DEBUFF };\n"
    text+=c_array("arena_v096_tiles",tiles)
    text+="static const unsigned short arena_v096_palette[16]={0,"+",".join(str(bgr555(c)) for c in COLORS)+"};\n"
    text+=c_array("arena_wind_tiles",wind)
    text+="static const unsigned short arena_wind_palette_tail[3]={"+",".join(str(bgr555(WIND_COLORS[i])) for i in (13,14,15))+"};\n"
    text+="static unsigned ArenaV096_BaseFrame(unsigned group,unsigned tick)\n{ if(group>6)group=4;return group*8+(group==5?(tick/3)%8:(tick/6)%4); }\n"
    text+="static unsigned ArenaV096_Frame(unsigned family,unsigned tick)\n{ static const unsigned char start[6]={4,12,20,28,36,52}; if(family<7)return ArenaV096_BaseFrame(family,tick);if(family>12)return ArenaV096_BaseFrame(4,tick);return start[family-7]+(tick/3)%4; }\n"
    (ROOT/"src/arena/v096_effect_art.inc").write_text(text)
    canonical_moves={name:i for i,name in enumerate((ROOT/"generated/moves.txt").read_text().splitlines())}
    def move_candidates(moves):
        entries=[]
        for name in moves:
            symbol="MOVE_"+name.upper().replace(" ","_")
            if symbol in canonical_moves:
                entries.append({"name":name,"symbol":symbol,"move_id":canonical_moves[symbol]})
        return entries
    manifest={"version":"0.9.6","format":"Nintendo DS OBJ tiled 4bpp, transparency index0",
        "frame_count":56,"frame_size":[32,32],"atlas_bytes":28672,"replaces":"existing ARENA_EXTRA_FRAMES bank; no additional 32x32 OBJ allocation",
        "wind_bytes":512,"wind_frame_count":2,"wind_frame_size":[32,16],"wind_palette_bank":15,"wind_palette_slots":[1,13,14,15],
        "palette_bgr555":[0]+[bgr555(c) for c in COLORS],"palette_policy":"Fixed common 15-color palette; nearest RGB color, alpha threshold96; nearest-neighbor sequence shared scale",
        "tile_sha256":sha(b"".join(tiles)),"wind_sha256":sha(b"".join(wind)),
        "runtime":"All tile data is compiled into render.c via v096_effect_art.inc; load atlas once, reuse static frames; no per-frame file IO or allocation",
        "family_map":[{"name":name,"family_id":i,"atlas_start":start,"frames":count,"ticks_per_frame":ticks,"native_anchor":[16,16],"compatible_moves":moves,"canonical_move_candidates":move_candidates(moves)} for i,(name,start,count,ticks,moves) in enumerate(FAMILIES)],
        "frames":records,"wind_frames":[record for _,record in windseq],"selected_sources":list(imp.selected.values()),
        "limits":["Compatible-family mappings are presentation candidates; renderer dispatch determines active runtime coverage.",
                  "Native palette reduction approximates source colors. Original retained PNGs and decoded previews make this reviewable.",
                  "Four-frame families trade cadence detail for six additional sourced silhouettes inside an unchanged 28672-byte atlas.",
                  "No claim that all 95 D/P sheets or all 19044 PMD source frames are runtime integrated."]}
    (DEST/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
    if not args.retained_source:
        (DEST/"source-inventory.json").write_text(json.dumps(make_inventory(args.extra_source,args.dp_source,imp.selected),indent=2)+"\n")
    preview=Image.new("RGB",(8*64,7*84),(43,49,56));draw=ImageDraw.Draw(preview)
    for i,data in enumerate(tiles):
        x=(i%8)*64;y=(i//8)*84
        draw.text((x+2,y+1),f"{i} "+records[i]["family"],fill="white")
        im=decode(data,32,32,palette).resize((64,64),Image.Resampling.NEAREST)
        preview.paste(im,(x,y+20),im)
    preview.save(DEST/"native-contact.png")
    windpreview=Image.new("RGB",(256,80),(43,49,56))
    for i,data in enumerate(wind):
        im=decode(data,32,16,WIND_COLORS).resize((128,64),Image.Resampling.NEAREST)
        windpreview.paste(im,(i*128,8),im)
    windpreview.save(DEST/"native-wind.png")
    # Side-by-side retained source crops demonstrate what generated tiles use.
    sourcepreview=Image.new("RGB",(8*96,7*116),(43,49,56));draw=ImageDraw.Draw(sourcepreview)
    for i,im in enumerate(atlas):
        x=(i%8)*96;y=(i//8)*116
        draw.text((x+1,y+1),f"{i} "+records[i]["family"],fill="white")
        enlarged=im.resize((96,96),Image.Resampling.NEAREST)
        sourcepreview.paste(enlarged,(x,y+20),enlarged)
    sourcepreview.save(DEST/"selected-source-contact.png")
    print(json.dumps({"atlas_frames":56,"atlas_bytes":28672,"additional_wind_bytes":512,
                      "selected_original_files":len(imp.selected),"atlas_sha256":manifest["tile_sha256"],"wind_sha256":manifest["wind_sha256"]}))


if __name__=="__main__":
    main()
