#!/usr/bin/env python3
"""Use each native Platinum move animation's first sound for action startup."""
from pathlib import Path
import re
import argparse
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');args=p.parse_args()
rows=['/* Generated from native move animation scripts by generate_move_sounds.py. */','static const u16 sMoveSounds[]={']
count=0
for move in (ROOT/'generated/moves.txt').read_text().splitlines():
    if not move.startswith('MOVE_'):continue
    path=ROOT/'res/moves'/move[5:].lower()/'anim.s'
    match=re.search(r'\b(?:SEQ_[A-Za-z0-9_]+|SE_[A-Za-z0-9_]+)_sseq(?:_\d+)?\b',path.read_text()) if path.exists() else None
    sound=match.group() if match else 'SEQ_SE_DP_KOUKA_M_sseq'
    count+=bool(match)
    rows.append('    '+sound+', /* '+move+' */')
rows.append('};\n')
content='\n'.join(rows);target=ROOT/'src/arena/move_sounds.inc'
if args.check:
    if not target.exists() or target.read_text()!=content:raise SystemExit('move sound map is out of date')
else:target.write_text(content)
print(f'{count} native move sounds mapped')
