#!/usr/bin/env python3
"""Map supplied Emerald and pinned FireRed player art into Platinum states.

The source sprites/portraits retain each regional character. Poketch/save/
heal/VS Seeker reuse regional gestures because the GBA source has no exact
DS-device animation. No Lucas/Dawn pixels are copied into these bundles.
"""
from pathlib import Path
from PIL import Image, ImageOps
import argparse, hashlib, json, struct, subprocess

ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=Path('/workspace/source-import/source/workspace'));a=p.parse_args()
OUT=ROOT/'res/arena/avatar';OUT.mkdir(parents=True,exist_ok=True)
KANTO=OUT/'kanto-source'
for item in json.loads((KANTO/'manifest.json').read_text())['files']:
 if 'error' in item: continue # Recorded unsuccessful metadata lookups are not imported art.
 source_file=KANTO/item['path']
 assert source_file.stat().st_size==item['bytes'],source_file
 assert hashlib.sha256(source_file.read_bytes()).hexdigest()==item['sha256'],source_file
STATE_COUNTS=[32,24,4,7,4,16,16,12,2,12,13,32]
entries=[];proof=[]

def nibble(im):
 data=list(im.getdata());return bytes(data[i]|(data[i+1]<<4)for i in range(0,len(data),2))
def tiles(im,bpp=4):
 out=bytearray()
 for y in range(0,im.height,8):
  for x in range(0,im.width,8):
   patch=im.crop((x,y,x+8,y+8));out.extend(nibble(patch)if bpp==4 else patch.tobytes())
 return bytes(out)
def add(body,state,palette,data,stride):
 entries.append((body,state,palette,data,stride))
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for regional,body,who in [(1,0,'brendan'),(1,1,'may'),(2,0,'red'),(2,1,'leaf')]:
 source_root=a.source if regional==1 else KANTO
 src=source_root/'graphics/object_events/pics/people'/who
 palpath=source_root/'graphics/object_events/palettes'/f'{who if regional==1 else "player"}.pal'
 pal=[tuple(map(int,s.split()))for s in palpath.read_text().splitlines()[3:19]]
 palbytes=b''.join(struct.pack('<H',sum((c>>3)<<(i*5)for i,c in enumerate(rgb)))for rgb in pal)
 flat=[c for rgb in pal for c in rgb]+[0]*(768-48)
 sources={}
 if regional==1:
  for f in src.glob('*.png'):
   sources[f.stem]=Image.open(f);proof.append({'path':str(f.relative_to(source_root)),'sha256':sha(f)})
 else:
  prefix='green'if body else'red'
  raw={}
  for suffix in ['normal','bike','fish','item','surf_run']:
   f=src.parent/f'{prefix}_{suffix}.png';raw[suffix]=Image.open(f)
   proof.append({'path':str(f.relative_to(source_root)),'sha256':sha(f),'repository':'pret/pokefirered'})
  sources['walking']=raw['normal'];sources['mach_bike']=raw['bike'];sources['fishing']=raw['fish']
  # FRLG keeps running poses after three surf poses in a separate 16x32 sheet.
  def remap(sheet,indices,width=16,target_width=16):
   result=Image.new('P',(target_width*len(indices),32),0);result.putpalette(flat)
   for target,index in enumerate(indices):result.paste(sheet.crop((index*width,0,(index+1)*width,32)),(target*target_width+(target_width-width)//2,0))
   return result
  sources['running']=remap(raw['surf_run'],[3,6,9,4,5,7,8,10,11])
  sources['surfing']=remap(raw['surf_run'],[0,0,1,1,2,2],target_width=32)
  sources['field_move']=remap(raw['item'],[0,1,2,3,4],target_width=32)
  # No Sprayduck exists in FRLG: preserve the correct north-facing identity.
  sources['watering']=remap(raw['normal'],[0,0,1,1,2,2],target_width=32)
 proof.append({'path':str(palpath.relative_to(source_root)),'sha256':sha(palpath),'repository':'pret/pokeemerald'if regional==1 else'pret/pokefirered'})
 def frame(name,index,mirror=False,width=16):
  sheet=sources[name];assert index<sheet.width//width
  pic=sheet.crop((index*width,0,(index+1)*width,32))
  if mirror:pic=ImageOps.mirror(pic)
  result=Image.new('P',(32,32),0);result.putpalette(flat)
  result.paste(pic,((32-width)//2,0));return result
 # Platinum texture names are N,S,W,E (Emerald's source indices are S,N,W).
 # A swapped first pair makes Up visibly face Down even though movement works.
 def directional(name):
  out=[]
  for direction in range(4):
   base=[1,0,2,2][direction];steps=[[5,6],[3,4],[7,8],[7,8]][direction]
   out.extend(frame(name,i,direction==3)for i in [base,steps[0],base,steps[1]])
  return out
 walk=directional('walking');run=directional('running')
 states=[]
 states.append(walk+run)
 bike=[frame('mach_bike',i,d==3,32)for d in range(4)for i in [[1,5,1,6],[0,3,0,4],[2,7,2,8],[2,7,2,8]][d]]
 bike+=[frame('acro_bike',i,mirror,32)for i,mirror in [(17,False),(17,True),(18,False),(18,True),(13,False),(9,False),(17,False),(17,True)]]if regional==1 else [frame('mach_bike',i,mirror,32)for i,mirror in [(2,False),(2,True),(7,False),(7,True),(1,False),(0,False),(2,False),(2,True)]]
 states.append(bike)
 states.append([frame('field_move',i,False,32)for i in [0,1,2,4]])
 states.append([frame('watering',i,False,32)for i in [2,2,3,2,3,2,2]])
 # Surf mount is native Platinum's separate renderer; source has the seated rider.
 states.append([frame('surfing',i,d==3,32)for d,i in enumerate([2,0,4,4])])
 states.append(walk)
 states.append([frame('fishing',i,d==3,32)for d in range(4)for i in [[4,5,6,7],[8,9,10,11],[0,1,2,3],[0,1,2,3]][d]])
 states.append([walk[d*4].copy()for d in range(4)for _ in range(3)])
 states.append([frame('field_move',i,False,32)for i in [0,1]])
 states.append([walk[d*4].copy()for d in [2,2,0,0,0,0,0,0,0,2,2,0]])
 states.append([frame('field_move',i,False,32)for i in [0,1,2,3,4,3,2,1,0,1,2,1,0]])
 states.append(states[0])
 for state,(images,count)in enumerate(zip(states,STATE_COUNTS)):
  assert len(images)==count,(state,len(images),count)
  # The native texture dictionary shares identical frames and is sorted by
  # texture name. Keep every alias group identical before writing in place.
  stem=['player_{s}','player_{s}_bike','player_{s}_holding_pokeball','player_{s}_sprayduck','player_{s}_surf','player_{s}_contest','player_{s}_fishing','player_{s}_poketch','player_{s}_save','player_{s}_pokecenter_heal','player_{s}_vs_seeker','dp_player_{s}'][state].format(s='m'if body==0 else'f')
  nsbtx=(ROOT/'build/res/graphics/field_sprites/field_sprites.narc.p'/f'{stem}.nsbtx').read_bytes()
  native=nsbtx[nsbtx.index(b'TEX0'):];dictionary=native[60:];num=dictionary[1];oe=struct.unpack_from('<H',dictionary,6)[0];unit,on=struct.unpack_from('<HH',dictionary,oe)
  aliases={}
  for i in range(num):
   name=dictionary[oe+on+i*16:oe+on+(i+1)*16].split(b'\0')[0].decode()
   frame_index=int(name.rsplit('.',1)[1])-1
   offset=(struct.unpack_from('<I',dictionary,oe+4+i*unit)[0]&65535)*8
   aliases.setdefault(offset,[]).append(frame_index)
  assert num==count
  for group in aliases.values():
   canonical=images[min(group)]
   for frame_index in group:images[frame_index]=canonical.copy()
  assert all(im.getbbox()for im in images)
  data=b''.join(nibble(im)for im in images);assert len(data)==count*512
  add(body,state,palbytes,data,512)
  sheet=Image.new('P',(32*8,32*((count+7)//8)),0);sheet.putpalette(flat)
  for i,im in enumerate(images):sheet.paste(im,((i%8)*32,(i//8)*32))
  sheet.save(OUT/f'{who}-state-{state:02}.png')
 # All creator bases show the same stationary field pose at 2x pixel scale.
 # The surrounding native 64x128 tilemap stays unchanged.
 previews=[]
 for direction in range(4):
  im=walk[direction*4].resize((64,64),Image.Resampling.NEAREST)
  canvas=Image.new('P',(64,128),0);canvas.putpalette(flat);canvas.paste(im,(0,32));previews.append(canvas)
 add(body,12,palbytes,b''.join(tiles(im)for im in previews),4096)
 def source_to_field_palette(path):
  im=Image.open(path);srcpal=im.getpalette();mapping={0:0}
  for idx in range(1,16):
   rgb=srcpal[idx*3:idx*3+3]
   mapping[idx]=min(range(1,16),key=lambda j:sum((rgb[k]-pal[j][k])**2 for k in range(3)))
  result=Image.new('P',im.size,0);result.putpalette(flat);result.putdata([mapping.get(v,0)for v in im.getdata()]);return result
 frontpath=source_root/'graphics/trainers/front_pics'/f'{who if regional==1 else who+"_front_pic"}.png'
 backpath=source_root/'graphics/trainers/back_pics'/f'{who if regional==1 else who+"_back_pic"}.png'
 front=source_to_field_palette(frontpath);back=source_to_field_palette(backpath)
 proof.extend({'path':str(f.relative_to(source_root)),'sha256':sha(f),'repository':'pret/pokeemerald'if regional==1 else'pret/pokefirered'}for f in [frontpath,backpath])
 # Card uses original 8bpp character/tilemap allocation (96 tiles, 32x32 map).
 card=Image.new('P',(256,24),0);card.putpalette(flat)
 portrait=Image.new('P',(48,80),0);portrait.putpalette(flat)
 portrait.paste(front.resize((48,48),Image.Resampling.NEAREST),(0,16))
 tilemap=bytearray(2048)
 raw=bytearray(6144)
 for ty in range(10):
  for tx in range(6):
   idx=1+ty*6+tx
   pix=portrait.crop((tx*8,ty*8,tx*8+8,ty*8+8))
   raw[idx*64:(idx+1)*64]=bytes((64+body*16+v)if v else 0 for v in pix.getdata())
   struct.pack_into('<H',tilemap,((6+ty)*32+22+tx)*2,idx)
 add(body,13,palbytes,bytes(raw)+tilemap,8192)
 # Existing NCER/OAM and eight-pose timing are retained; GBA throw poses
 # are held/interpolated to native cell count without reverting character.
 for state,face in [(14,'back'),(15,'front')]:
  canvas=Image.new('P',(80,647 if face=='back' else 80),0);canvas.putpalette(flat)
  if face=='back':
   for target,index in enumerate([0,0,1,1,2,2,3,3]if regional==1 else[0,0,1,2,2,3,4,4]):
    canvas.paste(back.crop((0,index*64,64,index*64+64)),(8,target*81+16))
  else:canvas.paste(front,(8,16))
  target=OUT/f'{who}-{face}.png';canvas.save(target)
  # nitrogfx -cell locates the sibling JSON to preserve source-cell ordering.
  cell=OUT/f'{who}-{face}_cell.json';cell.write_bytes((ROOT/f'res/trainers/classes/player_{"male" if body==0 else "female"}/{face}_cell.json').read_bytes())
  ncgr=OUT/f'{who}-{face}.NCGR'
  subprocess.run([str(ROOT/'build/tools/nitrogfx/nitrogfx'),str(target),str(ncgr),'-cell','-preservepath','-version101','-vram','-clobbersize','-mappingtype','64','-convertTo4Bpp'],check=True)
  n=ncgr.read_bytes();offset=24+struct.unpack_from('<I',n,44)[0];size=struct.unpack_from('<I',n,40)[0]
  data=n[offset:offset+size];assert len(data)==(25600 if face=='back' else 3200),(who,face,len(data),offset,size)
  add(body,state,palbytes,data,len(data))
# Two extra entries supply native Sinnoh previews in exactly the same format.
# Full Sinnoh movement continues to use the original native texture resources.
for body in range(2):
 source=ROOT/'res/graphics/field_sprites/player'/f'player_{"f" if body else "m"}.png'
 sheet=Image.open(source);pal=sheet.getpalette()[:48]
 palette=b''.join(struct.pack('<H',sum((pal[i*3+c]>>3)<<(c*5)for c in range(3)))for i in range(16))
 previews=[]
 for direction in range(4):
  im=sheet.crop((0,direction*4*32,32,(direction*4+1)*32)).resize((64,64),Image.Resampling.NEAREST)
  canvas=Image.new('P',(64,128),0);canvas.putpalette(sheet.getpalette());canvas.paste(im,(0,32));previews.append(canvas)
  if direction==1:canvas.save(OUT/f'{"dawn" if body else "lucas"}-preview.png')
 add(body,12,palette,b''.join(tiles(canvas)for canvas in previews),4096)
 proof.append({'path':str(source.relative_to(ROOT)),'sha256':sha(source),'repository':'pret/pokeplatinum'})
header=struct.pack('<4sIII',b'AVA1',3,len(entries),0)
base=len(header)+len(entries)*16;table=bytearray();blob=bytearray()
for body,state,pal,data,stride in entries:
 table.extend(struct.pack('<IIII',base+len(blob),len(data),stride,len(pal)))
 blob.extend(pal+data)
pack=header+table+blob;(OUT/'avatar.bin').write_bytes(pack)
manifest={'format':'AVA1','version':3,'file':'avatar.bin','bytes':len(pack),'sha256':hashlib.sha256(pack).hexdigest(),'bodies':['Brendan','May','Red','Leaf'],'states_per_body':16,'native_preview_entries':{'Lucas':64,'Dawn':65},'direction_order':['north','south','west','east'],'kanto_source_commit':'037335f4c725d7c9aecdac87066f2002b4bd7e14','source_art':proof,'limitations':['Poketch/heal use correctly facing regional field poses; save/VS Seeker use adapted field-move gestures.','Kanto Sprayduck uses north-facing idle art and bike special poses reuse the regional cycling sheet.','Contest uses regional outfits instead of native Sinnoh formal clothes.','Native throw duration retained with four Hoenn or five Kanto GBA poses held across eight cells.','Source trainer portrait palettes quantized to the matching 16-color field palette.']}
(OUT/'provenance.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:manifest[k]for k in ['bytes','sha256','states_per_body']}))
