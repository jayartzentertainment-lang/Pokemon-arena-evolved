#!/usr/bin/env python3
"""Validate staged Nitro assets and every dictionary map before ROM packaging."""
from pathlib import Path
import argparse,re,struct,json,hashlib
P=Path(__file__).resolve().parents[2]
a=argparse.ArgumentParser(description=__doc__)
a.add_argument('--arena',type=Path,help='Also compare every imported directional record against accepted Arena source')
args=a.parse_args()
s=(P/'src/arena/assets_data.c').read_text();pack=(P/'res/arena/arena.pack').read_bytes()
canonical=s.split('const AssetSpecies asset_species[]={',1)[1].split('\n};',1)[0]
identities=re.findall(r'\{"([^"]+)",(\d+),\{',canonical)
names=(P/'generated/species.txt').read_text().splitlines()[1:494]
assert len(identities)==493,len(identities)
for dex,((name,record_dex),expected) in enumerate(zip(identities,names),1):
    assert int(record_dex)==dex,(dex,name,record_dex)
    assert name==expected.removeprefix('SPECIES_'),(dex,name,expected)
styles=list(map(int,re.search(r'asset_species_animation_style\[\]\s*=\s*\{([^}]+)',s)[1].split(',')))
assert len(styles)==493 and all(style in (0,1) for style in styles)
provenance=json.loads((P/'res/arena/provenance.json').read_text())
assert provenance['directional_dex']==[i+1 for i,style in enumerate(styles) if style]
times={key:list(map(int,values.split(','))) for key,values in re.findall(r'const uint8_t (\w+)\[\]\s*=\s*\{([^}]+)',s) if key!='asset_species_animation_style'}
records=re.findall(r'\{(\d+)u,(\d+)u,(\d+)u,(\d+)u,(\d+)u,(\w+),\{([-\d,]+)\}\}',s)
form_count=len(provenance['native_forms'])
assert len(records)==(493+form_count)*5,len(records)
ranges={};frames=0
for off,size,count,total,hit,timing,grounds in records:
    off,size,count,total,hit=map(int,(off,size,count,total,hit));assert count and len(times[timing])==count and sum(times[timing])==total
    assert all(-32<=int(g)<=32 for g in grounds.split(','))
    assert off+size<=len(pack)
    if (off,size) in ranges:continue
    data=pack[off:off+size];dictionary,tiles=struct.unpack_from('<II',data)
    assert dictionary>=8+count*8*128 and dictionary+tiles*32<=size
    ids=struct.unpack_from('<%dH'%(count*8*64),data,8);assert max(ids)<tiles
    ranges[off,size]=size;frames+=count*8
cost=[]
for i in range(493+form_count):
    cost.append(sum({(int(r[0]),int(r[1])):int(r[1]) for r in records[i*5:i*5+5]}.values()))
assert max(cost)<=160*1024
# Keep the production 720896-byte heap's existing worst-case pose budget.
assert sum(sorted(cost,reverse=True)[:4])<=640824,('Four distinct pose caches exceed budget',sorted(cost,reverse=True)[:4])
# Verify the generated opaque-body measurements against cartridge pixels,
# including forms. Native portrait canvases must not inflate perceived size.
extents=list(map(int,re.search(r'arena_native_body_extent\[\]\s*=\s*\{([^}]+)',s)[1].split(',')))
assert len(extents)==493 and extents==provenance['native_body_extents']
reductions=list(map(int,re.search(r'arena_directional_reduction\[\]\s*=\s*\{([^}]+)',s)[1].split(',')))
assert len(reductions)==493 and reductions==provenance['directional_source_reductions']
assert all(reduction in (1,2,3,4) for reduction in reductions)
# Newly imported Gen I–III Pokémon may use the same bounded reduction as Gen IV.
form_extents={(int(dex),int(form)):int(extent) for dex,form,extent in re.findall(r'if\(dex==(\d+) && form==(\d+)\) return (\d+)u;',s)}
for i,rec in enumerate(records[::5]):
    if i<493 and styles[i]:
        assert extents[i]==0
        continue
    off,size,count=map(int,rec[:3]);data=pack[off:off+size]
    dictionary,tiles=struct.unpack_from('<II',data);measured=0
    for direction in range(8):
        ids=struct.unpack_from('<64H',data,8+direction*count*128);points=[]
        for tile_index,tile in enumerate(ids):
            raw=data[dictionary+tile*32:dictionary+(tile+1)*32]
            for pixel,pair in enumerate(raw):
                for half in range(2):
                    if (pair>>(half*4))&15:
                        points.append(((tile_index%8)*8+(pixel%4)*2+half,(tile_index//8)*8+pixel//4))
        assert points,(i,direction)
        measured=max(measured,max(x for x,y in points)-min(x for x,y in points)+1,max(y for x,y in points)-min(y for x,y in points)+1)
    expected=extents[i] if i<493 else form_extents[tuple(provenance['native_forms'][i-493])]
    assert measured==expected,(i,measured,expected)
for index in range(2):
    data=(P/('res/arena/arena_bg%d.bin'%index)).read_bytes();size=struct.unpack_from('<I',data)[0]
    assert size<=32768 and size%32==0 and len(data)==4132+size
    tilemap=struct.unpack_from('<2048H',data,36);assert max(tilemap)<size//32
preserved=None
if args.arena:
    original=(args.arena/'source/assets_data.c').read_text()
    original_pack=(args.arena/'assets/assets.pack').read_bytes()
    assert pack[:len(original_pack)]==original_pack,'Accepted tile dictionaries changed'
    original_blocks=re.findall(r'    \{"[^\n]+\n(?:        [^\n]+\n){5}    \}\}',original)
    canonical_blocks=re.findall(r'\{"[^\n]+\n(?:        [^\n]+\n){5}    \}\}',canonical)
    canonical_by_dex={int(re.match(r'\{"[^"]+",(\d+),',b)[1]):b for b in canonical_blocks}
    old_styles=list(map(int,re.search(r'asset_species_animation_style\[\]\s*=\s*\{([^}]+)',original)[1].split(',')))
    assert len(original_blocks)==len(old_styles)==386
    preserved=[]
    for block,style in zip(original_blocks,old_styles):
        dex=int(re.match(r'\s*\{"[^"]+",(\d+),',block)[1])
        if style:
            assert styles[dex-1]==style,(dex,style,styles[dex-1])
            assert canonical_by_dex[dex].strip()==block.strip(),('Directional metadata changed',dex)
            preserved.append(dex)
    assert len(preserved)==187 and all(reductions[dex-1]==1 for dex in preserved)
for directory,pack_name in [('gen4','gen4.pack'),('directional','directional.pack')]:
    extension_path=P/'res/arena'/directory/'manifest.json'
    if not extension_path.exists():continue
    extension=json.loads(extension_path.read_text())
    extension_pack=(extension_path.parent/pack_name).read_bytes()
    assert hashlib.sha256(extension_pack).hexdigest()==extension['pack_sha256']
    base=None
    for entry in extension['species']:
        dex=entry['dex'];assert styles[dex-1]==1
        assert reductions[dex-1]==entry['source_integer_reduction']
        for generated,original in zip(records[(dex-1)*5:dex*5],entry['animations']):
            off,size,count,total,hit=map(int,generated[:5])
            shift=off-original['offset']
            if base is None:base=shift
            assert shift==base and size==original['size']
            assert (count,total,hit)==(original['frames'],original['total_ticks'],original['hit_tick'])
            assert times[generated[5]]==original['durations']
            assert list(map(int,generated[6].split(',')))==original['ground']
            assert hashlib.sha256(pack[off:off+size]).hexdigest()==original['sha256']
    assert pack[base:base+len(extension_pack)]==extension_pack
print(json.dumps(dict(canonical_species=493,directional_species=sum(styles),preserved_directional_source_records=None if preserved is None else len(preserved),native_alternate_forms=form_count,validated_unique_frames=frames,max_species_bytes=max(cost),largest_four_distinct_bytes=sum(sorted(cost,reverse=True)[:4]),pack_bytes=len(pack),pack_sha256=hashlib.sha256(pack).hexdigest()),indent=2))
