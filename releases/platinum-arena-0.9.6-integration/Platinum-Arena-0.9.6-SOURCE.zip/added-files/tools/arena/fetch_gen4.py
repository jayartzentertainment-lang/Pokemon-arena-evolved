from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import argparse,urllib.request,urllib.error,json,xml.etree.ElementTree as E,hashlib,time
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser(description='Fetch pinned directional artwork and original artist credits; reuse downloaded files.')
parser.add_argument('--output',type=Path,default=ROOT/'res/arena/gen4/source')
selection=parser.add_mutually_exclusive_group()
selection.add_argument('--missing-from',type=Path,help='Fetch canonical species missing from this generated provenance file')
selection.add_argument('--dex-manifest',type=Path,help='Reuse the species selection from an existing download or compiled manifest')
args=parser.parse_args()
P=args.output;P.mkdir(parents=True,exist_ok=True);PIN='d25607ff4746957df10bdb78db090887cd94f1f8';BASE='https://raw.githubusercontent.com/PMDCollab/SpriteCollab/'+PIN+'/';MOTIONS=['Idle','Walk','Shoot','Attack','SpAttack'];names=(Path(__file__).resolve().parents[2]/'generated/species.txt').read_text().splitlines()[1:494]
def fetch(rel,dest):
 if dest.exists():return dest.read_bytes()
 for attempt in range(2):
  try:
   with urllib.request.urlopen(BASE+rel,timeout=25) as r:data=r.read(4000001)
   if len(data)>4000000:raise ValueError('Unexpected resource size')
   dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);return data
  except urllib.error.HTTPError as e:
   if e.code==404:raise
  except urllib.error.URLError:
   if attempt:raise
 raise ValueError('Resource transfer failed')
def one(dex):
 d=P/f'{dex:04}';rel=f'sprite/{dex:04}/';raw=fetch(rel+'AnimData.xml',d/'AnimData.xml');nodes={a.findtext('Name'):a for a in E.fromstring(raw).findall('./Anims/Anim')};credits=fetch(rel+'credits.txt',d/'credits.txt').decode();anims=[]
 for pose in MOTIONS:
  actual=pose if pose in nodes else 'Shoot' if 'Shoot' in nodes else 'Attack' if 'Attack' in nodes else 'Idle';seen=set()
  while nodes[actual].findtext('CopyOf'):
   if actual in seen:raise ValueError('Animation alias cycle')
   seen.add(actual);actual=nodes[actual].findtext('CopyOf')
  n=nodes[actual];png=fetch(rel+actual+'-Anim.png',d/(actual+'-Anim.png'));times=[int(a.text) for a in n.findall('./Durations/Duration')];assert times and all(1<=x<=255 for x in times)
  anims.append(dict(pose=pose,actual=actual,width=int(n.findtext('FrameWidth')),height=int(n.findtext('FrameHeight')),durations=times,hit_frame=int(n.findtext('HitFrame','0')),png_sha256=hashlib.sha256(png).hexdigest()))
 return dict(dex=dex,species=names[dex-1].removeprefix('SPECIES_'),directory=str(d),animations=anims,credits=credits,xml_sha256=hashlib.sha256(raw).hexdigest())
fetch('LICENSE.md',P/'LICENSE.md');rows=[];errors=[];start=time.time()
if args.dex_manifest:
 selected=json.loads(args.dex_manifest.read_text());requested=selected.get('requested_dex',[row['dex'] for row in selected['species']])
else:requested=sorted(set(range(1,494))-set(json.loads(args.missing_from.read_text())['directional_dex'])) if args.missing_from else list(range(387,494))
assert requested and all(1<=dex<=493 for dex in requested),'No missing species: use --dex-manifest to refresh a staged extension'
with ThreadPoolExecutor(max_workers=12) as pool:
 futures={pool.submit(one,dex):dex for dex in requested}
 for f in as_completed(futures):
  dex=futures[f]
  try:rows.append(f.result())
  except Exception as e:errors.append(dict(dex=dex,error=str(e)))
  if (len(rows)+len(errors))%10==0 or dex in (387,390,393):print(json.dumps(dict(done=len(rows)+len(errors),success=len(rows),errors=len(errors),last=dex,seconds=round(time.time()-start))),flush=True)
report=dict(requested_dex=requested,repo='PMDCollab/SpriteCollab',commit=PIN,source_base=BASE,species=sorted(rows,key=lambda x:x['dex']),errors=errors,seconds=round(time.time()-start),download_bytes=sum(x.stat().st_size for x in P.glob('????/*') if x.is_file()))
(P/'download-manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='species'},indent=2))
