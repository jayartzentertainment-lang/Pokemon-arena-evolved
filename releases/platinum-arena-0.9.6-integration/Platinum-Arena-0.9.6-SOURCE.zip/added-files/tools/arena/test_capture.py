#!/usr/bin/env python3
"""Exercise real live capture/party/combat against narrow native reward mocks."""
import argparse
from pathlib import Path
import re
import shlex
import subprocess

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument("--sanitize", action="store_true")
args = parser.parse_args()
out = ROOT / "build/arena-capture-checks" / ("sanitize" if args.sanitize else "normal")
out.mkdir(parents=True, exist_ok=True)
pad = ROOT / "subprojects/NitroSDK-4.2.30001/include/nitro/pad/common/pad.h"
constants = re.findall(r"^#define\s+(PAD_(?:BUTTON|KEY)_[A-Z]+)\s+(0x[0-9a-fA-F]+)\s*$", pad.read_text(), re.M)
prefix = out / "raw_pad.h"
prefix.write_text("#include <stdint.h>\ntypedef int32_t s32;\n" + "\n".join(
    f"#define {key} {value}" for key, value in constants) + "\n")
flags = ["-std=c11", "-Wall", "-Wextra", "-Werror", "-O2",
         "-DPOKEPLATINUM_GENERATED_ENUM", "-Itests/arena/party_stubs", "-Iinclude", "-Ibuild",
         "-include", str(prefix)]
if args.sanitize:
    flags += ["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
sources = ["tests/arena/test_capture.c", "src/arena/capture.c", "src/arena/party_bridge.c",
           "src/arena/controls.c",
           "src/arena/combat.c", "src/arena/move_data.c", "src/arena/vendor/arena_moves.c",
           "src/arena/vendor/arena_navigation.c", "src/arena/vendor/arena_physics.c"]
commands = [["cc", *flags, *sources, "-Wl,--wrap=ArenaParty_Store", "-o", str(out/"test_capture")],
            [str(out/"test_capture")]]
for index, command in enumerate(commands):
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out/f"{index}.log").write_text(shlex.join(command)+"\n"+result.stdout+f"\nexit={result.returncode}\n")
    print(result.stdout, end="", flush=True)
    result.check_returncode()
