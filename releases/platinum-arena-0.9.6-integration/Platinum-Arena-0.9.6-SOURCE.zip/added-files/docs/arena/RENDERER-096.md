# Native battle presentation 0.9.6

## Audit and retained systems

The previous renderer used one opaque 256x192 subscreen Window with hand-filled boxes, plus native font glyphs and two altered native healthbox silhouettes. Main OBJ occupied 64,832 / 65,536 bytes. Actors already had five eight-direction authored animation slots, phase-aware attack timing, planted feet, shared cached pose pools, held shields, continuous source beams and event-driven contact effects. Those systems remain in place.

The supplied `sprite.zip` was identified earlier as Venusaur. Its complete Hurt and Charge images exist locally. The staged roster sources otherwise contain the five imported poses, not matching Hurt/Charge sheets. No additional species-specific reaction sheets are claimed here.

## Battle artwork and memory

`tools/arena/generate_battle_ui.py` reads the original Platinum `res/prebuilt/battle/graphic/pl_batt_bg.narc`: character member 28, palette 242, battle command / move panel / disabled panel / Pokeball screen maps 42, 43, 47 and 49. It composes native bevels and corners by extending their flat centers. Native player/enemy healthbox outlines are retained with a silver name surface. The immutable art is 207 unique 4bpp tiles (6,624 bytes), a 2,048-byte screen map and a 32-byte palette. Palette index zero is reserved, so every visible art pixel remains opaque on DS hardware.

BG1 holds this art; BG0 holds transparent native-font text and changing bars. The subscreen uses VRAM C (128 KiB), with art at 0, text character data at 0x8000, art map at 0xF000 and text map at 0xF800. These regions do not overlap. Top battlefield BG/OBJ allocation is unchanged except for 512 sourced wind bytes. Final main OBJ: 65,344 / 65,536 bytes (192 spare). Shadow art reuses two former primitive slots. No per-frame allocation, file I/O, texture upload or species palette swap was added.

The lower HUD shows team stocks, current player and target species/level/HP/status, stamina, persistent stat-stage changes, all four learned move names/types/current PP/cooldown seconds, selected A/X bindings, the canonical PP-free natural move, and touchable Party/Bag/Settings buttons. In 2v2, small additional ally/opponent HP bars occupy the resource capsule.

## Touch contract

`ArenaRender_TouchMove(x,y)` returns a zero-based learned move slot, otherwise -1. Rectangles use inclusive left/top and exclusive right/bottom:

| Slot | Left | Top | Right | Bottom |
| --- | --- | --- | --- | --- |
| 0 | 8 | 80 | 124 | 114 |
| 1 | 132 | 80 | 248 | 114 |
| 2 | 8 | 118 | 124 | 152 |
| 3 | 132 | 118 | 248 | 152 |

`ArenaRender_TouchCommand(x,y)` covers y 168..191: x 0..84 returns Party=0, 85..169 Bag=1, 170..255 Settings=2. Modal text retains the preexisting renderer origin (9,8); the caller owns modal touch handling.

## Creature and effect presentation

- Authored idle/walk/attack timing remains simulation-driven. Discrete direction changes pass through intermediate eight-direction poses every two frames, or three for heavy species. Active attacks and dashes still align immediately with their real hit direction.
- Motion profiles distinguish grounded, agile, heavy, floating and winged species. Floating bodies keep altitude and drift through reactions; heavy gait uses smaller deformation and planted footfalls; agile idle includes brief alert foot lifts. Ground shadows remain at the collision plane.
- Guard holds an authored anticipation pose. Guard recoil follows the actual blocked direction. Hurt actors remain visible, lean with real knockback and preserve altitude where appropriate instead of blinking out.
- Venusaur uses its actual supplied two-frame Hurt and ten-frame Charge poses. `tools/arena/import_reaction_poses.py` validates canvas bounds and exact existing palette conversion, then emits resident compressed pose dictionaries. The metadata controller can accept more species later. Other species use their compatible existing authored poses plus motion-based recoil; they do not gain new invented body art.
- `ArenaRender_DeployActor` plays a 28-frame cached source-Pokeball entry and body reveal, including same-species replacement. Knocked-out bodies settle and collapse over 22 render frames when replacement timing permits it. These are presentation timers and grant no protection or action delay.
- Supplied 32x16 wind streaks rotate in all eight directions, follow the simulation's trail positions and age into a thinner frame, with a small ground chip late in the trail. The existing dash stamina/avoidance mechanics are unchanged by rendering.
- The supplied VFX atlas now contains distinct claw, leaf, psychic, shadow, buff and debuff families within its old 56-frame allocation. Stat arrows begin when actual simulation stages change. Status conditions periodically emit their corresponding aura. Claw/leaf follow-through appears during the move's active phase; contact impact bursts remain driven by successful hit events.
- Continuous beams, common clash coordinates, source sounds and source actor palettes remain supported. Beam emission includes the same floating/attack presentation offsets as its source body.

## Verification boundary

The generators completed successfully. Static checks verified map tile bounds, reserved zero transparency, opaque visible BG pixels, four-button hit regions and the OBJ budget. Native compilation, live glyph contrast, emulated input and performance must be assessed in the root task's actual Nintendo DS build/emulator run; these results are not implied by source generation.
