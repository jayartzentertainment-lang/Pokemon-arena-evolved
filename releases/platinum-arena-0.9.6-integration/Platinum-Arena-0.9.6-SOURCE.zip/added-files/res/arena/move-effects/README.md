# Move-specific effects

Swift's star art is selected from the user-supplied
`DS _ DSi - Pokemon Diamond _ Pearl - Miscellaneous - Attack Graphics.zip`.
Archive SHA-256:
`91b0c12f5fab445321a9c99a7578b6829626c27899a2f6d907917ce995801e08`.

The original `source/Swift.png` is retained unchanged. `manifest.json` records
the source hash, exact frame cuts, conversion and native tile output. Recreate
the bounded art include with `tools/arena/import_swift_art.py`.

This is artwork selected for the existing Swift projectile implementation,
not a replacement move script or a full imported Diamond/Pearl animation.
The supplied Swift sheet does not establish an individual ripper credit;
retain the full source/archive provenance and add verified attribution when
available. Do not assign another sheet's embedded credit to Swift by inference.

The existing Ranger/PMD/KOF art and its recorded credits remain separate.
