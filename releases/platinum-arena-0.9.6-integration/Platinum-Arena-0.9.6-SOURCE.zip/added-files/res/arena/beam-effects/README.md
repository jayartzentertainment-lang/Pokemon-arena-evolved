# Original continuous beam strips

The medium fire, thin fire, water, and ice styles retain the original four-frame strips from Pokémon Ranger: Guardian Signs (Nintendo DS), supplied by the user as `0/104.png`, `0/106.png`, `0/102.png`, and `0/108.png`. Only these four source sheets are retained under `source/`. The style names describe their selected visual roles; the ripped filenames do not establish move IDs.

Credits: Nintendo/The Pokémon Company. The source archive is `DS _ DSi - Pokemon Ranger 3_ Guardian Signs - Miscellaneous - Attack Effects.zip` (1,000,852 bytes; SHA-256 `6de9c9527a722f71b2bbfd910867a2327c5928beca97c26dae44e93cc4bdda6b`). The supplied archive contains no author, readme, or license notice, and no source URL is recorded. This provenance record does not grant rights to the underlying game artwork. Exact source hashes are recorded in `manifest.json`.

Regenerate from the retained subset with:

```sh
python3 tools/arena/import_beam_effects.py
```

For frame `i` from 0 to 3, all styles use the same source crop `(4, 40*i+4, 132, 40*i+36)`. Magenta registration pixels (`r>190`, `b>190`, `g<100`) become transparent. The resulting common 128×32 canvas is preserved without resizing or recentering. All 13 opaque source colors are retained at separate palette indices 1–13: five shared fire colors, four water colors, and four ice colors. Their RGB channels are already divisible by 8, so their native RGB5 values require no rounding, color quantization, or color merging. Index 0 is transparent; indices 14–15 are unused.

The generated arrays in `src/arena/beam_effects.c` contain four styles × four frames × 2,048 bytes = **32,768 tile bytes**, plus one 32-byte palette. Each frame is four contiguous 32×32 4bpp OBJ images, ordered left to right at byte offsets 0, 512, 1,024, and 1,536. Each chunk contains 4×4 row-major 8×8 tiles; each byte stores the left pixel in its low nibble and the next pixel in its high nibble. This order permits one selected frame to be uploaded into a shared **2,048-byte OBJ image slot**, using four 32×32 OAM objects and one palette bank. Square chunks also leave room inside their double-area affine bounds for diagonal rotation.

Array bounds are `style < ARENA_BEAM_STYLES` (4) and `frame < ARENA_BEAM_FRAMES` (4). Selection, animation cadence, angle, placement, and live VRAM ownership belong to the renderer; this importer only emits bounded native image and palette data.
