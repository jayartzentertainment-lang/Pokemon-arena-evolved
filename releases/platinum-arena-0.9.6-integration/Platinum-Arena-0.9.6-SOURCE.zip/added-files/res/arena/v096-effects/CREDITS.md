# Source artwork and attribution

All selected artwork comes from sprite archives supplied for this project.
No image generation was used. Retained source PNGs are byte-for-byte copies;
their SHA-256 values are in `manifest.json`.

- **Pokémon Diamond/Pearl, Nintendo DS:** claw strokes, leaves, psychic
  crescents, shadow particles and stat arrows. Original artwork: Nintendo,
  The Pokémon Company and Game Freak. The supplied `Status.png` sheet visibly
  credits its rip to **KLNOTHINCOMIN**. Other selected D/P sheets do not contain
  a verified individual ripper credit, so that credit is not assigned to them.
- **Pokémon Ranger: Guardian Signs, Nintendo DS:** defensive rings and a tiny
  open wind curl. Original artwork: Nintendo, The Pokémon Company and the
  game's creators.
- **Pokémon Mystery Dungeon: Explorers of Sky, Nintendo DS:** fire, water,
  electrical and ice sequences. Original artwork: Nintendo, The Pokémon
  Company and Chunsoft.
- **The King of Fighters XI, PlayStation 2:** impact, clash and tapered curved
  sweep sprites. Original artwork: SNK. The wind's quiet gray-green tint and
  layered arrangement are adaptations made by this importer.

Archive filenames, byte counts and SHA-256 values are preserved in
`archives.json`. The supplied archives contain no separate README or licence
grant. This file records provenance and does not grant rights to the original
game artwork.
