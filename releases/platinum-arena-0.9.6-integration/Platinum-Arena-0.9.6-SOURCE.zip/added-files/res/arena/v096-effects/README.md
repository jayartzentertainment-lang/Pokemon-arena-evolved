# Supplied VFX conversion for 0.9.6

This pack replaces the existing **56 × 32×32 4bpp** extra-effects atlas in
place. Its 28,672 tile bytes occupy the same OBJ allocation as before. Six
additional families use the former upper four frames of each original family
except guard: slash, leaves, psychic crescent, shadow, stat up and stat down.
Guard keeps all eight cels because held shields address its cels directly.
The other original families keep four readable active cels rather than empty
first/last source frames. The renderer retains the old family enum values.

Two extra 32×16 wind frames use **512 bytes** and primitive palette bank 15's
previously unused slots 13–15, plus its existing white at slot 1. They combine
the supplied KOF 164/165 curved, tapered sweeps with a tiny open Ranger 124
air curl. Their color adaptation is a quiet gray-green. Two thin layered
curves communicate motion; neither frame contains an opaque backdrop.

All tiles and palettes are compiled into `src/arena/v096_effect_art.inc`.
The renderer uploads the atlas once and selects cached frame indices. The
pack performs no per-frame filesystem access or allocation. Frame selection
and anchor metadata do not change combat damage, status rules or hitboxes.

| Family | Native atlas frames | Actual supplied artwork |
| --- | --- | --- |
| Fire | 0–3 | PMD `move_VFX/0005/000` active bursts |
| Slash/contact | 4–7 | D/P `Scratch-Shadow-Claw.png` gold claw strokes, reveal/hold/retract adaptation |
| Water | 8–11 | PMD `0103/000` expanding splash |
| Leaves | 12–15 | D/P `Leaves.png`, two registered leaves using the four source orientations |
| Electric | 16–19 | PMD `0215/000` electrical arc/discharge |
| Psychic | 20–23 | D/P `Psycho-Cut.png` four original crescent cels |
| Ice | 24–27 | PMD `0141/000` crystal burst and fragments |
| Shadow/dark | 28–31 | D/P `Shadow-Force.png` four lower shadow particles |
| Body impact | 32–35 | KOF effects 0, 1, 3 and 6 |
| Stat up | 36–39 | D/P `Status.png` isolated yellow up-arrows, rising motion |
| Guard | 40–47 | Ranger `24.png` eight registered expansion/recession cels |
| Clash | 48–51 | KOF effects 390, 392, 394 and 397 |
| Stat down/status | 52–55 | D/P `Status.png` isolated cyan down-arrows, falling motion |

The 15 shared opaque colors approximate the original sprite palettes while
preserving different silhouettes. Index 0 is transparency. Source alignment
is computed once per sequence, with one common scale and center anchor;
individual growing/shrinking frames are never independently fitted to fill
their slots. Original selected PNG bytes are preserved unchanged in `source/`.

`manifest.json` records exact crops, original SHA-256 values, shared bounds,
native anchors, frame cadence, compositing, palette, native tile digests and
candidate canonical move IDs. Candidate mappings describe compatible family
presentation, not a claim to reproduce the source game's move scripts.
The renderer determines runtime dispatch; beams and Swift retain their
separately imported exact artwork from `beam-effects/` and `move-effects/`.

`native-contact.png` and `native-wind.png` are decoded from the generated
4bpp tile bytes. `selected-source-contact.png` shows the normalized original
source colors for comparison. `source-dp-page*.png` review all 95 original
D/P sheets; `source-ranger-page*.png` review all 256 Ranger sheets. The original
KOF contact sheet and PMD representative-sequence contact sheet were also
inspected at `/workspace/platinum-port/extra-effects/`. These broad reviews
do not mean every one of PMD's 19,044 individual source frames was viewed.

`source-inventory.json` enumerates all D/P sheets with selected/deferred
dispositions and hashes, package image counts, and PMD sequence frame counts.
Large opaque backgrounds, credit panels, side-view-only presentation and
unused move families are deferred under the fixed OBJ budget. This coherent
slice does **not** import all 95 D/P sheets or all PMD sequences into runtime.

Rebuild from the retained original subset:

```sh
python3 tools/arena/import_v096_effects.py --retained-source
```

Rebuild and refresh the broad inventory from the reviewed full source trees:

```sh
python3 tools/arena/import_v096_effects.py \
  --extra-source /workspace/platinum-port/extra-effects \
  --dp-source /workspace/asset-review/arsenal-2026-10-21/diamond-pearl-attack-graphics/source
```

Full-sheet source review contact pages are review artifacts retained from the
intake; the importer deterministically regenerates the selected source/native
contact previews, atlas, wind frames and exact selection manifest.

Credits and original archive identities are recorded in `CREDITS.md` and
`archives.json`. The D/P status sheet visibly credits **KLNOTHINCOMIN**;
the complete original sheet and its credit panel remain in `source/dp/`.
