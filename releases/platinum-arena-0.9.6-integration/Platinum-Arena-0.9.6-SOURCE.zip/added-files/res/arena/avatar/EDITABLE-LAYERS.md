# Supplied editable trainer layers

`custom.bin` is native artwork assembled from the user's `pokemon png.rar`
upload. It is independent of the existing Lucas/Dawn, Hoenn and Kanto artwork.
The files under `/workspace/asset-review/arsenal-2026-10-21/pokemon-trainer-png/source/pokemon png`
remain unmodified. `custom-provenance.json` records each selected source path,
SHA-256, cleanup rule, native entry, and the completed pack SHA-256.

Reproduce the bank with:

```sh
python tools/arena/import_editable_avatars.py --source '/path/to/pokemon png'
```

The converter uses Pillow and the existing built native NSBTX dictionaries to
preserve shared frame addresses. It never automatically recenters individual
layers or frames. The PNG exports have precisely doubled pixels: each source
64x64 overworld cell reduces to a native 32x32 cell, with all original layer
offsets retained. Source rows are south, west, east, north; native output rows
are north, south, west, east. Low alpha editor/reference pixels are discarded;
foreign reference colors in black hair exports are masked. Source shading is
mapped to the fixed semantic 16-color palette without image quantization.

Two body bases each support four authored hairstyles, T-shirt/Hoodie/Open
jacket tops, Jeans/Shorts/Capris, and None/Beanie/Fedora headwear. The base feet
also support a shoe dye. There are no independent shoe shape assets. The
tops, legwear and hairstyles have distinct pixel **and silhouette** hashes for
every body; these checks run during conversion. The proof PNGs show choices
with identical dyes and no hats, at four times native overworld resolution.

The exact source walk, run, bicycle, full-body front and five throwing poses
are included. Unsupported scripted field gestures use directionally correct
custom walk poses while preserving the selected appearance. Back portraits
are waist-up, so legwear is correctly absent there. Five source throwing poses
map to native eight-cell timing as `[0,0,1,2,2,3,4,4]`. Every layer uses the
same back crop and fit. Front/card portraits retain the entire visible figure.

## Binary contract

All words are little endian. Header: `AVC1`, version `1`, entry count `416`,
reserved `0`. Each entry contains four u32 words: byte offset, data size,
frame stride, palette size (`0`). Entry index is
`(body * 16 + state) * 13 + layer`. Repeated identical payloads share offsets.

Layer indices are `0` body, `1..3` legwear, `4..6` tops, `7..10` hair,
`11..12` hats. Compose nonzero pixels in that order. Hat None skips the hat
layer. The body feet and every layer's source outline remain visible.

| State | Payload | Stride |
| --- | --- | --- |
| 0..11 | Native 32x32 linear 4bpp field frames, alias-normalized | 512 |
| 12 | Four north/south/west/east standing 32x32 linear 4bpp frames | 512 |
| 13 | 6144 bytes of 8bpp semantic indices for card character tiles | 6144 |
| 14 | Eight native throw OAM cells, 3200 bytes each, tiled 4bpp | 25600 |
| 15 | One 80x80 native front OAM cell, tiled 4bpp | 3200 |

State13 has a blank tile0 followed by a 6x10 tile portrait, each tile containing
64 semantic pixel indices. The runtime adds its native palette offset after
composition and places these tiles at card map x22/y6, as in the regional
avatar pack. The front is reduced from160x160 to80x80 and cropped x16..64 for
the 48x80 card, without rebasing any layer. State14/15 OAM encoding was checked
byte-for-byte against the project's prebuilt `nitrogfx` converter.

Palette slots: 0 transparent; 1 outline; 2..4 skin light/shade/deep; 5..7 hair
light/shade/deep; 8..10 top and hat light/shade/deep; 11..12 legwear; 13..14
shoes; 15 fixed white/metal. Palette choice and composition occur when the
appearance/state changes, with fixed runtime buffers and no per-frame heap
allocation.

The supplied archive contains no separate licence or verified sprite credit.
Its document metadata names Chris Loesche; that does not establish authorship.
