#ifndef POKEPLATINUM_ARENA_REWARDS_H
#define POKEPLATINUM_ARENA_REWARDS_H

#include "field_battle_data_transfer.h"

typedef struct ArenaLearnMove {
    u8 partySlot;
    u8 level;
    u16 move;
} ArenaLearnMove;

/* One offline battle is active at a time. Begin must precede every session. */
void ArenaRewards_Begin(FieldBattleDTO *dto);
/* Call for active actor bindings at entry and after replacements/switches. */
void ArenaRewards_OnSendOut(FieldBattleDTO *dto, int owner, int partySlot);
void ArenaRewards_OnDefeat(FieldBattleDTO *dto, int enemyOwner, int partySlot, u32 playerParticipants);
void ArenaRewards_Finalize(FieldBattleDTO *dto, int result);

/* Full movesets are never overwritten without an explicit player decision. */
int ArenaRewards_PendingMoveCount(void);
BOOL ArenaRewards_PendingMove(int index, ArenaLearnMove *out);
BOOL ArenaRewards_ResolveMove(FieldBattleDTO *dto, int index, int replaceSlot);

/* Initial action controls throw ordinary Poke Balls; other balls remain intact. */
BOOL ArenaRewards_CanThrow(FieldBattleDTO *dto);
BOOL ArenaRewards_ConsumeBall(FieldBattleDTO *dto, int ball);
int ArenaRewards_CatchShakes(FieldBattleDTO *dto, int enemyOwner, int partySlot, int ball, u32 *rngState);
BOOL ArenaRewards_Catch(FieldBattleDTO *dto, int enemyOwner, int partySlot, int ball);

#endif
