#ifndef PLATINUM_ARENA_HEAP_H
#define PLATINUM_ARENA_HEAP_H

#include <nitro/types.h>

/* Read-only preflight for a native child heap. Total free bytes may be split
 * into blocks and Heap_Create asserts on an oversized contiguous request. */
u32 ArenaHeap_MaxAllocatableSize(u32 heapID);

#endif
