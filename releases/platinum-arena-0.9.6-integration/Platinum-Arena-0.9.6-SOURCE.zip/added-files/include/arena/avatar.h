#ifndef POKEPLATINUM_ARENA_AVATAR_H
#define POKEPLATINUM_ARENA_AVATAR_H

/* Saved trainer identity. Custom garments use authored directional layers,
 * while the original regional profiles retain their complete native rigs. */
#ifdef ARENA_AVATAR_HOST
#include <stdint.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef struct SaveData SaveData;
#else
#include <nitro/types.h>
#include "savedata.h"
#endif

#define ARENA_AVATAR_SKIN_COUNT 4
#define ARENA_AVATAR_HAIR_COUNT 6
#define ARENA_AVATAR_OUTFIT_COUNT 8
#define ARENA_AVATAR_REGION_COUNT 4
#define ARENA_AVATAR_PRESET_COUNT 3
#define ARENA_AVATAR_CUSTOM_REGION 3
#define ARENA_AVATAR_STYLE_COUNT 4
#define ARENA_AVATAR_TOP_COUNT 3
#define ARENA_AVATAR_LEGWEAR_COUNT 3
#define ARENA_AVATAR_HAT_COUNT 3
#define ARENA_AVATAR_LEG_COLOR_COUNT 4
#define ARENA_AVATAR_SHOE_COLOR_COUNT 4
/* 663,552 bounded custom identities; twenty payload bits, seven version bits
 * and CRC5 occupy the same four original PlayerSave padding bytes. */
#define ARENA_AVATAR_CUSTOM_PROFILE_COUNT 663552u
#define ARENA_AVATAR_CUSTOM_RECORD_MARKER 0x5e
/* Two tag bits differ from v2, so a one-bit error cannot select that decoder. */
#define ARENA_AVATAR_RECORD_TAG 0xA913
#define ARENA_AVATAR_LEGACY_RECORD_TAG 0xA902
#define ARENA_AVATAR_PLAYER_SAVE_BYTES 44

typedef struct ArenaAvatarProfile {
    u8 body;
    u8 skin;
    u8 hair;
    u8 outfit;
    u8 regional; // 0 Sinnoh Lucas/Dawn; 1 Hoenn Brendan/May; 2 Kanto Red/Leaf
    u8 hairstyle;
    u8 top;
    u8 legwear;
    u8 hat;
    u8 legColor;
    u8 shoes; // Shoe dye; the source provides no separate shoe silhouettes.
} ArenaAvatarProfile;

void ArenaAvatar_Default(ArenaAvatarProfile *profile, int body);
void ArenaAvatar_CustomDefault(ArenaAvatarProfile *profile, int body);
int ArenaAvatar_IsValid(const ArenaAvatarProfile *profile);
/* Uses only the four audited padding bytes of the original PlayerSave. */
void ArenaAvatar_ReadRecord(const u8 *playerSave, int body, ArenaAvatarProfile *profile);
void ArenaAvatar_WriteRecord(u8 *playerSave, const ArenaAvatarProfile *profile);
void ArenaAvatar_Load(SaveData *saveData, ArenaAvatarProfile *profile);
void ArenaAvatar_Save(SaveData *saveData, const ArenaAvatarProfile *profile);
void ArenaAvatar_Bind(SaveData *saveData);
const ArenaAvatarProfile *ArenaAvatar_CurrentProfile(void);
/* RGB555 semantic recoloring of native player palettes; never recolors UI. */
void ArenaAvatar_ApplyPalette(const ArenaAvatarProfile *profile, u16 *colors, int count);
void ArenaAvatar_ApplyPlayerTexture(void *textureResource);
/* Art state 12:64x128 field preview, available for every base. Custom profiles
 * accept facing frames 0..3 (north, south, west, east), scaled from their rig.
 * Regional states 13:card chars+map,
 * 14:source-adapted eight-cell throw, 15:trainer front. */
int ArenaAvatar_LoadCardArt(const ArenaAvatarProfile *profile, void *characters, u32 characterSize, void *tilemap, u32 tilemapSize, u16 palette[16]);
int ArenaAvatar_LoadArt(const ArenaAvatarProfile *profile, int state, int frame,
    void *destination, u32 size, u16 palette[16]);
/* Creator-only preview; 6144 bytes selects 96x128 at 3x, 512 bytes selects
 * native 32x32. Step 0..3 uses the same walking rig as play. */
int ArenaAvatar_LoadPreview(const ArenaAvatarProfile *profile, int facing, int step,
    void *destination, u32 size, u16 palette[16]);
int ArenaAvatar_LoadCreatorPortrait(const ArenaAvatarProfile *profile, void *destination,
    u32 size, u16 palette[16]);

#endif
