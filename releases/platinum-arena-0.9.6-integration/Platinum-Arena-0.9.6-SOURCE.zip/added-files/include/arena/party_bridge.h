#ifndef PLATINUM_ARENA_PARTY_BRIDGE_H
#define PLATINUM_ARENA_PARTY_BRIDGE_H

#include "arena/combat.h"
#include "field_battle_data_transfer.h"

#define ARENA_PARTY_HP_SCALE 8
#define ARENA_PARTY_STAT_SCALE 4
#define ARENA_PARTY_SLOT_NONE 0xFF

typedef struct ArenaPartyActor {
    u8 owner;
    u8 slot;
    u8 active;
    u8 level;
    u8 form;
    u8 ppUps[4];
    u8 pp[4];
    u16 moves[4];
    u16 ability;
    u16 heldItem;
    u32 status;
} ArenaPartyActor;

typedef struct ArenaPartyMember {
    u16 hp;
    u16 nativeHp;
    u16 nativeMaxHp;
    u8 initialized;
    u8 defeatReported;
    u8 stamina;
    u8 regenDelay;
    u8 dashCooldown;
    u16 cooldown[4];
    u32 cooldownFrame;
} ArenaPartyMember;

typedef void (*ArenaPartyDefeatCallback)(void *context, unsigned actor,
    unsigned owner, unsigned slot, Pokemon *mon, u32 playerParticipants);

/* Allocate this with the session, on its heap. It owns no party/Pokemon data.
 * DTO parties keep Platinum's encryption, ownership and field-save contract. */
typedef struct ArenaPartyBridge {
    FieldBattleDTO *dto;
    Combat *combat;
    ArenaPartyActor actor[COMBAT_FIGHTERS];
    ArenaPartyMember member[MAX_BATTLERS][MAX_PARTY_SIZE];
    u32 playerParticipants[MAX_BATTLERS][MAX_PARTY_SIZE];
    ArenaPartyDefeatCallback onDefeat;
    void *defeatContext;
    u8 actorCount;
    u8 controlActor;
    u8 result;
    u8 begun;
    u8 manualPlayerReplacement;
} ArenaPartyBridge;

BOOL ArenaParty_Begin(ArenaPartyBridge *bridge, FieldBattleDTO *dto, Combat *combat);
void ArenaParty_SetDefeatCallback(ArenaPartyBridge *bridge,
    ArenaPartyDefeatCallback callback, void *context);
/* Run after every simulation tick, including a provisional combat winner.
 * Stores all actors before rewards, reports each enemy member once and fills
 * fainted slots from their real owner's reserves before deciding the result. */
int ArenaParty_Advance(ArenaPartyBridge *bridge);
void ArenaParty_Store(ArenaPartyBridge *bridge);
/* Refresh after native EXP/level-up/move-learning/capture changes. Fractional
 * action HP persists when the native HP value has not actually changed. */
void ArenaParty_Refresh(ArenaPartyBridge *bridge);
BOOL ArenaParty_SwitchPlayer(ArenaPartyBridge *bridge, unsigned partySlot);
/* Native session pauses for a player-owned reserve choice after fainting.
 * Default remains automatic for callers that do not provide a party menu. */
void ArenaParty_SetManualPlayerReplacement(ArenaPartyBridge *bridge, BOOL enabled);
BOOL ArenaParty_NeedsPlayerReplacement(const ArenaPartyBridge *bridge);
Pokemon *ArenaParty_ActorPokemon(const ArenaPartyBridge *bridge, unsigned actor);
u32 ArenaParty_PlayerParticipants(const ArenaPartyBridge *bridge,
    unsigned owner, unsigned partySlot);
BOOL ArenaParty_PlayerSlotAvailable(const ArenaPartyBridge *bridge, unsigned partySlot);

#endif
