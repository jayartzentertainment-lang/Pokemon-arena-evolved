#ifndef PLATINUM_ARENA_SESSION_H
#define PLATINUM_ARENA_SESSION_H
#include "field_battle_data_transfer.h"
#include "overlay_manager.h"
BOOL ArenaSession_CanRun(const FieldBattleDTO *dto);
/* 0 running, 1 complete with native DTO result, -1 clean vanilla fallback. */
int ArenaSession_Run(ApplicationManager *appMan);
/* Title-screen practice runs a private DTO and never accesses the save. */
extern const ApplicationManagerTemplate gArenaPracticeAppTemplate;
#endif
