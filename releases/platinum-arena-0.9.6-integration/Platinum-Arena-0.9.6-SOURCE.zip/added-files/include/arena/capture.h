#ifndef PLATINUM_ARENA_CAPTURE_H
#define PLATINUM_ARENA_CAPTURE_H
#include "arena/party_bridge.h"
enum ArenaCapturePhase { ARENA_CAPTURE_IDLE, ARENA_CAPTURE_AIM, ARENA_CAPTURE_THROW,
    ARENA_CAPTURE_ABSORB, ARENA_CAPTURE_DROP, ARENA_CAPTURE_SHAKE, ARENA_CAPTURE_BREAK,
    ARENA_CAPTURE_CAUGHT, ARENA_CAPTURE_MISS };
typedef struct ArenaCapture {
    ArenaPartyBridge *party;
    s32 aimX,aimY,ballX,ballY,startX,startY,previousX,previousY,velocityX,velocityY;
    u32 random,clock;
    u16 age,notice;
    u8 phase,target,heldLatch,manual,shakes,finished,recovery;
    const char *message;
} ArenaCapture;
void ArenaCapture_Init(ArenaCapture *,ArenaPartyBridge *,u32 seed,u32 held);
BOOL ArenaCapture_Process(ArenaCapture *,u32 held,u32 pressed,CombatInput *);
#endif
