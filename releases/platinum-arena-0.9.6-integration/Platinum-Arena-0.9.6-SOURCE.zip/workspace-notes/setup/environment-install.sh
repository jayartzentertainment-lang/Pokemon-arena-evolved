#!/usr/bin/env bash
set -euo pipefail
# Reuse the current task checkout and the retained setup helpers.
# Each cloud task is isolated; no Git worktree is needed.
cd /workspace/Pokemon-arena-evolved
bash ds/tools/setup_toolchain.sh
make -C ds -j3
make -C ds test

bash /workspace/platinum-port/setup/bootstrap.sh
source /workspace/platinum-port/setup/env.sh
cd /workspace/platinum-port/pokeplatinum
make rom
if test "$(git rev-parse HEAD)" = 1dc13dcea40c04ab53f1f607de46023dc409ef20 \
    && test -z "$(git status --porcelain)"; then
    # The original retail checksum applies to the unchanged baseline.
    make check
else
    echo 'Modified Platinum source: use feature validation; original retail hash is inapplicable.'
    python3 tools/arena/test_core.py --sanitize
    python3 tools/arena/test_party.py --sanitize
    python3 tools/arena/test_capture.py --sanitize
    python3 tests/test_arena_rewards.py
    python3 tools/arena/validate_assets.py
fi
python3 /workspace/platinum-port/prototype/run_probe.py
