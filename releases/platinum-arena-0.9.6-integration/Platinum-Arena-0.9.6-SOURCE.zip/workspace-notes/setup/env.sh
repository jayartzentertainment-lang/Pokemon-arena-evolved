# Source this file before building pokeplatinum.
export PATH=/workspace/platinum-port/setup/bin:/workspace/platinum-port/setup/local/usr/bin:/workspace/.tools/arm/usr/bin:"$PATH"
export NINJA=/workspace/platinum-port/setup/bin/ninja
export PKG_CONFIG_PATH=/workspace/platinum-port/setup/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}
export PKG_CONFIG_PATH_FOR_BUILD=/workspace/platinum-port/setup/pkgconfig${PKG_CONFIG_PATH_FOR_BUILD:+:$PKG_CONFIG_PATH_FOR_BUILD}
export LD_LIBRARY_PATH=/workspace/platinum-port/setup/local/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export BISON_PKGDATADIR=/workspace/platinum-port/setup/local/usr/share/bison
export M4=/workspace/platinum-port/setup/local/usr/bin/m4
