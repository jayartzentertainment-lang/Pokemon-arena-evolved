#!/usr/bin/env python3
"""Record a strict, unchanged-source baseline only after upstream make passes."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

setup = Path(__file__).resolve().parent
repo = setup.parent / "pokeplatinum"
commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert commit == "1dc13dcea40c04ab53f1f607de46023dc409ef20", commit
status = subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=repo, text=True)
assert not status, f"Source tree changed during baseline: {status}"
rom = repo / "build/pokeplatinum.us.nds"
payload = rom.read_bytes()
expected_sha1 = (repo / "platinum.us/rom_rev1.sha1").read_text().split()[0]
actual_sha1 = hashlib.sha1(payload).hexdigest()
assert actual_sha1 == expected_sha1, (actual_sha1, expected_sha1)
test_records = [json.loads(line) for line in (repo / "build/meson-logs/testlog.json").read_text().splitlines() if line]
assert len(test_records) == 5, len(test_records)
assert all(record["result"] == "OK" for record in test_records), test_records
artifacts = setup / "artifacts"
artifacts.mkdir(exist_ok=True)
copy = artifacts / "pokeplatinum-us-rev1-baseline-1dc13dcea40c.nds"
shutil.copyfile(rom, copy)
assert hashlib.sha1(copy.read_bytes()).hexdigest() == expected_sha1
result = {
    "repository": "https://github.com/pret/pokeplatinum",
    "commit": commit,
    "source_status": "clean; no tracked modifications or untracked files",
    "rom": str(rom),
    "preserved_rom": str(copy),
    "bytes": len(payload),
    "sha1": actual_sha1,
    "expected_sha1_unchanged": expected_sha1,
    "sha256": hashlib.sha256(payload).hexdigest(),
    "tests": [{"name": test["name"], "result": test["result"]} for test in test_records],
    "command": "source /workspace/platinum-port/setup/env.sh; make -C /workspace/platinum-port/pokeplatinum",
    "build_log": str(setup / "baseline-build.log"),
    "limitations": "This is the unchanged original Platinum baseline, not the custom live action port. No emulator or physical hardware test is claimed by this record."
}
(setup / "baseline-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
