#!/usr/bin/env python3
"""Adapt ignored build tools to an x86-64 host without IA32 emulation.

Original Metroskrew executables remain byte-for-byte in bin/.i386. Every launch
uses QEMU with the extracted 32-bit libc; no system installation is required.
"""
from pathlib import Path
import os
import shlex
import subprocess

setup = Path(__file__).resolve().parent
repo = setup.parent / "pokeplatinum"
local = setup / "local"
for deb in sorted((setup / "debs").glob("*.deb")):
    subprocess.run(["dpkg-deb", "-x", str(deb), str(local)], check=True)

link = local / "lib"
if not link.exists():
    link.symlink_to("usr/lib32", target_is_directory=True)

pc_dir = setup / "pkgconfig"
pc_dir.mkdir(exist_ok=True)
pc_text = (local / "usr/lib/x86_64-linux-gnu/pkgconfig/libpng16.pc").read_text()
pc_text = pc_text.replace("=/usr", f"={local}/usr")
for name in ("libpng16.pc", "libpng.pc"):
    (pc_dir / name).write_text(pc_text)

adapter_bin = setup / "bin"
adapter_bin.mkdir(exist_ok=True)
ninja_adapter = adapter_bin / "ninja"
ninja_adapter.write_text(
    "#!/bin/sh\n"
    'case " $* " in\n'
    f'  *" -t "*|*" --tool "*) exec {shlex.quote(str(local / "usr/bin/ninja"))} "$@" ;;\n'
    f'  *) exec {shlex.quote(str(local / "usr/bin/ninja"))} -j4 "$@" ;;\n'
    'esac\n'
)
ninja_adapter.chmod(0o755)

bin_dir = repo / "tools/metroskrew/bin"
originals = bin_dir / ".i386"
originals.mkdir(exist_ok=True)
qemu = local / "usr/bin/qemu-i386"
for executable in sorted(bin_dir.iterdir()):
    if not executable.is_file() or executable.name.startswith("."):
        continue
    original = originals / executable.name
    if not original.exists():
        if executable.read_bytes()[:4] != b"\x7fELF":
            raise RuntimeError(f"Unexpected non-ELF original: {executable}")
        executable.rename(original)
    executable.write_text(
        "#!/bin/sh\n"
        f"exec {shlex.quote(str(qemu))} -L {shlex.quote(str(local))} "
        f"-0 {shlex.quote(str(executable))} {shlex.quote(str(original))} \"$@\"\n"
    )
    executable.chmod(0o755)

env = setup / "env.sh"
env.write_text(
    "# Source this file before building pokeplatinum.\n"
    f"export PATH={shlex.quote(str(adapter_bin))}:{shlex.quote(str(local / 'usr/bin'))}:/workspace/.tools/arm/usr/bin:\"$PATH\"\n"
    f"export NINJA={shlex.quote(str(ninja_adapter))}\n"
    f"export PKG_CONFIG_PATH={shlex.quote(str(pc_dir))}${{PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}}\n"
    f"export PKG_CONFIG_PATH_FOR_BUILD={shlex.quote(str(pc_dir))}${{PKG_CONFIG_PATH_FOR_BUILD:+:$PKG_CONFIG_PATH_FOR_BUILD}}\n"
    f"export LD_LIBRARY_PATH={shlex.quote(str(local / 'usr/lib/x86_64-linux-gnu'))}${{LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}}\n"
    f"export BISON_PKGDATADIR={shlex.quote(str(local / 'usr/share/bison'))}\n"
    f"export M4={shlex.quote(str(local / 'usr/bin/m4'))}\n"
)
print(env)
