#!/usr/bin/env bash
# Local dependencies only. Run bash /workspace/platinum-port/setup/bootstrap.sh.
set -euo pipefail
PLATINUM_SETUP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PLATINUM_REPO_DIR="$(dirname -- "$PLATINUM_SETUP_DIR")/pokeplatinum"
cd -- "$PLATINUM_SETUP_DIR"

for program in gcc g++ ar git make python3 curl tar xz pkg-config dpkg-deb; do
    command -v "$program" >/dev/null || { echo "Required host program missing: $program" >&2; exit 1; }
done
test -x /workspace/.tools/arm/usr/bin/arm-none-eabi-gcc || {
    echo "First run /workspace/Pokemon-arena-evolved/ds/tools/setup_toolchain.sh for the pinned local ARM assembler." >&2
    exit 1
}

mkdir -p apt/etc/apt.conf.d apt/etc/sources.list.d apt/lists/partial apt/cache/archives/partial debs archives
cat > apt/etc/sources.list <<'SOURCES'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
SOURCES
cat > apt/apt.conf <<CONFIG
Dir::Etc::main "/dev/null";
Dir::Etc::parts "$PLATINUM_SETUP_DIR/apt/etc/apt.conf.d";
Dir::Etc::sourcelist "$PLATINUM_SETUP_DIR/apt/etc/sources.list";
Dir::Etc::sourceparts "$PLATINUM_SETUP_DIR/apt/etc/sources.list.d";
Dir::State::lists "$PLATINUM_SETUP_DIR/apt/lists";
Dir::Cache "$PLATINUM_SETUP_DIR/apt/cache";
APT::Sandbox::User "agent";
CONFIG
if ! sha256sum --quiet -c debs/SHA256SUMS; then
    apt-get -c "$PLATINUM_SETUP_DIR/apt/apt.conf" update > apt-update.log 2>&1
    (
        cd debs
        apt-get -c "$PLATINUM_SETUP_DIR/apt/apt.conf" download \
            'bison=2:3.8.2+dfsg-1+b2' 'flex=2.6.4-8.2+b4' \
            'libc6-i386=2.41-12+deb13u4' 'libcapstone5=5.0.7-1~deb13u1' \
            'libpng-dev=1.6.48-1+deb13u5' 'libpng16-16t64=1.6.48-1+deb13u5' \
            'liburing2=2.9-1' 'm4=1.4.19-8' 'nasm=2.16.03-1' 'ninja-build=1.12.1-1' \
            'qemu-user=1:10.0.13+ds-0+deb13u1'
    )
    sha256sum --quiet -c debs/SHA256SUMS
fi

PLATINUM_SKREW_ARCHIVE=archives/metroskrew-linux-0.1.3.tar.xz
if test ! -f "$PLATINUM_SKREW_ARCHIVE"; then
    curl --fail --location --retry 2 --max-time 120 \
        https://github.com/mid-kid/metroskrew/releases/download/0.1.3/metroskrew-linux.tar.xz \
        -o "$PLATINUM_SKREW_ARCHIVE"
fi
printf '%s  %s\n' 2fec5ba308690a25157afc532ed87411a413501d43d85892ae4bfb9eb3975790 "$PLATINUM_SKREW_ARCHIVE" | sha256sum --check --status
if test ! -e "$PLATINUM_REPO_DIR/tools/metroskrew/bin/skrewrap"; then
    mkdir -p extraction
    tar -xf "$PLATINUM_SKREW_ARCHIVE" -C extraction
    mv extraction/metroskrew "$PLATINUM_REPO_DIR/tools/metroskrew"
fi

make -C "$PLATINUM_REPO_DIR" meson
test "$(git -C "$PLATINUM_REPO_DIR/subprojects/meson-1.12.0" rev-parse HEAD)" = ab4508e6abe338a3bd2e6eb5da1d18b8cf55dc93
python3 prepare_local_tools.py
(
    cd "$PLATINUM_REPO_DIR"
    sha256sum --quiet -c "$PLATINUM_SETUP_DIR/metroskrew-originals.sha256"
)
python3 cache_wrap_patches.py
echo "Local setup complete. Source $PLATINUM_SETUP_DIR/env.sh, then make -C $PLATINUM_REPO_DIR."
