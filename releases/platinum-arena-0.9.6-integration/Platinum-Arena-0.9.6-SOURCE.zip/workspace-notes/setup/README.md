# Platinum toolchain and preserved baseline

This setup originally verified the unchanged pret/pokeplatinum project in
`/workspace/platinum-port/pokeplatinum`. The user-uploaded split archive matches
commit `1dc13dcea40c04ab53f1f607de46023dc409ef20` byte for byte.

Prerequisites already present in this cloud workspace: x86-64 Debian 13,
GCC/G++ 14.2, GNU Make, Git, Python 3, pkg-config, curl, tar, xz, Debian archive
keyring, dpkg-deb, and the local ARM GNU compiler at
`/workspace/.tools/arm/usr/bin`. That compiler is GCC 14.2.1 with binutils 2.44;
its existing provenance is `/workspace/.tools/toolchain-provenance.json`.

Run:

```bash
bash /workspace/platinum-port/setup/bootstrap.sh
source /workspace/platinum-port/setup/env.sh
make -C /workspace/platinum-port/pokeplatinum
```

The active checkout now contains the requested live combat port. Build that
checkout with `make -C /workspace/platinum-port/pokeplatinum rom`. Original retail
checksum tests apply only to the preserved unmodified baseline. Current feature
checks are listed in `../PORT-STATUS.md` and `environment-install.sh`.

The first build downloads the source project's pinned SDK subprojects. No base
ROM is needed. The default `make` includes all original SHA1 checks, including
the full retail-compatible revision 1 ROM hash
`0862ec35b24de5c7e2dcb88c9eea0873110d755c`.

The cloud host cannot execute 32-bit x86 instructions directly. The setup keeps
every original Metroskrew executable unchanged in its ignored `bin/.i386`
directory and creates shell launchers using local QEMU i386 and local 32-bit
libc. QEMU runs the original compiler, assembler, and linker. The Ninja adapter
limits builds to four jobs. `NINJA` must be an executable path, because Meson
also reads it; setting `NINJA='ninja -j4'` prevents Meson from finding Ninja.
These are tool
execution adapters, not modifications to game code or expected hashes.

All extracted packages, tool launchers, archives, configuration, and logs live
under `/workspace`. No root installation or system configuration change is
needed. `PKG_CONFIG_PATH_FOR_BUILD` is essential for native libpng discovery in
this cross build; `M4` and `BISON_PKGDATADIR` point to the local parser tools.

Integrity and network handling:

* Debian package downloads use a signed trixie package index and APT package
  digests. `debs/SHA256SUMS` pins every extracted package. Package URLs and signed
  index hashes are in `debian-package-uris.txt`.
* Metroskrew is version 0.1.3 from the official GitHub release, SHA256
  `2fec5ba308690a25157afc532ed87411a413501d43d85892ae4bfb9eb3975790`.
  `metroskrew-originals.sha256` records the preserved executable hashes.
* Meson is the project's pinned 1.12.0 tag at commit
  `ab4508e6abe338a3bd2e6eb5da1d18b8cf55dc93`.
* The proxy blocks `wrapdb.mesonbuild.com`. `cache_wrap_patches.py` fetches the
  identical official patch archives from GitHub release mirrors and verifies
  their SHA256 hashes against the unchanged `.wrap` files. Meson separately
  validates downloaded source archives and applies the project's own patches.

Setup failures and successful baseline build output are retained separately.
During onboarding, no game source or expected checksum was edited. Subsequent
user-authorized game implementation changes source and manifests; expected retail
checksums remain untouched. The preserved baseline is an unmodified Platinum ROM.

## Verified result

The helper was rerun successfully, then the command above completed without a
rebuild and passed all five original checksum suites (shared SBINs,
revision-specific SBINs, ARM7 SBINs, filesystem, and entire ROM). The Git working
tree remained clean.

The 134,217,728-byte ROM has the exact expected SHA1
`0862ec35b24de5c7e2dcb88c9eea0873110d755c` and SHA256
`fbce4c4def0c7797f8dd238a3d7a5e48b4a7e3abd86890ac65f6321cef781bdb`.
A preserved copy is
`artifacts/pokeplatinum-us-rev1-baseline-1dc13dcea40c.nds`. Use this separate copy
for baseline emulator checks while development modifies the normal build.

`baseline-result.json`, `baseline-build.log`, and `bootstrap-validation.log`
record the successful result. Earlier setup failures have separate diagnostic
logs. No emulator or physical hardware test is claimed by this setup record.
`record_baseline.py` enforces the original commit, clean tree, full ROM digest,
and all five test results before producing its report and preserved ROM copy.
