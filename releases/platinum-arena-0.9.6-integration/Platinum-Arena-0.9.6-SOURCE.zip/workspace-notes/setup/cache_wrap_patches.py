#!/usr/bin/env python3
"""Fetch official WrapDB patch mirrors, enforcing the untouched wrap hashes."""
from pathlib import Path
import configparser
import hashlib
import urllib.request

repo = Path(__file__).resolve().parent.parent / "pokeplatinum"
cache = repo / "subprojects/packagecache"
cache.mkdir(exist_ok=True)
for package in ("rapidjson", "yyjson"):
    cfg = configparser.ConfigParser()
    cfg.read(repo / "subprojects" / f"{package}.wrap")
    wrap = cfg["wrap-file"]
    target = cache / wrap["patch_filename"]
    url = ("https://github.com/mesonbuild/wrapdb/releases/download/"
           f"{package}_{wrap['wrapdb_version']}/{target.name}")
    if not target.exists():
        with urllib.request.urlopen(url, timeout=50) as response:
            payload = response.read()
        actual = hashlib.sha256(payload).hexdigest()
        if actual != wrap["patch_hash"]:
            raise RuntimeError(f"Unexpected SHA256 from official mirror {url}: {actual}")
        target.write_bytes(payload)
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    if actual != wrap["patch_hash"]:
        raise RuntimeError(f"Unexpected existing SHA256 for {target}: {actual}")
    print(f"{url}\nsha256 {actual}")
