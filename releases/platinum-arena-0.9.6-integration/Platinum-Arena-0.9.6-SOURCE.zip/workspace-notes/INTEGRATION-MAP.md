# Platinum live action integration map

Source audit: 18 October 2026. Paths below are relative to
`/workspace/platinum-port/pokeplatinum`, unless marked `arena`.
This is the original source audit and its historical implementation proposal.
The current0.9.3 implementation and exact-build evidence are described in
PORT-STATUS.md. Native send-out presentation now finishes before the action
overlay loads; the audited DTO ownership and encounter boundaries still apply.

## 1. Preserve Platinum's existing encounter boundary

| Boundary | Actual source and behavior |
| --- | --- |
| Encounter creation | `src/encounter.c`: `Encounter_NewVsTrainer` (724), `Encounter_NewVsFirstBattle` (653), `Encounter_NewVsWild` (342), scripted species/honey/Giratina variants. These already construct canonical trainers/Pokémon, encounter effects, BGM and battle flags. |
| Field suspension | `FieldTask_Encounter` (160) and `FieldTask_WildEncounter` (364) pause movement, run the encounter effect and `FieldTransition_FinishMap`, then call the battle child task. |
| App dispatch | `src/unk_0203D1B8.c`: `gBattleApplicationTemplate` (234) loads the `battle` overlay; `FieldSystem_StartBattleProcess` (241) starts the child process; `ApplicationMain_Battle` (220) calls `Battle_Main`. |
| Overlay lifecycle | `src/overlay_manager.c`: `ApplicationManager_Exec` loads the template overlay, runs init/main/exit on successive frames and unloads it only after exit. `ApplicationManager_Args` is the existing `FieldBattleDTO *`. |
| First battle instruction | `src/battle/battle_main.c`: `Battle_Main` (182), initial state `BATTLE_STATE_CREATE_HEAP`, creates a `0xB0000` battle heap. This is the earliest central battle hook before allocating native graphics/parties. |

The narrow first proof is a disabled-by-default dispatch or observation point at
the start of `Battle_Main`, before `BATTLE_STATE_CREATE_HEAP`. It can inspect the
real DTO and then leave vanilla execution untouched. That proves the boundary
without replacing scripts or falsely claiming a completed combat port.

A later custom branch must own its complete init/tick/cleanup sequence. It must
remain selected on every app frame, rather than accidentally falling back into
the native state's switch. It must not call native cleanup with partially
initialized `BattleSystem` data. Initially restrict it to explicitly supported
offline battles; leave link/recording/Frontier/Safari/Pal Park/tutorial and special
Giratina cases native until each has a verified implementation.

Native initialization is more extensive than the state names suggest:
`BattleMain_InitPartnerIntro` (1944) always allocates `BattleSystem` and calls
`BattleSys_New` (1013), including in offline play when it immediately skips the
partner intro. `BATTLE_STATE_INIT_GRAPHICS` loads `overlay11` and `battle_anim`,
then `BattleMain_InitGraphics` (515) allocates fonts, palettes, windows, sprite
managers, HP boxes, particle system, battle subscreen, animation context and
per-frame tasks. `BattleMain_ExecuteBattlerCommands` (638) runs the native battle
controller and battler I/O. Replacing only a turn-selection button does not
replace this turn-based engine with simultaneous action.

## 2. DTO ownership and team mapping

`include/field_battle_data_transfer.h` defines the actual contract.
`FieldBattleDTO_New` allocates four independent `Party` objects, four trainer
infos, copied bag/Pokédex/options and a capture-attempt object.
`FieldBattleDTO_InitFromGameState` (234) copies the player's real party into
`parties[0]`, trainer info, bag and Pokédex. `pcBoxes`, `saveData`, records,
Pokétch and several other fields point into existing game state; they are not
all private transaction copies. Do not free or replace those pointers as if
they were owned custom allocations.

`include/constants/battle.h` defines actor order: player 0 and ally 2 versus
enemy 1 and enemy 3. **Actor index is not always the party owner.** Mirror
`BattleSystem_GetParty`, `BattleSystem_GetPartyCount` and
`BattleSystem_GetPartyPokemon` (`src/battle/battle_system.c`, 124–159):

| Type | Actors | Party owner for actors 0, 1, 2, 3 |
| --- | --- | --- |
| Ordinary singles | 0, 1 | 0, 1; actors 2/3 inactive |
| Ordinary `BATTLE_TYPE_DOUBLES` | all four | 0, 1, 0, 1 |
| `BATTLE_TYPE_TAG` without `2vs2` | all four | 0, 1, 0, 3 |
| `BATTLE_TYPE_2vs2`, including AI partner | all four | 0, 1, 2, 3 |

Platinum's `TAG` case means two enemy trainers with the player's two Pokémon
sharing party 0. An NPC ally is `BATTLE_TYPE_AI_PARTNER` or
`BATTLE_TYPE_TRAINER_WITH_AI_PARTNER` and includes `2vs2`; its party 2 belongs to
the ally, not the save's player party. `Encounter_NewVsTrainer` chooses these
flags from the two opponent IDs and partner ID, then `Trainer_Encounter`
(`src/trainer_data.c`, 25) builds those exact source teams.

`BattleSys_New` has separate initialization branches matching these cases. For
a shared-party doubles side, select two distinct healthy, non-egg party slots;
for separate trainers, select a slot from each owner's party. Retain explicit
`actor -> owner -> partySlot` bindings through voluntary switching, fainted
replacement and both enemy waves. A swap may not duplicate a deployed member,
overwrite the ally's party or award experience twice for one defeated member.

The accepted arena's `Combat_InitTeams` already uses the compatible 0+2 / 1+3
team ordering, but its `StoryDoubles` bridge is for the Emerald adapter and is
not a Platinum ownership implementation.

## 3. Import real stats and write HP/PP back exactly

Use native `Pokemon_GetValue`/`Pokemon_SetValue` and
`Party_GetPokemonBySlotIndex`, rather than editing the encrypted Pokémon
structure directly. `BattleSystem_InitBattleMon` in `src/battle/battle_lib.c`
(70) is the authoritative list: species/form, actual calculated HP/max HP,
ATK/DEF/SPEED/SP_ATK/SP_DEF, four moves/current PP/PP Ups, types, ability,
status, held item, personality, OT, level and experience.

For a DTO-only custom branch, mutate the bound Pokémon in the DTO's party;
retain identity, IVs/EVs, moves, held items and status unless a supported effect
changes them. `CombatFighterConfig.hp` initializes arena maximum HP; import
native max HP there and then restore current HP separately. Keep zero HP zero.
Do not convert to a percentage and back. Preserve unsupported move IDs and PP
in the native Pokémon even if unavailable to the action controller.

For a branch retaining native `BattleSystem`, `BattleMon_CopyToParty`
(`src/battle/battle_lib.c`, 1819) is **asynchronous**, emitting
`BattleController_EmitUpdatePartyMon`. Actual writes occur in
`BtlIOCmd_UpdatePartyMon` (`src/battle/battle_io_command.c`, 571), respecting
Transform/Mimic/item removal before writing HP/status/PP/form. Drain native I/O
before final copies. Simply changing `battleCtx->battleMons[]` and returning
does not commit those values.

`BattleMain_CopyBattleSysToDTOAndFree` (678) copies parties/trainer money/bag/
Pokédex and battle metadata back from the native battle system. After evolution
and app exit, `FieldBattleDTO_UpdateFieldSystem` (`src/field_battle_data_transfer.c`,
415) copies party 0, trainer info 0, bag/Pokédex and Safari-ball count into the
field save. It does not copy party 2 into the player's party. Keep that normal
field writeback route and Platinum's own saving, rather than importing the
arena's small custom EEPROM journals.

## 4. Native aftermath is not a rewards callback

| Behavior | Where it really happens | Consequence for custom combat |
| --- | --- | --- |
| EXP distribution and EVs | `BattleControllerPlayer_AnyExpPayout` (`src/battle/battle_controller_player.c`, 4449) dispatches `subscript_grant_exp`; `BtlCmd_CalcExpGain` (`src/battle/battle_script.c`, 2187), `BattleScript_GetExpTask` (9685) and `BattleScript_CalcEffortValues` (10214) handle participation, Exp Share, trainer/traded/Lucky Egg bonuses, growth and EV rules. | Not automatically run after the battle app returns. Queue each genuine defeated foe once, retaining participant masks and exclusions. |
| Level-up and move learning UI | `BattleScript_GetExpTask` handles level gauges/stat windows, `Pokemon_LevelUpMove`, move-forget selection and PP initialization. | Preserve/adapt the native task with its required `BattleSystem`/graphics state, or implement a separately tested equivalent. These static functions are not a simple public DTO API. |
| Evolution | `Battle_Main`, `BATTLE_STATE_CHECK_EVOLUTION`/`WAIT_FOR_EVOLUTION`; `Battle_FindEvolvingPartyMember` (`src/battle/battle_system.c`, 824) consumes `dto->leveledUpMonsMask`, tests native conditions/map method and calls `Evolution_Begin`. | This part is genuinely post-battle. Set the real level-up bitmask and preserve this lifecycle; do not trigger evolution on every capture/switch. |
| Trainer winnings / blackout money | `BtlCmd_PayPrizeMoney` (`src/battle/battle_script.c`, 3705), called by `res/battle/scripts/subscripts/subscript_battle_won.s` and `subscript_battle_lost.s`. It uses trainer classes/last level and both enemy parties for applicable tag battles; loss uses `BattleSystem_CalcMoneyPenalty`. | Returning WIN/LOSE does not pay or deduct money. Preserve the original reward sequence or explicitly adapt it exactly once. |
| Pay Day, Pickup/Honey Gather and related end effects | `subscript_battle_won.s`: `GenerateEndOfBattleItem`, `AddPayDayMoney`; implementations in `battle_script.c`. | These also occur before app exit, not in the field return wrapper. |
| Field story, blackout routing and journal | `FieldTask_Encounter`/`FieldTask_WildEncounter` restore field copies, return the result, process partner healing, records, TV/journal and map transitions. Trainer scripts use `ScrCmd_CheckWonBattle`/`ScrCmd_CheckLostBattle` (`src/scrcmd_trainer.c`, 256/265), then set their native story flags/rewards. Wild losses route to `FieldTask_BlackOutFromBattle`. | Keep native scripts and result semantics. Do not set gym/story completion flags inside custom combat. Script rewards remain distinct from battle prize money. |

The robust integration has two phases: the action simulation resolves a real
fight, then a native-compatible reward/capture phase runs before DTO writeback.
A direct DTO-only battle can be an early prototype, but lacks a complete story
contract until the above reward tasks exist. Reusing vanilla menus requires
their actual graphics/context/overlay dependencies, not just copying artwork.

## 5. Catching must use Platinum Pokémon, bag and storage

Keep accepted interaction semantics: hold L+R to aim, release a shoulder to
throw, B cancels while aiming; consume one ball only after a valid throw starts.
Standalone L cycles move selection and R remains available. Chord detection
must run before L cycling. The source reference is
`arena/source/battle_controls.c` and `arena/source/capture.c`.

In Platinum, `BattleControllerPlayer_ItemCommand` (1905) selects
`subscript_throw_pokeball`, removes the ball from the battle's bag via
`Bag_TryRemoveItem`, and stores the item in `battleCtx->msgItemTemp`.
`BtlCmd_StartCatchMonTask` and `BattleScript_CatchMonTask` (10354) resolve the
native capture flow, including trainer blocking and special battle rules.
Successful capture is a sequence, not just a result flag:

1. Preserve the actual encountered Pokémon's species/form/personality/IVs/level,
   HP and supported status. Use the chosen native ball ID and native modifiers.
2. `BattleSystem_DexFlagCaught`, `BattleSystem_SetPokemonCatchData`
   (`battle_lib.c`, 6238 -> `Pokemon_SetCatchData`), Pokétch history,
   `CaptureAttempt_Init`, records and native nickname/Pokédex UI run.
3. `Party_AddPokemon` copies into player party 0 when it has space. Otherwise
   `PCBoxes_FirstEmptyBox`, `PCBoxes_SetCurrentBox` and
   `PCBoxes_TryStoreBoxMonInBox` place the native BoxPokemon in the actual PC;
   the native path restores PP and normalizes relevant forms for boxed mons.
4. Set `caughtBattlerIdx`, capture-attempt data/balls-thrown metadata and
   `BATTLE_RESULT_CAPTURED_MON`. `UpdateJournal` expects to find the captured
   source Pokémon in `dto->parties[caughtBattlerIdx]`.

PC boxes are a direct save pointer, so a second placement after returning would
duplicate a catch. Capacity checks must cover both party and all 18 native PC
boxes before spending a ball. Partner/double wild encounters need Platinum's
target restrictions and correct enemy owner; do not catch an ally or a trainer's
Pokémon. The accepted Emerald formula/art animation may inform feel, but is not
a substitute for Gen IV ball/status/species rules. Preserve tutorial/Safari/Pal
Park as native until their separate rules are supported.

## 6. Result values are exact enums expressed as masks

`include/constants/battle.h`: progress 0, WIN 1, LOSE 2, DRAW 3,
CAPTURED_MON 4, PLAYER_FLED 5, ENEMY_FLED 6. Values 0x40/0x80 are transient
flee-control flags; native finalization strips them. Do not combine WIN and
CAPTURED_MON to report a successful catch: 5 means the player fled.

`CheckPlayerWonBattle` treats only LOSE and DRAW as failure;
`CheckPlayerLostBattle` treats only WIN and CAPTURED_MON as not-lost. These are
different predicates and even have overlapping answers for flee cases.
Do not simplify them to `mask & WIN`, leave progress 0 as a final result, or
allow trainer fleeing when `BATTLE_STATUS_NO_RUNNING`/battle rules disallow it.
Carry actual source enemy HP/status back for roamer bookkeeping, preserve
`battleStatusMask`, and define sensible elapsed-turn/record counters rather than
pretending action frames are native turns.

## 7. Hard DS resource constraints

| Resource | Source-grounded constraint |
| --- | --- |
| Main memory | Standard DS has 4 MiB main RAM. Platinum already owns its static image, SDK arenas, overlays and save/field/application heaps. There is no additional standalone homebrew address space. |
| Application heap | `include/constants/heap.h`: `HEAP_SIZE_APPLICATION = 0x10D800` (1,103,872 bytes); battle is a `0xB0000` (720,896-byte) child. Evolution needs `0x30000` after the battle heap is destroyed. Heap allocator adds per-allocation metadata. Measure `HeapExp_FndGetTotalFreeSize` at real transitions. |
| Accepted asset cache | `arena/include/assets.h`: 160 KiB per `AssetFighter`; four occupy at least 655,360 bytes. `arena/source/main.c` additionally owns two 256×192 RGB15 buffers (196,608 bytes), four decoded 64×64 frames (32,768 bytes), and other arena/world data. Those three groups alone exceed the entire native battle heap. Loading both engines wholesale cannot fit that heap. |
| Current standalone binary | Read-only `arm-none-eabi-size arena/build/arm9.elf`: text 1,537,575, data 96, BSS 2,029,008 bytes (3,566,679 total). This includes the standalone Emerald world/UI and must not be linked wholesale into Platinum. Port only combat/physics/navigation plus bounded fight assets. |
| Stack | `platinum.us/main.lsf.in` declares `StackSize 0 2048`; the SDK parser identifies the second number as the IRQ stack, not a 2 KiB main-stack limit. Inspect the linked SDK stack symbols/arena boundary and measure task usage. Keep decoded frames/cache/state off the stack. |
| Overlay layout | Same linker file: main at `0x02000000`; `overlay11 After nintendo_wfc`; `battle_anim`, `battle_sub_menus`, `trainer_ai` all `After overlay11`; `battle After battle_anim`. Those three alternatives intentionally overlap in RAM. Existing switching unloads one before loading another. Inspect final generated overlay table/map and BSS bounds for each modified build; `After` is a dependency, not a fixed free address. |
| Active overlays | `src/game_overlay.c` tracks only eight active overlays per region and checks RAM overlap. Native party/bag submenu entry unloads battle animation or AI and restores it on exit. Do not keep pointers/tasks into an unloaded alternative overlay. |
| Graphics | `BattleMain_InitBattleGraphics` (799) assigns A=main BG, H=sub BG, E=main OBJ, I=sub OBJ, B/C=textures, F/G=texture palette. Native battle uses VBlank callbacks, sprite/particle tasks and 3D buffers. A new arena framebuffer renderer needs explicit VRAM ownership, callback teardown and clean return to field/native reward screens. |
| OS, ARM7, card and save | Do not import `arena/source/platform.c` initialization. It disables IRQs, takes VRAM/WRAM/card bus/timers, uses custom ARM7 shared memory at `0x02FFF000`, raw card commands and an 8 KiB EEPROM protocol. Platinum already uses Nitro input, audio, ARM7, FS and save services. Adapt input from `gSystem`, assets from FS/NARC, presentation through scheduled tasks, and saving through the existing native save path. |

A bounded 1v1 cache is already tight beside all native UI allocations; 2v2 needs
deduplicated/shared poses or a different bounded cache design. Relinking growing
`battle_anim` also shifts the dependent `battle` overlay; baseline hash matching
is no longer expected for a modified ROM, but overlay bounds and lifecycle still
must validate.

### Concrete renderer option: exact pose pool plus native BG/OBJ

This is a design supported by existing formats and APIs, not implemented code.
It avoids porting the standalone RGB15 screen compositor or allocating four
fixed-size `AssetFighter` objects inside Platinum.

The host reporter in `audit/report_arena_cache.c` was compiled against the
unchanged accepted `arena/source/assets_data.c`. It reproduces `assets_load`'s
per-species `(offset,size)` alias elimination and bounds checks. Results are in
`audit/arena-cache-sizes.tsv` and `audit/arena-cache-summary.json`, with SHA256s
for the measured sources/pack:

| Measured accepted 386-species data | Compressed bytes |
| --- | ---: |
| Largest complete five-pose species: Shedinja | 141,288 |
| Next largest: Beautifly | 136,288 |
| Next: Wailord | 129,952 |
| Next: Entei | 125,696 |
| Four largest distinct complete species, total | 533,224 |
| Four copies of the largest species with no sharing | 565,152 |
| Four identical largest species sharing immutable pose data | 141,288 |
| Largest single pose: Gastly | 56,744 |
| Four distinct largest single-pose sizes, total | 220,640 |
| Median complete species | 7,448 |

The table covers 187 directional species and 199 static fallbacks. It does not
bound newly added Sinnoh art, forms, palette variants or future animations.
It excludes metadata/allocation overhead. The four-largest-distinct sum is a
safe content-pool bound for this pack when identical species share immutable
data; actor animation tick/direction/HP remain separate. Pose sharing is not
the same as making all identical actors show the same current frame.

Allocate a refcounted immutable pool of only the distinct pose ranges needed
by the deployed species; descriptors hold pointers rather than a 160 KiB inline
array. Preload all five poses when entering a fight or replacing a member.
Before a replacement, retire its no-longer-referenced cache before loading the
new member, so the pool does not temporarily hold five complete species.
Free the fight cache before switching to native capture/reward/evolution UI.
Do not assume 533,224 bytes plus the complete existing battle graphics context
fits: that live heap measurement remains required. A custom arena renderer
should allocate only its own necessary managers and reconstruct the native
aftermath context separately, or a later design must reduce pose residency.

The measured largest-pose total suggests a smaller one-pose-per-species cache,
but changing pose during combat would then require card reads. That is not the
preferred first design: it introduces attack latency unless asynchronous
prefetch and a measured deadline/fallback policy are implemented. All-pose
residency avoids combat-frame I/O.

For each displayed fighter, reconstruct a **64×64 4bpp tiled frame** directly
from the accepted dictionary: its direction/frame map contains 64 tile IDs,
each naming a 32-byte dictionary tile. Copy those 64 tiles in OBJ order into a
2,048-byte staging buffer; no per-pixel RGB15 conversion is necessary. Preserve
palette index 0 transparency and load the species' 16-color palette into a
dedicated native OBJ palette slot. Frame durations and ground anchors remain
the accepted metadata. Four actors need 8 KiB of tiles, or 16 KiB with separate
pending/current staging buffers. Identical species may share the compressed
source and palette while actors retain independent frame buffers.

Native APIs already available:

- `SpriteSystem_Init`, `SpriteSystem_NewSprite`, palette/cell/animation resource
  loading, `SpriteSystem_DrawSprites` and `SpriteSystem_TransferOam`
  (`include/sprite_system.h`). Supply a valid native 64×64 cell and a simple
  animation descriptor; the custom dictionary is not itself NCGR/NCER/NANR.
- `CharTransfer_AllocRange`/`CharTransfer_ClearRange`
  (`include/char_transfer.h`) and `Sprite_GetImageProxy` can reserve/identify a
  bounded 1D-mapped OBJ tile range. `VramTransfer_Request` with
  `NNS_GFD_DST_2D_OBJ_CHAR_MAIN` queues changed frames to that range;
  `VramTransfer_Process` commits them during VBlank. Keep the source staging
  buffer valid until that commit, flush CPU cache as required by the transfer
  contract, check request success and do not reuse queued memory early.
- `ManagedSprite_SetPositionFxXY`/`Sprite_SetPosition`,
  `Sprite_SetAffineScale` and `AFFINE_OVERWRITE_MODE_DOUBLE`
  (`include/sprite.h`) support positioning and a double-area affine 64×64 cell.
  The fixed-point `Sprite_SetAffineScale` avoids unnecessary floating-point
  calculation. This can present the accepted 80–128 pixel species sizes without
  storing larger decoded source frames; keep foot anchors and hitboxes separate.
  Count OBJ entries/affine matrices and measure scanline cost for four enlarged
  actors plus effects, rather than assuming hardware scaling guarantees speed.
- The existing VBlank example is `BattleMain_VBlankCallback` (1439): VRAM
  transfers, OAM transfer, palette commit and BG scheduled updates are explicit.
  A custom renderer owns exactly one such callback and tears down all related
  tasks before native UI/field return. `VramTransfer_New` uses a singleton:
  do not create a second manager while the native one is active.

A selected battle arena background can be converted offline into native BG
tiles/palettes and a **512×256 text-BG tilemap**, with the 384×256 playable area
inside it. Validate the native 10-bit tile index limit (at most 1,024 unique
tiles for that text BG), color/palette limits and VRAM budget during conversion;
deduplicate/quantize the art or reject it clearly if it cannot fit. One map is
4,096 bytes; 1,024 4bpp tiles cost 32 KiB (8bpp costs 64 KiB). Native
`Bg_LoadTiles`, `Bg_LoadTilemapBuffer`, `Bg_ScheduleScroll` and
`Bg_RunScheduledUpdates` (`include/bg_window.h`) then replace whole-screen RAM
blits. Transfer the chosen background once at fight entry. Keep HUD/message
layers separate and stationary. If richer scenery later needs streaming,
update only a bounded tile-cache working set between measured frame deadlines;
do not retain the standalone 196,608-byte background array in application RAM.

Retain the accepted finite world/camera geometry: 384×256 arena, 256×160 battle
viewport at y=16; camera x clamps to 0–128 and y to 0–96. Scroll the BG and
subtract that same camera from actors, props, projectiles and VFX; keep
`BattleView_Marker` indicators for offscreen targets. This is camera motion
inside one arena, not an unbounded streamed field or a widened physical DS
screen. Additional Platinum native arena backgrounds require the same explicit
conversion and geometry decision.

An indicative arena allocation is 533,224 bytes of complete compressed poses,
16,384 bytes of double-buffered 4bpp staging and a 4,096-byte map = 553,704
bytes before descriptors, combat/nav/props, palettes, UI windows, transfer/OAM
managers and allocator overhead. That leaves 167,192 bytes of the nominal
720,896-byte heap, **not a proven runtime margin**. The fixed four 160 KiB
caches plus two RAM framebuffers are eliminated. Release this arena-specific
memory before allocating native post-fight screens, then test both transitions
and every worst-case pool configuration on the actual linked ROM.

## 8. Combat, VFX, controls and customization boundaries

Reuse accepted `Combat_Init`, `Combat_InitTeams`, `Combat_Tick`,
`Combat_ReplaceFighter`, physics/navigation and action timing, with a native
adapter. Physical controls remain D-pad movement, Y basic strike, A selected
move, X following move, B guard/dash, L cycle, Select aim lock, Start pause and
L+R catching. R has no standalone action. These are the actual accepted
`BattleControls_Map` semantics; do not remap Y back to lock-on.

Current stamina is 100 max; strike costs 5, move 10, dash 25, guard initiation 8,
with separate block drain and regeneration delays; regeneration is one point
every three simulation frames after delay (`arena/source/combat.c`). The user
requested a rearrangement; no replacement values are approved or implemented
by this document. Keep tuning isolated from controller/DTO correctness so
changes can be compared against the accepted feel.

Platinum has species 387–493 and additional forms, moves and Gen IV move
physical/special categories absent from the current 386-species arena pack and
limited supported move table. Import native actual stats/move data; provide
honest, explicit art fallback for missing directional animation. Do not
silently make unavailable moves erase native moves or replace Sinnoh species
with unrelated sprites. Native front/back battle animations are not eight-way
walking/attack sheets. Native VFX live in `src/battle_anim`,
`res/graphics/battle/moves`, `res/graphics/battle/particles` and the animation
script resources; adapting them to moving actors needs anchors, live target
positions, effect bounds and pause/cleanup rules.

Custom avatars are a separate native field/model/save integration. Keep the
user's original story/scripts and native menus; do not change trainer gender
or story identity just to pick an outfit. The custom appearance record needs
an explicitly versioned compatible save extension and coverage for walking,
cycling/surfing, trainer card, battle intro and gender/model-dependent scenes.
See `CHARACTER-CREATOR.md` beside this document for the dedicated audit.

## 9. Evidence required before calling this playable

1. Clean Platinum baseline builds and boots; record source/tool/ROM hashes.
2. Observation hook sees a genuine first-rival and wild DTO and leaves vanilla
   battle/outcome/story/save unchanged. Label this integration instrumentation.
3. Live 1v1 returns to the original field with exact HP/PP/party and real
   win/loss/flee semantics; no hard-coded winner or auto-awarded progression.
4. Defeated foes pay native EXP/EVs/move learning/evolution, money/blackout and
   original trainer scripts exactly once; save/reopen keeps results.
5. Catch tests cover aim cancellation, failed throw, last ball, party capacity,
   PC fallback/full PC, true native Pokémon identity, Pokédex/nickname and reload.
6. Ordinary doubles, two-enemy-trainer TAG and NPC ally `2vs2` use all four live
   actors with distinct owner/slot bindings, reserves and supported split rewards.
7. Repeated battle/menu/capture/evolution/field transitions leave no stale
   VBlank tasks, overlay calls or growing heap use; measure performance and
   worst-case RAM on the immutable ROM being tested.

Until these are demonstrated, describe builds by the specific proof completed,
not as a finished Platinum action story port.
