# Platinum Arena workspace

The native Platinum port keeps Sinnoh's story and adds top-down live 1v1/2v2.
Version 0.9.6 integrates the supplied layered trainer assets, a new dual-screen
creator, actual Platinum battle-menu artwork, source VFX and wind dashes,
persistent stat stages/statuses, natural attacks and stat-driven beam contests.
The previous 0.9.5 download remains preserved. Focused test and actual native
emulator results for this exact candidate belong to `validation/v096/`;
compile success, host checks and gameplay observations remain distinct.

Current game/source delivery is recorded in `release/integration-096/`.
Read `pokeplatinum/docs/arena/CHANGES-0.9.6.md` for feature scope and limits.
Hold L+R+Select at the title screen for the save-isolated Battle Lab.

The user-requested preview A download is recorded in
`release/preview-093/upload-plan.json`; final builds and exact-hash acceptance
reports live under `validation/v093/`. A preview is separate from the completed
feature build. Full campaign and hardware coverage remain open.

- [PORT-STATUS.md](PORT-STATUS.md): implementation and practical limits.
- [CHARACTER-CREATOR.md](CHARACTER-CREATOR.md): six bases, compatibility and sprite sources.
- [setup/README.md](setup/README.md): pinned toolchain and original baseline.
- [release/README.md](release/README.md): exact-ROM release acceptance gates.
- `pokeplatinum/src/arena/`: current native implementation.
- `validation/`: build, sanitizer, art and normal-input emulator evidence.
- `prototype/`: historical isolated compiler probe, separate from current code.

Build:

```sh
source /workspace/platinum-port/setup/env.sh
make -C /workspace/platinum-port/pokeplatinum rom
```

The two uploaded archives matched all 27,668 files at pret/pokeplatinum commit
`1dc13dcea40c04ab53f1f607de46023dc409ef20`. Its preserved original baseline
passed all five checksum tests. Modified ROMs have different hashes and use
the feature checks in PORT-STATUS.md. No extra base ROM upload is needed.

Older Emerald-based Arena Plus DS releases and saves remain separate in
`/workspace/Pokemon-arena-evolved/dist`.
