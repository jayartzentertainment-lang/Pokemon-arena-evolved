# Platinum Arena 0.9.6 integration status

Updated 21 October 2026. The supplied trainer layers now drive actual hair,
clothing, legwear and hat shapes with independent dyes, a large portrait and
four-facing preview, category/touch navigation and compatible saved appearance.
Genuine Platinum UI tiles replace the plain combat menu. New source effects,
wind dash, species-aware motion, stages/statuses, learned cooldowns, natural
attacks, stat-driven clashes, allied tactics and reserve selection are integrated.

Build and focused host/native-emulator evidence: `validation/v096/`.
Download metadata: `release/integration-096/`. Full campaign and real hardware
remain separate coverage; see the final delivery report for exact outcomes.

Remaining work includes elemental hazard pools, global followers, full authored
reaction/form coverage and advanced retail move/ability/weather/item scripts.
See [changes](pokeplatinum/docs/arena/CHANGES-0.9.6.md),
[renderer notes](pokeplatinum/docs/arena/RENDERER-096.md) and
[combat notes](pokeplatinum/docs/arena/COMBAT-096.md).

## Previous 0.9.5 status (historical)

# Platinum Arena 0.9.5 integration status

Updated 21 October 2026. This focused pass changes equipped-move controls,
contact feedback, Swift artwork and interactive beam pressure within the
existing native Platinum overlay. Compiler/package records belong to
`validation/v095/` and `release/integration-095/`. Gameplay testing belongs to
the user; no emulator, gameplay or automated regression tests were run for
this pass. Earlier runtime evidence does not validate this exact build.

- Y uses equipped move 1, A move 2, and X move 3 or 4; L toggles X between
  those slots. B is fixed for stationary guard/directional dodge. Other
  bindings remain session-configurable. Select aim, Start pause and L+R
  catching retain their roles; R has no standalone default action.
- Releasing and pressing the same direction again within 12 simulation ticks
  can start a dash through the ordinary dodge stamina, cooldown and cancellation
  checks. When every equipped move is out of PP, an emergency Struggle fallback
  avoids leaving the fighter unable to act.
- Swift now uses selected stars from the supplied Diamond/Pearl sheet. Active
  melee attacks no longer emit unconditional hit art; actual damaging contact
  emits its own spark. Other generic move-art fallbacks remain. Approved
  continuous beams and existing sound mappings are retained.
- Fresh taps of the firing button push a shared clash contact point, with
  per-actor tap cooldowns and bounded AI pressure. Reaching an endpoint makes
  one normal damage attempt; timed-out clashes dissipate mutually. Two owned
  pairs remain available in simultaneous 2v2. Battle Lab Clash modes use the
  first equipped beam, now Y by default.
- Small grounded motion envelopes and move-slot HUD/help labels accompany
  the control/contact changes. Native story, party, catching, save and reward
  interfaces remain the foundation. This source description is not gameplay
  verification.

The current expanded layered creator, global followers, additional pose/form
coverage and comprehensive native ability/weather/item/move-script interactions
are not implemented by this pass. Existing six-base palette customization is
retained. Full campaign, hardware, timing and save continuation remain user
playtest work. Current changes are documented in
[pokeplatinum/docs/arena/CHANGES-0.9.5.md](pokeplatinum/docs/arena/CHANGES-0.9.5.md).

## Previous 0.9.4 implementation and evidence (historical)

# Platinum Arena 0.9.4 integration status

Updated 20 October 2026. This pass adapts the approved continuous-beam artwork,
attack timing, dodging, guard presentation and live-combat interface into the
existing native Platinum overlay. Gameplay testing is assigned to the user;
compiler results and exact candidate/download hashes belong to
`validation/v094/` and `release/integration-094/`.

Current changes are documented in
[pokeplatinum/docs/arena/CHANGES-0.9.4.md](pokeplatinum/docs/arena/CHANGES-0.9.4.md).
The previous 0.9.3 build and evidence remain separate. No earlier emulator
result establishes this new ROM's gameplay behavior.

- Fire uses the approved Ranger 104/106 art, with separate source water/ice
  strips and a neutral energy fallback for other registered beams.
- Authored animation timing follows attack phases; sound cue IDs are retained
  and trigger once at release. Held defence uses an idle fallback rather than
  a firing pose, with a body-fitted shield and directional impact feedback.
- Dodges ease in/out, allow limited late steering and use narrow directional
  streaks. Sustained beam clashes have two independently owned pairs for 2v2,
  a shared pressure point and bounded recovery after mutual deflection.
- The HUD consumes native levels/status and full team remaining/total counts.
  Battle Lab has Free/Clash choices for 1v1/2v2. Item/menu failures show stable
  notices until dismissed. Native story/party/save boundaries remain.
- The existing 64 KiB OBJ mapping uses 64,512 bytes. Four live effect slots add
  8 KiB of RAM and at most 8 KiB of active VBlank image transfer. A contiguous
  heap-space preflight protects child-heap allocation while retaining a 16 KiB
  application reserve and the native initialization fallback.

Dedicated hurt/brace art, exact per-pose emitters, additional typed beam art,
64 alternate forms' directional coverage, and complete ability/weather/item/
move-script behavior remain later work. Control remapping is session-only.
[MISSING-POSES.md](pokeplatinum/docs/arena/MISSING-POSES.md) provides confirmed
source files and the requested download format; another ROM upload is not needed.

No emulator session, gameplay test, screenshots or exhaustive regression sweep
is performed for this pass. Runtime checks remain pending user playtesting.

## Previous 0.9.3 implementation and evidence (historical)

# Platinum Arena 0.9.3 status

Updated 20 October 2026. The native Platinum source now implements the requested
creator and combat polish. The256 MiB preview A was built and uploaded at the
user's request. PreviewA passed normal-input first-story-battle entry, action
combat, legitimate loss, return to Barry/Mom dialogue, native saving and full
emulator restart/Continue. Its exact-hash report is
`validation/playtest-093-story-a/runtime-results.json`.

The final 0.9.3 build adds the newly supplied effects, visible menu cursors,
clearer remapped control labels and practice music. Its exact-ROM acceptance
and release receipt are recorded under `validation/v093/` and `release/`.
Do not treat preview evidence as proof of the final ROM's runtime behavior.

## Implemented

- Native Platinum maps, scripts, field menus, encounter teams, party and save
  APIs remain. Supported encounters play the original trainer/Pokemon entrance
  presentation, then transition to the action overlay before a native turn.
  Teardown drains display messages and does not commit presentation HP/PP or
  rewards. Link, Frontier, Safari, Pal Park, tutorial and recorded battles use
  the original battle engine.
- Live 1v1 and simultaneous 2v2 have explicit actor/party-owner/slot bindings,
  an AI teammate, reserve waves, native current HP/PP and physical/special
  stats. Defeats award native EXP/EV, money, move-learning choices and evolution
  handoff. Party switching, medicine and native L+R catching are integrated.
- Hold B stationary for a sustained shield. Starting costs 6 stamina, sustaining
  drains 1 per 4 ticks, and blocked pressure also drains stamina. At zero the
  shield drops and requires release before restarting. Power 80+ attacks chip
  through guard. B+direction starts a 22-stamina dodge. Strikes are stamina-free;
  special moves spend PP. Opposing beams and swept projectiles can clash.
- Attack movement penalties are reduced, dash recovery decelerates and rushes
  stop on contact. Critical and guard events trigger a brief shared-camera
  zoom. The arena is448x320 with a256x160 viewport. Scene, actors, projectiles
  and effects share a smooth affine camera.
- The HUD uses native Platinum healthbox silhouettes, party-ball counts,
  type labels, PP and stamina. Native move-animation scripts supply 461 start
  sound cues. Controls can be remapped from the battle pause menu or Lab,
  remain active across battles, and reset when the ROM restarts.
- Hold L+R+Select on the title screen for Battle Lab. Choose all 493 species,
  levels 5–100, meadow/training hall and1v1/2v2. Lab uses a private temporary DTO
  and teams, suppresses rewards/capture and discards changes on exit.
- Six creator bases: Lucas/Dawn, Brendan/May and Red/Leaf. Every preview is a
  stationary small overworld sprite. Entry uses a fade; Hoenn/Kanto native
  N/S/W/E mapping is corrected. Four skin, six hair-color and eight outfit-color
  choices follow the player rigs. The 44-byte native save layout is unchanged,
  and legacy 0.9.2 profiles decode correctly. See CHARACTER-CREATOR.md.

## Art and memory

All 493 canonical species have genuine eight-direction animation sets. All 187
supplied animated records and source bytes are preserved exactly. The remaining
306 sets use pinned PMDCollab/SpriteCollab revision
`d25607ff4746957df10bdb78db090887cd94f1f8`; source hashes, licenses and per-artist
credits are retained. The 64 alternate forms use native still-image fallbacks.

The sprite pack is45,985,216 bytes with SHA256
`a880d9fcd353d3bfd9779096531f292380a70483173e09046f2513db5a6c71ea`.
The validator checks 138,528 unique frames. Largest single species 161,704 B;
largest four distinct pose pools 640,824 B, unchanged from 0.9.2. Poses are loaded
at deployment and shared by matching species/form. No per-frame card reads.
Gyarados uses a 128px canvas (~60px visible body); Lapras 72px (~45px body).

The new 56-frame effect atlas cuts selected fire/water/electric/ice art from
Mystery Dungeon, shield rings from Ranger and hit/clash effects from KOF XI.
It uses 28 KiB OBJ VRAM and no extra heap pose buffers. Sources, archive/PNG
hashes and a visual contact sheet remain in `res/arena/extra-effects/`.
The other native arena VFX and supplied source-art credits are retained.

## Validation and limits

Core combat/2v2, held-guard/chip/clash/critical events,13,068 navigation routes,
all 128 destruction masks,19,602 cone geometry cases and physics regressions
pass ASan/UBSan. Native party, capture, reward and asynchronous handoff tests
pass. Creator tests cover 1,152 current and 768 independently encoded legacy
profiles, 5,070 palettes, 66 pack entries and 696 native frame aliases.
The original retail baseline remains unchanged and passed its five checksum
checks; modified ROMs use feature tests rather than retail hashes.

The full campaign and real DS hardware remain unverified. Move IDs and Gen IV
categories are imported, but many action behaviors use bounded generic
adapters. Full abilities, weather, held-item combinations and complex native
move scripts are incomplete. Catching currently uses ordinary Poke Balls and
skips native nickname/Pokedex-detail screens. Long party-switch sessions,
all trainer/tag/NPC-partner encounters and all avatar special states need
broader runtime coverage. No complete arbitrary haircut/clothing editor.

## Build and source

Source: pret/pokeplatinum commit
`1dc13dcea40c04ab53f1f607de46023dc409ef20`, US Rev1. All 27,668 uploaded source
files matched this revision before modifications. Native tools are pinned
and activated with `source /workspace/platinum-port/setup/env.sh`, then
`make -C /workspace/platinum-port/pokeplatinum rom`.
Original baseline and older Arena Plus DS releases remain preserved.

The separately uploaded SpriteCollab and compiled-source RARs exceeded the
attachment tool's 32 MiB limit. Existing extracted source and the pinned upstream
sprite files were used; no claim is made that those uninspected RARs were read.
