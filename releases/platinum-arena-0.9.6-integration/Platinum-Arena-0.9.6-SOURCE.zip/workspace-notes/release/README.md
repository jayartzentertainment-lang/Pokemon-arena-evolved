# Packaging the Platinum playtest build

`package_test_release.py` packages an immutable, runtime-tested production ROM;
it does not compile, link, alter source/build files or publish anything. It
keeps earlier Arena Plus releases and refuses to overwrite different bytes at
its own release paths. The ZIP contains the ROM, a short novice player guide,
SHA256 checksums, original source-art credits/licenses and an exact-ROM
test/limits manifest. ZIP entry timestamps
are fixed so the same ROM and evidence produce the same archive.

The production first-story-battle handoff and native first-loss return pass
on the recorded preview A; final builds require their own exact-ROM checks. Do not mark the checks below as passed until normal-input tests on the
final production candidate demonstrate them. Fixture-only doubles or capture
tests do not establish the exact final production story hook.

Create a runtime acceptance JSON after those checks, using the actual hash:

```json
{
  "candidate_sha256": "FULL_FINAL_PRODUCTION_ROM_SHA256",
  "production_build": true,
  "validation_only": false,
  "directional_species": 493,
  "checks": {
    "native_story_live_battle": "pending",
    "native_story_battle_return": "pending",
    "native_save_reload": "pending"
  },
  "tested": ["Describe only checks passed on this exact ROM."],
  "not_tested": ["Full campaign", "Real DS hardware", "List other untested cases."]
}
```

Replace each `pending` with `passed` only after its check passes. Additional
check names are allowed. The candidate hash must match the evidence; the
unchanged baseline and paths marked as validation-only fixtures are rejected.
The helper deliberately has no option to bypass these checks. It records the
evidence JSON's hash in `RELEASE.json`; retain the complete evidence alongside
the validation screenshots/logs. `directional_species` should match the tested
ROM; when omitted it uses the current generated Platinum asset provenance.
The packager retains SpriteCollab and Kenney license text, original contributor
attributions and source manifests in `credits/`. It labels older Emerald
manifest counts as original source information, not current Platinum coverage.

```sh
python3 /workspace/platinum-port/release/package_test_release.py \
  --candidate /workspace/platinum-port/validation/candidates/FINAL-PRODUCTION.nds \
  --evidence /workspace/platinum-port/validation/final-runtime-acceptance.json
```

Default output directory: `/workspace/Pokemon-arena-evolved/dist`.

- `ArenaPlus-Platinum-0.9.3.nds`
- `ArenaPlus-Platinum-0.9.3.zip`
- `READ-ME-Platinum-0.9.3.txt`
- `ArenaPlus-Platinum-0.9.3.json`
- `SHA256SUMS-Platinum-0.9.3`

Use `--dist /tmp/some-empty-folder` to prepare outputs elsewhere. Do not use a
test fixture as a production release or include a fixture save in the ZIP.
The script never includes a save file or SDK/compiler tools.

`capture_source_snapshot.py` separately saves the binary-safe tracked patch
against the pinned upstream commit, added arena code/assets/tests, credits and
setup notes. It excludes ROMs, saves, SDK/compiler binaries, build outputs and
the duplicated intermediate directional staging packs. By default it writes a
hash-named ZIP under `validation/source-snapshots/`; `--output` can select the
final source-download path. Run it after final source/docs are settled.
