#!/usr/bin/env python3
"""Package an explicitly unplaytested build for the user's gameplay testing.

Separate from package_test_release.py, whose runtime-tested release contract
is unchanged. This tool never records gameplay checks as passed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile
import zipfile

ROOT = Path('/workspace/platinum-port')
REPO = ROOT / 'pokeplatinum'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def build(args):
    rom = args.candidate.read_bytes()
    receipt = json.loads(args.build_receipt.read_text())
    rom_sha = digest(rom)
    if len(rom) < 0x200 or receipt.get('rom_sha256') != rom_sha:
        raise ValueError('candidate differs from the recorded compiler build')
    if receipt.get('build_exit_code') != 0:
        raise ValueError('a successful compiler/linker build is required')
    version = args.version
    new_controls = version not in ('0.9.3', '0.9.4')
    controls = ('D-pad: move; double-tap a direction: dash; Y: equipped move 1;\n'
                'A: equipped move 2; X: equipped move 3 or 4; L: toggle X between 3/4;\n'
                'B held while stationary: shield; B + direction: dodge; SELECT: aim lock;\n'
                'START: pause/party/bag/controls. L + R: catch in supported wild encounters.\n'
                'B is fixed to defence. R remains available outside the catch chord.'
                if new_controls else
                'D-pad: move; Y: normal strike; A/X: selected/next special move; L: cycle move;\n'
                'B held while stationary: shield; B + direction: dodge; SELECT: aim lock;\n'
                'START: pause/party/bag/controls. L + R: catch in supported wild encounters.\n'
                'R remains available for future input outside the original catch chord.')
    scope = ('This pass updates equipped-move controls, double-tap dashing, interactive\n'
             'beam pressure, move-specific Swift artwork, contact-driven impact visuals\n'
             'and live-combat presentation. Expanded layered character creation and\n'
             'global Pokemon followers are not integrated in this build.'
             if new_controls else
             'This pass integrates the approved flame VFX, clearer guard/dash feedback,\n'
             'attack presentation timing, sustained beam-clash interaction and native\n'
             'Platinum HUD/session data.')
    name = 'Platinum-Arena-' + version + '-INTEGRATION'
    rom_name = name + '.nds'
    manifest = dict(
        name='Platinum Arena ' + version + ' integration playtest build',
        rom=rom_name, rom_bytes=len(rom), rom_sha256=rom_sha,
        status='Compiler-built; gameplay testing assigned to the user',
        build_receipt_sha256=digest(args.build_receipt.read_bytes()),
        checks=dict(native_compile_link='passed',
                    native_story_live_battle='pending_user_playtest',
                    native_story_battle_return='pending_user_playtest',
                    native_save_reload='pending_user_playtest',
                    live_1v1='pending_user_playtest',
                    live_2v2='pending_user_playtest',
                    vfx_and_sound='pending_user_playtest',
                    real_ds_hardware='pending_user_playtest'),
        limitations=[
            'This exact ROM has not been run in an emulator or on hardware by the assistant.',
            'Platinum story hooks and native party/save interfaces are retained; full campaign coverage is unverified.',
            'Complex abilities, weather, held-item interactions and native move scripts remain incomplete.',
            'Dedicated hurt/charge/brace art import is a later animation pass; current fallback poses are documented.',
            'Control remapping remains session-only and resets on a ROM restart.',
        ],
    )
    guide = '''PLATINUM ARENA {version} — INTEGRATION PLAYTEST BUILD

This is the native Platinum-based game with live-action combat. It is not a
standalone Emerald ROM or a 3DS executable. It has compiled and linked; this
exact build is being delivered for YOUR gameplay testing, not marked as tested.

PLAY
1. Extract {name}.zip.
2. Open {rom_name} in your Nintendo DS emulator.
3. Keep a backup of your existing save before trying a new development build.
4. Play the Platinum story normally, or open Battle Lab from the title screen
   by holding L + R + SELECT. Battle Lab uses temporary teams and discards
   practice HP/PP/rewards when you leave.

DEFAULT LIVE-COMBAT CONTROLS
{controls}

SCOPE
{scope}
Exact implementation details and remaining limits
are in the accompanying changelog and RELEASE.json.

The source changes are supplied as a separate download. New source files are
enough for development; no further base ROM upload is required.

TESTING
Gameplay validation, including story entry/return/save, 1v1/2v2, controls,
sound, collision feel and visual timing, remains pending your playtesting.
Compiler success does not establish these behaviors.

Artwork credits and source notices are retained in credits/.
'''.format(version=version, name=name, rom_name=rom_name, controls=controls, scope=scope)
    payloads = {
        rom_name: rom,
        'READ-ME-FIRST.txt': guide.encode(),
        'RELEASE.json': (json.dumps(manifest, indent=2) + '\n').encode(),
        'BUILD.json': args.build_receipt.read_bytes(),
    }
    if args.changelog:
        payloads['CHANGES.md'] = args.changelog.read_bytes()
    for relative in ['res/arena/SPRITE-CREDITS.md', 'res/arena/ADDITIONAL-CREDITS.md',
                     'res/arena/SpriteCollab-LICENSE.md', 'res/arena/extra-effects/README.md',
                     'res/arena/beam-effects/README.md', 'res/arena/beam-effects/manifest.json',
                     'res/arena/move-effects/README.md', 'res/arena/move-effects/manifest.json',
                     'docs/arena/MISSING-POSES.md', 'docs/arena/USER-DIRECTION-094.md']:
        path = REPO / relative
        if path.is_file():
            payloads['credits/' + relative.replace('/', '__')] = path.read_bytes()
    payloads['SHA256SUMS'] = ''.join(digest(data) + '  ' + path + '\n'
                                  for path, data in sorted(payloads.items())).encode()
    args.output.mkdir(parents=True, exist_ok=True)
    destination = args.output / (name + '.zip')
    with tempfile.NamedTemporaryFile(dir=args.output, prefix='.integration-', suffix='.zip', delete=False) as stream:
        temporary = Path(stream.name)
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path, data in sorted(payloads.items()):
                entry = zipfile.ZipInfo(path, (1980, 1, 1, 0, 0, 0))
                entry.compress_type = zipfile.ZIP_DEFLATED
                entry._compresslevel = 9
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry, data)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError('download ZIP is corrupt')
        zip_sha = digest(temporary.read_bytes())
        if destination.exists() and digest(destination.read_bytes()) != zip_sha:
            raise ValueError('refusing to replace a different integration build')
        temporary.replace(destination)
        (args.output / 'RELEASE.json').write_text(json.dumps(manifest, indent=2) + '\n')
        (args.output / 'README.txt').write_text(guide)
        (args.output / 'SHA256SUMS').write_text(zip_sha + '  ' + destination.name + '\n' + rom_sha + '  ' + rom_name + '\n')
        print(json.dumps(dict(zip=str(destination), bytes=destination.stat().st_size,
                              sha256=zip_sha, candidate_sha256=rom_sha), indent=2))
    finally:
        temporary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--build-receipt', type=Path, required=True)
    parser.add_argument('--version', default='0.9.5')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--changelog', type=Path)
    args = parser.parse_args()
    if any(c not in '0123456789.-' for c in args.version):
        parser.error('invalid version label')
    build(args)


if __name__ == '__main__':
    main()
