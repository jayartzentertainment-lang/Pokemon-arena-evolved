#!/usr/bin/env python3
"""Package a tested production candidate without touching the source/build tree."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile


VERSION = "0.9.3"
NAME = "ArenaPlus-Platinum-" + VERSION
ASSETS = Path("/workspace/platinum-port/pokeplatinum/res/arena")
ORIGINAL_ASSETS = Path("/workspace/Pokemon-arena-evolved/ds/assets")
BASELINE_SHA256 = "fbce4c4def0c7797f8dd238a3d7a5e48b4a7e3abd86890ac65f6321cef781bdb"
REQUIRED_CHECKS = (
    "native_story_live_battle",
    "native_story_battle_return",
    "native_save_reload",
)

PLAYER_GUIDE = """PLATINUM ARENA 0.9.3 - PLAYTEST BUILD

HOW TO PLAY
1. Unzip this download.
2. Open ArenaPlus-Platinum-0.9.3.nds in your Nintendo DS emulator
   (for example, melonDS or DeSmuME). Open the .nds file, not the ZIP.
3. Start New Game. Choose your character and follow Platinum's story.
4. Use the game's Save menu before closing the emulator. Keep the emulator's
   save file beside the game or in its configured save folder.

This is a new Platinum game, separate from Emerald Arena. Emerald/Arena Plus
DS saves cannot be transferred. Keep a backup before testing future builds.
To continue a Platinum Arena preview save, use your emulator's Import Save
option or copy its .sav/.dsv under the new ROM's matching filename. Preserve
the original save first; save states are not a substitute for an in-game save.
The file is {rom_mib} MiB; the extra directional animation sets need more ROM
storage. Only active fighters' animations are loaded into DS memory.

PRACTICE MODE
Hold L+R+Select on the title screen to open the battle test menu.
Choose Pokemon, arena, level and 1v1 or 2v2. Practice uses separate teams
and does not change your story save. B returns to the native main menu.

LIVE BATTLE CONTROLS (NINTENDO DS BUTTONS)
D-pad: move and aim
Y: normal strike
A: selected move
X: next move, without changing your selection
L: cycle selected move
R: reserved; no standalone action
B + direction: dash
Hold B without a direction: shield until release or stamina exhaustion
Select: toggle aim lock
Start: pause; switch Pokemon, use medicine or try to run

Your emulator lets you map these DS buttons to keyboard/controller buttons.
The field/story menus keep their original Platinum controls.
The live battle pause menu also offers control remapping. These mappings
remain active until the ROM restarts; they are not stored in the story save.

CATCHING
Hold L+R to aim; use the D-pad, then release either shoulder to throw.
B cancels before throwing. Carry ordinary Poke Balls in your bag.
In a wild double battle, reduce the opposing team to one Pokemon first.
Caught Pokemon go to your real party or PC.

COMBAT AND APPEARANCE
Normal strikes use no stamina. Special moves spend PP. Dash and sustained
guard use stamina, which refills after a delay. Strong moves can chip through
guard. Opposing beams can clash. Double battles include an AI teammate.
EXP, level-ups, rewards and evolution connect to your native Platinum party.
The new-game creator offers Lucas, Dawn, Brendan, May, Red or Leaf, with skin, hair-color
and outfit-color choices. Arbitrary haircuts/clothing shapes are not included.

PLEASE EXPECT AN EARLY BUILD
The original Platinum story/maps remain, but the full campaign and real DS
hardware have not been validated. Some moves use simplified action behavior;
full abilities, weather and complex held-item rules are incomplete.
{directional_species} canonical species use directional animations. Extra
alternate forms may use native front/back battle images. Artist credits and
pinned source manifests are included in the credits folder.
Link, Frontier, Safari, Pal Park, tutorial and recorded battles keep the
original Platinum battle engine. Action catching currently uses ordinary
Poke Balls and skips the native nickname/Pokedex-detail screens.

TESTED IN THIS EXACT ROM
{tested}

OTHER UNTESTED OR LIMITED AREAS RECORDED FOR THIS ROM
{not_tested}

If you find a bug, record the area, Pokemon/moves, buttons pressed and what
happened. A screenshot or short video plus your emulator name is helpful.
The included RELEASE.json records the exact tested ROM SHA256.
Source-art attributions and license notices are retained in the credits folder.
"""


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def string_list(value, name, required=False):
    if not isinstance(value, list) or any(not isinstance(s, str) or not s.strip() for s in value):
        raise ValueError(name + " must be a list of nonempty strings")
    if required and not value:
        raise ValueError(name + " must describe the runtime checks")
    return value


def add_zip_file(archive, path, name):
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info._compresslevel = 9
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    # Streaming avoids retaining a 128 MiB ROM plus compressed copy in RAM.
    with path.open("rb") as source, archive.open(info, "w", force_zip64=True) as dest:
        shutil.copyfileobj(source, dest, 1024 * 1024)


def package(args):
    candidate = args.candidate.resolve(strict=True)
    if candidate.suffix.lower() != ".nds":
        raise ValueError("candidate must be an .nds file")
    if "VALIDATION-ONLY" in candidate.name.upper() or "runtime-fixture" in candidate.parts:
        raise ValueError("validation-only fixture ROMs cannot be released")
    if candidate.stat().st_size not in (134217728, 268435456):
        raise ValueError("expected a complete 128 or 256 MiB Platinum build")
    with candidate.open("rb") as stream:
        header = stream.read(512)
    if header[12:16] != b"CPUE":
        raise ValueError("candidate is not the configured US Platinum build")
    if (128 * 1024 << header[0x14]) != candidate.stat().st_size:
        raise ValueError("ROM capacity byte does not match the complete cartridge size")
    evidence = json.loads(args.evidence.read_text(encoding="utf-8"))
    if not isinstance(evidence, dict):
        raise ValueError("runtime evidence must be a JSON object")
    digest = sha256(candidate)
    if digest == BASELINE_SHA256:
        raise ValueError("candidate is the unchanged retail baseline")
    if evidence.get("candidate_sha256") != digest:
        raise ValueError("runtime evidence does not match the candidate SHA256")
    if evidence.get("production_build") is not True or evidence.get("validation_only") is not False:
        raise ValueError("evidence must explicitly identify a production, non-fixture build")
    checks = evidence.get("checks", {})
    if not isinstance(checks, dict):
        raise ValueError("checks must be a JSON object")
    missing = [name for name in REQUIRED_CHECKS if checks.get(name) != "passed"]
    if missing:
        raise ValueError("runtime acceptance checks are pending: " + ", ".join(missing))
    tested = string_list(evidence.get("tested"), "tested", required=True)
    not_tested = string_list(evidence.get("not_tested"), "not_tested", required=True)
    provenance = json.loads((ASSETS / "provenance.json").read_text(encoding="utf-8"))
    directional_species = evidence.get("directional_species", provenance["directional_species"])
    if not isinstance(directional_species, int) or not 0 <= directional_species <= 493:
        raise ValueError("directional_species must be an integer from 0 to 493")
    readme = PLAYER_GUIDE.format(
        tested="\n".join("- " + s for s in tested),
        not_tested="\n".join("- " + s for s in not_tested),
        directional_species=directional_species,
        rom_mib=candidate.stat().st_size // (1024 * 1024),
    )
    credit_sources = {
        "SPRITE-CREDITS.md": ASSETS / "SPRITE-CREDITS.md",
        "ADDITIONAL-CREDITS.md": ASSETS / "ADDITIONAL-CREDITS.md",
        "SpriteCollab-LICENSE.md": ASSETS / "SpriteCollab-LICENSE.md",
        "platinum-provenance.json": ASSETS / "provenance.json",
        "avatar-provenance.json": ASSETS / "avatar/provenance.json",
        "avatar/README.md": ASSETS / "avatar/README.md",
        "avatar/kanto-source/manifest.json": ASSETS / "avatar/kanto-source/manifest.json",
        "gen4/manifest.json": ASSETS / "gen4/manifest.json",
        "gen4/LICENSE.md": ASSETS / "gen4/LICENSE.md",
        "gen4/README.md": ASSETS / "gen4/README.md",
        "gen4/download-manifest.json": ASSETS / "gen4/source/download-manifest.json",
        "manifest.json": ORIGINAL_ASSETS / "manifest.json",
        "effects-provenance.json": ORIGINAL_ASSETS / "effects-provenance.json",
        "UI-SPRITES-CREDITS.md": ORIGINAL_ASSETS / "UI-SPRITES-CREDITS.md",
        "ui-sprites.json": ORIGINAL_ASSETS / "ui-sprites.json",
    }
    for name in ("Kenney-License.txt", "Kenney-README.md", "flame-source.html",
                 "guard-source.html", "stage-credits.json"):
        credit_sources["source/effects/" + name] = ORIGINAL_ASSETS / "source/effects" / name
    for path in sorted((ASSETS / "gen4/source").glob("*/credits.txt")):
        credit_sources["gen4/source/" + path.parent.name + "/credits.txt"] = path
    for name in ("manifest.json", "README.md", "LICENSE.md", "source/download-manifest.json"):
        credit_sources["directional/" + name] = ASSETS / "directional" / name
    for path in sorted((ASSETS / "directional/source").glob("*/credits.txt")):
        credit_sources["directional/source/" + path.parent.name + "/credits.txt"] = path
    for name in ("README.md", "manifest.json", "archives.json", "contact.png"):
        credit_sources["extra-effects/" + name] = ASSETS / "extra-effects" / name
    # Fail before writing any release when attribution inputs are missing.
    credit_hashes = {name: sha256(path) for name, path in credit_sources.items()}
    report = {
        "name": "Platinum Arena",
        "version": VERSION,
        "stage": "playtest",
        "rom": NAME + ".nds",
        "bytes": candidate.stat().st_size,
        "sha256": digest,
        "production_build": True,
        "validation_only": False,
        "checks": checks,
        "tested": tested,
        "not_tested": not_tested,
        "directional_species": directional_species,
        "credit_files_sha256": credit_hashes,
        "runtime_evidence_sha256": sha256(args.evidence),
        "baseline_revision": "1dc13dcea40c04ab53f1f607de46023dc409ef20",
    }

    args.dist.mkdir(parents=True, exist_ok=True)
    # Prepare everything first; an existing release with different bytes is never overwritten.
    with tempfile.TemporaryDirectory(prefix=".platinum-release-", dir=args.dist) as temporary:
        stage = Path(temporary)
        rom = stage / (NAME + ".nds")
        shutil.copyfile(candidate, rom)
        if sha256(rom) != digest:
            raise ValueError("candidate changed while copying into release")
        (stage / "PLAYER-README.txt").write_text(readme, encoding="utf-8")
        (stage / "RELEASE.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        payloads = [rom, stage / "PLAYER-README.txt", stage / "RELEASE.json"]
        for name, source in sorted(credit_sources.items()):
            destination = stage / "credits" / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
            if sha256(destination) != credit_hashes[name]:
                raise ValueError("credit input changed while copying: " + str(source))
            payloads.append(destination)
        credit_readme = stage / "credits/README.txt"
        credit_readme.write_text(
            "These original notices retain the supplied source-art attributions.\n"
            "SPRITE-CREDITS.md and manifest.json describe the original Emerald\n"
            "Arena asset import; their counts are not Platinum coverage claims.\n"
            "platinum-provenance.json describes this Platinum asset conversion.\n"
            "gen4/ retains pinned upstream source hashes, per-species artist\n"
            "credits and the license for the 107 added Gen IV directional sets.\n"
            "directional/ retains the corresponding records for the remaining\n"
            "canonical directional animation sets added in 0.9.3.\n"
            "The SpriteCollab license applies to its identified contributions;\n"
            "the Kenney notice applies to the identified Kenney particle. These\n"
            "licenses are not a license for all Pokemon/Nintendo/Chunsoft art.\n",
            encoding="utf-8")
        payloads.append(credit_readme)
        (stage / "SHA256SUMS").write_text(
            "".join(sha256(path) + "  " + path.relative_to(stage).as_posix() + "\n" for path in payloads), encoding="ascii"
        )
        archive = stage / (NAME + ".zip")
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
            for path in payloads + [stage / "SHA256SUMS"]:
                add_zip_file(zipped, path, path.relative_to(stage).as_posix())
        with zipfile.ZipFile(archive) as zipped:
            if zipped.testzip() is not None:
                raise ValueError("generated ZIP failed its CRC check")

        outputs = {
            rom: args.dist / rom.name,
            archive: args.dist / archive.name,
            stage / "PLAYER-README.txt": args.dist / ("READ-ME-Platinum-" + VERSION + ".txt"),
            stage / "RELEASE.json": args.dist / (NAME + ".json"),
            stage / "SHA256SUMS": args.dist / ("SHA256SUMS-Platinum-" + VERSION),
        }
        # Include the ZIP hash in the external checksum file, without a cyclic hash inside the ZIP.
        external_sums = stage / "external-SHA256SUMS"
        external_sums.write_text(
            "".join(sha256(path) + "  " + dest.name + "\n" for path, dest in outputs.items()
                    if path.name != "SHA256SUMS"), encoding="ascii"
        )
        del outputs[stage / "SHA256SUMS"]
        outputs[external_sums] = args.dist / ("SHA256SUMS-Platinum-" + VERSION)
        for source, destination in outputs.items():
            if destination.exists() and sha256(source) != sha256(destination):
                raise ValueError("refusing to overwrite an existing release: " + str(destination))
        for source, destination in outputs.items():
            if not destination.exists():
                os.replace(source, destination)
        result = dict(report)
        result["rom"] = str(args.dist / rom.name)
        result["zip"] = str(args.dist / archive.name)
        result["zip_sha256"] = sha256(args.dist / archive.name)
        print(json.dumps(result, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True, help="immutable production .nds candidate")
    parser.add_argument("--evidence", type=Path, required=True, help="matching runtime acceptance JSON (see README.md)")
    parser.add_argument("--dist", type=Path, default=Path("/workspace/Pokemon-arena-evolved/dist"))
    args = parser.parse_args()
    try:
        package(args)
    except (ValueError, OSError, json.JSONDecodeError) as error:
        parser.exit(1, "Cannot package release: " + str(error) + "\n")


if __name__ == "__main__":
    main()
