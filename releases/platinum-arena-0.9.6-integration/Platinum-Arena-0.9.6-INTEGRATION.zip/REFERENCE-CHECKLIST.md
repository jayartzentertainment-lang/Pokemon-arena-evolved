# Native Platinum Arena 0.9.6: Phase 0 reference checklist

Prepared 21 October 2026. This document audits supplied footage and the preserved
0.9.5 baseline. It does not assert that the in-progress 0.9.6 ROM has been built
or played. Source implementation, prior runtime evidence, sampled reference
observations and new-candidate acceptance must remain separate.

## Evidence boundaries and baseline

- Directive: `MASTER-DIRECTIVE.txt` beside this document. Latest user direction
  authorizes targeted native tests/emulator verification and supersedes the
  older no-testing directions recorded in historical intake/release documents.
- Frozen baseline ROM: `../candidates/ArenaPlus-Platinum-0.9.5-INTEGRATION-adee9101fa8f.nds`,
  SHA-256 `adee9101fa8ff3d5170f5aa7411a521ba231c5b78b55a73bb9b48216d37170c9`.
- Baseline source ZIP: `../../release/integration-095/Platinum-Arena-0.9.5-SOURCE.zip`,
  SHA-256 `f31c3f39bf9d2c1616171d936bbdc39232fea0995376a3f36123e0c6eb250487`.
  Fifty native arena source/header files were extracted read-only under
  `reference-review/baseline-095/`; `EXTRACTION.json` gives ZIP entries and hashes.
- `../v095/HANDOFF.json` records native compile/link success only. Its gameplay,
  emulator, host tests and hardware checks were not run under the earlier request.
- `../v093/final-runtime-acceptance.json` records a different 0.9.3-D ROM
  (`47970d69c1eb…`) with creator previews and Battle Lab 1v1/shields observed;
  its final story/return/save-reload and final 2v2 checks were still pending.
  Preview-A story/save successes belong to yet another ROM (`1413f0c56a23…`).
  None is evidence that 0.9.5 or 0.9.6 passes those scenarios.

## Actual video availability and inspection

All seven locally available uploaded MP4s were probed with ffprobe. Nine evenly
spaced frames per clip were decoded and visually inspected. Six clips also have
short-window sheets (12–20 frames each), inspected to understand release/contact,
shield and beam continuity. This is sampled visual review, not uninterrupted
playback or frame-by-frame input/physics reconstruction. Exact metadata, hashes,
sample timestamps and contact-sheet paths are in
`reference-review/video-availability.json`.

The three files called `videoplayback` are different footage. The external
Sediment-ID-to-local-path mapping for the main video was not retained here; all
three are explicitly identified by path/hash rather than silently conflated.
The four distinctly named Emerald clips are present. No missing reference clip
is inferred from a filename collision.

| Key / file and local attachment directory | Duration; raster; nominal rate | Content actually observed |
| --- | --- | --- |
| V1 `emerald-arena-combat-update.mp4`, `09335b2e-…` | 15.738 s; 960×640; ~59.73 fps | Top-down Blastoise/Eevee field fight, move menu with Water Gun/Bite/Rapid Spin/Protect, PP and HP updates. |
| V2 `emerald-arena-17s.mp4`, `a62b681f-…` | 17.000 s; 960×640; 60 fps | Overworld-to-arena transition, Charizard/Blastoise fight, directional creature poses, streaks and projectile/contact feedback. |
| V3 `emerald-arena-protect-playtest.mp4`, `ae44355c-…` | 49.793 s; 1440×1010; 60 fps | Gardevoir/Dragonite shield/flame interaction, later Blastoise/Sceptile, native bag/party healing and Charizard replacement. |
| V4 `videoplayback (1).mp4`, `d9151d42-…` | 36.037 s; 640×360; 30 fps | Overworld followers and real-time in-map battles with native-looking HP/move panels. |
| V5 `emerald-arena-cover-smoke.mp4`, `dbb51e25-…` | 23.050 s; 1440×1080; 60 fps | Elite Four entry, arena cover, Substitute, fixed-world smoke, continuous flame and broken props/debris. |
| V6 `videoplayback.mp4`, `e612883a-…` | 205.055 s; 640×360; 30 fps | Extended enclosed top-down duel showcase: Persian, Pidgeot, Jolteon, Rhydon, Lapras, Alakazam, Scyther, Arcanine, Dodrio, Exeggutor and Charizard/Blastoise variants. |
| V7 `videoplayback.mp4`, `e90dbc4b-…` | 122.183 s; 640×360; 30 fps | Cinematic edited montage including giant Onix, environment damage, Charizard/Blastoise beam collision and psychic/electric effects. |

### Movement, animation, dash and attack timing

| Clip | Movement / acceleration, idle / turning | Dash distance / animation | Anticipation, execution, recovery / reactions |
| --- | --- | --- | --- |
| V1 | Pokémon change position and facing in the arena; Blastoise shows distinct side/front/back poses. Acceleration and idle breathing cannot be measured from these samples. | No unambiguous controlled dash isolated. | Detail 3.682→3.818 s changes Blastoise firing pose and Water Gun PP 25→24; shot visible at 3.955 s, Eevee HP 89→66 by 4.091 s with impact puff. These are brackets, not exact hit/startup durations. Recovery and knockback magnitude are not separable from ongoing movement. |
| V2 | Charizard's wing/body poses and Blastoise facing vary visibly. Both move independently across a fixed field; acceleration and deceleration are not quantified. | Pale rectangular trails and colored streaks occur around 3.4–4.4 s; no input log establishes which are dash versus move effects or exact travel distance. | Wing Attack PP 35→34 by 3.136 s, then creature motion/trails. Later HP drops and floating damage make reactions readable. Cannot infer canonical invulnerability or attack recovery from the clip. |
| V3 | Dragonite and Gardevoir turn/reposition; Gardevoir leans during the shield sequence. Nonmoving spans exist, but breathing cadence is not resolved. | No distinct dash measured in chosen window. | Flame buildup/release and defender shield are visible 5.6–6.7 s. Guarded HP appears stable across this sequence. Exact recoil magnitude and whether movement is AI, player or hit impulse remain unknown. |
| V4 | Trainer and follower traverse the overworld; creature encounters retain a top-down world setting and directions. Acceleration/idle mechanics are unknown. | No unambiguous dash evidence. | Move-name/PP panels, damage and “Miss!” feedback are visible. Sparse samples do not isolate release/recovery or contact timing. |
| V5 | Charizard changes facing and moves away from its smoke origin; Shelgon moves independently. Facing matches flame direction. Acceleration not measured. | No isolated dash input or distance. | Smoke grows around 12.263–12.789 s. Flame begins between 15.421–15.684 s and continues through 16.474 s before ending by 16.737 s. Charizard has a recognizable extended firing pose. Reaction flash/damage text precedes this flame; it must not be called proof of flame damage. |
| V6 | Many species have different silhouettes, animated body/wing poses and movement/contact effects. Attack names and hit/type messages are frequent; exact species speed curves are unknown. | Dust and directional motion trails are visible; input and distance are not recoverable from the sampled footage. | 72–76 s detail shows X-Scissor/contact flashes, multiple damage numbers, Flame Blitz, fainting and recoil text. Fast successive events remain readable through distinct effects; exact mechanics are not proven by those labels. |
| V7 | Onix visibly bends/segments across the field; other species show large pose changes and dramatic recoil/motion. Edited cuts and camera changes prevent speed/idle measurement. | Onix has a ground dust trail near 30.5 s; no canonical dash distance/rule can be inferred. | 69.316 s shows blue charge before opposing streams appear by 69.579 s; both sustain through 71.158 s before a cut at 71.421 s. This establishes visual continuity, not simulation duration or winning-clash damage. |

### Guard, clashes, VFX, camera, environment and pacing

| Clip | Guard / clashes | Camera / special VFX | Environment / battle pacing |
| --- | --- | --- | --- |
| V1 | Protect appears in the menu; chosen samples do not prove its use. No clash isolated. | Fixed whole-arena framing; slim blue Water Gun shot, compact contact puffs/damage numbers, persistent top HP/PP strip. | Rocks/crate/foliage stay fixed in the samples. Several attacks/exchanges occur inside ~12 s of combat with a menu interruption. |
| V2 | No shield or clash conclusively isolated. | Fixed whole arena after overworld entry; water shots, contact feedback and streaks. Trainers remain at edges. | No verified elemental terrain reaction. Rapid attacks but both bodies and HP remain legible. |
| V3 | Clear blue circular Protect surrounds Gardevoir at 6.133–6.667 s while flame terminates toward it; PP 10→9. This supports layered defensive contact presentation. No attack-vs-attack clash isolated. | Fixed battlefield, native party/bag overlays interrupt the view; shield scales to the defender without replacing its silhouette. | Stable rocks/foliage; later healing and replacement demonstrate tactical pauses. No proof of guard stamina, damage formula or temporary hazards. |
| V4 | No guard/clash proven from sampled frames. | Camera follows overworld traversal; encounters occur in the same map view with HP/PP panels. | Grass/path world remains visible; no tested destruction/hazard. Short encounter loops interleave traversal. |
| V5 | Substitute is visible; no shield/clash isolated. | Fixed whole arena; expanding dense smoke persists at its world location while Charizard moves, then wide flame with clear mouth-facing origin. | Left crate disappears and debris remains after flame at ~16–18 s. Smoke conceals Shelgon visually. Concealment/accuracy logic, elemental damage and object health rules cannot be established visually. |
| V6 | No guard or paired-beam collision isolated in sampled windows. | Fixed enclosed field with top HP/type/team/status panels; slash marks, auras, projectiles, impacts, brief dramatic hit insert. | Floor marks/debris persist between sampled beats. Stat and ability labels are visible but do not prove underlying arithmetic. Long showcase with repeated exchanges, fainting/replacements and varied species. |
| V7 | Two distinct streams meet at a shared bright center with spray/steam at 69.579–71.158 s. No input or fair/stat-driven resolution is recoverable from the montage. | Changing shots/zooms, huge species silhouettes, continuous beams, electric arcs, psychic orbs and rings. Do not copy montage cutting/shake into the required stable DS battle camera. | Broken flooring, debris, dust, fire and steam visually connect to impacts. Cinematic edits exclude reliable overall combat-speed comparison. |

## Reference-to-feature implementation checklist

“Present” below means the frozen 0.9.5 C source contains the behavior. It does
not mean it passed 0.9.5 gameplay verification. New 0.9.6 deltas need their own
build hash and runtime/host evidence; no row is automatically upgraded here.

| Requirement / reference | Frozen 0.9.5 implementation | Gap or acceptance still required |
| --- | --- | --- |
| Top-down direct combat; whole field; trainers outside active field (V1–V7) | Native encounter→arena overlay, direct control, top battlefield/lower HUD, 1v1/2v2 source paths. | Verify new candidate boot, Lab 1v1 first, 2v2 next and native encounter return. |
| Eight-way motion, turning, timed idle/walk (V1/V2/V6) | Q8 acceleration/braking in `ArenaPlus_MoveStep`; eight direction rows; 493 canonical species directional asset coverage; displacement-driven walking phase. | Authored extra poses only five slots (`Idle/Walk/Shoot/Attack/SpAttack`); 64 alternate forms retain still-image fallback. Exact feel/anchors remain unverified. |
| Windup→active→recovery, contact reaction (V1/V5/V6) | Explicit phases, XML hit-tick mapping, source attack envelopes, contact event emitted on real damage; damped knockback/hurt timer. | Separate hurt/brace/charge/entry/faint art not loaded broadly. No universal extra limb motion can be claimed. Must compare new sprite/beam registration while turning. |
| Species-specific motion and attack origins (V6/V7) | Speed/stat differences, authored species dimensions, ground point and scaled beam emitters. | No comprehensive species locomotion/archetype controller. Validate representative small/heavy/floating sprites and real source poses rather than identical scaling. |
| Air/wind dash (request, V2 contextual streaks) | Directional B dash and released-direction double-tap; 12-tick velocity envelope, 22 stamina, 30-tick cooldown; directional narrow generated streaks. | Thin two-frame primitive family is a limited treatment; layered curved wind, startup swirl and surface-specific disturbance are incomplete. Check all eight directions, cleanup and wall behavior. |
| Guard/contact/recoil (V3) | Held directional guard, five-tick perfect window, stamina drain/exhaustion, heavy chip/rebound, imported shield art, bounded hit pause. | Guard uses idle body pose. New candidate must show appropriate silhouette, incoming direction, recoil and no sticky B state. |
| Beam/projectile clashes (V7) | Two owned beam pairs; shared point, action serials and cleanup; projectile mutual collision. | 0.9.5 beam pressure uses repeated fresh button taps and bounded AI pulses. Latest directive specifically rejects arbitrary button-mashing; reconcile in 0.9.6 and document real stat/type/power/angle rules. |
| Sustained typed VFX (V3/V5/V7) | Cached animated flame/water/ice beam art, selected PMD/Ranger/KOF atlas, Swift stars from supplied D/P sheet, move profiles and release sounds. | Most moves still share visual families; non-fire/water/ice beams neutralized to generic energy. Expanded supplied art is an arsenal, not complete move coverage. Keep per-move manifest and truthful fallback list. |
| Buffs/debuffs and statuses (V6 labels; directive functional requirement) | Timed attack/defense/speed up/down and slow; 300/240/120-tick counters influence damage/movement; heal and guard classification. | No canonical bounded stat stages or distinct special/accuracy/evasion stage model. Poison/burn/paralysis/sleep/freeze/confusion are absent from live behavior; several moves are approximated as slow/guard. HUD native status labels alone do not implement status mechanics. |
| Slightly slower readable commitments | Per-move timing profiles exist; simulation is fixed-clock rather than globally slowed. | No verified reference-derived timing match; 10–15% request must be tested per archetype with fast inputs still responsive. |
| Four learned moves, PP, natural attacks | All four equipped slots accessible Y/A/X plus L-toggle; PP spent on successful action start; all-empty PP-free Struggle fallback. | Dedicated species-appropriate PP-free natural attack not exposed. Heavy per-move cooldown rather than recovery-only gating needs explicit audit. |
| Latest intended controls | Baseline Y=move1, A=move2, X=move3/4, L=toggle, B=guard/dodge, Select=aim, Start=pause, L+R=catch. | Differs from directive's Y natural, L+Y/L+A cycling, R switch, held R+X tactic. Existing player input/HUD/config must change together if adopting latest intended layout. |
| World smoke / props / terrain (V5/V7) | Obstacle collision, destructible props, debris/fuses/chain effects in physics, world coordinates; terrain explosion is explicitly visual/physical only. | No complete fixed-world concealment system or gameplay fire/steam/ice/electrified-puddle hazard lifecycle. Do not treat decorative terrain bursts as damage/status zones. |
| AI, allies and switching | AI considers range/type/PP/stamina/threats; actor/team ownership, no friendly HP damage, replacements, controlled-ally transfer source APIs; pause-party switch UI. | No complete directive tactical-command system, hazard-aware planning or R-tap/held-R UI. Must verify 1v1 before 2v2, faint/replacement/cleanup and preserved native rewards. |
| PokéMMO-inspired creator | Six regional base identities with skin/hair/outfit palette choices, stationary large field preview, native naming, CRC/versioned record in four audited PlayerSave padding bytes. | No layered hairstyle/top/legwear/hat/dye creator, facing controls, tabs/random/reset, or supported eye/face layers in baseline. New creator must pass name handoff and normal save/restart retaining its visible appearance. |
| DS resources | 0.9.5 chosen OBJ bank allocation 64,832/65,536 bytes; streamed cached effects, four actors, no per-frame source PNG read. | Only 704 bytes spare in that bank; profile new atlas/OAM/RAM changes and 2v2 beam/hazard load. Host/emulator FPS is not real DS performance proof. |

## Asset source-of-truth

See `ASSET-AVAILABILITY.json` for freshly checked local archive paths/hashes,
native manifests and explicitly inherited prior review locations. This review
did not re-open 19,044 PMD PNGs or render every XCF layer. It uses those saved
inventories honestly instead of treating an earlier asset audit as new viewing.

- `/workspace/asset-review/2026-10-20-sprite-intake.md`: 19,044 PMD frames/pieces,
  256 Ranger PNGs, 402 KOF PNGs; source markers/transparency/timing limitations;
  original inline UI sheets had no locally available source file in that audit.
- `/workspace/asset-review/arsenal-2026-10-21/REVIEW.md` and subreviews: 95 D/P
  sheets, 1,729 trainer PNGs, 12 XCF projects / 3,411 layer entries. New exports
  carry reference/guide pixels and require explicit masks/offsets.
- `/workspace/asset-review/customization-2026-10-21/character-customization/FRAME-REVIEW.md`:
  first 158-PNG 32×48 layer set and source-only compositor coverage.
- `/workspace/asset-review/pokemmo-hub-2026-10-21/UI-REVIEW.md`: pinned Cosmetics
  Helper structure/catalogue reference; remote avatar rendering is not native
  trainer-layer artwork or a DS implementation.
- `/workspace/asset-review/animation-code-2026-10-21/` and `followup/`: preserved
  Unity sketches and static defect reviews. No source execution or platform
  switch is implied. Their timing examples are not measured reference timings.
- Native `res/arena/{directional,gen4,extra-effects,beam-effects,move-effects}/`
  manifests are the authoritative imported subsets, not the full source arsenal.

For execution steps and concrete evidence gates see `TARGETED-SMOKE-PLAN.md`.
