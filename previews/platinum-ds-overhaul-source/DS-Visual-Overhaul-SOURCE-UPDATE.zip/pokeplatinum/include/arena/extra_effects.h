#ifndef PLATINUM_ARENA_EXTRA_EFFECTS_H
#define PLATINUM_ARENA_EXTRA_EFFECTS_H
#include <stdint.h>
enum ArenaExtraEffect { ARENA_EXTRA_FIRE,ARENA_EXTRA_WATER,ARENA_EXTRA_ELECTRIC,
    ARENA_EXTRA_ICE,ARENA_EXTRA_HIT,ARENA_EXTRA_GUARD,ARENA_EXTRA_CLASH };
#define ARENA_EXTRA_FRAMES 56
#ifdef ARENA_ENABLE_LEGACY_ATLAS
extern const uint8_t arena_extra_tiles[ARENA_EXTRA_FRAMES][512];
extern const uint16_t arena_extra_palette[16];
#endif
unsigned ArenaExtra_Frame(unsigned group,unsigned tick);
unsigned ArenaExtra_ForType(unsigned type);
#endif
