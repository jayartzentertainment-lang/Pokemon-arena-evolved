/* Presentation only: no PP, hitbox, damage or status changes. */
#ifndef PLATINUM_ARENA_PRESENTATION_H
#define PLATINUM_ARENA_PRESENTATION_H
#include <stdint.h>

enum ArenaPresentationFamily {
    ARENA_PRESENT_FIRE, ARENA_PRESENT_WATER, ARENA_PRESENT_ELECTRIC,
    ARENA_PRESENT_ICE, ARENA_PRESENT_HIT, ARENA_PRESENT_GUARD,
    ARENA_PRESENT_CLASH, ARENA_PRESENT_SLASH, ARENA_PRESENT_LEAF,
    ARENA_PRESENT_PSYCHIC, ARENA_PRESENT_SHADOW, ARENA_PRESENT_BUFF,
    ARENA_PRESENT_DEBUFF,
    ARENA_PRESENT_POISON, ARENA_PRESENT_GROUND, ARENA_PRESENT_ROCK,
    ARENA_PRESENT_WIND, ARENA_PRESENT_FIGHTING, ARENA_PRESENT_BUG,
    ARENA_PRESENT_DRAGON, ARENA_PRESENT_STEEL, ARENA_PRESENT_SOUND,
    ARENA_PRESENT_PULSE, ARENA_PRESENT_GRASS_ENERGY, ARENA_PRESENT_SHADOW_ORB,
    ARENA_PRESENT_SWORDS, ARENA_PRESENT_HEAL, ARENA_PRESENT_ENERGY,
    ARENA_PRESENT_BOLT, ARENA_PRESENT_FAMILY_COUNT
};
enum ArenaPresentationFlags {
    ARENA_PRESENT_SWIFT = 1, ARENA_PRESENT_NONE = 2, ARENA_PRESENT_CLAW = 4
};
#define ARENA_PRESENT_FIRST_STREAMED ARENA_PRESENT_POISON
#define ARENA_PRESENT_STREAMED_FAMILIES 16
#define ARENA_PRESENT_MOVE_COUNT 468
#define ARENA_PRESENT_FRAME_BYTES 512
#define ARENA_PRESENT_FRAMES 4

typedef struct {
    uint8_t family, flags;
} ArenaMoveVisual;

/* All 467 equipped move IDs have a generated, explicit assignment. Invalid
 * IDs intentionally produce no visual; a source filename never drives IDs. */
const ArenaMoveVisual *ArenaPresentation_Move(unsigned move);
unsigned ArenaPresentation_TypeFamily(unsigned type);
/* Four source cels at three simulation ticks each, shared by family so that
 * all active instances of a family need exactly one native OBJ image slot. */
unsigned ArenaPresentation_Frame(unsigned clock);
int ArenaPresentation_Oriented(unsigned family);
#endif
