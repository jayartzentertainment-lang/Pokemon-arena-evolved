#!/usr/bin/env python3
"""Import four supplied Ranger beam strips as bounded native DS OBJ data.

This importer preserves the common 128x32 frame canvas and all selected
opaque source colors. It performs no resizing, color quantization, or frame-by-frame
recentering. Each frame contains four left-to-right 32x32 OBJs, so the renderer
can upload one 2048-byte frame into a shared OBJ image slot.
"""

import argparse
import hashlib
import json
from pathlib import Path
import shutil

from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "res/arena/beam-effects"
STYLES = (("MEDIUM", "0/107.png"), ("THIN", "0/106.png"),
          ("WATER", "0/105.png"), ("ICE", "0/108.png"))
FRAMES = 4
WIDTH = 128
HEIGHT = 32
CHUNKS = 4
CHUNK_WIDTH = 32
CHUNK_BYTES = CHUNK_WIDTH * HEIGHT // 2
FRAME_BYTES = WIDTH * HEIGHT // 2
ARCHIVE = {
    "file": "DS _ DSi - Pokemon Ranger 3_ Guardian Signs - Miscellaneous - Attack Effects.zip",
    "bytes": 1000852,
    "sha256": "6de9c9527a722f71b2bbfd910867a2327c5928beca97c26dae44e93cc4bdda6b",
    "source": "User-supplied sprite archive",
}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def remove_registration(pixel):
    r, g, b, a = pixel
    return (0, 0, 0, 0) if r > 190 and b > 190 and g < 100 else pixel


def pack_frame(indices):
    """Pack four contiguous 32x32 4bpp OBJs; low nibble is the left pixel."""
    if len(indices) != WIDTH * HEIGHT:
        raise ValueError("A beam frame must contain exactly 128x32 pixels")
    packed = bytearray()
    for chunk in range(CHUNKS):
        for tile_y in range(HEIGHT // 8):
            for tile_x in range(CHUNK_WIDTH // 8):
                for pixel_y in range(8):
                    row = (tile_y * 8 + pixel_y) * WIDTH
                    for pixel_x in range(0, 8, 2):
                        x = chunk * CHUNK_WIDTH + tile_x * 8 + pixel_x
                        packed.append(indices[row + x] | (indices[row + x + 1] << 4))
    if len(packed) != FRAME_BYTES:
        raise ValueError("Unexpected packed frame size")
    return bytes(packed)


def c_bytes(data, indent):
    return "\n".join(
        indent + ", ".join(f"0x{value:02x}" for value in data[start:start + 16]) + ","
        for start in range(0, len(data), 16)
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEST / "source",
                        help="Retained source directory containing the four selected 0/*.png sheets")
    parser.add_argument("--import-upload", type=Path,
                        help="Extracted user archive directory containing the selected 0/*.png sheets")
    args = parser.parse_args()
    source = args.import_upload or args.source

    sequences = []
    source_records = []
    colors = set()
    for name, relative in STYLES:
        path = source / relative
        original_bytes = path.read_bytes()
        with Image.open(path) as opened:
            original = opened.convert("RGBA")
        if original.size != (136, 160):
            raise ValueError(f"{relative}: expected the original 136x160 sheet")
        frames = []
        frame_records = []
        for index in range(FRAMES):
            crop = (4, 40 * index + 4, 132, 40 * index + 36)
            frame = original.crop(crop)
            pixels = [remove_registration(pixel) for pixel in frame.getdata()]
            if any(a not in (0, 255) for r, g, b, a in pixels):
                raise ValueError(f"{relative}: partial alpha cannot be represented by native 4bpp OBJ")
            opaque = {(r, g, b) for r, g, b, a in pixels if a}
            if not opaque:
                raise ValueError(f"{relative}: frame {index} is empty")
            colors.update(opaque)
            frames.append(pixels)
            frame_records.append({"frame": index, "crop": list(crop)})
        sequences.append(frames)
        source_records.append({
            "style": name,
            "source": "source/" + relative,
            "source_sha256": sha256(original_bytes),
            "source_bytes": len(original_bytes),
            "source_size": [136, 160],
            "frames": frame_records,
        })

    # Index zero is transparent. Sorting makes palette assignment deterministic.
    # Source channels already lie on the DS RGB5 lattice, so no rounding or
    # nearest-color lookup is allowed: each opaque RGB tuple gets its own index.
    ordered_colors = sorted(colors)
    if not 1 <= len(ordered_colors) <= 15:
        raise ValueError("Native 4bpp OBJ requires at most 15 opaque colors")
    if any(channel % 8 for color in ordered_colors for channel in color):
        raise ValueError("Source contains colors outside the exact DS RGB5 lattice")
    color_indices = {color: index + 1 for index, color in enumerate(ordered_colors)}
    palette = [0] + [r // 8 | ((g // 8) << 5) | ((b // 8) << 10)
                     for r, g, b in ordered_colors]
    if len(set(palette[1:])) != len(ordered_colors):
        raise ValueError("Source colors would collide in the DS palette")
    palette.extend([0] * (16 - len(palette)))
    tiles = [[pack_frame([color_indices[(r, g, b)] if a else 0
                          for r, g, b, a in frame]) for frame in sequence]
             for sequence in sequences]
    all_tiles = b"".join(frame for sequence in tiles for frame in sequence)
    if len(all_tiles) != 32768:
        raise ValueError("The bounded beam asset must occupy exactly 32768 tile bytes")

    header = """/* Generated by tools/arena/import_beam_effects.py. */
#ifndef PLATINUM_ARENA_BEAM_EFFECTS_H
#define PLATINUM_ARENA_BEAM_EFFECTS_H

#include <stdint.h>

enum ArenaBeamStyle {
    ARENA_BEAM_MEDIUM = 0,
    ARENA_BEAM_THIN = 1,
    ARENA_BEAM_WATER = 2,
    ARENA_BEAM_ICE = 3
};

#define ARENA_BEAM_STYLES 4
#define ARENA_BEAM_FRAMES 4
#define ARENA_BEAM_FRAME_BYTES 2048
#define ARENA_BEAM_CHUNK_BYTES 512
#define ARENA_BEAM_CHUNKS 4
#define ARENA_BEAM_WIDTH 128
#define ARENA_BEAM_HEIGHT 32

/* Bounds: style < ARENA_BEAM_STYLES, frame < ARENA_BEAM_FRAMES.
 * Frame layout: four 32x32 OBJs from left to right, at 512-byte intervals.
 * Each chunk has row-major 8x8 tiles; pixel pairs use low nibble then high.
 * Palette index 0 is transparent; other indices preserve selected source colors.
 * Upload only the selected frame: one shared 2048-byte image slot suffices.
 */
extern const uint8_t arena_beam_tiles[ARENA_BEAM_STYLES][ARENA_BEAM_FRAMES][ARENA_BEAM_FRAME_BYTES];
extern const uint16_t arena_beam_palette[16];

#endif
"""
    generated = [
        "/* Generated by tools/arena/import_beam_effects.py; credits in res/arena/beam-effects. */",
        '#include "arena/beam_effects.h"',
        "",
        "const uint8_t arena_beam_tiles[ARENA_BEAM_STYLES][ARENA_BEAM_FRAMES][ARENA_BEAM_FRAME_BYTES] = {",
    ]
    for (name, _), sequence in zip(STYLES, tiles):
        generated.append(f"    {{ /* {name} */")
        for index, frame in enumerate(sequence):
            generated.extend([f"        {{ /* frame {index} */", c_bytes(frame, "            "), "        },"])
        generated.append("    },")
    generated.extend([
        "};",
        "",
        "const uint16_t arena_beam_palette[16] = {",
        "    " + ", ".join(f"0x{word:04x}" for word in palette) + ",",
        "};",
        "",
    ])

    manifest = {
        "archive": ARCHIVE,
        "game": "Pokémon Ranger: Guardian Signs (Nintendo DS)",
        "style_count": len(STYLES),
        "frames_per_style": FRAMES,
        "frame_size": [WIDTH, HEIGHT],
        "chunk_size": [CHUNK_WIDTH, HEIGHT],
        "chunks_per_frame": CHUNKS,
        "chunk_bytes": CHUNK_BYTES,
        "frame_bytes": FRAME_BYTES,
        "tile_bytes": len(all_tiles),
        "palette_bytes": 32,
        "rom_data_bytes": len(all_tiles) + 32,
        "live_obj_image_bytes": FRAME_BYTES,
        "opaque_palette_colors": len(ordered_colors),
        "palette_rgb888": [[0, 0, 0]] + [list(color) for color in ordered_colors],
        "palette_rgb5_words": palette,
        "transparent_palette_index": 0,
        "color_conversion": "Exact RGB5 conversion: all source channels are divisible by 8; no quantization, rounding, or color merging.",
        "crop": "For frame i=0..3, crop (4,40*i+4,132,40*i+36); preserve that 128x32 common canvas with no resizing or recentering.",
        "registration_removal": "Set pixels with r>190 and b>190 and g<100 transparent.",
        "layout": "Style-major, then frame-major. Each frame contains four left-to-right 32x32 chunks, 512 bytes each. Within a chunk, 8x8 tiles are row-major; low nibble is the left pixel of each pair.",
        "tile_sha256": sha256(all_tiles),
        "sources": source_records,
    }

    DEST.mkdir(parents=True, exist_ok=True)
    if args.import_upload:
        for _, relative in STYLES:
            target = DEST / "source" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if (source / relative).resolve() != target.resolve():
                shutil.copyfile(source / relative, target)
    (ROOT / "include/arena/beam_effects.h").write_text(header, encoding="utf-8")
    (ROOT / "src/arena/beam_effects.c").write_text("\n".join(generated), encoding="utf-8")
    (DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"styles": len(STYLES), "frames_per_style": FRAMES,
                      "tile_bytes": len(all_tiles), "palette_bytes": 32,
                      "live_obj_image_bytes": FRAME_BYTES,
                      "opaque_colors": len(ordered_colors), "tile_sha256": manifest["tile_sha256"]}))


if __name__ == "__main__":
    main()
