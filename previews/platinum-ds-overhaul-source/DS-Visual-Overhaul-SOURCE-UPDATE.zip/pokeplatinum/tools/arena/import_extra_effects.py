#!/usr/bin/env python3
"""Cut the supplied effect frames into a bounded native DS sprite atlas."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / 'res/arena/extra-effects'
GROUPS = ('FIRE', 'WATER', 'ELECTRIC', 'ICE', 'HIT', 'GUARD', 'CLASH')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=DEST/'source')
    parser.add_argument('--import-upload', type=Path, help='Extracted 0 Ranger / 1 KOF / 2 PMD folders')
    args = parser.parse_args()
    source = args.import_upload or args.source
    selections = []
    for group, folder in [('FIRE','0005'),('WATER','0103'),('ELECTRIC','0215'),('ICE','0141')]:
        files = sorted((source/'2/move_VFX'/folder/'000').glob('*.png'))
        if not files:
            raise ValueError('Missing original effect directory: '+folder)
        for i in range(8):
            selections.append((group, files[round(i*(len(files)-1)/7)], None))
    for i in range(8):
        selections.append(('HIT', source/'1/Effects'/('Effects_'+str(i)+'.png'), None))
    # Ranger cells have variable heights; transparent separator rows define
    # these first five rings. Do not assume a square grid for that sheet.
    rings=[(0,7,120,17),(0,33,120,55),(0,74,120,110),(0,124,120,172),(0,187,120,236)]
    for index in [0,1,2,3,4,3,2,1]:
        selections.append(('GUARD', source/'0/24.png', rings[index]))
    for index in range(390,398):
        selections.append(('CLASH', source/'1/Effects'/('Effects_'+str(index)+'.png'), None))

    # Keep a common origin/scale within each sequence. The transparent canvas
    # is measured once across its sequence so growing rings do not jitter.
    sequences=[]; records=[]
    for group in GROUPS:
        chosen=[s for s in selections if s[0]==group]
        images=[]
        for _,path,crop in chosen:
            im=Image.open(path).convert('RGBA')
            if crop:
                im=im.crop(crop)
                # The Ranger sheet uses isolated magenta registration dots.
                im.putdata([(0,0,0,0) if r>190 and b>190 and g<100 else (r,g,b,a)
                            for r,g,b,a in im.getdata()])
                im=im.crop(im.getbbox())
            images.append(im)
        width=max(im.width for im in images);height=max(im.height for im in images)
        canvas=[]
        for im in images:
            frame=Image.new('RGBA',(width,height));frame.alpha_composite(im,((width-im.width)//2,(height-im.height)//2));canvas.append(frame)
        bounds=[im.getbbox() for im in canvas if im.getbbox()]
        box=(min(b[0] for b in bounds),min(b[1] for b in bounds),max(b[2] for b in bounds),max(b[3] for b in bounds))
        scale=min(30/(box[2]-box[0]),30/(box[3]-box[1]),1)
        size=(max(1,round((box[2]-box[0])*scale)),max(1,round((box[3]-box[1])*scale)))
        for i,(im,(_,path,crop)) in enumerate(zip(canvas,chosen)):
            cut=im.crop(box).resize(size,Image.Resampling.NEAREST)
            frame=Image.new('RGBA',(32,32));frame.alpha_composite(cut,((32-size[0])//2,(32-size[1])//2));sequences.append(frame)
            relative=path.relative_to(source)
            records.append({'group':group,'frame':i,'source':relative.as_posix(),'source_sha256':digest(path),'crop':crop,'sequence_bounds':box,'display_size':size})
            if args.import_upload:
                target=DEST/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
                if not target.exists():shutil.copyfile(path,target)

    # Native4bpp sprites reserve index0 for alpha. A single palette lets fire,
    # water, shield and clash effects coexist without fighting over banks.
    samples=[pixel[:3] for im in sequences for pixel in im.getdata() if pixel[3]>=96]
    palette_image=Image.new('RGB',(len(samples),1));palette_image.putdata(samples)
    quantized=palette_image.quantize(colors=15,method=Image.Quantize.MEDIANCUT)
    raw=quantized.getpalette()[:45];colors=[tuple(raw[i:i+3]) for i in range(0,45,3)]
    colors=list(dict.fromkeys(colors))
    while len(colors)<15:colors.append((0,0,0))
    palette=[0]+[(r>>3)|((g>>3)<<5)|((b>>3)<<10) for r,g,b in colors]
    tiles=[];decoded=[]
    for im in sequences:
        indices=[]
        for r,g,b,a in im.getdata():
            index=0 if a<96 else 1+min(range(15),key=lambda k:sum((colors[k][j]-(r,g,b)[j])**2 for j in range(3)))
            indices.append(index)
        data=bytes(indices[(ty*8+y)*32+tx*8+x]|(indices[(ty*8+y)*32+tx*8+x+1]<<4)
                   for ty in range(4) for tx in range(4) for y in range(8) for x in range(0,8,2))
        assert len(data)==512 and any(data)
        tiles.append(data)
        preview=Image.new('RGBA',(32,32));preview.putdata([(0,0,0,0) if index==0 else (*colors[index-1],255) for index in indices]);decoded.append(preview)
    assert len(tiles)==56 and len(tiles)*512<=32768
    header='''#ifndef PLATINUM_ARENA_EXTRA_EFFECTS_H
#define PLATINUM_ARENA_EXTRA_EFFECTS_H
#include <stdint.h>
enum ArenaExtraEffect { ARENA_EXTRA_FIRE,ARENA_EXTRA_WATER,ARENA_EXTRA_ELECTRIC,
    ARENA_EXTRA_ICE,ARENA_EXTRA_HIT,ARENA_EXTRA_GUARD,ARENA_EXTRA_CLASH };
#define ARENA_EXTRA_FRAMES 56
#ifdef ARENA_ENABLE_LEGACY_ATLAS
extern const uint8_t arena_extra_tiles[ARENA_EXTRA_FRAMES][512];
extern const uint16_t arena_extra_palette[16];
#endif
unsigned ArenaExtra_Frame(unsigned group,unsigned tick);
unsigned ArenaExtra_ForType(unsigned type);
#endif
'''
    (ROOT/'include/arena/extra_effects.h').write_text(header)
    text='/* Generated by tools/arena/import_extra_effects.py; source credits in res/arena/extra-effects. */\n#include "arena/extra_effects.h"\n'
    text+='#ifdef ARENA_ENABLE_LEGACY_ATLAS\n'
    text+='const uint8_t arena_extra_tiles[ARENA_EXTRA_FRAMES][512]={\n'+',\n'.join('{'+','.join(map(str,t))+'}' for t in tiles)+'\n};\n'
    text+='const uint16_t arena_extra_palette[16]={'+','.join(map(str,palette))+'};\n'
    text+='#endif /* ARENA_ENABLE_LEGACY_ATLAS: superseded, not runtime loaded */\n'
    text+='unsigned ArenaExtra_Frame(unsigned group,unsigned tick)\n{return (group<=ARENA_EXTRA_CLASH?group:ARENA_EXTRA_HIT)*8+(tick/3)%8;}\n'
    text+='unsigned ArenaExtra_ForType(unsigned type)\n{switch(type){case 10:return ARENA_EXTRA_FIRE;case 11:return ARENA_EXTRA_WATER;case 13:return ARENA_EXTRA_ELECTRIC;case 15:return ARENA_EXTRA_ICE;default:return ARENA_EXTRA_HIT;}}\n'
    (ROOT/'src/arena/extra_effects.c').write_text(text)
    DEST.mkdir(parents=True,exist_ok=True)
    manifest={'frame_count':56,'tile_bytes':28672,'shared_palette_colors':15,'groups':list(GROUPS),'conversion':'Alpha threshold96, shared sequence bounds, nearest-neighbor size cap30px, shared15color median-cut palette; Ranger magenta registration markers removed.','frames':records,'tile_sha256':hashlib.sha256(b''.join(tiles)).hexdigest()}
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    sheet=Image.new('RGB',(8*64,7*80),(43,49,56));draw=ImageDraw.Draw(sheet)
    for i,im in enumerate(decoded):
        x=i%8*64;y=i//8*80;draw.text((x,y),GROUPS[i//8] if i%8==0 else str(i%8),fill='white');im=im.resize((64,64),Image.Resampling.NEAREST);sheet.paste(im,(x,y+16),im)
    sheet.save(DEST/'contact.png')
    print(json.dumps({'frames':56,'bytes':28672,'sha256':manifest['tile_sha256']}))

if __name__=='__main__':main()
