#!/usr/bin/env python3
"""Show exact converted tiles. These are asset previews, not ROM captures."""
from pathlib import Path
import hashlib
import json
import re

from PIL import Image, ImageDraw
from import_v096_effects import decode

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / 'res/arena/ds-overhaul'
manifest = json.loads((DEST / 'manifest.json').read_text())
tiles = (DEST / 'effect-tiles.bin').read_bytes()
assert hashlib.sha256(tiles).hexdigest() == manifest['tile_sha256']
palette = {i: ((c & 31) * 8, ((c >> 5) & 31) * 8, ((c >> 10) & 31) * 8)
           for i, c in enumerate(manifest['palette_bgr555'])}
loops = []
for phase in range(4):
    canvas = Image.new('RGB', (640, 560), (38, 43, 51))
    draw = ImageDraw.Draw(canvas)
    draw.text((10, 8), 'DS EFFECT ASSETS - NOT A ROM CAPTURE', fill='white')
    for slot, sequence in enumerate(manifest['sequences']):
        x = (slot % 4) * 160
        y = 32 + (slot // 4) * 128
        draw.text((x + 6, y), sequence['name'].replace('_', ' '), fill='white')
        start = (slot * 4 + phase) * 512
        native = decode(tiles[start:start + 512], 32, 32, palette)
        large = native.resize((96, 96), Image.Resampling.NEAREST)
        canvas.paste(large, (x + 32, y + 20), large)
    loops.append(canvas)
loops[0].save(DEST / 'effect-loop.gif', save_all=True, append_images=loops[1:],
              duration=50, loop=0, disposal=2)

beam_manifest = json.loads((ROOT / 'res/arena/beam-effects/manifest.json').read_text())
source = (ROOT / 'src/arena/beam_effects.c').read_text()
body = source.split('const uint8_t arena_beam_tiles', 1)[1].split('=', 1)[1].split(
    'const uint16_t arena_beam_palette', 1)[0]
beams = bytes(int(value, 16) for value in re.findall(r'0x([0-9a-fA-F]{2})', body))
assert len(beams) == 32768
assert hashlib.sha256(beams).hexdigest() == beam_manifest['tile_sha256']
beam_palette = {i + 1: tuple(color) for i, color in enumerate(beam_manifest['palette_rgb888'])}
sheet = Image.new('RGB', (600, 16 * 112 + 28), (38, 43, 51))
draw = ImageDraw.Draw(sheet)
draw.text((10, 8), 'EXACT NATIVE BEAM CELLS - NOT A ROM CAPTURE', fill='white')
for style, name in enumerate(['FULL FLAME', 'THIN FLAME', 'WATER JET', 'ICE']):
    for frame in range(4):
        row = style * 4 + frame
        draw.text((8, 38 + row * 112), name + ' ' + str(frame), fill='white')
        beam = Image.new('RGBA', (128, 32))
        for chunk in range(4):
            start = (row * 4 + chunk) * 512
            cell = decode(beams[start:start + 512], 32, 32, beam_palette)
            beam.paste(cell, (chunk * 32, 0))
        beam = beam.resize((384, 96), Image.Resampling.NEAREST)
        # A fixed canvas and scale make the four source frames comparable.
        sheet.paste(beam, (180, 24 + row * 112), beam)
sheet.save(DEST / 'beam-sprites.png')
print('Exported exact native effect GIF and beam PNG; no ROM build.')
