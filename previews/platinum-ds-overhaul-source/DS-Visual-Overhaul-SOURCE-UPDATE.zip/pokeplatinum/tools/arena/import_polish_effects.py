#!/usr/bin/env python3
"""Convert supplied art into sixteen bounded, shared DS effect sequences.

The renderer reuses legacy OBJ slots 15..30. Only one cel per family is
uploaded in a frame, so all sixteen families can coexist without eviction.
Original source PNGs, crop/registration metadata and decoded tiles are kept.
"""
import argparse
from collections import deque
import hashlib
import json
from pathlib import Path
import shutil

from PIL import Image, ImageDraw
from import_v096_effects import bgr555, c_array, decode, pack, quantize

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / 'res/arena/ds-overhaul'
DEFAULT_EXTRA = Path('/workspace/platinum-port/extra-effects')
DEFAULT_DP = Path('/workspace/asset-review/arsenal-2026-10-21/diamond-pearl-attack-graphics/source')
PMD = [('POISON', 163), ('ROCK', 182), ('WIND', 244), ('FIGHTING', 171),
       ('BUG', 150), ('DRAGON', 240), ('STEEL', 177), ('SOUND', 89),
       ('SHADOW_ORB', 176), ('SWORDS', 130),
       ('HEAL', 105), ('ENERGY', 239)]
ORDER = ['POISON', 'GROUND', 'ROCK', 'WIND', 'FIGHTING', 'BUG', 'DRAGON',
         'STEEL', 'SOUND', 'PULSE', 'GRASS_ENERGY', 'SHADOW_ORB', 'SWORDS',
         'HEAL', 'ENERGY', 'BOLT']
# Bank12 was uploaded by the old renderer but never addressed by its OBJs.
# A separate earthy/energy palette preserves brown rocks without changing
# the existing fire/ice/guard artwork's bank13 indices.
COLORS = [(248,248,248), (248,216,72), (208,136,56), (128,80,32),
          (64,144,232), (120,224,248), (40,64,144), (80,192,48),
          (24,88,40), (152,88,184), (216,168,232), (64,24,88),
          (144,160,152), (40,40,48), (192,160,104)]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def clear_background(im):
    """Remove edge-connected pale neutral sheet backgrounds, keeping cores."""
    im = im.copy()
    px = im.load()
    width, height = im.size
    queue = deque([(x, y) for x in range(width) for y in (0, height - 1)] +
                  [(x, y) for y in range(height) for x in (0, width - 1)])
    seen = set()
    while queue:
        x, y = queue.popleft()
        if (x, y) in seen or not (0 <= x < width and 0 <= y < height):
            continue
        seen.add((x, y))
        r, g, b, a = px[x, y]
        if a != 0 and not (min(r, g, b) >= 230 and max(r, g, b) - min(r, g, b) <= 8):
            continue
        px[x, y] = (0, 0, 0, 0)
        queue.extend(((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)))
    return im


def normalize(items):
    width = max(im.width for im, _ in items)
    height = max(im.height for im, _ in items)
    aligned = []
    for im, _ in items:
        canvas = Image.new('RGBA', (width, height))
        canvas.alpha_composite(im, ((width - im.width) // 2, (height - im.height) // 2))
        aligned.append(canvas)
    boxes = [im.getbbox() for im in aligned]
    if any(box is None for box in boxes):
        raise ValueError('An active source cel is empty')
    bounds = (min(b[0] for b in boxes), min(b[1] for b in boxes),
              max(b[2] for b in boxes), max(b[3] for b in boxes))
    factor = min(30 / (bounds[2] - bounds[0]), 30 / (bounds[3] - bounds[1]), 1)
    size = (max(1, round((bounds[2] - bounds[0]) * factor)),
            max(1, round((bounds[3] - bounds[1]) * factor)))
    result = []
    for im, (_, record) in zip(aligned, items):
        out = Image.new('RGBA', (32, 32))
        out.alpha_composite(im.crop(bounds).resize(size, Image.Resampling.NEAREST),
                            ((32 - size[0]) // 2, (32 - size[1]) // 2))
        record.update(shared_source_bounds=list(bounds), shared_native_size=list(size),
                      anchor=[16, 16], ticks_per_frame=3)
        result.append((out, record))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--extra-source', type=Path, default=DEFAULT_EXTRA)
    parser.add_argument('--dp-source', type=Path, default=DEFAULT_DP)
    parser.add_argument('--retained-source', action='store_true')
    args = parser.parse_args()
    DEST.mkdir(parents=True, exist_ok=True)
    selected = {}

    def source(package, relative, crop=None, registration=False, rotate=0):
        key = package + '/' + str(relative)
        kept = DEST / 'source' / key
        origin = kept if args.retained_source else (args.dp_source if package == 'dp' else args.extra_source) / relative
        raw = origin.read_bytes()
        if not args.retained_source:
            kept.parent.mkdir(parents=True, exist_ok=True)
            if not kept.exists() or kept.read_bytes() != raw:
                shutil.copyfile(origin, kept)
        im = Image.open(origin).convert('RGBA')
        selected[key] = {'sha256': sha(raw), 'bytes': len(raw), 'size': list(im.size)}
        if crop:
            im = im.crop(crop)
        if registration:
            im.putdata([(0, 0, 0, 0) if r > 190 and b > 190 and g < 100 else (r, g, b, a)
                        for r, g, b, a in im.getdata()])
        # Transparent PMD/Ranger frames already carry their original alpha.
        # Flood-filling pale art next to transparency would erase white wind,
        # lightning and healing cores. Only the opaque Mud Shot sheet needs it.
        if package == 'dp' and str(relative) == 'Mud-Shot.png':
            im = clear_background(im)
        if rotate:
            im = im.rotate(rotate, Image.Resampling.NEAREST, expand=True)
        return im, {'source': key, 'source_sha256': sha(raw), 'crop': crop,
                    'remove_magenta_registration': registration, 'rotation_degrees': rotate,
                    'background': ('Edge-connected pale-neutral sheet pixels only; preserve enclosed white highlights'
                                   if package == 'dp' and str(relative) == 'Mud-Shot.png'
                                   else 'Original alpha preserved; no pale-color key')}

    sequences = {}
    previous = json.loads((DEST / 'manifest.json').read_text()) if args.retained_source else None
    for name, number in PMD:
        if previous:
            records = next(s for s in previous['sequences'] if s['name'] == name)['frames']
            paths = [r['source'].removeprefix('extra/') for r in records]
        else:
            folder = Path('2/move_VFX') / f'{number:04d}' / '000'
            paths = sorted((args.extra_source / folder).glob('*.png'))
            if not paths:
                raise ValueError('Missing PMD sequence: ' + str(folder))
            paths = [(folder / paths[round((i + 1) * (len(paths) - 1) / 5)].name).as_posix()
                     for i in range(4)]
        sequences[name] = normalize([source('extra', path) for path in paths])
    sequences['GROUND'] = normalize([
        source('dp', 'Mud-Shot.png', (0, row * 144, 256, (row + 1) * 144), rotate=-45)
        for row in (3, 4, 5, 6)])
    sequences['PULSE'] = normalize([
        source('dp', 'Water-Pulse.png', box) for box in
        [(0, 0, 120, 124), (125, 0, 260, 124), (125, 0, 260, 124), (0, 0, 120, 124)]])
    sequences['GRASS_ENERGY'] = normalize([
        source('dp', 'Energy-Ball.png', box) for box in
        [(0, 28, 27, 59), (76, 28, 100, 59), (149, 28, 175, 59), (219, 28, 248, 59)]])
    sequences['BOLT'] = normalize([
        source('extra', '0/111.png', (4, 40 * i + 4, 132, 40 * i + 36), registration=True)
        for i in range(4)])
    palette = {i + 1: color for i, color in enumerate(COLORS)}
    tiles, records = [], []
    for slot, name in enumerate(ORDER):
        frames = []
        for frame, (im, record) in enumerate(sequences[name]):
            data = pack(quantize(im, palette), 32, 32)
            if len(data) != 512 or not any(data):
                raise ValueError('Empty native sprite: ' + name)
            tiles.append(data)
            record.update(frame=frame, slot=slot)
            frames.append(record)
        records.append({'name': name, 'family_id': slot + 13, 'slot': slot,
                        'presentation': 'Shared sourced component, adapted for top-down live combat',
                        'frames': frames})
    assert len(tiles) == 64 and sum(map(len, tiles)) == 32768
    (ROOT / 'src/arena/polish_effect_art.inc').write_text(
        '/* Generated by tools/arena/import_polish_effects.py; retained provenance in res/arena/ds-overhaul. */\n' +
        c_array('arena_polish_tiles', tiles) +
        'static const unsigned short arena_polish_palette[16] = {0,' +
        ','.join(str(bgr555(color)) for color in COLORS) + '};\n')
    (DEST / 'effect-tiles.bin').write_bytes(b''.join(tiles))
    report = {'format': 'DS tiled 4bpp, 32x32, 4 cels per shared family',
              'scope': 'Source overhaul; no ROM built or hardware performance claim',
              'frames': 64, 'families': 16, 'source_tile_bytes': 32768,
              'native_dynamic_vram_bytes': 16 * 512,
              'vram_region': 'Reuse original effect art slots 15..30; original props0..14 and capture32..34 stay intact',
              'runtime_io': 'No filesystem access or allocation in Draw/VBlank',
              'palette': 'Independent 15-color earth/energy palette, unused OBJ bank12; transparency index0',
              'palette_bgr555': [0] + [bgr555(color) for color in COLORS],
              'sequences': records, 'selected_sources': selected,
              'tile_sha256': sha(b''.join(tiles)),
              'limits': ['Four cel adaptations use shared bounds; source sequences may have additional unimported cels.',
                         'Family assignment does not add missing retail move mechanics.',
                         'Most moves intentionally reuse coherent elemental components.']}
    (DEST / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    sheet = Image.new('RGB', (512, 16 * 84), (38, 43, 51))
    draw = ImageDraw.Draw(sheet)
    preview = DEST / 'transparent-frames'
    preview.mkdir(exist_ok=True)
    for row, name in enumerate(ORDER):
        draw.text((5, row * 84 + 4), name.replace('_', ' '), fill='white')
        for frame in range(4):
            native = decode(tiles[row * 4 + frame], 32, 32, palette)
            native.save(preview / f'{name.lower()}-{frame}.png')
            large = native.resize((64, 64), Image.Resampling.NEAREST)
            sheet.paste(large, (188 + frame * 80, row * 84 + 18), large)
    sheet.save(DEST / 'effect-sprites.png')
    print(json.dumps({'families': 16, 'native_frames': 64, 'tile_bytes': 32768,
                      'vram_growth_bytes': 0, 'tile_sha256': report['tile_sha256']}))


if __name__ == '__main__':
    main()
