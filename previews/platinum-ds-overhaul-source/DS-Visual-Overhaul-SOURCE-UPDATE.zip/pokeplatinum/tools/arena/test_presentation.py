#!/usr/bin/env python3
"""Small portable presentation checks; never creates or runs a DS ROM."""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
SOURCES = ['tests/arena/test_presentation.c', 'src/arena/presentation.c',
           'src/arena/combat.c', 'src/arena/move_data.c',
           'src/arena/vendor/arena_moves.c', 'src/arena/vendor/arena_navigation.c',
           'src/arena/vendor/arena_physics.c']

subprocess.run(['python3', 'tools/arena/generate_presentation.py', '--check'],
               cwd=ROOT, check=True)
with tempfile.TemporaryDirectory(prefix='arena-presentation-') as temporary:
    target = Path(temporary) / 'presentation-check'
    subprocess.run([os.environ.get('CC', 'cc'), '-std=c11', '-O1', '-g',
                    '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined',
                    '-fno-omit-frame-pointer', '-Iinclude', *SOURCES,
                    '-o', str(target)], cwd=ROOT, check=True)
    subprocess.run([str(target)], cwd=ROOT, check=True)
