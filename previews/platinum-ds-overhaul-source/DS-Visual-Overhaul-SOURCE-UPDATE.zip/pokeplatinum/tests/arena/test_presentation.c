/* Coverage and real simulation/presentation timing regressions, no display. */
#include "arena/presentation.h"
#include "arena/combat.h"
#include "arena/vendor/arena_moves.h"
#include "arena/vendor/arena_navigation.h"
#include "arena/vendor/constants/moves.h"
#include <assert.h>
#include <stdio.h>

static Combat combat;

static void setup(unsigned move,int close)
{
    CombatFighterConfig config[2]={
        {390,5000,100,100,70,{0,0,0,0},{10,255},100,100},
        {9,5000,100,100,70,{0,0,0,0},{11,255},100,100}
    };
    unsigned i;
    config[0].moves[0]=(uint16_t)move;
    Combat_Init(&combat,config);combat.aiEnabled=0;
    for(i=0;i<ARENA_OBSTACLES;i++)ArenaNav_SetObstacle(i,0);
    combat.fighters[0].x=combat.fighters[0].previousX=70*256;
    combat.fighters[0].y=combat.fighters[0].previousY=80*256;
    combat.fighters[0].direction=COMBAT_E;
    combat.fighters[1].x=combat.fighters[1].previousX=(close?92:370)*256;
    combat.fighters[1].y=combat.fighters[1].previousY=(close?80:240)*256;
}

static void phase_clock(unsigned move,unsigned command,int basic)
{
    unsigned frame,active=0,released=0,previousPhase=COMBAT_READY,previousTick=0;
    setup(move,0);
    for(frame=0;frame<300;frame++){
        CombatFighter *f=&combat.fighters[0];
        Combat_Tick(&combat,(CombatInput){0,(uint16_t)(frame?0:command)});
        if(f->phase!=COMBAT_READY){
            unsigned time=Combat_PhaseTick(f),duration=Combat_PhaseDuration(f);
            assert(duration&&time<duration);
            if(previousPhase==f->phase)assert(time>=previousTick);
            previousTick=time;
            if(f->phase==COMBAT_ACTIVE){
                if(!active)assert(time==0);
                if(basic)assert(duration==6);
                active++;
            }
        }
        previousPhase=f->phase;
        if(f->releaseSerial)released=1;
        if(f->actionSerial&&f->phase==COMBAT_READY)break;
    }
    assert(active&&released&&frame<300);
}

static void real_contact_metadata(void)
{
    unsigned frame,i,found=0;
    setup(MOVE_FIRE_PUNCH,1);
    for(frame=0;frame<100;frame++){
        Combat_Tick(&combat,(CombatInput){0,(uint16_t)(frame?0:COMBAT_X)});
        for(i=0;i<COMBAT_EFFECTS;i++){
            CombatEffect *effect=&combat.effects[i];
            if(!effect->life)continue;
            if(effect->kind==COMBAT_CONTACT&&effect->move==MOVE_FIRE_PUNCH)found=1;
            if(effect->kind!=COMBAT_CONTACT)assert(!effect->move);
        }
    }
    assert(found&&combat.hits);
}

int main(void)
{
    unsigned move,stars=0;
    assert(ArenaPresentation_Move(0)->flags&ARENA_PRESENT_NONE);
    assert(ArenaPresentation_Move(9999)->flags&ARENA_PRESENT_NONE);
    for(move=1;move<ARENA_PRESENT_MOVE_COUNT;move++){
        const ArenaMoveVisual *visual=ArenaPresentation_Move(move);
        assert(Combat_GetMoveInfo((uint16_t)move)->move==move);
        assert(visual->family<ARENA_PRESENT_FAMILY_COUNT);
        if(visual->flags&ARENA_PRESENT_SWIFT){assert(move==MOVE_SWIFT);stars++;}
    }
    assert(stars==1);
    assert(ArenaPresentation_Move(MOVE_THUNDERBOLT)->family==ARENA_PRESENT_BOLT);
    assert(ArenaPresentation_Move(MOVE_SHADOW_BALL)->family==ARENA_PRESENT_SHADOW_ORB);
    assert(ArenaPresentation_Move(MOVE_ENERGY_BALL)->family==ARENA_PRESENT_GRASS_ENERGY);
    assert(ArenaPresentation_Move(MOVE_WATER_PULSE)->family==ARENA_PRESENT_PULSE);
    assert(ArenaPresentation_Move(MOVE_SPLASH)->flags&ARENA_PRESENT_NONE);
    phase_clock(MOVE_FLAMETHROWER,COMBAT_X,0);
    phase_clock(MOVE_WATER_GUN,COMBAT_X,0);
    phase_clock(MOVE_SWORDS_DANCE,COMBAT_X,0);
    phase_clock(MOVE_FIRE_PUNCH,COMBAT_L,1);
    real_contact_metadata();
    puts("PASS: 467 move mappings; real heavy/basic/status phase clocks; move-specific confirmed contact metadata");
    return 0;
}
