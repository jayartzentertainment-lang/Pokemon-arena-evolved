# Source artwork

Artwork was selected from the user's previously supplied archives:

- DS/DSi — Pokemon Mystery Dungeon: Explorers of Sky — Attack Effects.
- DS/DSi — Pokemon Ranger 3: Guardian Signs — Attack Effects.
- DS/DSi — Pokemon Diamond/Pearl — Attack Graphics.

Original Pokémon game artwork belongs to its respective creators. The
complete original selected PNGs, including any embedded credit panels, are
retained unchanged under `source/`. The supplied Mud Shot sheet credits
**KLNOTHINCOMIN**. No other ripper identity is inferred from a filename.
Archive provenance is also retained in `../v096-effects/archives.json` and
`../v096-effects/CREDITS.md`. Per-file SHA256, crop, rotation, shared bounds,
native anchor and sequence timing are recorded in `manifest.json`.

PMD numeric effect-folder names are source component IDs, not Platinum move
IDs. Their roles in this pack are deliberate adaptations. Frame extraction,
palette conversion, registration and renderer wiring are project changes;
they do not imply that new hand-drawn source artwork was created.
