# DS visual overhaul — source pass

This is an editable presentation upgrade over the delivered 0.9.6 source.
No replacement ROM has been built, linked, run in an emulator or playtested.
The existing story, battle rules, controls and character creator are retained.

## Connected source changes

- Every canonical move ID 1..467 has an explicit entry in `move-visuals.csv`
  and `src/arena/presentation_moves.inc`. Shared families are identified as
  shared art; this is not a claim of 467 unique animations.
- Swift alone uses its dedicated star. Electric, dragon, steel and other
  projectiles no longer inherit that star through a generic visual enum.
- All former primitive projectile orbs now address sourced effect sprites.
- Sixteen additional families use supplied PMD, Ranger and Diamond/Pearl
  art: poison, ground, rock, wind, fighting, bug, dragon, steel, sound, water
  pulse, grass energy, shadow energy, swords, healing, energy and lightning.
- Non-fire/water/ice sustained beams use themed chains of sourced cells,
  replacing the recolored water geometry. These are shared DS adaptations,
  not dedicated original beam strips for every move.
- Ground, wind and lightning projectiles face their travel direction.
  Projectile height now matches the height of confirmed contact flashes.
- Self moves can show the assigned activation art. Splash intentionally
  remains a harmless body animation. Visual assignment does not implement
  an unsupported retail status, healing or field rule.
- Windup/release `COMBAT_RING` events no longer draw false impact puffs.
  Real contacts keep impact flashes and can add their move's elemental art.
- Phase clocks read the combat system's actual basic/heavy-adjusted timing;
  charge, follow-through and sustained-beam growth use those same clocks.
- All 493 existing canonical directional sets and species scale rules remain.
  The 64 alternate forms still use the existing native portrait fallback.

## DS budgets

The main OBJ allocation remains **65,344 of 65,536 bytes**. Sixteen 512-byte
cells reuse previously undrawn original effect slots 15..30. Terrain art
slots 0..14 and capture art slots 32..34 are preserved.

All instances of one new family use the same four-cel clock, so there is
exactly one live native image per family. All 16 families fit concurrently;
there is no eviction, per-frame file access or heap allocation. Source
pointers select immutable compiled cells, avoiding an 8 KiB CPU frame cache.
The worst additional OBJ upload is 8 KiB per VBlank when all 16 families appear.

OBJ palette bank 12 was previously uploaded but unused by the renderer's
objects. It now holds an independent earth/energy palette. Existing actor,
terrain, fire/water/ice beam, guard and capture palettes remain independent.

The superseded `arena_extra_tiles` atlas is retained behind the opt-in
`ARENA_ENABLE_LEGACY_ATLAS` macro and excluded by default. Its 28,672 tile
bytes and 32 palette bytes are replaced by 32,768 new tile bytes, 32 palette
bytes, 936 move-table bytes and small pointer/event metadata. This is a source
allocation estimate, **not a completed ROM link-map or heap measurement**.

The existing four independently owned beam/shield image slots are retained
for 2v2. No animation is allowed to change damage, PP, collision or status
timing. Hardware frame rate and the final linked memory footprint still need
checking with an explicitly requested ROM build.

## Recreate and inspect

```sh
python tools/arena/generate_presentation.py
python tools/arena/import_polish_effects.py --retained-source
python tools/arena/import_beam_effects.py
python tools/arena/test_presentation.py
```

The first three commands generate source assets only. The last runs a small
host check of real simulation timing, all 467 move mappings and hit metadata;
it does not create a DS ROM. Selected original PNGs and hashes are retained
under `source/` and in `manifest.json`. `effect-sprites.png` and transparent
frames decode the exact new 4bpp tiles, not emulator screenshots.

## Work still separate

This pass does not fix the reported Lucas/custom-creator entry issue, add new
trainer parts, replace alternate-form portraits, implement unsupported move
mechanics or redesign the bottom-screen UI. Existing capture recovery input
limitations remain. The 467-move table is explicit coverage of visual choices,
not a completion claim for those other systems. Additional choreography and
move-specific art can be added within the same family/slot budget.
