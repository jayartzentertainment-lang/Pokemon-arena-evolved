/* Native Platinum action presentation. Compressed poses are loaded only on
 * deployment; actual actor graphics are 4bpp OBJ, scenery is a text BG, and
 * native font glyphs/windows provide the interface. No software framebuffers. */
#include "arena/render.h"
#include "arena/assets.h"
#include "arena/extra_effects.h"
#include "arena/beam_effects.h"
#include "arena/presentation.h"
#include "arena/vendor/arena_navigation.h"
#include "arena/vendor/arena_moves.h"
#include "arena/vendor/arena_physics.h"
#include "bg_window.h"
#include "constants/charcode.h"
#include "constants/battle/condition.h"
#include "font.h"
#include "gx_layers.h"
#include "heap.h"
#include "screen_fade.h"
#include "system.h"
#include "text.h"
#include <nitro.h>
#include <stddef.h>
#include <string.h>
#include "swift_art.inc"
#include "battle_ui_art.inc"
#include "v096_effect_art.inc"
#include "polish_effect_art.inc"

#define ACTOR_BYTES 2048
#define EFFECT_BASE (4 * ACTOR_BYTES)
#define EFFECT_BYTES (35 * 512)
/* Original slots0..14 are terrain and32..34 are Pokeballs. Slots15..30
 * were never drawn; sixteen sourced families share those existing bytes. */
#define POLISH_BASE (EFFECT_BASE + 15 * 512)
typedef char ArenaPolishSlotsFit[(ARENA_PRESENT_STREAMED_FAMILIES <= 16) ? 1 : -1];
typedef char ArenaPolishSlotsAvoidBalls[(POLISH_BASE + 16 * 512 <= EFFECT_BASE + 32 * 512) ? 1 : -1];
#define PRIMITIVE_BASE (EFFECT_BASE + EFFECT_BYTES)
#define EXTRA_BASE ((PRIMITIVE_BASE + 19 * 64 + 511) & ~511)
/* One live image per actor is shared by its beam or held shield. This keeps
 * all four independently animated beams inside the existing64KiB OBJ bank. */
#define BEAM_BASE (EXTRA_BASE + ARENA_EXTRA_FRAMES * 512)
#define SWIFT_BASE (BEAM_BASE + 4 * ARENA_BEAM_FRAME_BYTES)
#define CONTACT_GLINT_BASE (SWIFT_BASE + 2 * 128)
#define WIND_BASE (CONTACT_GLINT_BASE + 64)
typedef char ArenaExtraFitsOBJ[(WIND_BASE + 512 <= 65536) ? 1 : -1];
#define UI_BG BG_LAYER_SUB_0
#define UI_ART_BG BG_LAYER_SUB_1
#define TOP_BG BG_LAYER_MAIN_0
#define ARENA_BG BG_LAYER_MAIN_3
#define GLYPHS 96
#define VIEW_TOP 16
#define VIEW_HEIGHT 160

typedef struct {
    const AssetSpecies *species;
    u8 *storage;
    const u8 *poses[5];
    u32 bytes;
    unsigned references;
} ArenaPosePool;

typedef struct {
    ArenaPosePool *pool;
    unsigned form;
} ArenaRenderActor;

typedef struct {
    unsigned dex;
    AssetAnimation hurt;
    const u8 *hurtData;
    AssetAnimation charge;
    const u8 *chargeData;
} ArenaReactionArt;
#include "reaction_art.inc"

static const ArenaReactionArt *Reaction(unsigned dex)
{
    unsigned i;
    for(i=0;i<sizeof(arena_reaction_art)/sizeof(arena_reaction_art[0]);i++)
        if(arena_reaction_art[i].dex==dex)return &arena_reaction_art[i];
    return NULL;
}

/* Native Window_CopyGlyph reads 32-bit rows. TextGlyph itself is 130 bytes,
 * so an array of bare glyphs misaligns alternate entries on ARM9. */
typedef union {
    TextGlyph glyph;
    u32 words[(sizeof(TextGlyph) + sizeof(u32) - 1) / sizeof(u32)];
} ArenaCachedGlyph;
typedef char ArenaCachedGlyphStrideAligned[(sizeof(ArenaCachedGlyph) % 4 == 0) ? 1 : -1];
typedef char ArenaCachedGlyphPixelsAligned[((offsetof(ArenaCachedGlyph, glyph)
    + offsetof(TextGlyph, gfx)) % 4 == 0) ? 1 : -1];

struct ArenaRender {
    enum HeapID heapID;
    BgConfig *bg;
    Window top, bottom, ui;
    ArenaPosePool pools[4];
    ArenaRenderActor actors[4];
    GXOamAttr oam[128];
    u8 tiles[4][ACTOR_BYTES];
    /* GX_LoadOBJ uses DMA, whose source must be main RAM rather than the
     * native game's DTCM stack. Reticle/marker/debris art therefore lives here. */
    u8 primitives[19][64];
    u8 liveEffects[4][ARENA_BEAM_FRAME_BYTES];
    u8 liveEffectMask;
    /* Immutable main-RAM source pointers, not another frame-buffer cache. */
    const u8 *polishFrames[ARENA_PRESENT_STREAMED_FAMILIES];
    u16 polishMask;
    u32 effectClock;
    u8 partyIcons[2][32];
    u16 palettes[256];
    ArenaCachedGlyph glyphs[GLYPHS];
    s32 cameraX,cameraY;
    u16 zoom;
    u16 stride[4];
    u8 facing[4],deployAge[4];
    u8 motionStyle[4],faintAge[4];
    u16 previousHp[4];
    s8 previousStages[4][7];
    u8 statEffect[4],statEffectAge[4];
    s16 shapeX[4],shapeY[4];
    u8 partyTotal[2],partyRemaining[2];
    u8 levels[4];
    u32 status[4];
    char controls[6][8];
    u32 resident;
    unsigned oamCount,uiCounter;
    GXDispSelect oldDisplay;
    u8 oldWhichScreen;
    volatile BOOL ready;
    BOOL fontCreated,windowsCreated,bgCreated,uiDirty;
    char message[256];
    unsigned capturePhase,captureTarget,captureAge;
    s32 aimX,aimY,ballX,ballY;
};

static unsigned MotionStyle(unsigned dex);

static u16 Read16(const u8 *p) { return (u16)(p[0]|((u16)p[1]<<8)); }
static u32 Read32(const u8 *p) { return (u32)Read16(p)|((u32)Read16(p+2)<<16); }
static int Clamp(int x,int lo,int hi) { return x<lo?lo:x>hi?hi:x; }

static charcode_t Code(unsigned c)
{
    if(c>='A'&&c<='Z')return CHAR_A+c-'A';
    if(c>='a'&&c<='z')return CHAR_a+c-'a';
    if(c>='0'&&c<='9')return CHAR_0+c-'0';
    if(c==':')return CHAR_COLON;
    if(c=='-')return CHAR_MINUS;
    if(c=='+')return CHAR_PLUS;
    if(c=='/')return CHAR_SLASH;
    if(c=='(')return CHAR_PAREN_OPEN;
    if(c==')')return CHAR_PAREN_CLOSE;
    if(c=='%')return CHAR_PERCENT;
    if(c=='.')return CHAR_PERIOD;
    if(c=='!')return CHAR_EXCLAMATION;
    if(c=='?')return CHAR_QUESTION;
    if(c=='>')return CHAR_ARROW_MENU;
    if(c=='<')return CHAR_ARROW_LEFT;
    return CHAR_SPACE;
}

static void Text(ArenaRender *r,Window *w,int x,int y,const char *s)
{
    int begin=x;
    while(*s){
        unsigned ch=(unsigned char)*s++;
        const TextGlyph *g;
        if(ch=='\n'){x=begin;y+=16;continue;}
        /* The subscreen font's menu-control character has no bitmap glyph.
         * Draw the native-sized cursor explicitly so modal selections stay
         * visible in the Lab, controls, party and medicine menus. */
        if(ch=='>'){
            unsigned row;
            if(x+8>Window_GetWidth(w)*8){x=begin;y+=16;}
            if(y+16>Window_GetHeight(w)*8)return;
            for(row=0;row<10;row++)Window_FillRectWithColor(w,1,x,y+3+row,row<5?row+1:10-row,1);
            x+=8;continue;
        }
        if(ch<32||ch>=128)ch='?';
        g=&r->glyphs[ch-32].glyph;
        if(x+g->width>Window_GetWidth(w)*8){x=begin;y+=16;}
        if(y+g->height>Window_GetHeight(w)*8)return;
        Window_CopyGlyph(w,g->gfx,g->width,g->height,x,y,0);
        x+=g->width;
    }
}

static void Label(ArenaRender *r,Window *w,int x,int y,int width,const char *s)
{
    while(*s){
        unsigned ch=(unsigned char)*s++;const TextGlyph *g;
        if(ch<32||ch>=128)ch='?';g=&r->glyphs[ch-32].glyph;
        if((int)g->width>width)return;
        Window_CopyGlyph(w,g->gfx,g->width,g->height,x,y,0);
        x+=g->width;width-=g->width;
    }
}

static void Number(ArenaRender *r,Window *w,int x,int y,unsigned n)
{
    char digits[12],out[12];unsigned i=0,j;
    do{digits[i++]=(char)('0'+n%10);n/=10;}while(n&&i<10);
    for(j=0;j<i;j++)out[j]=digits[i-1-j];out[i]=0;Text(r,w,x,y,out);
}

static void Box(Window *w,int x,int y,int width,int height,u8 fill)
{
    Window_FillRectWithColor(w,3,x,y,width,height);
    Window_FillRectWithColor(w,2,x+1,y+1,width-2,height-2);
    Window_FillRectWithColor(w,fill,x+2,y+2,width-4,height-4);
    if(width>12&&height>10){
        Window_FillRectWithColor(w,4,x+3,y+2,width-6,1);
        Window_FillRectWithColor(w,3,x+3,y+height-2,width-6,1);
    }
}

static void Bar(Window *w,int x,int y,int width,unsigned value,unsigned max,u8 color)
{
    int fill=max?(int)((u32)value*width/max):0;
    Window_FillRectWithColor(w,3,x-1,y-1,width+2,6);
    Window_FillRectWithColor(w,6,x,y,width,4);
    if(fill>0)Window_FillRectWithColor(w,color,x,y,Clamp(fill,0,width),4);
}

static BOOL ReadAt(FSFile *file,u32 offset,void *dst,u32 bytes)
{
    return FS_SeekFile(file,(s32)offset,FS_SEEK_SET)&&FS_ReadFile(file,dst,(s32)bytes)==(s32)bytes;
}

static void ReleasePool(ArenaPosePool *pool)
{
    if(!pool)return;
    if(pool->references&&--pool->references)return;
    if(pool->storage)Heap_Free(pool->storage);
    MI_CpuClear8(pool,sizeof(*pool));
}

BOOL ArenaRender_SetActor(ArenaRender *r,unsigned side,unsigned dex,unsigned form)
{
    const AssetSpecies *species;
    ArenaPosePool *pool=NULL;
    FSFile file;
    unsigned i,j;u32 used=0;
    if(!r||side>=4)return FALSE;
    species=ArenaAssets_FindSpecies(dex,form);if(!species)return FALSE;
    if(r->actors[side].pool&&r->actors[side].pool->species==species)return TRUE;
    r->ready=FALSE;
    if(r->actors[side].pool){
        pool=r->actors[side].pool;
        if(pool->references==1)r->resident-=pool->bytes;
        ReleasePool(pool);r->actors[side].pool=NULL;
    }
    for(i=0;i<4;i++)if(r->pools[i].species==species){pool=&r->pools[i];pool->references++;break;}
    if(i==4){
        for(i=0;i<4;i++)if(!r->pools[i].references){pool=&r->pools[i];break;}
        if(i==4)return FALSE;
        for(i=0;i<5;i++){
            const AssetAnimation *a=&species->animations[i];
            if(!a->size||a->offset>asset_pack_size||a->size>asset_pack_size-a->offset)return FALSE;
            for(j=0;j<i;j++)if(a->offset==species->animations[j].offset&&a->size==species->animations[j].size)break;
            if(j==i){if(a->size>160*1024-used)return FALSE;used+=a->size;}
        }
        if(HeapExp_FndGetTotalFreeSize(r->heapID)<used+128)return FALSE;
        pool->storage=Heap_Alloc(r->heapID,used);if(!pool->storage)return FALSE;
        pool->bytes=used;used=0;
        FS_InitFile(&file);
        if(!FS_OpenFile(&file,"data/arena.pack")){ReleasePool(pool);return FALSE;}
        for(i=0;i<5;i++){
            const AssetAnimation *a=&species->animations[i];
            for(j=0;j<i;j++)if(a->offset==species->animations[j].offset&&a->size==species->animations[j].size)break;
            if(j<i)pool->poses[i]=pool->poses[j];
            else{
                pool->poses[i]=pool->storage+used;
                if(!ReadAt(&file,a->offset,pool->storage+used,a->size)){FS_CloseFile(&file);ReleasePool(pool);return FALSE;}
                used+=a->size;
            }
        }
        FS_CloseFile(&file);pool->species=species;pool->references=1;r->resident+=pool->bytes;
    }
    r->actors[side].pool=pool;r->actors[side].form=form;
    r->stride[side]=0;r->shapeX[side]=r->shapeY[side]=256;
    r->motionStyle[side]=(u8)MotionStyle(dex);r->facing[side]=0;
    MI_CpuCopy16(species->palette,&r->palettes[side*16],32);
    r->uiCounter=0;
    return TRUE;
}

static unsigned AnimationFrame(const AssetAnimation *a,unsigned tick)
{
    unsigned i;if(!a->frames||!a->total_ticks)return 0;tick%=a->total_ticks;
    for(i=0;i+1<a->frames&&tick>=a->durations[i];i++)tick-=a->durations[i];return i;
}

static BOOL Decode(const AssetAnimation *a,const u8 *data,unsigned dir,unsigned frame,u8 *dst)
{
    const u8 *map;
    u32 offset,count,mapEnd;unsigned i;
    if(!data||a->size<8||frame>=a->frames||dir>=8)return FALSE;
    offset=Read32(data);count=Read32(data+4);mapEnd=8+8*a->frames*128;
    if(offset<mapEnd||offset>a->size||count>(a->size-offset)/32)return FALSE;
    map=data+8+(dir*a->frames+frame)*128;
    for(i=0;i<64;i++){
        unsigned tile=Read16(map+i*2);if(tile>=count)return FALSE;
        MI_CpuCopy8(data+offset+tile*32,dst+i*32,32);
    }
    return TRUE;
}

enum ArenaMotionStyle { MOTION_GROUNDED,MOTION_AGILE,MOTION_HEAVY,MOTION_FLOATING,MOTION_WINGED };

/* Species identity is independent of action state: floating bodies retain
 * altitude through their recoil; heavy bodies plant their feet on impact. */
static unsigned MotionStyle(unsigned dex)
{
    switch(dex){
    case 81:case 82:case 92:case 93:case 94:case 109:case 110:case 200:case 201:
    case 337:case 338:case 343:case 344:case 353:case 354:case 355:case 356:
    case 358:case 425:case 426:case 429:case 436:case 437:case 442:case 462:
    case 477:case 479:case 480:case 481:case 482:case 487:return MOTION_FLOATING;
    case 6:case 12:case 15:case 18:case 22:case 42:case 49:case 142:case 144:
    case 145:case 146:case 149:case 169:case 193:case 249:case 250:case 267:
    case 269:case 284:case 330:case 334:case 373:case 384:case 414:case 415:
    case 416:case 430:case 468:case 469:return MOTION_WINGED;
    case 25:case 26:case 27:case 37:case 38:case 52:case 53:case 58:case 59:
    case 133:case 134:case 135:case 136:case 172:case 196:case 197:case 215:
    case 252:case 253:case 254:case 255:case 256:case 257:case 359:case 390:
    case 391:case 392:case 417:case 427:case 428:case 447:case 448:case 461:
    case 470:case 471:return MOTION_AGILE;
    case 3:case 9:case 76:case 95:case 112:case 130:case 131:case 143:case 208:
    case 232:case 248:case 289:case 306:case 321:case 365:case 376:case 377:
    case 378:case 379:case 382:case 383:case 389:case 395:case 409:case 450:
    case 460:case 464:case 473:case 483:case 484:case 486:return MOTION_HEAVY;
    default:return MOTION_GROUNDED;
    }
}

static unsigned Size(unsigned dex)
{
    switch(dex){
    /* Scale the visible art, rather than treating transparent canvas padding
     * as body size: Gyarados occupies ~30px and Lapras ~40px of the 64px sheet.
     * These give ~60px and ~45px bodies respectively, leaving walking space. */
    case 130:case 321:return 128;
    case 131:return 72;
    case 95:case 208:case 350:case 382:case 384:case 483:case 484:case 487:return 112;
    case 149:case 248:case 249:case 250:case 357:case 373:case 376:case 383:case 389:case 486:case 493:return 96;
    case 112:case 115:case 143:case 160:case 306:case 365:case 398:case 445:case 460:case 464:case 473:return 88;
    case 3:case 6:case 9:case 18:case 31:case 34:case 59:case 68:case 71:case 73:case 76:case 78:case 80:case 99:case 103:case 128:case 142:case 144:case 145:case 146:case 150:case 154:case 157:case 181:case 214:case 217:case 230:case 232:case 243:case 244:case 245:case 254:case 257:case 260:case 272:case 275:case 289:case 297:case 330:case 334:case 336:case 348:case 377:case 378:case 379:case 392:case 395:case 405:case 409:case 411:case 452:case 454:case 465:case 467:case 468:case 472:return 80;
    default:return 64;}
}

static int ScreenX(ArenaRender *r,s32 x){return (x-r->cameraX)*(s32)r->zoom/65536;}
static int ScreenY(ArenaRender *r,s32 y){return VIEW_TOP+(y-r->cameraY)*(s32)r->zoom/65536;}

static void Oam(ArenaRender *r,int x,int y,GXOamShape shape,unsigned tile,unsigned palette,unsigned priority)
{
    if(r->oamCount>=120||x < -64||x>255||y < -64||y>191)return;
    if(r->zoom!=256){
        int half=shape==GX_OAM_SHAPE_8x8?4:shape==GX_OAM_SHAPE_16x16?8:16;
        G2_SetOBJAttr(&r->oam[r->oamCount++],x-half,y-half,priority,GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_AFFINE_DOUBLE,shape,GX_OAM_COLORMODE_16,tile,palette,4);
    }else G2_SetOBJAttr(&r->oam[r->oamCount++],x,y,priority,GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_NONE,shape,GX_OAM_COLORMODE_16,tile,palette,0);
}

static void Reticle(ArenaRender *r,int x,int y)
{
    unsigned i;
    for(i=0;i<4;i++)Oam(r,x+((i&1)?8:-16),y+((i&2)?8:-16),GX_OAM_SHAPE_8x8,PRIMITIVE_BASE/64+i,15,0);
}

static void Marker(ArenaRender *r,int x,int y)
{
    unsigned direction;
    if(x<8)direction=2;else if(x>247)direction=3;else if(y<40)direction=0;else if(y>167)direction=1;else return;
    Oam(r,Clamp(x,8,247)-4,Clamp(y,40,167)-4,GX_OAM_SHAPE_8x8,PRIMITIVE_BASE/64+4+direction,15,0);
}

static void SwiftStar(ArenaRender *r,int x,int y,unsigned tick)
{
    unsigned frame=(tick/4)&1;
    Oam(r,x-8,y-8,GX_OAM_SHAPE_16x16,SWIFT_BASE/64+frame*2,15,0);
}

static void ContactGlint(ArenaRender *r,int x,int y)
{
    Oam(r,x-4,y-4,GX_OAM_SHAPE_8x8,CONTACT_GLINT_BASE/64,15,0);
}

static const u8 *FamilyFrame(unsigned family,unsigned clock)
{
    if(family>=ARENA_PRESENT_FIRST_STREAMED&&family<ARENA_PRESENT_FAMILY_COUNT)
        return arena_polish_tiles[(family-ARENA_PRESENT_FIRST_STREAMED)*4+ArenaPresentation_Frame(clock)];
    return arena_v096_tiles[ArenaV096_Frame(family,clock)];
}

static unsigned EffectTile(ArenaRender *r,unsigned family,unsigned tick)
{
    if(family>=ARENA_PRESENT_FIRST_STREAMED&&family<ARENA_PRESENT_FAMILY_COUNT){
        unsigned slot=family-ARENA_PRESENT_FIRST_STREAMED;
        r->polishFrames[slot]=FamilyFrame(family,r->effectClock);
        r->polishMask|=1u<<slot;
        return POLISH_BASE/64+slot*8;
    }
    return EXTRA_BASE/64+ArenaV096_Frame(family,tick)*8;
}

static void ExtraEffect(ArenaRender *r,int x,int y,unsigned group,unsigned tick)
{
    unsigned palette=group>=ARENA_PRESENT_FIRST_STREAMED?12:13;
    Oam(r,x-16,y-16,GX_OAM_SHAPE_32x32,EffectTile(r,group,tick),palette,1);
}

static const s16 sDirections[8][2]={{0,256},{181,181},{256,0},{181,-181},
    {0,-256},{-181,-181},{-256,0},{-181,181}};

static unsigned Pixel4(const u8 *tiles,unsigned width,unsigned x,unsigned y)
{
    unsigned tile=(y/8)*(width/8)+x/8;
    unsigned byte=tile*32+(y&7)*4+(x&7)/2;
    return (tiles[byte]>>((x&1)*4))&15;
}

static void BodyBounds(const u8 *tiles,int *left,int *top,int *right,int *bottom)
{
    unsigned x,y;*left=*top=63;*right=*bottom=0;
    for(y=0;y<64;y++)for(x=0;x<64;x++)if(Pixel4(tiles,64,x,y)){
        if((int)x<*left)*left=x;if((int)x>*right)*right=x;
        if((int)y<*top)*top=y;if((int)y>*bottom)*bottom=y;
    }
    if(*right<*left||*bottom<*top){*left=*top=20;*right=*bottom=43;}
}

static unsigned Root(unsigned value)
{
    unsigned root=0,bit=1u<<30;
    while(bit>value)bit>>=2;
    while(bit){if(value>=root+bit){value-=root+bit;root=(root>>1)+bit;}else root>>=1;bit>>=2;}
    return root;
}

static void ScaledExtra(ArenaRender *r,int x,int y,unsigned group,unsigned tick,
    unsigned size,unsigned affine)
{
    MtxFx22 scale;unsigned tile=EffectTile(r,group,tick);
    size=Clamp(size*r->zoom/256,8,60);
    if(r->oamCount>=120||x < -32||x>287||y < -32||y>223)return;
    scale._00=scale._11=FX32_ONE*32/(int)size;scale._01=scale._10=0;
    G2_SetOBJAffine(&((GXOamAffine *)r->oam)[affine],&scale);
    G2_SetOBJAttr(&r->oam[r->oamCount++],x-32,y-32,1,GX_OAM_MODE_NORMAL,FALSE,
        GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_32x32,GX_OAM_COLORMODE_16,
        tile,group>=ARENA_PRESENT_FIRST_STREAMED?12:13,affine);
}

static void HeldShield(ArenaRender *r,const Combat *c,unsigned side,unsigned sizeX,unsigned sizeY,
    int x,int y,int ground,int left,int top,int right,int bottom)
{
    const CombatFighter *f=&c->fighters[side];
    unsigned frame=ARENA_EXTRA_GUARD*8+4,tx,ty,px,py;
    unsigned width,height,sourceWidth,sourceHeight;
    int minX=31,minY=31,maxX=0,maxY=0,centerY;
    u8 *dst=r->liveEffects[side];MtxFx22 scale;
    /* Hold the fully opened shield rather than looping an expansion pulse.
     * Padding the32px ring in a64px cell permits large bodies without clipping. */
    if(f->guardAge<6)frame=ARENA_EXTRA_GUARD*8+2+f->guardAge/3;
    MI_CpuClear8(dst,ARENA_BEAM_FRAME_BYTES);
    for(ty=0;ty<4;ty++)for(tx=0;tx<4;tx++)
        MI_CpuCopy8(arena_v096_tiles[frame]+(ty*4+tx)*32,
            dst+((ty+2)*8+tx+2)*32,32);
    for(py=0;py<32;py++)for(px=0;px<32;px++)if(Pixel4(arena_v096_tiles[frame],32,px,py)){
        if((int)px<minX)minX=px;if((int)px>maxX)maxX=px;
        if((int)py<minY)minY=py;if((int)py>maxY)maxY=py;
    }
    sourceWidth=maxX-minX+1;sourceHeight=maxY-minY+1;
    width=Clamp((right-left+1)*(int)sizeX/64+12,28,108);
    height=Clamp((bottom-top+1)*(int)sizeY/64+10,28,108);
    centerY=y+(((top+bottom)/2)-32)*(int)sizeY/64-ground;
    scale._00=FX32_ONE*(int)sourceWidth/(int)width;
    scale._11=FX32_ONE*(int)sourceHeight/(int)height;scale._01=scale._10=0;
    G2_SetOBJAffine(&((GXOamAffine *)r->oam)[9+side],&scale);
    if(r->oamCount<120)G2_SetOBJAttr(&r->oam[r->oamCount++],x-64,centerY-64,1,
        GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_64x64,
        GX_OAM_COLORMODE_16,(BEAM_BASE+side*ARENA_BEAM_FRAME_BYTES)/64,13,9+side);
    r->liveEffectMask|=1u<<side;
    if(c->impactKind==COMBAT_IMPACT_BLOCK&&c->impactActor==side&&c->impactTimer>12){
        int dx=sDirections[f->direction&7][0],dy=sDirections[f->direction&7][1];
        ExtraEffect(r,x+dx*(int)width/512,centerY+dy*(int)height/512,
            ARENA_EXTRA_HIT,(18-c->impactTimer)*3);
    }
}

static void Beam(ArenaRender *r,const Combat *c,unsigned side,const struct ArenaMoveProfile *profile,
    const CombatMoveInfo *move,unsigned nativeWidth,unsigned nativeHeight,int left,int top,int right,int bottom,
    int bodyOffsetX,int bodyOffsetY)
{
    const CombatFighter *f=&c->fighters[side];
    int direction=f->attackDirection&7,dx=sDirections[direction][0],dy=sDirections[direction][1];
    int sourceX=(left+right)/2,sourceY=top+(bottom-top)*2/5;
    int ground=r->actors[side].pool->species->animations[f->animation<5?f->animation:0].ground[direction];
    int sx,sy,ex,ey,length,reach,front,age,remaining,grow,style,frame,clashing=0;
    s32 startX,startY,endX,endY,contactX,contactY;
    unsigned chunk,palette=11;MtxFx22 matrix;
    if(dx>200)sourceX=right;else if(dx< -200)sourceX=left;
    else if(dx)sourceX+=(dx>0?1:-1)*(right-left)/3;
    if(dy< -200)sourceY=top;else if(dy>200)sourceY=bottom-3;
    startX=f->x+(sourceX-32)*(int)nativeWidth*4+bodyOffsetX*256;
    startY=f->y+((sourceY-32)-ground)*(int)nativeHeight*4+bodyOffsetY*256;
    front=((startX-f->x)*dx+(startY-f->y)*dy)/65536;
    reach=Clamp((int)profile->range-Clamp(front,0,64),8,180);
    endX=startX+dx*reach;endY=startY+dy*reach;
    if(Combat_BeamContact(c,side,&contactX,&contactY)){
        /* Every participant uses the identical shared visual contact point. */
        endX=contactX;endY=contactY-12*256;clashing=1;
    }
    sx=ScreenX(r,startX);sy=ScreenY(r,startY);ex=ScreenX(r,endX);ey=ScreenY(r,endY);
    age=Combat_PhaseTick(f);
    remaining=Clamp((int)Combat_PhaseDuration(f)-age,0,255);
    grow=clashing?6:Clamp(age+1,1,6);ex=sx+(ex-sx)*grow/6;ey=sy+(ey-sy)*grow/6;
    dx=ex-sx;dy=ey-sy;length=Root(dx*dx+dy*dy);if(length<3)return;
    style=move&&move->type==10?((!clashing&&(age<6||remaining<6))?ARENA_BEAM_THIN:ARENA_BEAM_MEDIUM):
        move&&move->type==15?ARENA_BEAM_ICE:ARENA_BEAM_WATER;
    frame=(c->frame/4)&3;
    MI_CpuCopy8(arena_beam_tiles[style][frame],r->liveEffects[side],ARENA_BEAM_FRAME_BYTES);
    if(move&&move->type!=10&&move->type!=11&&move->type!=15){
        const ArenaMoveVisual *visual=ArenaPresentation_Move(f->actionMove);
        const u8 *cel=FamilyFrame(visual->family,c->frame);
        /* A themed chain of authored energy/sound/lightning cells replaces
         * the water-shaped neutral fallback. Same four chunks and hitbox. */
        for(chunk=0;chunk<4;chunk++)MI_CpuCopy8(cel,
            r->liveEffects[side]+chunk*ARENA_BEAM_CHUNK_BYTES,ARENA_BEAM_CHUNK_BYTES);
        palette=visual->family>=ARENA_PRESENT_FIRST_STREAMED?12:13;
    }
    r->liveEffectMask|=1u<<side;
    matrix._00=dx*FX32_ONE*128/(length*length);
    matrix._01=dy*FX32_ONE*128/(length*length);
    matrix._10=-dy*FX32_ONE*256/(length*r->zoom);
    matrix._11=dx*FX32_ONE*256/(length*r->zoom);
    G2_SetOBJAffine(&((GXOamAffine *)r->oam)[5+side],&matrix);
    for(chunk=0;chunk<4;chunk++){
        int cx=sx+dx*(16+(int)chunk*32)/128,cy=sy+dy*(16+(int)chunk*32)/128;
        if(r->oamCount>=120||cx< -32||cx>287||cy< -32||cy>223)continue;
        G2_SetOBJAttr(&r->oam[r->oamCount++],cx-32,cy-32,1,GX_OAM_MODE_NORMAL,FALSE,
            GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_32x32,GX_OAM_COLORMODE_16,
            (BEAM_BASE+side*ARENA_BEAM_FRAME_BYTES+chunk*ARENA_BEAM_CHUNK_BYTES)/64,palette,5+side);
    }
}

static void DashStreak(ArenaRender *r,int x,int y,unsigned direction,unsigned age)
{
    unsigned affine=13+(direction&7),frame=age<3?0:1;
    if(r->oamCount>=120||x< -32||x>287||y< -32||y>223)return;
    G2_SetOBJAttr(&r->oam[r->oamCount++],x-32,y-16,1,GX_OAM_MODE_NORMAL,FALSE,
        GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_32x16,GX_OAM_COLORMODE_16,
        WIND_BASE/64+frame*4,15,affine);
    /* The pale sourced streak lifts above a small, low-contrast ground chip. */
    if(age>2&&!(age&1))Oam(r,x-2,y+5,GX_OAM_SHAPE_8x8,PRIMITIVE_BASE/64+8,15,2);
}

/* All deformation is relative to the authored ground point. Feet remain on
 * the collision plane; beam emitters use the same scaled source coordinates. */
static s16 ShapeStep(s16 value,int target)
{
    int step=(target-value)/3;
    if(!step&&target!=value)step=target>value?1:-1;
    return (s16)(value+step);
}

static void Actor(ArenaRender *r,const Combat *c,unsigned side)
{
    const CombatFighter *f=&c->fighters[side];
    ArenaPosePool *p=r->actors[side].pool;
    const AssetAnimation *pose;
    const u8 *poseData;
    const ArenaReactionArt *reaction;
    unsigned anim,frame,sizeX,sizeY,nativeSize,nativeWidth,nativeHeight,index;
    int x,y,ground,left,top,right,bottom,shapeX=256,shapeY=256;
    int bodyLift=0,bodyLean=0,bodyOffsetX=0,bodyOffsetY=0;
    unsigned direction,style=r->motionStyle[side],entry=r->deployAge[side];
    int travelX=f->x-f->previousX,travelY=f->y-f->previousY;
    MtxFx22 scale;
    if(!p||!p->species)return;
    if(!f->hp){
        if(r->previousHp[side])r->faintAge[side]=1;
        r->previousHp[side]=0;
        if(!r->faintAge[side]||r->faintAge[side]>22)return;
        bodyOffsetY=r->faintAge[side]/2;r->faintAge[side]++;
    }else {r->previousHp[side]=f->hp;r->faintAge[side]=0;}
    if(entry){
        if(entry<28)r->deployAge[side]++;else r->deployAge[side]=0;
        if(entry<13){
            int bx=ScreenX(r,f->x),by=ScreenY(r,f->y)-8;
            Oam(r,bx-16,by-16,GX_OAM_SHAPE_32x32,EFFECT_BASE/64+32*8,14,0);
        }
        if(entry<8)return;
    }
    direction=r->facing[side]&7;
    if(!c->frame||f->phase!=COMBAT_READY||f->dashTimer||f->hurtTimer)direction=f->direction&7;
    else if(direction!=(f->direction&7)&&!(c->frame%(style==MOTION_HEAVY?3:2))){
        unsigned turn=(f->direction+8-direction)&7;
        direction=(direction+(turn<=4?1:7))&7;
    }
    r->facing[side]=(u8)direction;
    anim=f->animation<5?f->animation:0;
    if(f->hurtTimer)anim=COMBAT_IDLE;
    else if(f->guardTimer)anim=COMBAT_ATTACK;
    frame=AnimationFrame(&p->species->animations[anim],Combat_AnimationTick(f,
        p->species->animations[anim].total_ticks,p->species->animations[anim].hit_tick));
    if(f->guardTimer){
        const AssetAnimation *guard=&p->species->animations[anim];
        unsigned pose=guard->hit_tick?guard->hit_tick/2:guard->total_ticks/4;
        frame=AnimationFrame(guard,pose);
    }else if(f->hurtTimer&&p->species->animations[anim].frames>1){
        frame=p->species->animations[anim].frames-1;
    }
    pose=&p->species->animations[anim];poseData=p->poses[anim];
    reaction=Reaction(p->species->dex);
    if(reaction&&f->hurtTimer){
        unsigned tick=Clamp(14-f->hurtTimer,0,reaction->hurt.total_ticks-1);
        pose=&reaction->hurt;poseData=reaction->hurtData;frame=AnimationFrame(pose,tick);
    }else if(reaction&&f->phase==COMBAT_WINDUP&&!f->basicAttack){
        unsigned duration=Combat_PhaseDuration(f);
        if(!duration)duration=1;
        pose=&reaction->charge;poseData=reaction->chargeData;
        frame=AnimationFrame(pose,Clamp(Combat_PhaseTick(f)*pose->hit_tick/duration,0,pose->hit_tick?pose->hit_tick-1:0));
    }
    if(!Decode(pose,poseData,direction,frame,r->tiles[side]))return;
    {
        static const s8 wave[16]={0,1,2,3,4,3,2,1,0,-1,-2,-3,-4,-3,-2,-1};
        int pulse=wave[((c->frame+side*13)/(style==MOTION_HEAVY?6:4))&15];
        if(style==MOTION_FLOATING){
            bodyLift=5+pulse/2;
            bodyOffsetX=wave[((c->frame+side*13)/7)&15]/2;
        }else if(style==MOTION_WINGED){bodyLift=3+pulse/3;}
        else if(style==MOTION_AGILE&&anim==COMBAT_IDLE&&!f->guardTimer&&!f->hurtTimer){
            /* Small alert foot lifts augment the actual idle/tail frames. */
            if((c->frame+side*19)%96>84)bodyLift=(pulse<0?-pulse:pulse)/2;
        }
        if(f->phase==COMBAT_WINDUP){
            bodyOffsetX-=sDirections[f->attackDirection&7][0]*(style==MOTION_HEAVY?1:2)/256;
            bodyOffsetY-=sDirections[f->attackDirection&7][1]/256;
        }else if(f->phase==COMBAT_ACTIVE&&!ArenaMoves_Beam(f->actionMove)){
            bodyOffsetX+=sDirections[f->attackDirection&7][0]*2/256;
            bodyOffsetY+=sDirections[f->attackDirection&7][1]*2/256;
        }
        if(f->dashTimer){bodyLift+=style==MOTION_HEAVY?0:2;bodyLean=sDirections[f->dashDirection&7][0]/32;}
        if(f->hurtTimer){
            int recoil=Clamp(f->hurtTimer,0,12)/3;
            bodyOffsetX+=Clamp((f->vx/256),-recoil,recoil);
            bodyOffsetY-=style==MOTION_FLOATING?recoil:0;
            bodyLean=Clamp(f->vx/64,-14,14);
        }else if(c->impactKind==COMBAT_IMPACT_BLOCK&&c->impactActor==side&&c->impactTimer>9){
            int amount=(c->impactTimer-9)/2;
            bodyOffsetX-=sDirections[direction][0]*amount/256;
            bodyOffsetY-=sDirections[direction][1]*amount/256;
        }
    }
    if(travelX<0)travelX=-travelX;if(travelY<0)travelY=-travelY;
    r->stride[side]+=(travelX+travelY)/8;
    if(!f->guardTimer&&!f->hurtTimer&&!f->dashTimer){
        if(f->phase==COMBAT_READY&&anim==COMBAT_WALK){
            static const s8 gait[16]={0,2,4,6,8,6,4,2,0,-2,-4,-6,-8,-6,-4,-2};
            int pulse=gait[(r->stride[side]>>6)&15];
            if(style==MOTION_HEAVY){shapeX+=pulse/3;shapeY-=pulse/3;bodyOffsetY+=pulse>4?1:0;}
            else if(style!=MOTION_FLOATING&&style!=MOTION_WINGED){shapeX+=pulse/2;shapeY-=pulse/2;bodyLift+=pulse>0?pulse/5:0;}
        }else if(f->phase==COMBAT_WINDUP){shapeX=262;shapeY=250;}
        else if(f->phase==COMBAT_ACTIVE&&!ArenaMoves_Beam(f->actionMove)){
            unsigned direction=f->attackDirection&7;
            if(direction==COMBAT_E||direction==COMBAT_W){shapeX=264;shapeY=248;}
            else if(direction==COMBAT_N||direction==COMBAT_S){shapeX=248;shapeY=264;}
            else {shapeX=260;shapeY=260;}
        }
    }
    if(r->shapeX[side]<240||r->shapeY[side]<240)r->shapeX[side]=r->shapeY[side]=256;
    r->shapeX[side]=ShapeStep(r->shapeX[side],shapeX);
    r->shapeY[side]=ShapeStep(r->shapeY[side],shapeY);
    nativeSize=ArenaAssets_DisplaySize(p->species->dex,r->actors[side].form,Size(p->species->dex));
    nativeWidth=Clamp(nativeSize*r->shapeX[side]/256,4,128);
    nativeHeight=Clamp(nativeSize*r->shapeY[side]/256,4,128);
    sizeX=nativeWidth*r->zoom/256;sizeY=nativeHeight*r->zoom/256;
    if(entry>=8&&entry<21){sizeX=sizeX*(entry-7)/13;sizeY=sizeY*(entry-7)/13;}
    if(r->faintAge[side]>8)sizeY=sizeY*(24-r->faintAge[side])/16;
    if(side==r->captureTarget&&r->capturePhase>=3&&r->capturePhase<=7){
        if(r->capturePhase==3){
            unsigned amount=24-Clamp(r->captureAge,0,23);
            sizeX=sizeX*amount/24;sizeY=sizeY*amount/24;
        }else if(r->capturePhase==6){
            unsigned amount=Clamp(r->captureAge,1,22);
            sizeX=sizeX*amount/22;sizeY=sizeY*amount/22;
        }else return;
    }
    if(sizeX<4||sizeY<4)return;
    x=ScreenX(r,f->x);y=ScreenY(r,f->y);
    if(r->oamCount<118){
        MtxFx22 shadow;unsigned width=Clamp(sizeX/3,12,32),height=style==MOTION_FLOATING?5:7;
        shadow._00=FX32_ONE*16/(int)width;shadow._11=FX32_ONE*16/(int)height;shadow._01=shadow._10=0;
        G2_SetOBJAffine(&((GXOamAffine *)r->oam)[23+side],&shadow);
        G2_SetOBJAttr(&r->oam[r->oamCount++],x-16,y-16,2,GX_OAM_MODE_NORMAL,FALSE,
            GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_16x16,GX_OAM_COLORMODE_16,PRIMITIVE_BASE/64+17,15,23+side);
    }
    x+=bodyOffsetX*(int)r->zoom/256;y+=(bodyOffsetY-bodyLift)*(int)r->zoom/256;
    ground=pose->ground[direction]*(int)sizeY/64;
    if(x < -64||x>320||y < -64||y>256)return;

    index=r->oamCount++;
    if(sizeX==64&&sizeY==64&&!bodyLean){
        G2_SetOBJAttr(&r->oam[index],x-32,y-32-ground,1,GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_NONE,GX_OAM_SHAPE_64x64,GX_OAM_COLORMODE_16,side*32,side,0);
    }else{
        G2_SetOBJAttr(&r->oam[index],x-64,y-64-ground,1,GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_64x64,GX_OAM_COLORMODE_16,side*32,side,side);
        scale._00=(FX32_ONE*64)/(int)sizeX;scale._11=(FX32_ONE*64)/(int)sizeY;
        scale._01=bodyLean*FX32_ONE/256;scale._10=0;
        G2_SetOBJAffine(&((GXOamAffine *)r->oam)[side],&scale);
    }
    if(f->hp&&(f->guardTimer||f->phase==COMBAT_ACTIVE))BodyBounds(r->tiles[side],&left,&top,&right,&bottom);
    if(f->hp&&f->guardTimer)HeldShield(r,c,side,sizeX,sizeY,x,y,ground,left,top,right,bottom);
    if(f->hp&&f->phase==COMBAT_ACTIVE){
        const struct ArenaMoveProfile *profile=ArenaMoves_Get(f->actionMove);
        const CombatMoveInfo *move=Combat_GetMoveInfo(f->actionMove);
        const ArenaMoveVisual *visual=ArenaPresentation_Move(f->actionMove);
        unsigned phaseTick=Combat_PhaseTick(f);
        int dx=sDirections[f->attackDirection&7][0],dy=sDirections[f->attackDirection&7][1];
        if(profile&&profile->kind==ARENA_MOVE_CONE&&!(visual->flags&ARENA_PRESENT_NONE)){
            unsigned step,spacing=profile->range/3,group=visual->family;
            if(spacing<24)spacing=24;
            if(ArenaMoves_Beam(f->actionMove))Beam(r,c,side,profile,move,nativeWidth,nativeHeight,left,top,right,bottom,bodyOffsetX,bodyOffsetY-bodyLift);
            else for(step=14;step<=profile->range;step+=spacing){
                int bx=x+dx*(int)step*r->zoom/65536,by=y+dy*(int)step*r->zoom/65536;
                ExtraEffect(r,bx,by-12*r->zoom/256,group,phaseTick+step/6);
            }
        }
        if(profile&&profile->kind==ARENA_MOVE_SELF&&phaseTick<12&&
            !(visual->flags&ARENA_PRESENT_NONE)&&visual->family!=ARENA_PRESENT_GUARD)
            ExtraEffect(r,x,y-12,visual->family,phaseTick*2);
        if(profile&&((visual->flags&ARENA_PRESENT_CLAW)||profile->visual==ARENA_VIS_CLAW||profile->visual==ARENA_VIS_LEAF)
            &&phaseTick<10){
            unsigned family=(visual->flags&ARENA_PRESENT_CLAW)||profile->visual==ARENA_VIS_CLAW?ARENA_V096_SLASH:ARENA_V096_LEAF;
            ExtraEffect(r,x+dx*18/256,y+dy*14/256-4,family,
                phaseTick*2);
        }
        /* Contact impacts remain event-driven; authored claw/leaf motion is
         * only the attack's active follow-through and is also visible on a miss. */
    }
    if(f->hp&&r->statEffectAge[side])ExtraEffect(r,x,y-14,r->statEffect[side],24-r->statEffectAge[side]);
    if(f->hp&&f->status&&f->status!=COMBAT_STATUS_SLEEP&&c->frame%72<12){
        unsigned family=f->status==COMBAT_STATUS_BURN?ARENA_EXTRA_FIRE:
            f->status==COMBAT_STATUS_PARALYSIS?ARENA_EXTRA_ELECTRIC:
            f->status==COMBAT_STATUS_FREEZE?ARENA_EXTRA_ICE:ARENA_PRESENT_POISON;
        ExtraEffect(r,x,y-4,family,c->frame%72*2);
    }
}

static void PartyBalls(ArenaRender *r,unsigned team,int x,int y)
{
    unsigned i;
    for(i=0;i<r->partyTotal[team]&&i<6;i++)
        Window_BlitBitmapRectWithTransparency(&r->ui,r->partyIcons[i<r->partyRemaining[team]?0:1],0,0,8,8,x+i*8,y,8,8,0);
}

static const char *StatusName(u32 status,unsigned hp)
{
    if(!hp)return "KO";
    if(status&MON_CONDITION_SLEEP)return "SLP";
    if(status&MON_CONDITION_ANY_POISON)return "PSN";
    if(status&MON_CONDITION_BURN)return "BRN";
    if(status&MON_CONDITION_FREEZE)return "FRZ";
    if(status&MON_CONDITION_PARALYSIS)return "PAR";
    return NULL;
}

static const char *ActionName(const Combat *c,unsigned side)
{
    const CombatFighter *f=&c->fighters[side];s32 x,y;
    if(!f->hp)return "FAINTED";
    if(Combat_BeamContact(c,side,&x,&y))return "BEAM CLASH";
    if(f->guardTimer)return "GUARDING";
    if(f->dashTimer)return "DODGING";
    if(f->hurtTimer)return "TAKING A HIT";
    if(f->phase==COMBAT_WINDUP)return "PREPARING MOVE";
    if(f->phase==COMBAT_ACTIVE)return "ATTACKING";
    if(f->phase==COMBAT_RECOVERY)return "RECOVERING";
    return f->stamina?"READY TO BATTLE":"STAMINA RECOVERING";
}

static const char *TypeName(unsigned type)
{
    static const char *names[]={"NORMAL","FIGHT","FLYING","POISON","GROUND","ROCK","BUG","GHOST","STEEL","???","FIRE","WATER","GRASS","ELEC","PSYCH","ICE","DRAGON","DARK"};
    return type<18?names[type]:"???";
}

static const CombatBeamClash *VisibleClash(const Combat *c,unsigned controlled)
{
    const CombatBeamClash *fallback=NULL;unsigned i;
    for(i=0;i<COMBAT_BEAM_CLASHES;i++)if(c->beamClashes[i].phase){
        const CombatBeamClash *clash=&c->beamClashes[i];
        if(clash->actor[0]==controlled||clash->actor[1]==controlled)return clash;
        if(!fallback)fallback=clash;
    }
    return fallback;
}

static const char *FiringLabel(ArenaRender *r,const CombatFighter *f)
{
    if(f->basicAttack)return r->controls[0];
    if(f->actionSlot==f->selected)return r->controls[2];
    return r->controls[3];
}

/* Only variable pixels live on BG0. The native textured Platinum command
 * panels, silver healthboxes and Pokeball watermark are immutable BG1 art. */
static void HUD(ArenaRender *r,const Combat *c)
{
    unsigned i,controlled=c->controlActor<4?c->controlActor:0;
    unsigned foe=Combat_TargetFighter(c,controlled);
    const CombatFighter *f=&c->fighters[controlled];
    const CombatBeamClash *clash=VisibleClash(c,controlled);
    Window_FillTilemap(&r->top,2);Window_FillTilemap(&r->bottom,2);
    Window_FillTilemap(&r->ui,0);
    Window_FillRectWithColor(&r->top,5,0,14,256,2);
    Window_FillRectWithColor(&r->bottom,5,0,0,256,2);
    if(clash&&clash->phase==COMBAT_CLASH_PRESSURE){
        int pressure=clash->pressure;
        if((clash->actor[0]&1)!=(controlled&1))pressure=-pressure;
        Text(r,&r->top,5,0,"BEAM CLASH");
        if(clash->actor[0]==controlled||clash->actor[1]==controlled){
            Text(r,&r->top,105,0,"TAP");Label(r,&r->top,130,0,38,FiringLabel(r,f));
        }else Text(r,&r->top,105,0,"ALLY");
        Bar(&r->top,175,6,68,Clamp(pressure+COMBAT_CLASH_PRESSURE_LIMIT,0,
            COMBAT_CLASH_PRESSURE_LIMIT*2),COMBAT_CLASH_PRESSURE_LIMIT*2,10);
        Window_FillRectWithColor(&r->top,1,209,4,1,8);
    }else{
        if(clash&&clash->phase==COMBAT_CLASH_BURST)
            Text(r,&r->top,5,0,clash->winner>=COMBAT_FIGHTERS?"BEAMS DISSIPATE":
                (clash->winner&1)==(controlled&1)?"BREAKTHROUGH!":"BEAM BROKEN!");
        else Text(r,&r->top,5,0,"PLATINUM ARENA");
        Text(r,&r->top,195,0,c->fighterCount==4?"2 VS 2":"1 VS 1");
    }
    Text(r,&r->bottom,4,0,"B: GUARD / DIRECTION TAP: DASH");
    Label(r,&r->ui,8,0,31,"TEAM");PartyBalls(r,0,43,5);
    Label(r,&r->ui,136,0,27,"FOE");PartyBalls(r,1,171,5);
    for(i=0;i<2;i++){
        unsigned actor=i?foe:controlled;
        const CombatFighter *a;
        ArenaPosePool *p;
        const char *status;
        int x=2+i*128;
        if(actor>=4)continue;
        a=&c->fighters[actor];p=r->actors[actor].pool;
        status=StatusName(r->status[actor],a->hp);
        if(!status&&a->status){
            static const char *names[]={NULL,"BRN","PSN","TOX","PAR","SLP","FRZ"};
            if(a->status<sizeof(names)/sizeof(names[0]))status=names[a->status];
        }
        if(p)Label(r,&r->ui,x+9,18,r->levels[actor]?75:105,p->species->name);
        if(r->levels[actor]){Text(r,&r->ui,x+86,18,"Lv");Number(r,&r->ui,x+102,18,r->levels[actor]);}
        if(status){
            Window_FillRectWithColor(&r->ui,a->hp?11:6,x+10,36,29,13);
            Label(r,&r->ui,x+12,33,26,status);
        }else{
            Number(r,&r->ui,x+10,33,(a->hp+7)/8);Text(r,&r->ui,x+33,33,"/");Number(r,&r->ui,x+39,33,(a->maxHp+7)/8);
        }
        Bar(&r->ui,x+70,42,45,a->hp,a->maxHp,a->hp*4<a->maxHp?9:a->hp*2<a->maxHp?8:7);
    }
    {
        const char *stageNames[]={"ATK","DEF","SPA","SPD","SPE","ACC","EVA"};
        unsigned stage,shown=0;
        for(stage=0;stage<7;stage++)if(f->stages[stage]&&shown<2){
            int x=14+shown*67;Label(r,&r->ui,x,56,31,stageNames[stage]);
            Text(r,&r->ui,x+28,56,f->stages[stage]>0?"+":"-");
            Number(r,&r->ui,x+37,56,f->stages[stage]>0?f->stages[stage]:-f->stages[stage]);shown++;
        }
        if(!shown)Label(r,&r->ui,14,56,136,f->confusionTicks?"CONFUSED":ActionName(c,controlled));
        Text(r,&r->ui,158,56,"STAMINA");
        Bar(&r->ui,157,73,82,f->stamina,COMBAT_STAMINA_MAX,f->stamina<20?9:10);
        if(c->fighterCount==4){
            unsigned ally=controlled^2,enemy=foe<4?foe^2:4;
            if(ally<4){Bar(&r->ui,14,73,53,c->fighters[ally].hp,c->fighters[ally].maxHp,7);}
            if(enemy<4){Bar(&r->ui,85,73,53,c->fighters[enemy].hp,c->fighters[enemy].maxHp,9);}
        }
    }
    for(i=0;i<4;i++){
        const CombatMoveInfo *info=Combat_GetMoveInfo(f->moves[i]);
        int x=8+(i&1)*124,y=80+(i/2)*38;
        if(i==f->selected||i==f->specialSlot)
            Window_FillRectWithColor(&r->ui,i==f->selected?10:9,x+4,y+4,2,25);
        Label(r,&r->ui,x+9,y+1,100,info?info->name:"No learned move");
        Text(r,&r->ui,x+9,y+16,"PP");Number(r,&r->ui,x+27,y+16,f->pp[i]);
        if(f->cooldown[i]){
            Text(r,&r->ui,x+48,y+16,"CD");Number(r,&r->ui,x+65,y+16,(f->cooldown[i]+59)/60);
            Text(r,&r->ui,x+80,y+16,"s");
        }else if(info)Label(r,&r->ui,x+48,y+16,44,TypeName(info->type));
        if(i==f->selected)Text(r,&r->ui,x+99,y+16,r->controls[2]);
        else if(i==f->specialSlot)Text(r,&r->ui,x+99,y+16,r->controls[3]);
        if(!info||!f->pp[i])Window_FillRectWithColor(&r->ui,9,x+8,y+31,100,1);
    }
    {
        const CombatMoveInfo *natural=Combat_GetMoveInfo(Combat_NaturalMove(f));
        Label(r,&r->ui,12,152,16,r->controls[0]);Text(r,&r->ui,25,152,":");
        Label(r,&r->ui,31,152,77,natural?natural->name:"NATURAL");
        Text(r,&r->ui,112,152,"L:CYCLE R+X:AI");
    }
    Text(r,&r->ui,12,171,"PARTY R");Text(r,&r->ui,103,171,"BAG");Text(r,&r->ui,184,171,"SETTINGS");
    if(r->message[0]){
        Box(&r->ui,3,2,250,188,15);Text(r,&r->ui,9,8,r->message);
    }
    r->uiDirty=TRUE;
}

int ArenaRender_TouchMove(unsigned x,unsigned y)
{
    unsigned row,column;
    if(x>=8&&x<124)column=0;else if(x>=132&&x<248)column=1;else return -1;
    if(y>=80&&y<114)row=0;else if(y>=118&&y<152)row=1;else return -1;
    return (int)(row*2+column);
}

int ArenaRender_TouchCommand(unsigned x,unsigned y)
{
    if(y<168||y>=192||x>=256)return -1;
    return x<85?0:x<170?1:2;
}

void ArenaRender_Draw(ArenaRender *r,const Combat *c)
{
    unsigned i,j,controlled,target;int tx,ty;unsigned order[4]={0,1,2,3};
    s32 desiredX,desiredY;
    if(!r||!c)return;r->ready=FALSE;
    controlled=c->controlActor<4?c->controlActor:0;target=Combat_TargetFighter(c,controlled);if(target>=4)target=controlled;
    {
        int zoomTarget=256;
        s32 focusX=c->fighters[controlled].x+Clamp((c->fighters[target].x-c->fighters[controlled].x)/3,-32*256,32*256);
        s32 focusY=c->fighters[controlled].y+Clamp((c->fighters[target].y-c->fighters[controlled].y)/3,-20*256,20*256);
        if(c->impactTimer&&c->impactKind){
            int strength=Clamp(c->impactTimer,0,12);
            zoomTarget+=strength*2;
            focusX+=(c->impactX-focusX)*strength/24;
            focusY+=(c->impactY-focusY)*strength/24;
        }
        r->zoom=(u16)(r->zoom+(zoomTarget-r->zoom)/3);
        if(r->zoom<257&&zoomTarget==256)r->zoom=256;
        desiredX=focusX-128*65536/r->zoom;
        desiredY=focusY-80*65536/r->zoom;
        desiredX=Clamp(desiredX,0,ARENA_WORLD_WIDTH*256-256*65536/r->zoom);
        desiredY=Clamp(desiredY,0,ARENA_WORLD_HEIGHT*256-VIEW_HEIGHT*65536/r->zoom);
        if(!c->frame){r->cameraX=desiredX;r->cameraY=desiredY;}
        else {r->cameraX+=(desiredX-r->cameraX)/6;r->cameraY+=(desiredY-r->cameraY)/6;}
    }
    for(i=0;i<128;i++)G2_SetOBJAttr(&r->oam[i],0,0,0,GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_NODISPLAY,GX_OAM_SHAPE_8x8,GX_OAM_COLORMODE_16,0,0,0);
    r->oamCount=0;r->liveEffectMask=0;r->polishMask=0;r->effectClock=c->frame;
    { MtxFx22 scale;scale._00=scale._11=FX32_ONE*256/r->zoom;scale._01=scale._10=0;
      G2_SetOBJAffine(&((GXOamAffine *)r->oam)[4],&scale); }
    for(i=0;i<8;i++){
        MtxFx22 spin;int dx=sDirections[i][0],dy=sDirections[i][1];
        spin._00=dx*FX32_ONE/r->zoom;spin._01=dy*FX32_ONE/r->zoom;
        spin._10=-dy*FX32_ONE/r->zoom;spin._11=dx*FX32_ONE/r->zoom;
        G2_SetOBJAffine(&((GXOamAffine *)r->oam)[13+i],&spin);
    }
    for(i=0;i<ARENA_OBSTACLES;i++){
        int x=ScreenX(r,(gArenaObstacles[i].left+gArenaObstacles[i].right)*128);
        int y=ScreenY(r,gArenaObstacles[i].bottom*256);
        unsigned pose=gArenaProps[i].broken?2:gArenaProps[i].hp<gArenaProps[i].maxHp?1:0;
        unsigned art=pose*5+gArenaProps[i].kind;
        if(art>=15)art=0;
        MI_CpuCopy16(arena_effect_palettes[art],&r->palettes[(4+i)*16],32);
        Oam(r,x-16,y-30,GX_OAM_SHAPE_32x32,EFFECT_BASE/64+art*8,4+i,2);
    }
    for(i=0;i<c->fighterCount&&i<4;i++){
        const CombatFighter *f=&c->fighters[i];
        if(r->statEffectAge[i])r->statEffectAge[i]--;
        for(j=0;j<7;j++)if(r->previousStages[i][j]!=f->stages[j]){
            r->statEffect[i]=f->stages[j]>r->previousStages[i][j]?ARENA_V096_BUFF:ARENA_V096_DEBUFF;
            r->statEffectAge[i]=24;r->previousStages[i][j]=f->stages[j];
        }
    }
    /* Lower feet win native OAM priority, independent of team index. */
    for(i=0;i<c->fighterCount;i++)for(j=i+1;j<c->fighterCount;j++)if(c->fighters[order[j]].y>c->fighters[order[i]].y){unsigned k=order[i];order[i]=order[j];order[j]=k;}
    for(i=0;i<c->fighterCount&&i<4;i++)Actor(r,c,order[i]);
    for(i=0;i<c->fighterCount&&i<4;i++)if(c->fighters[i].hp&&((i^controlled)&1))Marker(r,ScreenX(r,c->fighters[i].x),ScreenY(r,c->fighters[i].y));
    for(i=0;i<COMBAT_PROJECTILES;i++){
        const CombatProjectile *p=&c->projectiles[i];
        const ArenaMoveVisual *visual=ArenaPresentation_Move(p->move);
        unsigned family=visual->family;
        if(!p->life||visual->flags&ARENA_PRESENT_NONE)continue;
        tx=ScreenX(r,p->x);ty=ScreenY(r,p->y-12*256);
        if(visual->flags&ARENA_PRESENT_SWIFT){SwiftStar(r,tx,ty,c->frame+i);continue;}
        if(ArenaPresentation_Oriented(family)){
            unsigned direction=p->vx>0?(p->vy>0?COMBAT_SE:p->vy<0?COMBAT_NE:COMBAT_E):
                p->vx<0?(p->vy>0?COMBAT_SW:p->vy<0?COMBAT_NW:COMBAT_W):
                p->vy<0?COMBAT_N:COMBAT_S;
            unsigned tile=EffectTile(r,family,c->frame);
            if(r->oamCount<120&&tx>=-32&&tx<=287&&ty>=-32&&ty<=223)
                G2_SetOBJAttr(&r->oam[r->oamCount++],tx-32,ty-32,1,GX_OAM_MODE_NORMAL,FALSE,
                    GX_OAM_EFFECT_AFFINE_DOUBLE,GX_OAM_SHAPE_32x32,GX_OAM_COLORMODE_16,
                    tile,12,13+direction);
        }else ExtraEffect(r,tx,ty,family,c->frame);
    }
    for(i=0;i<COMBAT_BEAM_CLASHES;i++)if(c->beamClashes[i].phase){
        const CombatBeamClash *clash=&c->beamClashes[i];
        unsigned size=clash->phase==COMBAT_CLASH_PRESSURE?24+clash->age/12:34+clash->age;
        ScaledExtra(r,ScreenX(r,clash->x),ScreenY(r,clash->y-12*256),ARENA_EXTRA_CLASH,
            clash->phase==COMBAT_CLASH_PRESSURE?c->frame:clash->age*3,size,21+i);
    }
    for(i=0;i<COMBAT_EFFECTS;i++){
        const CombatEffect *e=&c->effects[i];unsigned age,frame;
        if(!e->life)continue;age=e->maxLife-e->life;tx=ScreenX(r,e->x);ty=ScreenY(r,e->y);
        /* RING is simulation windup/release bookkeeping, not a confirmed
         * contact. Showing it as HIT made attacks appear to land early. */
        if(e->kind==COMBAT_RING)continue;
        if(e->kind==COMBAT_DASH_TRAIL){
            DashStreak(r,tx,ty-4,e->direction,age);
        }else if(e->kind==COMBAT_SPARK||e->kind==COMBAT_TRAIL){
            if(e->life>3)ContactGlint(r,tx,ty);
        }else if(e->kind==COMBAT_CONTACT){
            if(age<8){
                const CombatMoveInfo *move=Combat_GetMoveInfo(e->move);
                ExtraEffect(r,tx,ty-12,ARENA_EXTRA_HIT,age*3);
                if(e->move&&move&&move->type!=0)
                    ExtraEffect(r,tx,ty-12,ArenaPresentation_Move(e->move)->family,age*3);
            }
        }else if(e->kind==COMBAT_BLOCK){
            int dx=sDirections[e->direction&7][0],dy=sDirections[e->direction&7][1];
            if(age<8)ExtraEffect(r,tx+dx*12/256,ty-12+dy*12/256,ARENA_EXTRA_HIT,age*3);
        }else if(e->kind==COMBAT_CLASH){
            unsigned paired=0,k;
            for(k=0;k<COMBAT_BEAM_CLASHES;k++)if(c->beamClashes[k].phase&&
                c->beamClashes[k].x-e->x<16*256&&c->beamClashes[k].x-e->x> -16*256&&
                c->beamClashes[k].y-e->y<16*256&&c->beamClashes[k].y-e->y> -16*256)paired=1;
            if(paired)continue;
            frame=Clamp(age*24/(e->maxLife?e->maxLife:1),0,23);
            ExtraEffect(r,tx,ty,ARENA_EXTRA_CLASH,frame);
        }else if(e->kind==COMBAT_IMMUNE){
            if(age<6)ContactGlint(r,tx,ty-12);
        }else if(age<8){
            ExtraEffect(r,tx,ty,ARENA_EXTRA_HIT,age*3);
        }
    }
    for(i=0;i<ARENA_FRAGMENTS;i++)if(gArenaFragments[i].life){
        const struct ArenaFragment *f=&gArenaFragments[i];
        Oam(r,ScreenX(r,f->x)-3,ScreenY(r,f->y)-f->z/256-3,GX_OAM_SHAPE_8x8,PRIMITIVE_BASE/64+8,15,0);
    }
    /* Keep palette animation consistent for all copies of a source effect. */
    MI_CpuCopy16(arena_beam_palette,&r->palettes[11*16],32);
    r->palettes[11*16+14]=0x6318;r->palettes[11*16+15]=0x7fff;
    MI_CpuCopy16(arena_polish_palette,&r->palettes[12*16],32);
    MI_CpuCopy16(arena_v096_palette,&r->palettes[13*16],32);
    if(!r->capturePhase)MI_CpuCopy16(arena_effect_palettes[32],&r->palettes[14*16],32);
    if(r->capturePhase==1){
        tx=ScreenX(r,r->aimX);ty=ScreenY(r,r->aimY);
        Reticle(r,tx,ty);
    }else if(r->capturePhase>=2){
        unsigned ball=32+(r->capturePhase==5?((r->captureAge/8)%3):0);
        tx=ScreenX(r,r->ballX);ty=ScreenY(r,r->ballY);
        if(r->capturePhase==2){int age=Clamp(r->captureAge,0,24);ty-=age*(24-age)/12;}
        MI_CpuCopy16(arena_effect_palettes[ball],&r->palettes[14*16],32);
        Oam(r,tx-16,ty-16,GX_OAM_SHAPE_32x32,EFFECT_BASE/64+ball*8,14,0);
    }
    if(!r->uiCounter||!(++r->uiCounter%6)){HUD(r,c);r->uiCounter=1;}
    DC_FlushRange(r->tiles,sizeof(r->tiles));
    if(r->liveEffectMask)DC_FlushRange(r->liveEffects,sizeof(r->liveEffects));
    DC_FlushRange(r->oam,sizeof(r->oam));DC_FlushRange(r->palettes,sizeof(r->palettes));
    r->ready=TRUE;
}

void ArenaRender_VBlank(ArenaRender *r)
{
    unsigned i;
    if(!r||!r->ready)return;
    GX_LoadOBJ(r->tiles,0,sizeof(r->tiles));GX_LoadOBJPltt(r->palettes,0,sizeof(r->palettes));GX_LoadOAM(r->oam,0,sizeof(r->oam));
    for(i=0;i<4;i++)if(r->liveEffectMask&(1u<<i))
        GX_LoadOBJ(r->liveEffects[i],BEAM_BASE+i*ARENA_BEAM_FRAME_BYTES,ARENA_BEAM_FRAME_BYTES);
    for(i=0;i<ARENA_PRESENT_STREAMED_FAMILIES;i++)if(r->polishMask&(1u<<i))
        GX_LoadOBJ(r->polishFrames[i],POLISH_BASE+i*ARENA_PRESENT_FRAME_BYTES,ARENA_PRESENT_FRAME_BYTES);
    if(r->uiDirty){
        Window_ScheduleCopyToVRAM(&r->top);Window_ScheduleCopyToVRAM(&r->bottom);Window_ScheduleCopyToVRAM(&r->ui);r->uiDirty=FALSE;
    }
    Bg_RunScheduledUpdates(r->bg);
    { MtxFx22 scale;scale._00=scale._11=FX32_ONE*256/r->zoom;scale._01=scale._10=0;
      /* Zero the hardware origin, then translate in Q8 so BG and OBJ use the
       * same camera exactly, including subpixel movement and impact zoom. */
      G2_SetBG3Affine(&scale,0,0,0,0);
      reg_G2_BG3X=r->cameraX;
      reg_G2_BG3Y=r->cameraY-VIEW_TOP*(s32)(scale._11>>4); }
    r->ready=FALSE;
}

void ArenaRender_SetMessage(ArenaRender *r,const char *message)
{
    unsigned i=0;if(!r)return;
    if((message&&!strncmp(r->message,message,sizeof(r->message)-1))||(!message&&!r->message[0]))return;
    if(message)while(message[i]&&i<sizeof(r->message)-1){r->message[i]=message[i];i++;}
    r->message[i]=0;r->uiCounter=0;
}

void ArenaRender_DeployActor(ArenaRender *r,unsigned actor)
{
    if(!r||actor>=4)return;
    r->deployAge[actor]=1;r->faintAge[actor]=0;r->previousHp[actor]=0;
    MI_CpuClear8(r->previousStages[actor],sizeof(r->previousStages[actor]));r->statEffectAge[actor]=0;
}

void ArenaRender_SetCapture(ArenaRender *r,unsigned phase,unsigned target,s32 aimX,s32 aimY,s32 ballX,s32 ballY,unsigned age)
{
    if(!r)return;r->capturePhase=phase;r->captureTarget=target;r->captureAge=age;r->aimX=aimX;r->aimY=aimY;r->ballX=ballX;r->ballY=ballY;
}

void ArenaRender_SetPartyStatus(ArenaRender *r,unsigned team,unsigned total,unsigned remaining)
{
    if(!r||team>1)return;total=Clamp(total,0,12);remaining=Clamp(remaining,0,total);
    if(r->partyTotal[team]!=total||r->partyRemaining[team]!=remaining){
        r->partyTotal[team]=(u8)total;r->partyRemaining[team]=(u8)remaining;r->uiCounter=0;
    }
}

void ArenaRender_SetActorInfo(ArenaRender *r,unsigned actor,unsigned level,u32 status)
{
    if(!r||actor>=4)return;level=Clamp(level,0,100);
    if(r->levels[actor]!=level||r->status[actor]!=status){
        r->levels[actor]=(u8)level;r->status[actor]=status;r->uiCounter=0;
    }
}

void ArenaRender_SetControlLabels(ArenaRender *r,const char *strike,const char *guard,const char *selected,const char *next,const char *cycle,const char *aim)
{
    const char *labels[6];unsigned i,j;if(!r)return;
    labels[0]=strike;labels[1]=guard;labels[2]=selected;labels[3]=next;labels[4]=cycle;labels[5]=aim;
    for(i=0;i<6;i++){for(j=0;j<7&&labels[i]&&labels[i][j];j++)r->controls[i][j]=labels[i][j];r->controls[i][j]=0;}
    r->uiCounter=0;
}

u32 ArenaRender_ResidentBytes(const ArenaRender *r){return r?r->resident:0;}

static BOOL InitBackground(ArenaRender *r,unsigned index)
{
    FSFile file;u32 size,tiles;u8 *data,*expanded;u16 *map;unsigned x,y,i;
    const char *path=index?"data/arena_bg1.bin":"data/arena_bg0.bin";
    FS_InitFile(&file);if(!FS_OpenFile(&file,path))return FALSE;
    size=FS_GetLength(&file);
    if(size<4132||size>36900){FS_CloseFile(&file);return FALSE;}
    data=Heap_Alloc(r->heapID,size);if(!data){FS_CloseFile(&file);return FALSE;}
    if(FS_ReadFile(&file,data,size)!=(s32)size){Heap_Free(data);FS_CloseFile(&file);return FALSE;}
    FS_CloseFile(&file);tiles=Read32(data);
    if(tiles>32768||size!=4132+tiles){Heap_Free(data);return FALSE;}
    expanded=Heap_Alloc(r->heapID,tiles*2);if(!expanded){Heap_Free(data);return FALSE;}
    for(i=0;i<tiles;i++){expanded[i*2]=data[4132+i]&15;expanded[i*2+1]=data[4132+i]>>4;}
    /* Extended affine BG retains all 1024 original tiles and enables a true
     * camera zoom. Four tiles of mirrored floor border surround the original
     * arena, matching the combat system's +32,+32 obstacle translation. */
    map=Bg_GetTilemapBuffer(r->bg,ARENA_BG);
    for(y=0;y<64;y++)for(x=0;x<64;x++){
        int sx=(int)x-4,sy=(int)y-4;
        if(sx<0)sx=-sx-1;else if(sx>=48)sx=95-sx;
        if(sy<0)sy=-sy-1;else if(sy>=32)sy=63-sy;
        sx=Clamp(sx,0,47);sy=Clamp(sy,0,31);
        map[y*64+x]=Read16(data+36+((sx/32)*1024+sy*32+sx%32)*2);
    }
    DC_FlushRange(data,size);GX_LoadBGPltt(data+4,0,32);
    Bg_CopyTilemapBufferToVRAM(r->bg,ARENA_BG);
    Bg_LoadTiles(r->bg,ARENA_BG,expanded,tiles*2,0);
    Heap_Free(expanded);Heap_Free(data);return TRUE;
}

ArenaRender *ArenaRender_New(enum HeapID heapID,unsigned background)
{
    ArenaRender *r;unsigned i,x,y;
    GXBanks banks={GX_VRAM_BG_128_A,GX_VRAM_BGEXTPLTT_NONE,GX_VRAM_SUB_BG_128_C,GX_VRAM_SUB_BGEXTPLTT_NONE,GX_VRAM_OBJ_64_E,GX_VRAM_OBJEXTPLTT_NONE,GX_VRAM_SUB_OBJ_16_I,GX_VRAM_SUB_OBJEXTPLTT_NONE,GX_VRAM_TEX_NONE,GX_VRAM_TEXPLTT_NONE};
    GraphicsModes modes={GX_DISPMODE_GRAPHICS,GX_BGMODE_3,GX_BGMODE_0,GX_BG0_AS_2D};
    BgTemplate arena={0,0,8192,0,BG_SCREEN_SIZE_512x512,BG_COLOR_MODE_8BPP,GX_BG_SCRBASE_0xc000,GX_BG_CHARBASE_0x00000,GX_BG_EXTPLTT_01,3,0,FALSE};
    BgTemplate top={0,0,2048,0,BG_SCREEN_SIZE_256x256,BG_COLOR_MODE_4BPP,GX_BG_SCRBASE_0xf000,GX_BG_CHARBASE_0x14000,GX_BG_EXTPLTT_01,0,0,FALSE};
    BgTemplate sub={0,0,2048,0,BG_SCREEN_SIZE_256x256,BG_COLOR_MODE_4BPP,GX_BG_SCRBASE_0xf800,GX_BG_CHARBASE_0x08000,GX_BG_EXTPLTT_01,0,0,FALSE};
    BgTemplate art={0,0,2048,0,BG_SCREEN_SIZE_256x256,BG_COLOR_MODE_4BPP,GX_BG_SCRBASE_0xf000,GX_BG_CHARBASE_0x00000,GX_BG_EXTPLTT_01,1,0,FALSE};
    static const u16 uiPalette[16]={0,0x18c6,0x6318,0x2529,0x7fff,0x56b5,0x3def,0x2328,0x03ff,0x019f,0x7e60,0x7b94,0x67bb,0x4e73,0x77bd,0x7fff};
    r=Heap_Alloc(heapID,sizeof(*r));if(!r)return NULL;MI_CpuClear8(r,sizeof(*r));r->heapID=heapID;r->resident=sizeof(*r);r->captureTarget=4;r->zoom=256;
    ArenaRender_SetControlLabels(r,"Y","B","A","X","L","SELECT");
    r->oldDisplay=GX_GetDispSelect();r->oldWhichScreen=gSystem.whichScreenIs3D;
    DisableHBlank();GXLayers_DisableEngineALayers();GXLayers_DisableEngineBLayers();GXLayers_SetBanks(&banks);SetAllGraphicsModes(&modes);GX_SetBGScrOffset(GX_BGSCROFFSET_0x10000);
    GX_SetDispSelect(GX_DISP_SELECT_MAIN_SUB);gSystem.whichScreenIs3D=0;
    MI_CpuClear32((void *)HW_BG_VRAM,128*1024);MI_CpuClear32((void *)HW_DB_BG_VRAM,128*1024);MI_CpuClear32((void *)HW_OBJ_VRAM,64*1024);
    GX_SetOBJVRamModeChar(GX_OBJVRAMMODE_CHAR_1D_64K);G2_BlendNone();G2S_BlendNone();GX_SetVisibleWnd(GX_WNDMASK_NONE);GXS_SetVisibleWnd(GX_WNDMASK_NONE);
    r->bg=BgConfig_New(heapID);if(!r->bg){ArenaRender_Free(r);return NULL;}
    Bg_InitFromTemplate(r->bg,ARENA_BG,&arena,BG_TYPE_STATIC_WITH_AFFINE);Bg_InitFromTemplate(r->bg,TOP_BG,&top,BG_TYPE_STATIC);Bg_InitFromTemplate(r->bg,UI_BG,&sub,BG_TYPE_STATIC);Bg_InitFromTemplate(r->bg,UI_ART_BG,&art,BG_TYPE_STATIC);r->bgCreated=TRUE;
    MI_CpuCopy16(arena_battle_ui_map,Bg_GetTilemapBuffer(r->bg,UI_ART_BG),sizeof(arena_battle_ui_map));
    Bg_CopyTilemapBufferToVRAM(r->bg,UI_ART_BG);
    Bg_LoadTiles(r->bg,UI_ART_BG,arena_battle_ui_tiles,sizeof(arena_battle_ui_tiles),0);
    DC_FlushRange(arena_battle_ui_palette,sizeof(arena_battle_ui_palette));GXS_LoadBGPltt(arena_battle_ui_palette,32,sizeof(arena_battle_ui_palette));
    if(!InitBackground(r,background)){ArenaRender_Free(r);return NULL;}
    Window_Add(r->bg,&r->top,TOP_BG,0,0,32,2,1,1);Window_Add(r->bg,&r->bottom,TOP_BG,0,22,32,2,1,65);Window_Add(r->bg,&r->ui,UI_BG,0,0,32,24,0,1);r->windowsCreated=TRUE;
    r->resident+=8192+2048+2048+2048+2048+2048+24576+sizeof(BgConfig);
    Window_FillTilemap(&r->top,15);Window_FillTilemap(&r->bottom,15);Window_FillTilemap(&r->ui,0);
    Window_PutToTilemap(&r->top);Window_PutToTilemap(&r->bottom);Window_PutToTilemap(&r->ui);
    DC_FlushRange(uiPalette,sizeof(uiPalette));GX_LoadBGPltt(uiPalette,32,32);GXS_LoadBGPltt(uiPalette,0,32);
    /* Cache only the 96 native Latin glyphs we display, not a full font ROM.
     * This makes combat/HUD frames independent of card I/O. */
    Font_InitManager(FONT_SUBSCREEN,heapID);r->fontCreated=TRUE;Text_GenerateFontHalfRowLookupTable(1,0,2);
    for(i=0;i<GLYPHS;i++)r->glyphs[i].glyph=*Font_TryLoadGlyph(FONT_SUBSCREEN,Code(i+32));
    Font_Free(FONT_SUBSCREEN);r->fontCreated=FALSE;
    for(i=0;i<7;i++)MI_CpuCopy16(arena_effect_palettes[i],&r->palettes[(4+i)*16],32);
    MI_CpuCopy16(arena_beam_palette,&r->palettes[11*16],32);MI_CpuCopy16(arena_polish_palette,&r->palettes[12*16],32);MI_CpuCopy16(arena_effect_palettes[31],&r->palettes[13*16],32);MI_CpuCopy16(arena_effect_palettes[32],&r->palettes[14*16],32);
    r->palettes[15*16+1]=0x7fff;r->palettes[15*16+2]=0x0421;r->palettes[15*16+3]=0x03ff;r->palettes[15*16+4]=22+(19<<5)+(12<<10);
    DC_FlushRange(arena_effect_tiles,EFFECT_BYTES);GX_LoadOBJ(arena_effect_tiles,EFFECT_BASE,EFFECT_BYTES);
    DC_FlushRange(arena_v096_tiles,sizeof(arena_v096_tiles));GX_LoadOBJ(arena_v096_tiles,EXTRA_BASE,sizeof(arena_v096_tiles));
    DC_FlushRange(arena_polish_tiles,sizeof(arena_polish_tiles));
    DC_FlushRange(arena_swift_tiles,sizeof(arena_swift_tiles));GX_LoadOBJ(arena_swift_tiles,SWIFT_BASE,sizeof(arena_swift_tiles));
    DC_FlushRange(arena_contact_glint,sizeof(arena_contact_glint));GX_LoadOBJ(arena_contact_glint,CONTACT_GLINT_BASE,sizeof(arena_contact_glint));
    DC_FlushRange(arena_wind_tiles,sizeof(arena_wind_tiles));GX_LoadOBJ(arena_wind_tiles,WIND_BASE,sizeof(arena_wind_tiles));
    MI_CpuCopy16(arena_wind_palette_tail,&r->palettes[15*16+13],sizeof(arena_wind_palette_tail));
    MI_CpuClear8(r->primitives,sizeof(r->primitives));
    {
        static const u16 colors[8]={0x019f,0x7e20,0x1f48,0x03ff,0x6c7a,0x7ff0,0x2294,0x6318};
        for(i=0;i<8;i++)r->palettes[15*16+5+i]=colors[i];
    }
    for(i=0;i<19;i++)for(y=0;y<8;y++)for(x=0;x<8;x++){
        unsigned color=0;
        if(i>=17){
            int dx=(int)x*2-7,dy=(int)y*2-7;
            if(i==17&&dx*dx+dy*dy<=45)color=2;
        }else if(i>=9){
            int dx=(int)x*2-7,dy=(int)y*2-7,d=dx*dx+dy*dy;
            if(d<=40)color=d>24?2:5+i-9;
            if(x>=2&&x<=3&&y>=2&&y<=3)color=1;
        }else if(i==8){if(x>=3&&x<=4&&y>=3&&y<=4)color=4;}
        else if(i<4){unsigned xx=(i&1)?7-x:x,yy=(i&2)?7-y:y;if((xx<2&&yy<7)||(yy<2&&xx<7))color=1;}
        else {unsigned xx=x,yy=y;if(i==5)yy=7-y;if(i==6){xx=y;yy=x;}if(i==7){xx=y;yy=7-x;}if(yy>=1&&yy<=6&&xx>=3-(yy/2)&&xx<=4+(yy/2))color=3;}
        r->primitives[i][y*4+x/2]|=(u8)(color<<((x&1)*4));
    }
    MI_CpuClear8(r->primitives[17],128);
    for(y=0;y<16;y++)for(x=0;x<16;x++){
        int dx=(int)x*2-15,dy=(int)y*2-15;
        if(dx*dx+dy*dy<=190){
            unsigned byte=(y/8*2+x/8)*32+(y&7)*4+(x&7)/2;
            ((u8 *)r->primitives[17])[byte]|=2u<<((x&1)*4);
        }
    }
    DC_FlushRange(r->primitives,sizeof(r->primitives));GX_LoadOBJ(r->primitives,PRIMITIVE_BASE,sizeof(r->primitives));
    for(i=0;i<2;i++)for(y=0;y<8;y++)for(x=0;x<8;x++){
        unsigned color=0;int dx=(int)x*2-7,dy=(int)y*2-7;
        if(dx*dx+dy*dy<=50){color=y<4?(i?6:9):4;if(dx*dx+dy*dy>=30||y==3||y==4)color=3;if(x>=3&&x<=4&&y>=3&&y<=4)color=i?6:4;}
        r->partyIcons[i][y*4+x/2]|=color<<((x&1)*4);
    }
    for(i=0;i<128;i++)G2_SetOBJAttr(&r->oam[i],0,0,0,GX_OAM_MODE_NORMAL,FALSE,GX_OAM_EFFECT_NODISPLAY,GX_OAM_SHAPE_8x8,GX_OAM_COLORMODE_16,0,0,0);
    DC_FlushRange(r->oam,sizeof(r->oam));GX_LoadOAM(r->oam,0,sizeof(r->oam));GXS_LoadOAM(r->oam,0,sizeof(r->oam));
    GXLayers_EngineASetLayers(GX_PLANEMASK_BG0|GX_PLANEMASK_BG3|GX_PLANEMASK_OBJ);GXLayers_EngineBSetLayers(GX_PLANEMASK_BG0|GX_PLANEMASK_BG1);
    ResetScreenMasterBrightness(DS_SCREEN_MAIN);ResetScreenMasterBrightness(DS_SCREEN_SUB);GXLayers_TurnBothDispOn();return r;
}

void ArenaRender_Free(ArenaRender *r)
{
    unsigned i;if(!r)return;r->ready=FALSE;
    GXLayers_DisableEngineALayers();GXLayers_DisableEngineBLayers();
    for(i=0;i<4;i++)if(r->pools[i].storage)Heap_Free(r->pools[i].storage);
    if(r->fontCreated)Font_Free(FONT_SUBSCREEN);
    if(r->windowsCreated){Window_Remove(&r->top);Window_Remove(&r->bottom);Window_Remove(&r->ui);}
    if(r->bg){if(r->bgCreated){Bg_FreeTilemapBuffer(r->bg,ARENA_BG);Bg_FreeTilemapBuffer(r->bg,TOP_BG);Bg_FreeTilemapBuffer(r->bg,UI_BG);Bg_FreeTilemapBuffer(r->bg,UI_ART_BG);}Heap_Free(r->bg);}
    GX_SetDispSelect(r->oldDisplay);gSystem.whichScreenIs3D=r->oldWhichScreen;Heap_Free(r);
}
