#include "arena/presentation.h"
#include "presentation_moves.inc"

const ArenaMoveVisual *ArenaPresentation_Move(unsigned move)
{
    return &arena_move_visuals[move < ARENA_PRESENT_MOVE_COUNT ? move : 0];
}

unsigned ArenaPresentation_TypeFamily(unsigned type)
{
    static const uint8_t families[] = {
        ARENA_PRESENT_ENERGY, ARENA_PRESENT_FIGHTING, ARENA_PRESENT_WIND,
        ARENA_PRESENT_POISON, ARENA_PRESENT_GROUND, ARENA_PRESENT_ROCK,
        ARENA_PRESENT_BUG, ARENA_PRESENT_SHADOW, ARENA_PRESENT_STEEL,
        ARENA_PRESENT_ENERGY, ARENA_PRESENT_FIRE, ARENA_PRESENT_WATER,
        ARENA_PRESENT_LEAF, ARENA_PRESENT_BOLT, ARENA_PRESENT_PSYCHIC,
        ARENA_PRESENT_ICE, ARENA_PRESENT_DRAGON, ARENA_PRESENT_SHADOW
    };
    return type < sizeof(families) ? families[type] : ARENA_PRESENT_ENERGY;
}

unsigned ArenaPresentation_Frame(unsigned clock) { return (clock / 3) & 3; }

int ArenaPresentation_Oriented(unsigned family)
{
    return family == ARENA_PRESENT_GROUND || family == ARENA_PRESENT_WIND
        || family == ARENA_PRESENT_BOLT;
}
