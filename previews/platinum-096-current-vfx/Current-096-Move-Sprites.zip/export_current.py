#!/usr/bin/env python3
"""Decode the current game's existing sprite data for inspection; no ROM build."""
from pathlib import Path
import hashlib
import json
import re
from PIL import Image, ImageDraw, ImageFont

ROOT=Path('/workspace/platinum-port/pokeplatinum')
OUT=Path(__file__).resolve().parent
FRAMES=OUT/'transparent-frames'
FRAMES.mkdir(exist_ok=True)

def array(path,name):
    text=path.read_text()
    m=re.search(r'\b'+re.escape(name)+r'\s*(?:\[[^\]]*\])+\s*(?:ATTRIBUTE_ALIGN\(4\)\s*)?=\s*\{',text)
    if not m: raise ValueError(name)
    start=m.end();depth=1;end=start
    while depth:
        if text[end]=='{':depth+=1
        elif text[end]=='}':depth-=1
        end+=1
    body=re.sub(r'/\*.*?\*/|//[^\n]*','',text[start:end-1],flags=re.S)
    return [int(x,0) for x in re.findall(r'0x[0-9a-fA-F]+|\b[0-9]+\b',body)]

def palette(words):
    def channel(value): return (value<<3)|(value>>2)
    return [(channel(w&31),channel((w>>5)&31),channel((w>>10)&31),255 if i else 0)
            for i,w in enumerate(words)]

def decode(data,w,h,colors,chunk=None):
    result=Image.new('RGBA',(w,h))
    for y in range(h):
        for x in range(w):
            if chunk:
                width=chunk;xx=x%chunk;base=(x//chunk)*chunk*h//2
            else:width=w;xx=x;base=0
            off=base+((y//8)*(width//8)+xx//8)*32+(y%8)*4+(xx%8)//2
            value=(data[off]>>((xx&1)*4))&15
            result.putpixel((x,y),colors[value])
    return result

beam_path=ROOT/'src/arena/beam_effects.c'
beam=bytes(array(beam_path,'arena_beam_tiles'))
beam_words=array(beam_path,'arena_beam_palette');beam_words[14:16]=[0x6318,0x7fff]
bp=palette(beam_words)
manifest=json.loads((ROOT/'res/arena/beam-effects/manifest.json').read_text())
assert len(beam)==32768 and hashlib.sha256(beam).hexdigest()==manifest['tile_sha256']

atlas_path=ROOT/'src/arena/v096_effect_art.inc'
atlas=bytes(array(atlas_path,'arena_v096_tiles'))
ap=palette(array(atlas_path,'arena_v096_palette'))
am=json.loads((ROOT/'res/arena/v096-effects/manifest.json').read_text())
assert len(atlas)==28672 and hashlib.sha256(atlas).hexdigest()==am['tile_sha256']

primitive_words=[0]*16
primitive_words[1:5]=[0x7fff,0x0421,0x03ff,22+(19<<5)+(12<<10)]
primitive_words[5:13]=[0x019f,0x7e20,0x1f48,0x03ff,0x6c7a,0x7ff0,0x2294,0x6318]
primitive_words[13:16]=array(atlas_path,'arena_wind_palette_tail')
pp=palette(primitive_words)
groups={}
for i,key in enumerate(['flame_medium','flame_thin','water_beam','ice_beam']):
    groups[key]=[decode(beam[(i*4+f)*2048:(i*4+f+1)*2048],128,32,bp,32) for f in range(4)]
neutral=[]
for f in range(4):
    data=beam[(2*4+f)*2048:(2*4+f+1)*2048]
    remapped=bytes((0 if not (v&15) else 14 if (v&15)<4 else 15)
                  |((0 if not(v>>4) else 14 if (v>>4)<4 else 15)<<4) for v in data)
    neutral.append(decode(remapped,128,32,bp,32))
groups['neutral_beam']=neutral
for family in am['family_map']:
    groups[family['name'].lower()]=[decode(atlas[(family['atlas_start']+f)*512:(family['atlas_start']+f+1)*512],32,32,ap)
                                  for f in range(family['frames'])]
swift=bytes(array(ROOT/'src/arena/swift_art.inc','arena_swift_tiles'))
groups['swift']=[decode(swift[f*128:(f+1)*128],16,16,pp) for f in range(2)]
wind=bytes(array(atlas_path,'arena_wind_tiles'))
groups['dash']=[decode(wind[f*256:(f+1)*256],32,16,pp) for f in range(2)]
orb=Image.new('RGBA',(8,8))
for y in range(8):
    for x in range(8):
        d=(x*2-7)**2+(y*2-7)**2
        color=(2 if d>24 else 12) if d<=40 else 0
        if 2<=x<=3 and 2<=y<=3:color=1
        orb.putpixel((x,y),pp[color])
groups['orb']=[orb]
for key,frames in groups.items():
    folder=FRAMES/key;folder.mkdir(exist_ok=True)
    for i,frame in enumerate(frames):frame.save(folder/f'{i+1:02}.png')

font_root=Path('/usr/share/fonts/truetype/dejavu')
def font(n,bold=False):
    path=font_root/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')
    return ImageFont.truetype(str(path),n) if path.exists() else ImageFont.load_default()
BG=(15,23,34);PANEL=(23,35,49);INK=(232,240,247);MUTED=(165,185,202);ACCENT=(125,211,252)

def checker(w,h):
    im=Image.new('RGB',(w,h),PANEL);d=ImageDraw.Draw(im)
    for y in range(0,h,12):
        for x in range(0,w,12):
            if (x//12+y//12)&1:d.rectangle((x,y,x+11,y+11),fill=(29,43,58))
    return im

beam_rows=[
 ('flame_medium','Flamethrower / Fire Blast','Sustained flame body - shared with Sacred Fire'),
 ('flame_thin','Flamethrower - thin phase','Startup and ending flame strip'),
 ('water_beam','Hydro Pump - Blastoise','Current continuous water stream'),
 ('ice_beam','Ice Beam / Aurora Beam','Current continuous ice stream'),
 ('neutral_beam','Hyper Beam / Psybeam / Solar Beam','Shared water geometry recoloured gray/white')]
W=1120;ROW=116
sheet=Image.new('RGB',(W,100+len(beam_rows)*ROW+30),BG);d=ImageDraw.Draw(sheet)
d.text((24,14),'CURRENT BEAM SPRITES - PLATINUM ARENA 0.9.6',font=font(23,True),fill=INK)
d.text((24,48),'Four decoded frames per row. Original pixels enlarged 2x; not a gameplay capture.',font=font(16),fill=MUTED)
for n,(key,label,note) in enumerate(beam_rows):
    y=93+n*ROW
    d.text((24,y),label,font=font(19,True),fill=ACCENT)
    d.text((520,y+2),note,font=font(14),fill=MUTED)
    for i,frame in enumerate(groups[key]):
        tile=checker(256,64);tile.paste(frame.resize((256,64),Image.Resampling.NEAREST),(0,0),frame.resize((256,64),Image.Resampling.NEAREST))
        sheet.paste(tile,(24+i*272,y+29))
sheet.save(OUT/'current-beam-sprites.png')

anim=[]
for step in range(4):
    im=Image.new('RGB',(880,88+len(beam_rows)*115),BG);d=ImageDraw.Draw(im)
    d.text((22,14),'CURRENT BEAM SPRITE LOOPS',font=font(24,True),fill=INK)
    d.text((22,49),'Existing art only - fixed preview length, no game changes',font=font(15),fill=MUTED)
    for n,(key,label,note) in enumerate(beam_rows):
        y=89+n*115
        d.text((22,y+16),label,font=font(17,True),fill=ACCENT)
        # Keep long notes readable without covering the stream.
        text={'flame_medium':'Flamethrower / Fire Blast / Sacred Fire',
              'flame_thin':'Flame startup / ending phase','water_beam':'Blastoise water beam',
              'ice_beam':'Ice Beam / Aurora Beam','neutral_beam':'Shared neutral fallback'}[key]
        d.text((22,y+43),text,font=font(13),fill=MUTED)
        tile=checker(384,96);frame=groups[key][step].resize((384,96),Image.Resampling.NEAREST)
        tile.paste(frame,(0,0),frame);im.paste(tile,(470,y))
    anim.append(im)
anim[0].save(OUT/'current-beams.gif',save_all=True,append_images=anim[1:],duration=[70,60,70,70],loop=0,disposal=2)

rows=[
 ('water','Water projectiles','Water Gun / Water Pulse / Surf / Bubble Beam'),
 ('fire','Fire projectiles','Ember / Fire Spin / Blast Burn'),
 ('electric','Electric effect','Thunder Wave / Discharge / paralysis feedback'),
 ('ice','Ice projectiles','Blizzard / Icy Wind / Ice Shard'),
 ('leaf','Grass projectiles','Absorb / Mega Drain / Energy Ball'),
 ('psychic','Psychic projectiles','Confusion / Psychic / Psycho Cut'),
 ('shadow','Shadow projectiles','Night Shade / Dark Pulse / Ominous Wind'),
 ('slash','Slash follow-through','Scratch / Cut / Slash / Dragon Claw'),
 ('hit','Contact impact','Tackle / Pound / Quick Attack - actual contact'),
 ('swift','Shared star effect','Swift / Thunderbolt / Thunder / Dragon Pulse'),
 ('buff','Stat increase','Swords Dance / Agility / Calm Mind'),
 ('debuff','Stat decrease','Growl / Tail Whip / Sand Attack'),
 ('guard','Guard / Protect','Held shield: startup frames 42/43, held frame 44'),
 ('clash','Clash burst','Shared collision / beam clash feedback'),
 ('dash','Wind dash','Shared directional dash - 2 frames'),
 ('orb','Generic orb fallback','Remaining unassigned projectile types - shared')]
W=1024;RH=108
im=Image.new('RGB',(W,94+len(rows)*RH+28),BG);d=ImageDraw.Draw(im)
d.text((24,14),'OTHER CURRENT MOVE SPRITES',font=font(24,True),fill=INK)
d.text((24,49),'Actual shared sprite families. Names are examples from the runtime mapping.',font=font(16),fill=MUTED)
for n,(key,label,note) in enumerate(rows):
    y=90+n*RH
    d.rounded_rectangle((16,y,W-16,y+RH-5),8,fill=PANEL)
    d.text((28,y+18),label,font=font(20,True),fill=ACCENT)
    # Wrap examples to the left label column.
    words=note.split();lines=['']
    for word in words:
        candidate=(lines[-1]+' '+word).strip()
        if d.textlength(candidate,font=font(14))>445:lines.append(word)
        else:lines[-1]=candidate
    for j,line in enumerate(lines):d.text((28,y+49+j*19),line,font=font(14),fill=MUTED)
    frames=groups[key]
    indices=[2,3,4] if key=='guard' else list(range(min(len(frames),4)))
    for col,idx in enumerate(indices):
        frame=frames[idx];scale=3 if frame.width==32 else 5 if frame.width==16 else 8
        enlarged=frame.resize((frame.width*scale,frame.height*scale),Image.Resampling.NEAREST)
        tile=checker(112,96);tile.paste(enlarged,((112-enlarged.width)//2,(96-enlarged.height)//2),enlarged)
        im.paste(tile,(524+col*118,y+3))
im.save(OUT/'current-move-sprites.png')
(OUT/'PREVIEW-NOTES.txt').write_text('Existing 0.9.6 sprite data decoded directly from C tile arrays.\nNo source/art/gameplay changes and no ROM build.\nBeam animation loops show fixed 128px native lengths; runtime rotates/scales/anchors them.\nShared families are not unique art per listed move. Full runtime mapping is included separately.\n')
print(json.dumps({'output':str(OUT),'sprite_groups':len(groups),'transparent_frames':sum(map(len,groups.values())),
                  'beam_data_sha256':hashlib.sha256(beam).hexdigest(),
                  'atlas_data_sha256':hashlib.sha256(atlas).hexdigest()},indent=2))
